
/* ---------- open issues (team tracker, same style as the knowledge base) ---------- */
const OS={sel:null,q:'',status:'Open',prio:'All'};
const OI_TYPES=['Task','Problem','Request','Improvement'],OI_STATUS=['New','In progress','Waiting','Resolved','Closed'],OI_PRIO=['Low','Medium','High','Critical'],OC_TYPES=['Comment','Update','Question','Resolution'];
let OIDIR=null;
const oiDone=r=>r.Status==='Resolved'||r.Status==='Closed';
const oiPrioN=p=>OI_PRIO.indexOf(p)<0?-1:OI_PRIO.indexOf(p);
const oiPrCls=p=>p==='Critical'?'b-bad':p==='High'?'b-warn':p==='Medium'?'b-info':'b-off';
const oiStCls=s=>s==='Resolved'||s==='Closed'?'b-ok':s==='In progress'?'b-info':s==='Waiting'?'b-warn':'b-off';
function oiDue(r){if(oiDone(r))return null;const d=daysTo(r['Due date']);if(d===null)return null;return d<0?['b-bad','Overdue '+(-d)+' d']:d<=3?['b-warn','Due in '+d+' d']:['b-off','Due '+r['Due date']]}
function oiRows(){
const q=OS.q.trim().toLowerCase();
return DB.OpenIssues.filter(r=>(OS.status==='All'?true:OS.status==='Open'?!oiDone(r):r.Status===OS.status)&&(OS.prio==='All'||r.Priority===OS.prio)&&(!q||[r.ID,r.Title,r.Description,r.Resolution,r.Assignee,r['Related item'],r.Category].join(' ').toLowerCase().indexOf(q)>=0))
.sort((a,b)=>(oiDone(a)-oiDone(b))||(oiPrioN(b.Priority)-oiPrioN(a.Priority))||String(a['Due date']||'9').localeCompare(String(b['Due date']||'9')));
}
function oiList(){
const rows=oiRows();
return rows.length?rows.map(r=>{const n=DB.OIComments.filter(c=>c.Issue===r.ID).length,du=oiDue(r);
return '<button class="btn" style="width:100%;flex-direction:column;align-items:stretch;gap:6px;height:auto;padding:10px 12px;text-align:left;white-space:normal;margin-bottom:6px;'+(r.ID===OS.sel?'border-color:var(--accent);background:var(--accent-soft)':'')+'" data-act="oisel" data-id="'+esc(r.ID)+'"><span><b>'+esc(r.Title)+'</b></span><span style="display:flex;flex-wrap:wrap;gap:6px;align-items:center"><span class="mono note">'+esc(r.ID)+'</span><span class="badge '+oiPrCls(r.Priority)+'">'+esc(r.Priority)+'</span><span class="badge '+oiStCls(r.Status)+'">'+esc(r.Status)+'</span>'+(du&&du[0]!=='b-off'?'<span class="badge '+du[0]+'">'+esc(du[1])+'</span>':'')+(n?'<span class="note">'+n+' comment'+(n>1?'s':'')+'</span>':'')+'</span></button>'}).join(''):'<div class="empty">No issue matches. Change the filters or raise a new one.</div>';
}
function oiDetail(){
const r=DB.OpenIssues.find(x=>x.ID===OS.sel);
if(!r)return '<div class="empty">Select an issue, or raise a new one.</div>';
const idx=DB.OpenIssues.indexOf(r),cm=DB.OIComments.filter(c=>c.Issue===r.ID),fl=kbFiles(r),du=oiDue(r),kb=DB.KB.find(x=>x.ID===String(r['Related KB']||'').trim());
const meta=[['Type',r.Type],['Category',r.Category],['Assignee',r.Assignee],['Raised by',r['Raised by']],['Due date',r['Due date']],['Related item',r['Related item']],['Created',r.Created],['Resolved',r.Resolved]].map(x=>'<label>'+x[0]+'<span style="color:var(--ink);font-size:14px">'+esc(x[1]||'—')+'</span></label>').join('');
const blk=(t,v)=>v?'<h3 style="font-size:14px;margin:16px 0 4px">'+t+'</h3><div style="white-space:pre-wrap">'+esc(v)+'</div>':'';
return '<div class="tools" style="justify-content:space-between"><div><span class="mono note">'+esc(r.ID)+'</span><h2 style="font-size:19px;margin:2px 0 0">'+esc(r.Title)+'</h2><div class="tools" style="margin-top:6px"><span class="badge '+oiPrCls(r.Priority)+'">'+esc(r.Priority)+'</span>'+(du?'<span class="badge '+du[0]+'">'+esc(du[1])+'</span>':'')+'</div></div><div class="tools"><button class="btn s" data-act="edit" data-sheet="OpenIssues" data-i="'+idx+'">Edit</button></div></div>'
+'<div class="fgrid" style="margin:14px 0"><label for="oi-status">Status<select class="inp" id="oi-status" data-act="oistatus">'+OI_STATUS.map(s=>'<option'+(r.Status===s?' selected':'')+'>'+s+'</option>').join('')+'</select></label>'+meta+'</div>'
+blk('Description',r.Description)
+(r.Resolution?'<div class="card" style="margin-top:16px;background:var(--surface2)"><h3 style="font-size:14px;margin:0 0 4px">Resolution</h3><div style="white-space:pre-wrap">'+esc(r.Resolution)+'</div><div class="tools" style="margin-top:8px"><button class="btn s" data-act="oikb">Create knowledge base article from this</button></div></div>':'<div class="note" style="margin-top:16px">No resolution yet. Add one in Edit, or use “Use as resolution” on a comment below.</div>')
+(r['Related KB']?'<div class="tools" style="margin-top:12px"><span class="note">Related article:</span>'+(kb?'<a class="lnk" href="#kb" data-act="oigokb" data-id="'+esc(kb.ID)+'">'+esc(kb.ID)+' · '+esc(kb.Title)+'</a>':'<span class="badge b-warn">'+esc(r['Related KB'])+' not found</span>')+'</div>':'')
+'<h3 style="font-size:14px;margin:18px 0 6px">Attachments</h3>'
+(fl.length?fl.map(n=>'<div class="tools" style="justify-content:space-between;border-top:1px solid var(--line2);padding:6px 0"><a class="lnk" href="Stuff/OpenIssues/'+encodeURIComponent(r.ID)+'/'+encodeURIComponent(n)+'" target="_blank" rel="noopener">'+esc(n)+' ↗</a><button class="btn s d" data-act="oifdel" data-name="'+esc(n)+'">Remove</button></div>').join(''):'<div class="note">No files attached.</div>')
+'<div class="tools" style="margin-top:8px"><label class="btn" for="oi-file" style="cursor:pointer">+ Attach file<input id="oi-file" type="file" multiple hidden></label>'+(!OIDIR?rootBtn():'')+'<span class="note">'+(OIDIR?'Connected: files are written to the folder.':'Files go to Stuff/OpenIssues/'+esc(r.ID)+'/ . Not connected, so only the name is recorded: copy the file there yourself.')+'</span></div>'
+'<h3 style="font-size:14px;margin:18px 0 4px">Activity</h3>'
+(cm.length?cm.map(c=>'<div class="cmt"><div><b>'+esc(c.Author)+'</b> <span class="badge '+cmCls(c.Type==='Update'?'Comment':c.Type)+'">'+esc(c.Type)+'</span> <small>'+esc(c.Time)+'</small></div><div style="white-space:pre-wrap">'+esc(c.Text)+'</div>'+(c.Type==='Resolution'||c.Type==='Comment'?'<div style="margin-top:6px"><button class="btn s" data-act="oires" data-ci="'+DB.OIComments.indexOf(c)+'">Use as resolution</button></div>':'')+'</div>').join(''):'<div class="note">No activity yet.</div>')
+'<div class="cmt"><label class="note" for="oc-text">Add a comment</label><textarea class="inp" id="oc-text" rows="3" placeholder="Progress, question, or the working resolution"></textarea><div class="tools"><select class="inp" id="oc-type" style="width:auto" aria-label="Comment type">'+OC_TYPES.map(t=>'<option>'+t+'</option>').join('')+'</select><select class="inp" id="oc-author" style="width:auto" aria-label="Comment author">'+DB.Operators.filter(o=>o.Active!=='No').map(o=>'<option>'+esc(o.Name)+'</option>').concat(['<option>Team</option>']).join('')+'</select><button class="btn p" data-act="oicomment">Add comment</button></div></div>';
}
function oiView(){
if(!OS.sel||!DB.OpenIssues.some(r=>r.ID===OS.sel))OS.sel=(oiRows()[0]||DB.OpenIssues[0]||{}).ID||null;
const op=DB.OpenIssues.filter(r=>!oiDone(r)),hi=op.filter(r=>r.Priority==='High'||r.Priority==='Critical').length,od=op.filter(r=>{const d=daysTo(r['Due date']);return d!==null&&d<0}).length,un=op.filter(r=>!String(r.Assignee||'').trim()).length;
const chips=(arr,k)=>['All'].concat(arr).map(o=>'<button class="chip'+(OS[k]===o?' on':'')+'" data-act="oif" data-k="'+k+'" data-v="'+esc(o)+'">'+esc(o)+'</button>').join('');
return head('Open issues','Anything the team has to do or follow up: raise it here, comment, attach files and record the resolution. Files live in Stuff/OpenIssues/<issue ID>/.','<button class="btn" data-act="cols" data-sheet="OpenIssues">Columns</button><button class="btn p" data-act="oinew">+ Raise issue</button>')
+'<div class="kpis"><div class="kpi"><span>Open</span><b>'+op.length+'</b><small>'+DB.OpenIssues.filter(oiDone).length+' resolved or closed</small></div><div class="kpi"><span>High or critical</span><b>'+hi+'</b><small class="'+(hi?'w':'g')+'">&nbsp;</small></div><div class="kpi"><span>Overdue</span><b>'+od+'</b><small class="'+(od?'w':'g')+'">'+(od?'Past the due date':'Nothing overdue')+'</small></div><div class="kpi"><span>Unassigned</span><b>'+un+'</b><small class="'+(un?'w':'g')+'">'+(un?'Needs an owner':'All assigned')+'</small></div></div>'
+'<div class="row" style="align-items:flex-start"><section class="card" style="flex:1 1 320px;max-width:440px"><input class="inp" id="oi-q" type="search" data-act="oiq" placeholder="Search title, text, assignee" value="'+esc(OS.q)+'" aria-label="Search open issues">'+fpanel([fgrp('Status',['Open','All'].concat(OI_STATUS).map(o=>({v:o,n:o==='Open'?op.length:o==='All'?DB.OpenIssues.length:DB.OpenIssues.filter(r=>r.Status===o).length,on:OS.status===o,act:'oif',k:'status'}))),fgrp('Priority',['All'].concat(OI_PRIO).map(o=>({v:o,n:o==='All'?DB.OpenIssues.length:DB.OpenIssues.filter(r=>r.Priority===o).length,on:OS.prio===o,act:'oif',k:'prio'})))])+'<div id="oi-list" style="margin-top:12px">'+oiList()+'</div></section>'
+'<section class="card" style="flex:2 1 520px" id="oi-detail">'+oiDetail()+'</section></div>';
}
async function oiAttach(files){
const r=DB.OpenIssues.find(x=>x.ID===OS.sel);if(!r)return;let n=0;const names=kbFiles(r);
try{for(const f of files){
if(OIDIR){const d=await OIDIR.getDirectoryHandle(r.ID,{create:true}),h=await d.getFileHandle(f.name,{create:true}),w=await h.createWritable();await w.write(f);await w.close()}
if(names.indexOf(f.name)<0)names.push(f.name);n++}}catch(e){toast('Could not write the file. Check the folder permission.')}
if(n){r.Files=names.join('; ');r.Updated=ds(0);changed()}route();if(n)toast(n+(n===1?' file ':' files ')+(OIDIR?'saved to the issue folder':'recorded. Copy it into Stuff/OpenIssues/'+r.ID+'/'));
}
