
/* ---------- Microsoft failover clusters (WSFC) ---------- */
const CLS={sel:'',tab:'cluster'};
const clA=s=>DB[s]||(DB[s]=[]);
const isRdm=t=>/^RDM/.test(String(t||''));
function clusterOpts(sheet,k){
if(sheet==='DrsRules'&&k==='Host group')return dhgA().map(g=>String(g.Group));
if(sheet==='DrsHostGroups'&&k==='Cluster')return [...new Set(DB.ESXi.map(h=>String(h.Cluster||'')).filter(Boolean))].sort();
if(sheet==='DrsRules'&&k==='Cluster')return [...new Set(DB.ESXi.map(h=>String(h.Cluster||'')).filter(Boolean))].sort();
if(sheet==='Datastores'&&k==='Datastore cluster')return dscA().map(c=>String(c['Datastore cluster']));
if(k==='Remote copy group'&&(sheet==='ArrayVolumes'||sheet==='Datastores'||sheet==='ClusterDisks'))return rcgA().map(g=>String(g.Group));
if(sheet==='RemoteCopyGroups'&&(k==='Source array'||k==='Target array'))return DB.Storage.map(r=>String(r.Array));
if(sheet==='ArrayVolumes'&&(k==='Array'||k==='Replica array'))return DB.Storage.map(r=>String(r.Array));
if(sheet==='ServerMI'&&k==='Failover cluster')return clA('Clusters').map(c=>String(c.Cluster));
if((sheet==='ServerDisks'||sheet==='ServerNics')&&k==='Server')return DB.ServerMI.filter(r=>r.Status!=='Decom').map(r=>String(r.Hostname)).sort();
if(sheet==='ClusterNodes'||sheet==='ClusterRoles'||sheet==='ClusterDisks'||sheet==='ClusterResources'){
if(k==='Cluster')return clA('Clusters').map(c=>String(c.Cluster));
if(k==='Role'&&sheet==='ClusterResources')return clA('ClusterRoles').map(r=>String(r.Role));
if(k==='Node'||k==='Owner node')return DB.ServerMI.filter(r=>r.Status!=='Decom'&&!isStand(r['Cluster/Standalone'])&&(!r.OS||/windows/i.test(r.OS))).map(r=>String(r.Hostname)).sort()}
return null}
function clData(name){const n=String(name),f=s=>clA(s).map((r,i)=>({r:r,i:i})).filter(x=>x.r.Cluster===n);return{nodes:f('ClusterNodes'),roles:f('ClusterRoles'),disks:f('ClusterDisks'),res:f('ClusterResources')}}
function clNodeInfo(node){const j=srvFind(node);return j>=0?{j:j,s:DB.ServerMI[j]}:null}
function clIssues(c,d){d=d||clData(c.Cluster);const o=[],add=(sev,t)=>o.push({sev:sev,t:t});
const nn=d.nodes.length;
if(nn<2)add('high',nn?'Only one node':'No nodes');
if(nn&&!d.nodes.some(x=>x.r.Primary==='Yes'))add('high','No primary node marked');
const hosts={};
d.nodes.forEach(x=>{const ni=clNodeInfo(x.r.Node);if(!ni){add('high','Node '+x.r.Node+' is not in ServersMI');return}
if(ni.s.Platform!=='Physical'&&ni.s['ESXi host']){const h=shortN(ni.s['ESXi host']);(hosts[h]=hosts[h]||[]).push(x.r.Node)}
if(ni.s.OS&&!/windows/i.test(ni.s.OS))add('medium','Node '+x.r.Node+' is not a Windows server ('+ni.s.OS+')');
if(ni.s.Status==='Decom')add('medium','Node '+x.r.Node+' is decommissioned')});
Object.keys(hosts).forEach(h=>{if(hosts[h].length>1)add('high',hosts[h].join(' and ')+' run on the same ESXi host ('+h+')')});
const q=c['Quorum type']||'';
if(!q)add('medium','Quorum not specified');
else if(q==='None'&&nn%2===0&&nn>0)add('medium','Even number of nodes and no witness');
if(isRdm(q)||/RDM/.test(q)){if(!c['Witness LUN ID']&&!c['Witness NAA'])add('high','Witness disk is an RDM but has no LUN ID / NAA')}
if(q==='File share witness'){if(!c['Witness share path'])add('high','File share witness has no share path');if(!c['Share stored on'])add('medium','Where the witness share is stored is not recorded');
else{const sh=shortN(String(c['Share stored on']).split(/[\s(]/)[0]);if(d.nodes.some(x=>shortN(x.r.Node)===sh))add('high','The witness share is stored on a cluster node ('+sh+')')}}
d.disks.forEach(x=>{if(isRdm(x.r.Type)&&!x.r['LUN ID']&&!x.r['NAA ID'])add('high','Drive '+x.r.Disk+' is an RDM without LUN ID / NAA');if(!x.r.Type)add('low','Drive '+x.r.Disk+' has no type')});
d.nodes.forEach(n=>{const sv=shortN(n.r.Node),nic=(memo('nicIdx',()=>{const m=new Map();clA('ServerNics').forEach(r=>{const k=shortN(r.Server);let a=m.get(k);if(!a){a=[];m.set(k,a)}a.push(r)});return m}).get(sv)||[]).filter(r=>shortN(r.Server)===sv),dk=sdRows(sv).map(x=>x.r);
if(!nic.some(r=>r.Purpose==='Heartbeat'))add('medium','Node '+n.r.Node+' has no heartbeat interface');
if(!nic.some(r=>r.Purpose==='Backup'))add('medium','Node '+n.r.Node+' has no backup interface');
nic.forEach(r=>{if(r.Purpose==='Heartbeat'&&r['DNS name'])add('medium','Heartbeat interface '+r.Interface+' on '+n.r.Node+' has a DNS name ('+r['DNS name']+')');if(r.Purpose==='Backup'&&!r['DNS name'])add('medium','Backup interface '+r.Interface+' on '+n.r.Node+' has no DNS name')});
if(dk.length)d.disks.forEach(x=>{if(!isRdm(x.r.Type)&&!/FC/.test(x.r.Type||''))return;const l=String(x.r['LUN ID']||''),nq=String(x.r['NAA ID']||'');if(!l&&!nq)return;if(!dk.some(r=>(l&&String(r['LUN ID'])===l)||(nq&&r['NAA ID']===nq)))add('medium','Drive '+x.r.Disk+' (LUN '+(l||nq)+') is not recorded on node '+n.r.Node)})});
d.roles.forEach(x=>{if(x.r['Owner node']&&!d.nodes.some(n=>shortN(n.r.Node)===shortN(x.r['Owner node'])))add('medium','Role '+x.r.Role+' is owned by '+x.r['Owner node']+', which is not a node of this cluster')});
avClusterIssues(c,d).forEach(i=>o.push(i));drsNodeIssues(c,d).forEach(i=>o.push(i));rcgClusterIssues(c,d).forEach(i=>o.push(i));
return o}
function clAllIssues(){const o=[];clA('Clusters').forEach(c=>clIssues(c).forEach(i=>o.push(c.Cluster+' · '+i.t)));return o}
/* validation + sync */
function clusterCheck(sheet,b,idx,form){
{const e=dscCheck(sheet,b,idx)||drsCheck(sheet,b,idx)||avLunCheck(sheet,b,idx,form)||rcgCheck(sheet,b,idx);if(e)return e}
if(sheet==='Clusters'){const nm=String(b.Cluster||'').trim().toLowerCase();if(clA('Clusters').some((r,i)=>i!==idx&&String(r.Cluster).trim().toLowerCase()===nm))return 'A cluster with this name already exists.';
const q=b['Quorum type']||'';if(/RDM/.test(q)&&!b['Witness LUN ID']&&!b['Witness NAA'])return 'Witness disk is an RDM: enter the LUN ID or the NAA ID.';
if(q==='File share witness'&&(!b['Witness share path']||!b['Share stored on']))return 'File share witness: enter the share path and where the share is stored.'}
if(sheet==='ClusterNodes'){if(!clNodeInfo(b.Node))return 'Node '+b.Node+' is not in ServersMI.';
const j=clNodeInfo(b.Node).s.Hostname;if(clA('ClusterNodes').some((r,i)=>i!==idx&&r.Cluster===b.Cluster&&shortN(r.Node)===shortN(j)))return j+' is already a node of '+b.Cluster+'.';
const o=clA('ClusterNodes').find((r,i)=>i!==idx&&r.Cluster!==b.Cluster&&shortN(r.Node)===shortN(j));if(o)return j+' already belongs to cluster '+o.Cluster+'. A server can be a node of one cluster only.'}
if(sheet==='ClusterRoles'&&clA('ClusterRoles').some((r,i)=>i!==idx&&r.Cluster===b.Cluster&&String(r.Role).toLowerCase()===String(b.Role).toLowerCase()))return 'This role already exists in '+b.Cluster+'.';
if(sheet==='ClusterResources'&&clA('ClusterResources').some((r,i)=>i!==idx&&r.Cluster===b.Cluster&&r.Role===b.Role&&String(r.Resource).toLowerCase()===String(b.Resource).toLowerCase()))return 'This resource already exists in that role.';
if(sheet==='ClusterDisks'){if(clA('ClusterDisks').some((r,i)=>i!==idx&&r.Cluster===b.Cluster&&String(r.Disk).toLowerCase()===String(b.Disk).toLowerCase()))return 'This drive already exists in '+b.Cluster+'.';
if(isRdm(b.Type)&&!b['LUN ID']&&!b['NAA ID'])return 'RDM drive: enter the LUN ID or the NAA ID.'}
if(sheet==='ServerDisks'){if(clA('ServerDisks').some((r,i)=>i!==idx&&shortN(r.Server)===shortN(b.Server)&&String(r.Disk).toLowerCase()===String(b.Disk).toLowerCase()))return 'This server already has a disk with this name.';
if(isRdm(b.Type)&&!b['LUN ID']&&!b['NAA ID'])return 'RDM disk: enter the LUN ID or the NAA ID.'}
if(sheet==='ServerNics'){{const old=clA('ServerNics')[idx];if(!old||old.Purpose!==b.Purpose)b['Detected by']='Manual'}if(clA('ServerNics').some((r,i)=>i!==idx&&shortN(r.Server)===shortN(b.Server)&&String(r.Interface).toLowerCase()===String(b.Interface).toLowerCase()))return 'This server already has an interface with this name.';
if(form&&form.dataset.warned!=='1'){const w=b.Purpose==='Heartbeat'&&b['DNS name']?'A heartbeat interface normally has no DNS name.':b.Purpose==='Backup'&&!b['DNS name']?'A backup interface normally has a DNS name.':'';if(w){form.dataset.warned='1';return w+' Save again to keep it as it is.'}}}
return ''}
function srvSetCl(node,cl){const ni=clNodeInfo(node);if(ni)ni.s['Failover cluster']=cl}
function clusterBefore(sheet,b,old){
lcBefore(sheet,b);
if(sheet==='ServerMI'){cmbCanon(b);if(isStand(b['Cluster/Standalone']))b['Failover cluster']=''}
if(sheet==='RemoteCopyGroups'&&old&&old.Group!==b.Group)['ArrayVolumes','Datastores','ClusterDisks'].forEach(s=>(DB[s]||[]).forEach(r=>{if(r['Remote copy group']===old.Group)r['Remote copy group']=b.Group}));
if(sheet==='ServerMI'&&b.Platform!=='Physical'){b.Blade='';b.Enclosure='';b.Bay=''}
if(old&&sheet==='ServerMI'&&old.Hostname!==b.Hostname)drsRename('VMs',old.Hostname,b.Hostname);
if(old&&sheet==='ESXi'&&old.Hostname!==b.Hostname){drsRename('Hosts',old.Hostname,b.Hostname);dhgRename(old.Hostname,b.Hostname)}
if(old&&sheet==='DrsHostGroups'&&old.Group!==b.Group)drsA().forEach(r=>{if(r['Host group']===old.Group)r['Host group']=b.Group});
if(sheet==='DatastoreClusters'&&old&&old['Datastore cluster']!==b['Datastore cluster'])DB.Datastores.forEach(d=>{if(d['Datastore cluster']===old['Datastore cluster'])d['Datastore cluster']=b['Datastore cluster']});
if(sheet==='Clusters'){const q=b['Quorum type']||'';if(!/RDM/.test(q)){b['Witness LUN ID']='';b['Witness NAA']=''}if(!/Disk witness/.test(q))b['Witness datastore / array']='';if(q!=='File share witness'){b['Witness share path']='';b['Share stored on']=''}
if(old&&old.Cluster!==b.Cluster){['ClusterNodes','ClusterRoles','ClusterDisks','ClusterResources'].forEach(s=>clA(s).forEach(r=>{if(r.Cluster===old.Cluster)r.Cluster=b.Cluster}));DB.ServerMI.forEach(r=>{if(r['Failover cluster']===old.Cluster)r['Failover cluster']=b.Cluster});if(CLS.sel===old.Cluster)CLS.sel=b.Cluster}}
if(old&&sheet==='ClusterRoles'&&(old.Role!==b.Role||old.Cluster!==b.Cluster))clA('ClusterResources').forEach(r=>{if(r.Cluster===old.Cluster&&r.Role===old.Role){r.Cluster=b.Cluster;r.Role=b.Role}});
if(sheet==='ClusterNodes'){const ni=clNodeInfo(b.Node);if(ni)b.Node=ni.s.Hostname;
if(b.Primary==='Yes')clA('ClusterNodes').forEach(r=>{if(r.Cluster===b.Cluster&&r!==old)r.Primary='No'});
else if(!clA('ClusterNodes').some(r=>r.Cluster===b.Cluster&&r!==old))b.Primary='Yes';
if(old&&(old.Node!==b.Node||old.Cluster!==b.Cluster))srvSetCl(old.Node,'')}
if(sheet==='ServerMI'){const oh=old?old.Hostname:'',oc=old?(old['Failover cluster']||''):'',nc=b['Failover cluster']||'';
if(old&&oh!==b.Hostname){clA('ClusterNodes').forEach(r=>{if(r.Node===oh)r.Node=b.Hostname});clA('ClusterRoles').forEach(r=>{if(r['Owner node']===oh)r['Owner node']=b.Hostname});clA('ServerDisks').forEach(r=>{if(r.Server===oh)r.Server=b.Hostname});clA('ServerNics').forEach(r=>{if(r.Server===oh)r.Server=b.Hostname})}
if(oc&&oc!==nc)DB.ClusterNodes=clA('ClusterNodes').filter(r=>!(r.Cluster===oc&&r.Node===b.Hostname));
if(nc&&!clA('ClusterNodes').some(r=>r.Cluster===nc&&r.Node===b.Hostname)){const first=!clA('ClusterNodes').some(r=>r.Cluster===nc);clA('ClusterNodes').push({Cluster:nc,Node:b.Hostname,Primary:first?'Yes':'No',Note:'',Updated:ds(0)})}}}
function clusterAfter(sheet,b){if(sheet==='ClusterNodes')srvSetCl(b.Node,b.Cluster)}
function clusterDel(sheet,r){
if(sheet==='RemoteCopyGroups')['ArrayVolumes','Datastores','ClusterDisks'].forEach(s=>(DB[s]||[]).forEach(x=>{if(x['Remote copy group']===r.Group)x['Remote copy group']=''}));
if(sheet==='ServerMI')drsRename('VMs',r.Hostname,'');
if(sheet==='ESXi'){drsRename('Hosts',r.Hostname,'');dhgRename(r.Hostname,'')}
if(sheet==='DrsHostGroups')drsA().forEach(x=>{if(x['Host group']===r.Group)x['Host group']=''});
if(sheet==='DatastoreClusters')DB.Datastores.forEach(d=>{if(d['Datastore cluster']===r['Datastore cluster'])d['Datastore cluster']=''});
if(sheet==='Clusters'){['ClusterNodes','ClusterRoles','ClusterDisks','ClusterResources'].forEach(s=>{DB[s]=clA(s).filter(x=>x.Cluster!==r.Cluster)});DB.ServerMI.forEach(s=>{if(s['Failover cluster']===r.Cluster)s['Failover cluster']=''})}
if(sheet==='ClusterRoles')DB.ClusterResources=clA('ClusterResources').filter(x=>!(x.Cluster===r.Cluster&&x.Role===r.Role));
if(sheet==='ClusterNodes')srvSetCl(r.Node,'');
if(sheet==='ServerMI'){DB.ClusterNodes=clA('ClusterNodes').filter(x=>x.Node!==r.Hostname);DB.ServerDisks=clA('ServerDisks').filter(x=>x.Server!==r.Hostname);DB.ServerNics=clA('ServerNics').filter(x=>x.Server!==r.Hostname)}}
function quorumUI(f){if(!f||!f.elements['Quorum type'])return;const t=f.elements['Quorum type'].value;
const show={'Witness LUN ID':/RDM/.test(t),'Witness NAA':/RDM/.test(t),'Witness datastore / array':/Disk witness/.test(t),'Witness share path':t==='File share witness','Share stored on':t==='File share witness'};
Object.keys(show).forEach(k=>{const e=f.elements[k],l=e&&e.closest('label');if(l)l.style.display=show[k]?'':'none'})}
/* page */
function clQuorum(c,short){const q=c['Quorum type']||'Not specified';
if(/RDM/.test(q))return q+' · LUN '+(c['Witness LUN ID']||'?')+(c['Witness datastore / array']?' on '+c['Witness datastore / array']:'');
if(/VMDK/.test(q))return q+(c['Witness datastore / array']?' on '+c['Witness datastore / array']:'');
if(q==='File share witness')return q+' · '+(c['Witness share path']||'?')+(c['Share stored on']?' (stored on '+c['Share stored on']+')':'');
return q}
function clBadge(n,hi){return n?'<em class="badge '+(hi?'b-bad':'b-warn')+'">'+n+' issue'+(n===1?'':'s')+'</em>':'<em class="badge b-ok">OK</em>'}
function clVol(r){if(!avA().length)return '<span class="note">—</span>';if(!isRdm(r.Type)&&!/FC/.test(r.Type||''))return '<span class="note">—</span>';const i=avFind(r['Datastore / array'],r['NAA ID'],r['LUN ID']);return i>=0?'<a href="#" data-act="relgo" data-sheet="ArrayVolumes" data-i="'+i+'">'+esc(avA()[i].Volume)+'</a>':(r['NAA ID']||r['LUN ID'])?'<span class="badge b-warn">not on array</span>':'<span class="note">—</span>'}
function clArrIdx(name){const k=shortN(name);return k?DB.Storage.findIndex(a=>shortN(a.Array)===k):-1}
function clustersView(){
const C=clA('Clusters');if(!CLS.sel||!C.some(c=>c.Cluster===CLS.sel))CLS.sel=C.length?C[0].Cluster:'';
const rows=C.map((c,i)=>{const d=clData(c.Cluster),is=clIssues(c,d);return{c:c,i:i,d:d,is:is,prim:(d.nodes.find(x=>x.r.Primary==='Yes')||{r:{}}).r.Node||''}});
const nodes=rows.reduce((a,x)=>a+x.d.nodes.length,0),rdm=rows.reduce((a,x)=>a+x.d.disks.filter(y=>isRdm(y.r.Type)).length,0),bad=rows.filter(x=>x.is.length).length;
const free=DB.ServerMI.filter(s=>/windows/i.test(s.OS||'')&&!s['Failover cluster']&&s.Status!=='Decom').length;
let h=head('Failover clusters','Microsoft failover clusters: nodes with the primary, roles, drives (RDM or not) and quorum. A server joins a cluster here or in its ServersMI form.','<button class="btn p" data-act="cladd">+ Add cluster</button>')
+'<div class="kpis"><div class="kpi"><span>Clusters</span><b>'+C.length+'</b><small>'+nodes+' nodes</small></div><div class="kpi"><span>Drives</span><b>'+clA('ClusterDisks').length+'</b><small>'+rdm+' RDM</small></div><div class="kpi"><span>Roles</span><b>'+clA('ClusterRoles').length+'</b><small>&nbsp;</small></div><div class="kpi"><span>Clusters with problems</span><b>'+bad+'</b><small class="'+(bad?'b':'g')+'">'+(bad?'see the list below':'all checks pass')+'</small></div></div>';
if(!C.length)return h+'<section class="card"><h2>No clusters yet</h2><p class="note">Add a cluster, then add its nodes, roles and drives. '+free+' Windows server'+(free===1?'':'s')+' in ServersMI could be nodes.</p><button class="btn p" data-act="cladd">+ Add cluster</button></section>';
h+='<section class="card" style="padding:0">'+ctTable('clusters',[
{k:'Cluster',l:'Cluster',v:x=>x.c.Cluster,h:x=>'<a href="#" data-act="clsel" data-n="'+esc(x.c.Cluster)+'" class="mono"><b>'+(x.c.Cluster===CLS.sel?'▸ ':'')+esc(x.c.Cluster)+'</b></a>'},

{k:'Status',l:'Status',v:x=>x.is.length,h:x=>clBadge(x.is.length,x.is.some(i=>i.sev==='high'))},
{k:'Env',l:'Env',v:x=>x.c.Env,h:x=>esc(x.c.Env||'')},{k:'DC',l:'DC',v:x=>x.c.DC,h:x=>esc(x.c.DC||'')},
{k:'Nodes',l:'Nodes',v:x=>x.d.nodes.length,h:x=>String(x.d.nodes.length)},
{k:'Primary',l:'Primary node',v:x=>x.prim,h:x=>esc(x.prim||'—')},
{k:'Roles',l:'Roles',v:x=>x.d.roles.length,h:x=>String(x.d.roles.length)},
{k:'Drives',l:'Drives',v:x=>x.d.disks.length,h:x=>x.d.disks.length+(x.d.disks.some(y=>isRdm(y.r.Type))?' · '+x.d.disks.filter(y=>isRdm(y.r.Type)).length+' RDM':'')},
{k:'Quorum',l:'Quorum',v:x=>x.c['Quorum type'],h:x=>esc(clQuorum(x.c))},
{k:'IP',l:'Cluster IP',v:x=>x.c['Cluster IP'],h:x=>'<span class="mono">'+esc(x.c['Cluster IP']||'')+'</span>'}],rows)+'</section>';
const x=rows.find(r=>r.c.Cluster===CLS.sel);if(!x)return h;
const c=x.c,d=x.d,tbl=(cols,body,empty)=>body.length?'<div class="tw"><table><thead><tr>'+cols.map(t=>'<th>'+t+'</th>').join('')+'</tr></thead><tbody>'+body.join('')+'</tbody></table></div>':'<p class="note" style="margin:0">'+empty+'</p>';
const nodeRows=d.nodes.map(n=>{const ni=clNodeInfo(n.r.Node),s=ni?ni.s:null;return '<tr class="clk" data-act="edit" data-sheet="ClusterNodes" data-i="'+n.i+'"><td>'+(ni?'<a href="#" class="mono" data-act="relgo" data-sheet="ServerMI" data-i="'+ni.j+'"><b>'+esc(n.r.Node)+'</b></a>':'<b class="mono">'+esc(n.r.Node)+'</b> <em class="badge b-bad">not in ServersMI</em>')+'</td><td>'+(n.r.Primary==='Yes'?'<em class="badge b-ok">Primary</em>':'<span class="note">secondary</span>')+'</td><td>'+esc(s?(s.Platform==='Physical'?'Physical'+(s.Rack?' · '+s.DC+'/'+s.Rack:''):(s['ESXi host']||'Virtual')):'')+'</td><td>'+esc(s?(s.OS||''):'')+'</td><td>'+esc(s?(s.IP||''):'')+'</td><td>'+esc(n.r.Note||'')+'</td></tr>'});
const stB=v=>v?'<em class="badge '+(/^online$/i.test(v)?'b-ok':/fail|offline/i.test(v)?'b-bad':'b-off')+'">'+esc(v)+'</em>':'';
const resOf=n=>d.res.filter(x=>x.r.Role===n.r.Role);
const roleRows=d.roles.map(n=>{const rs=resOf(n),open=CLS.rex&&CLS.rex[n.r.Role];return '<tr class="clk" data-act="edit" data-sheet="ClusterRoles" data-i="'+n.i+'"><td><b>'+esc(n.r.Role)+'</b></td><td>'+esc(n.r.Type||'')+'</td><td class="mono">'+esc(n.r['Virtual name']||'')+'</td><td>'+stB(n.r.State)+'</td><td class="mono">'+esc(n.r['Owner node']||'')+'</td><td class="mono">'+esc(n.r['Role IP']||'')+'</td><td>'+esc(n.r.Drives||'')+'</td><td data-act="rolex" data-n="'+esc(n.r.Role)+'" title="Show or hide the resources of this role"><a href="#" data-act="rolex" data-n="'+esc(n.r.Role)+'">'+rs.length+' resource'+(rs.length===1?'':'s')+(open?' ▾':' ▸')+'</a></td></tr>'+(open&&rs.length?'<tr class="resrow"><td colspan="8"><div class="tw"><table><thead><tr><th>Resource</th><th>Type</th><th>State</th><th>Owner node</th><th>Details</th></tr></thead><tbody>'+rs.map(x=>'<tr class="clk" data-act="edit" data-sheet="ClusterResources" data-i="'+x.i+'"><td>'+esc(x.r.Resource)+'</td><td>'+esc(x.r['Resource type']||'')+'</td><td>'+stB(x.r.State)+'</td><td class="mono">'+esc(x.r['Owner node']||'')+'</td><td class="mono">'+esc(x.r.Details||'')+'</td></tr>').join('')+'</tbody></table></div></td></tr>':'')});
const diskRows=d.disks.map(n=>{const ai=clArrIdx(n.r['Datastore / array']);return '<tr class="clk" data-act="edit" data-sheet="ClusterDisks" data-i="'+n.i+'"><td><b>'+esc(n.r.Disk)+'</b></td><td class="mono">'+esc(n.r['Drive / mount']||'')+'</td><td>'+(n.r['Size GB']!==''&&n.r['Size GB']!=null?esc(n.r['Size GB'])+' GB':'')+'</td><td><em class="badge '+(isRdm(n.r.Type)?'b-info':'b-off')+'">'+esc(n.r.Type||'')+'</em></td><td class="mono">'+esc(n.r['LUN ID']||'')+'</td><td class="mono">'+esc(n.r['NAA ID']||'')+'</td><td>'+(ai>=0?'<a href="#" data-act="relgo" data-sheet="Storage" data-i="'+ai+'">'+esc(n.r['Datastore / array'])+'</a>':esc(n.r['Datastore / array']||''))+'</td><td>'+clVol(n.r)+'</td><td>'+(rcgEff(n.r)?rcgLink(rcgEff(n.r)):'<span class="note">—</span>')+'</td><td>'+esc(n.r.Role||'')+'</td></tr>'});
const TABS=[['cluster','Cluster'],['shared','Shared drives'],['disks','Node disks'],['nics','Network interfaces']],tab=TABS.some(t=>t[0]===CLS.tab)?CLS.tab:'cluster';
const nodeNames=d.nodes.map(n=>n.r.Node);
const cntD=nodeNames.reduce((a,n)=>a+clA('ServerDisks').filter(r=>shortN(r.Server)===shortN(n)).length,0),cntN=nodeNames.reduce((a,n)=>a+clA('ServerNics').filter(r=>shortN(r.Server)===shortN(n)).length,0);
const tcount={cluster:d.nodes.length,shared:d.disks.length,disks:cntD,nics:cntN};
h+='<section class="card"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><div><h2 style="margin:0" class="mono">'+esc(c.Cluster)+'</h2><p class="note" style="margin:4px 0 0">'+esc([c['Cluster IP'],c['Cluster FQDN'],c['Functional level']?'level '+c['Functional level']:'',c.Env,c.DC,c.Purpose,c.Owner].filter(Boolean).join(' · '))+'</p></div><div class="tools"><button class="btn" data-act="relgo" data-sheet="Clusters" data-i="'+x.i+'">Relations</button><button class="btn" data-act="edit" data-sheet="Clusters" data-i="'+x.i+'">Edit cluster</button></div></div>'
+(x.is.length?'<ul class="clissues">'+x.is.map(i=>'<li class="'+i.sev+'">'+esc(i.t)+'</li>').join('')+'</ul>':'')
+'<div class="clq"><b>Quorum</b><span>'+esc(clQuorum(c))+'</span></div>'
+(c.Notes?'<p class="note" style="margin:8px 0 0">'+esc(c.Notes)+'</p>':'')+'</section>'
+'<div class="cltabs" role="tablist">'+TABS.map(t=>'<button class="chip'+(t[0]===tab?' on':'')+'" role="tab" aria-selected="'+(t[0]===tab)+'" data-act="cltab" data-t="'+t[0]+'">'+t[1]+' <span class="note">'+tcount[t[0]]+'</span></button>').join('')+'</div>';
const sec=(title,n,btn,inner)=>'<section class="card"><div class="tools" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">'+title+' <span class="note">'+n+'</span></h2>'+(btn||'')+'</div>'+inner+'</section>';
if(tab==='cluster')h+=sec('Nodes',d.nodes.length,'<button class="btn" data-act="cnadd">+ Add node</button>',tbl(['Node','Role in cluster','Runs on','OS','IP','Note'],nodeRows,'No nodes yet.'))
+sec('Roles',d.roles.length,'<button class="btn" data-act="rsadd">+ Add resource</button> <button class="btn" data-act="cradd">+ Add role</button>',tbl(['Role','Type','Virtual name','State','Owner node','Role IP','Drives','Resources'],roleRows,'No roles yet.'));
if(tab==='shared')h+=sec('Shared cluster drives',d.disks.length,'<button class="btn" data-act="cdadd">+ Add drive</button>',tbl(['Drive','Letter / mount','Size','Type','LUN ID','NAA ID','Datastore / array','Array volume','Remote copy group','Used by role'],diskRows,'No drives yet.')+'<p class="note" style="margin:8px 0 0">Drives owned by the cluster. RDM drives need a LUN ID or NAA ID. Each node\'s own view of them (and its OS disks) is on the Node disks tab.</p>');
if(tab==='disks')h+=d.nodes.length?d.nodes.map(n=>{const sv=shortN(n.r.Node),rows=clA('ServerDisks').map((r,i)=>({r:r,i:i})).filter(y=>shortN(y.r.Server)===sv);
return sec(esc(n.r.Node)+(n.r.Primary==='Yes'?' <em class="badge b-ok">Primary</em>':''),rows.length,'<button class="btn" data-act="sdadd" data-n="'+esc(n.r.Node)+'">+ Add disk</button>',tbl(['Disk','Letter / mount','Size','Type','Purpose','SCSI','LUN ID','NAA ID','Datastore / array'],rows.map(y=>{const ai=clArrIdx(y.r['Datastore / array']),di=DB.Datastores.findIndex(t=>shortN(t.Datastore)===shortN(y.r['Datastore / array']));return '<tr class="clk" data-act="edit" data-sheet="ServerDisks" data-i="'+y.i+'"><td><b>'+esc(y.r.Disk)+'</b></td><td class="mono">'+esc(y.r['Drive / mount']||'')+'</td><td>'+(y.r['Size GB']!==''&&y.r['Size GB']!=null?esc(y.r['Size GB'])+' GB':'')+'</td><td><em class="badge '+(isRdm(y.r.Type)?'b-info':'b-off')+'">'+esc(y.r.Type||'')+'</em></td><td>'+esc(y.r.Purpose||'')+'</td><td class="mono">'+esc(y.r['SCSI ID']||'')+'</td><td class="mono">'+esc(y.r['LUN ID']||'')+'</td><td class="mono">'+esc(y.r['NAA ID']||'')+'</td><td>'+(ai>=0?'<a href="#" data-act="relgo" data-sheet="Storage" data-i="'+ai+'">'+esc(y.r['Datastore / array'])+'</a>':di>=0?'<a href="#" data-act="relgo" data-sheet="Datastores" data-i="'+di+'">'+esc(y.r['Datastore / array'])+'</a>':esc(y.r['Datastore / array']||''))+'</td></tr>'}),'No disks recorded for this node.'))}).join(''):sec('Node disks',0,'','<p class="note" style="margin:0">Add nodes first.</p>');
if(tab==='nics')h+=d.nodes.length?d.nodes.map(n=>{const sv=shortN(n.r.Node),rows=clA('ServerNics').map((r,i)=>({r:r,i:i})).filter(y=>shortN(y.r.Server)===sv);
const bd={Production:'b-info',Heartbeat:'b-warn',Backup:'b-ok'};
return sec(esc(n.r.Node)+(n.r.Primary==='Yes'?' <em class="badge b-ok">Primary</em>':''),rows.length,'<button class="btn" data-act="snadd" data-n="'+esc(n.r.Node)+'">+ Add interface</button>',tbl(['Interface','Purpose','IP','Prefix','VLAN','DNS name','MAC','Port group / switch'],rows.map(y=>'<tr class="clk" data-act="edit" data-sheet="ServerNics" data-i="'+y.i+'"><td><b>'+esc(y.r.Interface)+'</b></td><td><em class="badge '+(bd[y.r.Purpose]||'b-off')+'">'+esc(y.r.Purpose||'')+'</em></td><td class="mono">'+esc(y.r.IP||'')+'</td><td>'+esc(y.r['Subnet / prefix']||'')+'</td><td>'+esc(y.r.VLAN||'')+'</td><td class="mono">'+(y.r['DNS name']?esc(y.r['DNS name']):'<span class="note">'+(y.r.Purpose==='Heartbeat'?'none (heartbeat)':'—')+'</span>')+'</td><td class="mono">'+esc(y.r.MAC||'')+'</td><td>'+esc(y.r['Port group / switch']||'')+'</td></tr>'),'No interfaces recorded for this node.'))}).join(''):sec('Network interfaces',0,'','<p class="note" style="margin:0">Add nodes first.</p>');
return h}
/* relations */
function clRel(sh,r,G,facts,name){
const clIdx=n=>clA('Clusters').findIndex(c=>c.Cluster===n);
const sn=shortN(name);
if(sh==='ServerMI'){const cn=r['Failover cluster'];const ci=cn?clIdx(cn):-1;
if(ci>=0){const c=clA('Clusters')[ci],d=clData(cn);facts=facts.concat(['Cluster '+cn]);
G.push(relGroup('Failover cluster',[relTile('Clusters',ci,cn,[c['Cluster IP'],clQuorum(c)].filter(Boolean).join(' · '),(d.nodes.find(x=>shortN(x.r.Node)===sn)||{r:{}}).r.Primary==='Yes'?'<em class="badge b-ok">primary</em>':'')]));
G.push(relGroup('Other nodes in '+esc(cn),d.nodes.filter(x=>shortN(x.r.Node)!==sn).map(x=>{const j=srvFind(x.r.Node);return j>=0?relTile('ServerMI',j,x.r.Node,(x.r.Primary==='Yes'?'primary · ':'')+(x.r.Note||'')):''}).filter(Boolean)));
G.push(relGroup('Cluster roles',d.roles.filter(x=>!x.r['Owner node']||shortN(x.r['Owner node'])===sn).map(x=>relTile('ClusterRoles',x.i,x.r.Role,[x.r.Type,x.r['Role IP'],x.r['Owner node']?'':'any node'].filter(Boolean).join(' · '))),'No roles'));
G.push(relGroup('Cluster drives',d.disks.map(x=>relTile('ClusterDisks',x.i,x.r.Disk+' '+(x.r['Drive / mount']||''),[x.r.Type,x.r['LUN ID']?'LUN '+x.r['LUN ID']:'',x.r['Datastore / array']].filter(Boolean).join(' · '))),'No drives'))}
else G.push(relGroup('Failover cluster',[],cn?'Cluster '+esc(cn)+' is not defined on the Failover clusters page':'Not a node of a failover cluster'));
const sdk=clA('ServerDisks').map((x,i)=>({r:x,i:i})).filter(x=>shortN(x.r.Server)===sn),snc=clA('ServerNics').map((x,i)=>({r:x,i:i})).filter(x=>shortN(x.r.Server)===sn);
const addb=(act,t)=>'<button class="btn s" data-act="'+act+'" data-n="'+esc(r.Hostname)+'" style="margin-top:8px">'+t+'</button>';
G.push(relGroup('Server disks',sdk.map(x=>relTile('ServerDisks',x.i,x.r.Disk+(x.r['Drive / mount']?' '+x.r['Drive / mount']:''),[x.r.Type,x.r.Purpose,x.r['Size GB']?x.r['Size GB']+' GB':'',x.r['LUN ID']?'LUN '+x.r['LUN ID']:'',x.r['Datastore / array']].filter(Boolean).join(' · '))),'No disks recorded').replace(/<\/section>$/,addb('sdadd','+ Add disk')+'</section>'));
G.push(relGroup('Network interfaces',snc.map(x=>relTile('ServerNics',x.i,x.r.Interface+' · '+(x.r.Purpose||''),[x.r.IP,x.r['DNS name']||(x.r.Purpose==='Heartbeat'?'no DNS name':''),x.r.VLAN?'VLAN '+x.r.VLAN:''].filter(Boolean).join(' · '))),'No interfaces recorded').replace(/<\/section>$/,addb('snadd','+ Add interface')+'</section>'));
const wit=clA('Clusters').map((c,i)=>({c:c,i:i})).filter(x=>x.c['Share stored on']&&shortN(String(x.c['Share stored on']).split(/[\s(]/)[0])===sn);
if(wit.length)G.push(relGroup('Hosts the witness share of',wit.map(x=>relTile('Clusters',x.i,x.c.Cluster,x.c['Witness share path']||''))))}
if(sh==='Clusters'){const d=clData(name);facts=[r['Cluster IP'],r.Env,r.DC,clQuorum(r)];
G.push(relGroup('Nodes',d.nodes.map(x=>{const j=srvFind(x.r.Node);return j>=0?relTile('ServerMI',j,x.r.Node,(x.r.Primary==='Yes'?'primary · ':'')+(x.r.Note||'')):'<div class="reltile static"><b>'+esc(x.r.Node)+'</b><span>not in ServersMI</span></div>'}),'No nodes'));
const hosts=[];d.nodes.forEach(x=>{const ni=clNodeInfo(x.r.Node);if(ni&&ni.s['ESXi host']){const hi=DB.ESXi.findIndex(h=>shortN(h.Hostname)===shortN(ni.s['ESXi host']));if(hi>=0&&!hosts.some(t=>t.hi===hi))hosts.push({hi:hi,n:[x.r.Node]});else if(hi>=0)hosts.find(t=>t.hi===hi).n.push(x.r.Node)}});
G.push(relGroup('ESXi hosts of the nodes',hosts.map(t=>relTile('ESXi',t.hi,DB.ESXi[t.hi].Hostname,t.n.join(', ')+(t.n.length>1?' — same host!':''))),'Physical nodes or no host recorded'));
G.push(relGroup('Roles',d.roles.map(x=>relTile('ClusterRoles',x.i,x.r.Role,[x.r.Type,x.r['Role IP'],x.r['Owner node']].filter(Boolean).join(' · '))),'No roles'));
G.push(relGroup('Drives',d.disks.map(x=>relTile('ClusterDisks',x.i,x.r.Disk+' '+(x.r['Drive / mount']||''),[x.r.Type,x.r['LUN ID']?'LUN '+x.r['LUN ID']:'',x.r['Datastore / array']].filter(Boolean).join(' · '))),'No drives'));
const nn=d.nodes.map(n=>shortN(n.r.Node));
G.push(relGroup('Network interfaces of the nodes',clA('ServerNics').map((x,i)=>({r:x,i:i})).filter(x=>nn.indexOf(shortN(x.r.Server))>=0).map(x=>relTile('ServerNics',x.i,x.r.Server+' · '+x.r.Interface,[x.r.Purpose,x.r.IP,x.r['DNS name']||(x.r.Purpose==='Heartbeat'?'no DNS name':'')].filter(Boolean).join(' · '))),'No interfaces recorded'));
G.push(relGroup('Disks of the nodes',clA('ServerDisks').map((x,i)=>({r:x,i:i})).filter(x=>nn.indexOf(shortN(x.r.Server))>=0).map(x=>relTile('ServerDisks',x.i,x.r.Server+' · '+x.r.Disk,[x.r.Type,x.r.Purpose,x.r['LUN ID']?'LUN '+x.r['LUN ID']:''].filter(Boolean).join(' · '))),'No disks recorded'));
const arrs=[];d.disks.forEach(x=>{const a=x.r['Datastore / array'];if(a&&arrs.indexOf(a)<0)arrs.push(a)});if(r['Witness datastore / array']&&arrs.indexOf(r['Witness datastore / array'])<0)arrs.push(r['Witness datastore / array']);
G.push(relGroup('Storage and datastores',arrs.map(a=>{const ai=clArrIdx(a),di=DB.Datastores.findIndex(t=>shortN(t.Datastore)===shortN(a));return ai>=0?relTile('Storage',ai,a,'Storage array'):di>=0?relTile('Datastores',di,a,'Datastore'):'<div class="reltile static"><b>'+esc(a)+'</b></div>'}),'No storage recorded'));
const q=r['Quorum type']||'';const qt=[];if(q==='File share witness'){const j=srvFind(String(r['Share stored on']||'').split(/[\s(]/)[0]);qt.push(j>=0?relTile('ServerMI',j,r['Share stored on'],r['Witness share path']||''):'<div class="reltile static"><b>'+esc(r['Witness share path']||'—')+'</b><span>stored on '+esc(r['Share stored on']||'?')+'</span></div>')}else if(/RDM/.test(q)){const ai=clArrIdx(r['Witness datastore / array']);qt.push(ai>=0?relTile('Storage',ai,r['Witness datastore / array'],'LUN '+(r['Witness LUN ID']||'?')+' '+(r['Witness NAA']||'')):'<div class="reltile static"><b>LUN '+esc(r['Witness LUN ID']||'?')+'</b><span>'+esc(r['Witness NAA']||'')+'</span></div>')}
G.push(relGroup('Quorum · '+esc(q||'not specified'),qt,q==='None'?'No witness':'Nothing recorded'));
const is=clIssues(r,d);G.push(relGroup('Cluster checks',is.map(i=>'<div class="reltile static"><b>'+esc(i.t)+'</b><span>'+i.sev+'</span></div>'),'All checks pass'))}
if(sh==='Storage'){const dk=clA('ClusterDisks').map((x,i)=>({r:x,i:i})).filter(x=>shortN(x.r['Datastore / array'])===sn),wq=clA('Clusters').map((c,i)=>({c:c,i:i})).filter(x=>shortN(x.c['Witness datastore / array'])===sn);
const sdd=clA('ServerDisks').map((x,i)=>({r:x,i:i})).filter(x=>shortN(x.r['Datastore / array'])===sn);
G.push(relGroup('Failover cluster drives and witnesses here',dk.map(x=>relTile('ClusterDisks',x.i,x.r.Cluster+' · '+x.r.Disk,[x.r.Type,x.r['LUN ID']?'LUN '+x.r['LUN ID']:'',x.r['Size GB']?x.r['Size GB']+' GB':''].filter(Boolean).join(' · '))).concat(wq.map(x=>relTile('Clusters',x.i,x.c.Cluster+' · witness',clQuorum(x.c)))),'None'));if(sdd.length)G.push(relGroup('Server disks (RDM / VMDK) on this array',sdd.map(x=>relTile('ServerDisks',x.i,x.r.Server+' · '+x.r.Disk,[x.r.Type,x.r['LUN ID']?'LUN '+x.r['LUN ID']:''].filter(Boolean).join(' · ')))))}
if(sh==='Datastores'){const dk=clA('ClusterDisks').map((x,i)=>({r:x,i:i})).filter(x=>shortN(x.r['Datastore / array'])===sn);if(dk.length)G.push(relGroup('Failover cluster drives in this datastore',dk.map(x=>relTile('ClusterDisks',x.i,x.r.Cluster+' · '+x.r.Disk,x.r.Type||''))));const sdd=clA('ServerDisks').map((x,i)=>({r:x,i:i})).filter(x=>shortN(x.r['Datastore / array'])===sn);if(sdd.length)G.push(relGroup('Server disks in this datastore',sdd.map(x=>relTile('ServerDisks',x.i,x.r.Server+' · '+x.r.Disk,[x.r.Type,x.r['Size GB']?x.r['Size GB']+' GB':''].filter(Boolean).join(' · ')))))}
if(sh==='ESXi'){const nodes=DB.ServerMI.map((s,i)=>({s:s,i:i})).filter(x=>shortN(x.s['ESXi host'])===sn&&x.s['Failover cluster']);if(nodes.length)G.push(relGroup('Failover cluster nodes on this host',nodes.map(x=>relTile('ServerMI',x.i,x.s.Hostname,'cluster '+x.s['Failover cluster']))))}
return facts}
const CLACT={
cltab(el){CLS.tab=el.dataset.t;route()},
sdadd(el){openForm('ServerDisks',null,{Server:el.dataset.n,Type:'VMDK'})},
snadd(el){openForm('ServerNics',null,{Server:el.dataset.n,Purpose:'Production'})},
clsel(el){CLS.sel=el.dataset.n;route()},
cladd(){openForm('Clusters',null,{Env:'PROD','Quorum type':'File share witness'})},
cnadd(){if(!CLS.sel)return;openForm('ClusterNodes',null,{Cluster:CLS.sel})},
rolex(el){const n=el.dataset.n;CLS.rex=CLS.rex||{};CLS.rex[n]=!CLS.rex[n];route()},
rsadd(){if(!CLS.sel)return;openForm('ClusterResources',null,{Cluster:CLS.sel})},
cradd(){if(!CLS.sel)return;openForm('ClusterRoles',null,{Cluster:CLS.sel})},
cdadd(){if(!CLS.sel)return;openForm('ClusterDisks',null,{Cluster:CLS.sel,Type:'RDM - physical'})}};
