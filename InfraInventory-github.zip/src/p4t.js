/* ---------- physical servers: one record in ServersMI, rack position there; duplicates in Other devices are merged ---------- */
function srvKey(n){return String(n||'').trim().toLowerCase()}
function srvMatch(r,k,short){const h=srvKey(r.Hostname);return h===k||h.split('.')[0]===short||srvKey(r.FQDN)===k||(h.indexOf('-')>0&&h.split('-')[0]===short)}
function srvFindIdx(){return memo('srvFind',()=>{const H=new Map(),S=new Map(),F=new Map(),D=new Map(),put=(m,k,i)=>{if(k&&!m.has(k))m.set(k,i)};DB.ServerMI.forEach((r,i)=>{const h=srvKey(r.Hostname);put(H,h,i);put(S,h.split('.')[0],i);put(F,srvKey(r.FQDN),i);if(h.indexOf('-')>0)put(D,h.split('-')[0],i)});return{H:H,S:S,F:F,D:D}})}
function srvFind(name){const k=srvKey(name);if(!k)return -1;const short=k.split('.')[0],ix=srvFindIdx();let best=-1;[ix.H.get(k),ix.S.get(short),ix.F.get(k),ix.D.get(short)].forEach(i=>{if(i!=null&&(best<0||i<best))best=i});
if(best>=0){const r=DB.ServerMI[best];if(r&&srvMatch(r,k,short))return best}else if(DB.ServerMI.length>400)return -1;
return DB.ServerMI.findIndex(r=>srvMatch(r,k,short))}
function physDups(){const o=[];DB.RackDevices.forEach((r,i)=>{if(isEncl(r))return;const j=srvFind(r.Name);if(j>=0)o.push({i:i,j:j,r:r,s:DB.ServerMI[j]})});return o}
const MERGE_COLS=['DC','Rack','U start','U size','Model','Serial','Support end','iLO URL'];
function mergeDup(i){const r=DB.RackDevices[i];if(!r)return null;const j=srvFind(r.Name);if(j<0)return null;const s=DB.ServerMI[j],o=r.Name,n=s.Hostname;
MERGE_COLS.forEach(k=>{if((s[k]==null||s[k]==='')&&r[k]!=null&&r[k]!=='')s[k]=r[k]});
if(!s.Platform||s.Platform==='Virtual')s.Platform='Physical';
if(r.Notes){s.Notes=(s.Notes?s.Notes+'\n':'')+'From Other devices: '+r.Notes}
s.Updated=ds(0);if(o!==n)devRename('RackDevices',o,n);
if(RK.sel&&RK.sel.sheet==='RackDevices'){if(RK.sel.i===i)RK.sel={sheet:'ServerMI',i:j};else if(RK.sel.i>i)RK.sel.i--}
DB.RackDevices.splice(i,1);return n}
function physBanner(){const d=physDups();if(!d.length)return '';
return '<section class="card callout"><div class="tools" style="justify-content:space-between"><div><b>'+d.length+' device'+(d.length===1?' is':'s are')+' also in ServersMI:</b> '+d.slice(0,6).map(x=>'<span class="mono">'+esc(x.r.Name)+'</span>'+(srvKey(x.r.Name)!==srvKey(x.s.Hostname)?' → <span class="mono">'+esc(x.s.Hostname)+'</span>':'')).join(', ')+(d.length>6?' …':'')+'<div class="note" style="margin-top:4px">Physical servers belong in ServersMI only. Merging copies the rack position, model, serial and support date into the server, keeps its ports and disks, and removes the duplicate here.</div></div><button class="btn p" data-act="physmergeall">Merge all into ServersMI</button></div></section>'}
function srvSync(f){if(!f||f.dataset.sheet!=='ServerMI')return;const el=f.elements;if(!el.Platform)return;srvStand(f);const phys=el.Platform.value==='Physical';if(el.Blade){if(!phys)el.Blade.checked=false;el.Blade.disabled=!phys;const bl0=el.Blade.closest('label');if(bl0)bl0.style.opacity=phys?1:.45;bladeSync(f)}const bl=el.Blade&&el.Blade.checked;
['DC','Rack','U start','U size'].forEach(k=>{const e=el[k];if(!e)return;const off=!phys||(bl&&k!=='DC');e.disabled=off;const lab=e.closest('label');if(lab)lab.style.opacity=off?.45:1})}
const PHYSACT={
physmergeall(el){if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to merge';return}undoSnap('merge duplicates');let n=0;for(let g=0;g<500;g++){const d=physDups();if(!d.length)break;if(!mergeDup(d[0].i))break;n++}changed();route();toast(n+' device'+(n===1?'':'s')+' merged into ServersMI',true)},
physmerge(el){const f=$('frm'),r=DB.RackDevices[+el.dataset.i];if(f&&r&&f.elements.Name){const old=r.Name;r.Name=f.elements.Name.value.trim();if(old!==r.Name)devRename('RackDevices',old,r.Name)}const n=mergeDup(+el.dataset.i);closeForm();if(n){changed();route();toast('Merged into ServersMI: '+n)}}};

const CMB={OS:[],'Cluster/Standalone':['Cluster','Standalone']};
function isStand(v){return /^\s*stand[- ]?alone/i.test(String(v||''))}
function srvStand(f){const el=f.elements,fc=el['Failover cluster'],cs=el['Cluster/Standalone'];if(!fc||!cs)return;const st=isStand(cs.value);if(st&&fc.value)fc.value='';fc.disabled=st;const l=fc.closest('label');if(l){l.style.opacity=st?.45:1;l.title=st?'A standalone server is never a failover cluster node':''}}
function cmbNames(k){const m=new Map();(CMB[k]||[]).forEach(v=>m.set(v.toLowerCase(),v));DB.ServerMI.forEach(r=>{const v=String(r[k]||'').trim();if(v&&!m.has(v.toLowerCase()))m.set(v.toLowerCase(),v)});return[...m.values()].sort((a,b)=>a.localeCompare(b))}
function cmbField(c,v,id,cls){const names=cmbNames(c.k);v=String(v||'');if(v&&names.indexOf(v)<0)names.push(v);
return '<label class="'+cls+'" for="'+id+'">'+esc(c.label||c.k)+'<select class="inp" id="'+id+'" name="'+esc(c.k)+'_sel"><option value=""></option>'+names.map(o=>'<option'+(v===o?' selected':'')+'>'+esc(o)+'</option>').join('')+'<option value="__new__">＋ New…</option></select><input class="inp" name="'+esc(c.k)+'" type="text" placeholder="Type the new value" value="'+esc(v)+'" style="display:none;margin-top:6px"></label>'}
function cmbSel(el){const f=el.form,k=el.name.replace(/_sel$/,''),t=f.elements[k];if(el.value==='__new__'){t.style.display='';t.value='';t.focus()}else{t.style.display='none';t.value=el.value}srvStand(f)}
function cmbCanon(b){Object.keys(CMB).forEach(k=>{const v=String(b[k]||'').trim();if(!v)return;const m=cmbNames(k).find(x=>x.toLowerCase()===v.toLowerCase());b[k]=m||v})}

/* dropdowns fed by a Settings list; "New…" adds the value to that list */
const CCF=n=>({Name:n,Color:'Blue',Active:'Yes'});
const LISTCMB={'DCSSActivity.Calendar category':['CalCategories',CCF],'PatchEvents.Calendar category':['CalCategories',CCF],'DCChecks.Calendar category':['CalCategories',CCF],'DCSSActivity.Type':['ActivityTypes',n=>({Name:n,Active:'Yes'}),'syncActivityTypes'],'DCSSActivity.Status':['ActivityStatuses',n=>({Name:n,Actionable:'No',Active:'Yes'}),'syncActivityStatuses'],'PatchEvents.Status':['ActivityStatuses',n=>({Name:n,Actionable:'No',Active:'Yes'}),'syncActivityStatuses'],
'DCSSActivity.Performed by':['Operators',n=>({Name:n,Active:'Yes'})],'DCChecks.Checked by':['Operators',n=>({Name:n,Active:'Yes'})],'OpenIssues.Assignee':['Operators',n=>({Name:n,Active:'Yes'})],'OpenIssues.Raised by':['Operators',n=>({Name:n,Active:'Yes'})],
'ServerMI.Env':['Environments',n=>({Name:n,Color:'Blue',Production:'No',Active:'Yes'}),'syncEnvOptions'],'Clusters.Env':['Environments',n=>({Name:n,Color:'Blue',Production:'No',Active:'Yes'}),'syncEnvOptions'],
'DCSSActivity.Assignment group':['AssignGroups',n=>({Group:n,Active:'Yes'})],'Contacts.Assignment group':['AssignGroups',n=>({Group:n,Active:'Yes'})],'KB.Type':['KBTypes',n=>({Name:n,Active:'Yes'}),'syncKBTypes'],'BackupJobs.Type':['BackupTypes',n=>({Name:n,'Counts as backup':'Yes',Cloud:'No',Active:'Yes'}),'syncBackupTypes']};
function lcNames(sheet,k){const d=LISTCMB[sheet+'.'+k];if(!d)return null;const m=new Map();(DB[d[0]]||[]).filter(r=>r.Active!=='No').forEach(r=>{const v=String(r[lcKey(d[0])]||'').trim();if(v&&!m.has(v.toLowerCase()))m.set(v.toLowerCase(),v)});return[...m.values()]}
function lcKey(l){return SCHEMA[l]&&SCHEMA[l].key||'Name'}
function lcField(sheet,c,v,id,cls){const names=lcNames(sheet,c.k);v=String(v||'');if(v&&!names.some(x=>x.toLowerCase()===v.toLowerCase()))names.push(v);
return '<label class="'+cls+'" for="'+id+'">'+esc(c.label||c.k)+'<select class="inp" id="'+id+'" name="'+esc(c.k)+'_sel"><option value=""></option>'+names.map(o=>'<option'+(v.toLowerCase()===o.toLowerCase()?' selected':'')+'>'+esc(o)+'</option>').join('')+'<option value="__new__">＋ New…</option></select><input class="inp" name="'+esc(c.k)+'" type="text" placeholder="Type the new value (it is added to the list in Settings)" value="'+esc(v)+'" style="display:none;margin-top:6px"></label>'}
function lcBefore(sheet,b){Object.keys(LISTCMB).forEach(key=>{if(key.indexOf(sheet+'.')!==0)return;const k=key.slice(sheet.length+1),d=LISTCMB[key],v=String(b[k]==null?'':b[k]).trim();if(!v)return;const L=DB[d[0]]=DB[d[0]]||[],KK=lcKey(d[0]),hit=L.find(r=>String(r[KK]||'').trim().toLowerCase()===v.toLowerCase());
if(hit){b[k]=String(hit[KK])}else{const r={};SCHEMA[d[0]].cols.forEach(c=>{r[c.k]=''});Object.assign(r,d[1](v));L.push(r);b[k]=v}
if(d[2]&&typeof window[d[2]]==='function')try{window[d[2]]()}catch(e){}else if(d[2])try{eval(d[2]+'()')}catch(e){}})}
