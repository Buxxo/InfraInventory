/* ---------- sortable tables with column chooser for custom pages (Patching, Backup jobs) ---------- */
let CTS={};try{CTS=JSON.parse(localStorage.getItem('ii-ct')||'{}')||{}}catch(e){CTS={}}
const CTREG={},CTLIM={};
function ctSave(){try{localStorage.setItem('ii-ct',JSON.stringify(CTS))}catch(e){}}
function ctSt(id){return CTS[id]=CTS[id]||{sk:null,sd:1,hide:[],ord:null}}
function ctCols(id){const st=ctSt(id),cols=CTREG[id].cols.slice();if(st.ord){const ix=c=>{const i=st.ord.indexOf(c.k);return i<0?999:i};cols.sort((a,b)=>(a.fix?1000:ix(a))-(b.fix?1000:ix(b)))}return cols}
function ctCmp(a,b){const na=typeof a==='number',nb=typeof b==='number';if(na&&nb)return a-b;a=String(a==null?'':a);b=String(b==null?'':b);if(!a&&b)return 1;if(a&&!b)return -1;return a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})}
function ctTable(id,cols,rows){CTREG[id]={cols:cols};const st=ctSt(id),C=ctCols(id).filter(c=>c.fix||st.hide.indexOf(c.k)<0);
const sc=st.sk&&cols.find(c=>c.k===st.sk&&c.v);if(sc){rows=rows.map((x,i)=>[x,i]).sort((a,b)=>ctCmp(sc.v(a[0]),sc.v(b[0]))*st.sd||a[1]-b[1]).map(a=>a[0])}
return '<div class="tw"><table><thead><tr>'+C.map(c=>c.fix||!c.v?'<th>'+(c.l||'')+'</th>':'<th data-act="ctsort" data-t="'+id+'" data-k="'+esc(c.k)+'" aria-sort="'+(st.sk===c.k?(st.sd>0?'ascending':'descending'):'none')+'" title="Sort by '+esc(c.l||c.k)+'">'+esc(c.l||c.k)+(st.sk===c.k?(st.sd>0?' ↑':' ↓'):'')+'</th>').join('')+'</tr></thead><tbody>'
+(CTLIM[id]||(CTLIM[id]=PGS>0?Math.max(PGS,100):1e9),rows.slice(0,CTLIM[id])).map(x=>'<tr>'+C.map(c=>'<td'+(c.cls?' class="'+c.cls+'"':'')+(c.st?' style="'+c.st+'"':'')+'>'+c.h(x)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>'
+(rows.length>CTLIM[id]?'<div class="pager"><span class="note">Showing '+CTLIM[id]+' of '+rows.length+'</span><span class="pgc"><button class="btn s" data-act="ctmore" data-t="'+id+'">Show '+Math.min(Math.max(PGS,100),rows.length-CTLIM[id])+' more</button><button class="btn s" data-act="ctall" data-t="'+id+'">Show all '+rows.length+'</button></span></div>':'')}
function ctBtn(id){return '<button class="btn s" data-act="ctcols" data-t="'+id+'"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16M15 4v16"/></svg>Columns</button>'}
function ctDlg(id){const st=ctSt(id),cols=ctCols(id).filter(c=>!c.fix);
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Columns" style="width:min(460px,100%)"><h2>Columns</h2><p class="note" style="margin:0">Tick the columns to show and use the arrows to change their order. Click a column header in the table to sort by it, click again to reverse.</p><div class="ctl">'
+cols.map((c,i)=>'<div class="ctr"><label class="chkrow" style="grid-column:auto;flex:1"><input type="checkbox" data-act="ctvis" data-t="'+id+'" data-k="'+esc(c.k)+'"'+(st.hide.indexOf(c.k)<0?' checked':'')+'> '+esc(c.l||c.k)+'</label><button class="btn s" data-act="ctmove" data-t="'+id+'" data-k="'+esc(c.k)+'" data-d="-1" aria-label="Move '+esc(c.l||c.k)+' up"'+(i===0?' disabled':'')+'>↑</button><button class="btn s" data-act="ctmove" data-t="'+id+'" data-k="'+esc(c.k)+'" data-d="1" aria-label="Move '+esc(c.l||c.k)+' down"'+(i===cols.length-1?' disabled':'')+'>↓</button></div>').join('')
+'</div><div class="acts"><button class="btn" data-act="ctreset" data-t="'+id+'">Reset to default</button><button class="btn p" data-act="mclose">Done</button></div></div></div>'}
const CTACT={
ctmore(el){const id=el.dataset.t;CTLIM[id]=(CTLIM[id]||100)+Math.max(PGS,100);route()},
ctall(el){CTLIM[el.dataset.t]=1e9;route()},
ctsort(el){const st=ctSt(el.dataset.t),k=el.dataset.k;if(st.sk===k){if(st.sd>0)st.sd=-1;else{st.sk=null;st.sd=1}}else{st.sk=k;st.sd=1}ctSave();route()},
ctcols(el){ctDlg(el.dataset.t)},
ctvis(el){const st=ctSt(el.dataset.t),k=el.dataset.k;st.hide=st.hide.filter(x=>x!==k);if(!el.checked)st.hide.push(k);ctSave();route();ctDlg(el.dataset.t)},
ctmove(el){const id=el.dataset.t,st=ctSt(id),o=ctCols(id).filter(c=>!c.fix).map(c=>c.k),i=o.indexOf(el.dataset.k),j=i+(+el.dataset.d);if(j<0||j>=o.length)return;o.splice(j,0,o.splice(i,1)[0]);st.ord=o;ctSave();route();ctDlg(id)},
ctreset(el){CTS[el.dataset.t]={sk:null,sd:1,hide:[],ord:null};ctSave();route();ctDlg(el.dataset.t)}};
