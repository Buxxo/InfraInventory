/* ---------- Overview calendar ---------- */
const CAL={a:null,sel:null,off:{},mode:'month'};
const CAL_SRC=[
{k:'act',sheet:'DCSSActivity',label:'DCSS Activity',c:'#5B8DFF',title:r=>r.Title,date:r=>r.Date,meta:r=>[r.Type,r.DC,r.Status].filter(Boolean).join(' · ')},
{k:'pat',sheet:'PatchEvents',label:'Patching',c:'#3DDC97',title:r=>(r.Title||'Patching')+(r.CRQ?' ('+r.CRQ+')':''),date:r=>r.Date,meta:r=>[r.Status,r.Servers?String(r.Servers).split(/\r?\n/).filter(Boolean).length+' servers':''].filter(Boolean).join(' · ')},
{k:'chk',sheet:'DCChecks',label:'DC checks',c:'#FFB547',title:r=>'DC check '+(r.DC||''),date:r=>r.Date,meta:r=>[r['Checked by'],r.Result].filter(Boolean).join(' · ')}];
const CC_PAL={Blue:'#5B8DFF',Green:'#3DDC97',Amber:'#FFB547',Red:'#FF6B6B',Purple:'#A98BFF',Teal:'#3DE0D0',Pink:'#FF7EC8',Grey:'#9AA7B8'};
function ccColor(n,d){return CC_PAL[n]||d||CC_PAL.Blue}
function calCat(s,r){return String(r['Calendar category']||'').trim()||s.label}
function calCatColor(n){const h=(DB.CalCategories||[]).find(x=>String(x.Name).toLowerCase()===String(n).toLowerCase());return h?h.Color:''}
function calCatList(){const l=(DB.CalCategories||[]).filter(x=>x.Active!=='No').map(x=>String(x.Name));CAL_SRC.forEach(s=>(DB[s.sheet]||[]).forEach(r=>{const n=calCat(s,r);if(l.indexOf(n)<0&&r['In calendar']!=='No')l.push(n)}));return l}

function calEvents(){return calEv0(true)}
function calEventsAll(){return calEv0(false)}
function calEv0(f){
const ev={};
CAL_SRC.forEach(s0=>{(DB[s0.sheet]||[]).forEach(r=>{if(r['In calendar']==='No')return;const cn=calCat(s0,r);if(f&&CAL.off[cn])return;const s=Object.assign({},s0,{cat:cn,label:cn,c:ccColor(calCatColor(cn),s0.c)});const d=String(s.date(r)||'').slice(0,10);if(!/^\d{4}-\d\d-\d\d$/.test(d))return;
let e=String(r['End date']||'').slice(0,10);if(!/^\d{4}-\d\d-\d\d$/.test(e)||e<=d||s.sheet==='DCChecks')e=d;
const t=String(s.title(r)||''),rng=e>d?d+' → '+e:'';let cur=d,n=0;
while(cur<=e&&n<92){(ev[cur]=ev[cur]||[]).push({s:s,r:r,t:t,cont:cur!==d,rng:rng});cur=CADD(cur,1);n++}})});
return ev}
const CD=s=>new Date(s+'T00:00:00'),CF=d=>d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate());
const CADD=(s,n)=>{const d=CD(s);d.setDate(d.getDate()+n);return CF(d)};
const CMON=s=>{const d=CD(s);return CADD(s,-((d.getDay()+6)%7))};
const DOW=['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
function calA(){if(!CAL.a)CAL.a=ds(0);return CAL.a}
const calDone=x=>/^(Done|Completed)$/i.test(String(x.r.Status||''));
function calChip(x,full){return '<a href="#" class="ce'+(full?' full':'')+(x.cont?' cont':'')+(calDone(x)?' done':'')+'" data-act="calopen" data-k="'+x.s.k+'" data-i="'+DB[x.s.sheet].indexOf(x.r)+'" style="--c:'+x.s.c+'" title="'+esc(x.s.label+': '+x.t+(x.rng?' ('+x.rng+')':'')+(x.s.meta(x.r)?' · '+x.s.meta(x.r):''))+'">'+(x.cont?'↳ ':'')+(calDone(x)?'✓ ':'')+esc(x.t)+(full&&(x.rng||x.s.meta(x.r))?'<small>'+esc((x.rng?x.rng+' · ':'')+x.s.meta(x.r))+'</small>':'')+'</a>'}
function calCardEv(x){return '<a class="evc'+(calDone(x)?' done':'')+'" href="#" data-act="calopen" data-k="'+x.s.k+'" data-i="'+DB[x.s.sheet].indexOf(x.r)+'" style="--c:'+x.s.c+'"><span><b>'+esc(x.t)+'</b><span class="em">'+esc((x.rng?x.rng+' · ':'')+x.s.meta(x.r))+'</span></span><span class="tag">'+esc(x.s.label)+'</span></a>'}
function calAddBtns(d){return CAL_SRC.map(s=>'<button class="btn s" data-act="caladd" data-k="'+s.k+'" data-d="'+d+'">+ '+esc(s.label)+'</button>').join('')}
/* this week, used on Overview */
function calCard(){
const ev=calEvents(),today=ds(0),mon=CMON(today);let cols='';
for(let i=0;i<7;i++){const d=CADD(mon,i),e=ev[d]||[],dt=CD(d);
cols+='<div class="wd'+(d===today?' today':'')+'"><div class="wh"><span>'+DOW[i]+'</span><b>'+dt.getDate()+'</b></div>'+(e.length?e.map(x=>calChip(x,1)).join(''):'<span class="note" style="margin:0">—</span>')+'</div>'}
const n=Object.keys(ev).filter(d=>d>=mon&&d<=CADD(mon,6)).reduce((a,d)=>a+ev[d].length,0);
return '<section class="card" id="calcard"><div class="tools" style="justify-content:space-between"><h2 style="margin:0">This week <span class="note" style="margin-left:8px">'+CD(mon).toLocaleString('en-GB',{day:'numeric',month:'short'})+' – '+CD(CADD(mon,6)).toLocaleString('en-GB',{day:'numeric',month:'short',year:'numeric'})+' · '+n+' event'+(n===1?'':'s')+'</span></h2><a class="btn s" href="#calendar">Open calendar</a></div><div class="weekgrid" style="margin-top:12px">'+cols+'</div></section>'}
/* calendar page */
function calMonthHtml(){
const a=calA(),d0=CD(a),y=d0.getFullYear(),m=d0.getMonth(),ev=calEvents(),today=ds(0);
const first=new Date(y,m,1),off=(first.getDay()+6)%7,dim=new Date(y,m+1,0).getDate();let cells='';
const total=Math.ceil((off+dim)/7)*7;
for(let i=0;i<total;i++){const day=i-off+1,col=i%7;if(day<1||day>dim){const ds2=CF(new Date(y,m,day));cells+='<div class="cd out" data-act="calday" data-d="'+ds2+'"><div class="dn"><b>'+new Date(y,m,day).getDate()+'</b></div></div>';continue}
const key=y+'-'+pad(m+1)+'-'+pad(day),e=ev[key]||[];
cells+='<div class="cd'+(key===today?' today':'')+(key===CAL.sel?' sel':'')+(col>4?' we':'')+(key<today?' past':'')+'" data-act="calday" data-d="'+key+'" tabindex="0"><div class="dn"><b>'+day+'</b>'+(e.length>3?'<span class="cnt">'+e.length+'</span>':'')+'</div>'+e.slice(0,3).map(x=>calChip(x)).join('')+(e.length>3?'<span class="cm">+'+(e.length-3)+' more</span>':'')+(e.length?'<span class="dots">'+e.slice(0,5).map(x=>'<i style="--c:'+x.s.c+'"></i>').join('')+'</span>':'')+'</div>'}
return '<div class="calgrid big">'+DOW.map(d=>'<div class="ch">'+d+'</div>').join('')+cells+'</div>'}
function calWeekHtml(){
const a=calA(),mon=CMON(a),ev=calEvents(),today=ds(0);let cols='';
for(let i=0;i<7;i++){const d=CADD(mon,i),e=ev[d]||[];
cols+='<div class="wd'+(d===today?' today':'')+'"><div class="wh"><span>'+DOW[i]+'</span><b>'+CD(d).getDate()+'</b></div>'+(e.length?e.map(x=>calChip(x,1)).join(''):'<span class="note" style="margin:0">Nothing</span>')+'<button class="btn s" data-act="calday" data-d="'+d+'" style="margin-top:auto">Details / add</button></div>'}
return '<div class="weekgrid tall">'+cols+'</div>'}
function calAgendaHtml(){
const a=calA(),d0=CD(a),y=d0.getFullYear(),m=d0.getMonth(),ev=calEvents(),pre=y+'-'+pad(m+1),keys=Object.keys(ev).filter(k=>k.slice(0,7)===pre).sort(),today=ds(0);
if(!keys.length)return '<div class="empty">No events in this month.</div>';
return keys.map(k=>{const d=CD(k);return '<div class="agd'+(k===today?' today':'')+'"><div class="agh"><small>'+d.toLocaleString('en-GB',{weekday:'short'})+'</small><b>'+d.getDate()+'</b><span>'+d.toLocaleString('en-GB',{month:'short'})+'</span></div><div class="evs">'+ev[k].map(calCardEv).join('')+'</div></div>'}).join('')}
function calSide(ev,sel,today,a){
const d=CD(sel),diff=Math.round((d-CD(today))/864e5),rel=diff===0?'Today':diff===1?'Tomorrow':diff===-1?'Yesterday':diff>0?'In '+diff+' days':(-diff)+' days ago';
const se=ev[sel]||[];
const hero='<div class="dayhero"><div class="rel"><small>'+esc(d.toLocaleString('en-GB',{weekday:'long'}))+' · '+rel+'</small><div class="big"><b>'+d.getDate()+'</b><span>'+esc(d.toLocaleString('en-GB',{month:'long',year:'numeric'}))+'</span></div></div><div class="dayadd">'+CAL_SRC.map(s=>'<button class="btn s" data-act="caladd" data-k="'+s.k+'" data-d="'+sel+'" style="--c:'+s.c+'">+ '+esc(s.label)+'</button>').join('')+'</div></div>';
const day='<section class="card"><h2>'+(se.length?se.length+' event'+(se.length>1?'s':''):'Nothing planned')+'</h2><div class="dayevs" style="margin-top:10px">'+(se.length?se.map(calCardEv).join(''):'<p class="note" style="margin:0">This day is free. Add an activity, patch event or DC check above.</p>')+'</div></section>';
const pre=a.slice(0,7),cnt={},ccol={};let tot=0;calCatList().forEach(n=>cnt[n]=0);Object.keys(ev).filter(k=>k.slice(0,7)===pre).forEach(k=>ev[k].forEach(x=>{if(!x.cont){cnt[x.s.cat]=(cnt[x.s.cat]||0)+1;ccol[x.s.cat]=x.s.c;tot++}}));
const mx=Math.max(1,...Object.keys(cnt).map(k=>cnt[k]));
const stat='<section class="card"><h2>'+esc(CD(a).toLocaleString('en-GB',{month:'long'}))+' at a glance <span class="note" style="margin-left:6px">'+tot+' total</span></h2><div class="mstat" style="margin-top:12px">'+Object.keys(cnt).filter(n=>cnt[n]).map(n=>'<div class="r" style="--c:'+ccol[n]+'"><i></i><span>'+esc(n)+'</span><b class="mono">'+cnt[n]+'</b><div class="t"><s style="width:'+Math.round(cnt[n]/mx*100)+'%"></s></div></div>').join('')+'</div></section>';
const up=[];Object.keys(ev).filter(k=>k>=today).sort().forEach(k=>ev[k].forEach(x=>{if(!x.cont&&up.length<6)up.push([k,x])}));
const upc='<section class="card"><h2>Coming up</h2><div class="upn" style="margin-top:8px">'+(up.length?up.map(u=>{const dd=CD(u[0]);return '<a href="#" data-act="calopen" data-k="'+u[1].s.k+'" data-i="'+DB[u[1].s.sheet].indexOf(u[1].r)+'" style="--c:'+u[1].s.c+'"><span class="d"><b>'+dd.getDate()+'</b><small>'+dd.toLocaleString('en-GB',{month:'short'})+'</small></span><span class="t"><b>'+esc(u[1].t)+'</b><span>'+esc(u[1].s.label)+'</span></span></a>'}).join(''):'<p class="note" style="margin:0">Nothing coming up.</p>')+'</div></section>';
return hero+day+stat+upc}
function calendarView(){
const a=calA(),d0=CD(a),mode=CAL.mode,ev=calEvents(),today=ds(0);
const mon=CD(CMON(a)),title=mode==='week'?'<span>'+esc(mon.toLocaleString('en-GB',{day:'numeric',month:'short'}))+' – '+esc(CD(CADD(CMON(a),6)).toLocaleString('en-GB',{day:'numeric',month:'short'}))+'</span> <em>'+CD(CADD(CMON(a),6)).getFullYear()+'</em>':'<span>'+esc(d0.toLocaleString('en-GB',{month:'long'}))+'</span> <em>'+d0.getFullYear()+'</em>';
const body=mode==='week'?calWeekHtml():mode==='agenda'?calAgendaHtml():calMonthHtml();
const seg=(k,l)=>'<button class="chip'+(mode===k?' on':'')+'" data-act="calmode" data-v="'+k+'">'+l+'</button>';
const pre=a.slice(0,7),cnt={},ccol={};const cats=calCatList();cats.forEach(n=>{cnt[n]=0;ccol[n]=ccColor(calCatColor(n),'#5B8DFF')});const ea=calEventsAll();Object.keys(ea).filter(k=>k.slice(0,7)===pre).forEach(k=>ea[k].forEach(x=>{if(!x.cont){cnt[x.s.cat]=(cnt[x.s.cat]||0)+1}}));
return head('Calendar','DCSS activities, patching events and DC checks. Tick “In calendar” on an event to show it here.','<button class="btn p" data-act="caladd" data-k="act" data-d="'+(CAL.sel||today)+'">+ Add event</button>')
+'<div class="calpage'+(mode==='week'?' wk':'')+'"><section class="card calmain" id="calcard"><div class="calbar"><div class="calnav"><h2 class="caltitle">'+title+'</h2></div><div class="calnav"><button class="btn s" data-act="calnav" data-n="-1" aria-label="Previous">‹</button><button class="btn s" data-act="calnav" data-n="0">Today</button><button class="btn s" data-act="calnav" data-n="1" aria-label="Next">›</button><input class="inp" type="date" id="cal-jump" data-act="caljumpx" value="'+a+'" aria-label="Go to date" style="width:auto;height:32px"><div class="chips" style="margin-left:6px">'+seg('month','Month')+seg('week','Week')+seg('agenda','Agenda')+'</div></div></div>'
+'<div class="calfilters">'+cats.map(n=>'<button class="chip lay'+(CAL.off[n]?'':' on')+'" data-act="calflt" data-k="'+esc(n)+'" style="--c:'+ccol[n]+'" aria-pressed="'+(!CAL.off[n])+'"><i></i>'+esc(n)+' <em>'+(cnt[n]||0)+'</em></button>').join('')+'</div>'+body+'</section><aside class="calside" aria-label="Selected day">'+calSide(ev,CAL.sel||today,today,a)+'</aside></div>'}
function calJump(el){if(el.value){CAL.a=el.value;calRedraw()}}
function calRedraw(){if(CUR==='calendar')$('view').innerHTML=calendarView()}
const CALACT={
calnav(el){const n=+el.dataset.n,a=calA();if(!n)CAL.a=ds(0);else if(CAL.mode==='week')CAL.a=CADD(a,7*n);else{const d=CD(a);d.setDate(1);d.setMonth(d.getMonth()+n);CAL.a=CF(d)}calRedraw()},
calmode(el){CAL.mode=el.dataset.v;calRedraw()},
calday(el){const d=el.dataset.d;CAL.sel=d||null;if(d)CAL.a=d;calRedraw()},
calflt(el){CAL.off[el.dataset.k]=!CAL.off[el.dataset.k];calRedraw()},
calopen(el){const s=CAL_SRC.find(x=>x.k===el.dataset.k);openForm(s.sheet,+el.dataset.i)},
caladd(el){const s=CAL_SRC.find(x=>x.k===el.dataset.k);if(s.sheet==='PatchEvents'){openPtBulk('',el.dataset.d);return}openForm(s.sheet,null,{Date:el.dataset.d})}};
