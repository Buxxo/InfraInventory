/* ---------- Activity log (who changed what, written to the workbook on every save) ---------- */
let USER='';try{USER=localStorage.getItem('infra-user')||''}catch(e){}
let SNAP=null,PENDLOG=[],USERRES=null;
const LOGSKIP={ActivityLog:1},LOGHIDE={ActivityLog:1,Todos:1};
function rid(sheet,r){const g=k=>String(r[k]==null?'':r[k]);return sheet==='DCMI'||sheet==='RackList'?g('DC')+'/'+g('Rack'):sheet==='BackupAssign'?g('Server')+' / '+g('Job'):sheet==='NetPorts'?g('Device')+' / '+g('Port'):sheet==='Disks'?g('Device')+' / '+g('Slot'):sheet==='DCChecks'?g('Date').slice(0,10)+' '+g('DC'):g(SCHEMA[sheet].key)}
function snap(){const o={};SHEETS.forEach(s=>{if(LOGSKIP[s])return;const m=new Map(),cnt={};(DB[s]||[]).forEach(r=>{let k=rid(s,r);cnt[k]=(cnt[k]||0)+1;if(cnt[k]>1)k+=' #'+cnt[k];const c={};Object.keys(r).forEach(h=>{if(h!=='Updated')c[h]=r[h]==null?'':String(r[h])});m.set(k,c)});o[s]=m});return o}
function logChanges(){
DB.ActivityLog=DB.ActivityLog.filter(r=>PENDLOG.indexOf(r)<0);PENDLOG=[];
if(!SNAP)return;
const now=snap(),t=nowStr(),out=[];
const mk=(a,s,rec,det)=>({Time:t,User:USER,Action:a,Sheet:s?SCHEMA[s].label:'',Record:rec,Details:det||'',Updated:ds(0)});
const sh=v=>{v=String(v==null?'':v).replace(/\s+/g,' ');return v.length>40?v.slice(0,38)+'…':v};
SHEETS.forEach(s=>{if(LOGHIDE[s])return;const a=SNAP[s]||new Map(),b=now[s],add=[],del=[],chg=[];
b.forEach((c,k)=>{const o=a.get(k);if(!o)add.push(k);else{const fs=[];Object.keys(c).concat(Object.keys(o)).forEach(h=>{if(fs.indexOf(h)<0&&(c[h]||'')!==(o[h]||''))fs.push(h)});if(fs.length)chg.push([k,fs.map(h=>h+': '+(sh(o[h])||'∅')+' → '+(sh(c[h])||'∅')).join('; ').slice(0,500)])}});
a.forEach((c,k)=>{if(!b.has(k))del.push(k)});
if(add.length>25)out.push(mk('Added',s,'('+add.length+' records)'));else add.forEach(k=>out.push(mk('Added',s,k)));
if(chg.length>25)out.push(mk('Changed',s,'('+chg.length+' records)'));else chg.forEach(x=>out.push(mk('Changed',s,x[0],x[1])));
if(del.length>25)out.push(mk('Deleted',s,'('+del.length+' records)'));else del.forEach(k=>out.push(mk('Deleted',s,k)))});
if(!out.length)out.push(mk('Saved','','','No data changes'));
out.forEach(r=>DB.ActivityLog.push(r));PENDLOG=out}
function askUser(){if(SEC.on&&SEC.user){secSetUser();return Promise.resolve(true)}return new Promise(res=>{USERRES=res;
$('modal').innerHTML='<div class="modal"><div class="dlg" role="dialog" aria-modal="true" aria-label="Your name" style="width:min(460px,100%)"><h2>Who is saving?</h2><p class="note" style="margin:0">Pick your name from the Operators list. It is written to the Activity log next to every change you save and kept in this browser only. Missing? Add yourself in Settings → Operators.</p><input class="inp" id="u-name" list="u-list" placeholder="Pick your operator name" value="'+esc(USER)+'"><datalist id="u-list">'+DB.Operators.filter(o=>o.Active!=='No').map(o=>'<option value="'+esc(o.Name)+'">').join('')+'</datalist><div class="acts"><span></span><div class="tools"><button class="btn" data-act="usercancel">Cancel</button><button class="btn p" data-act="userok">Continue</button></div></div></div></div>';
setTimeout(()=>{const e=$('u-name');if(e)e.focus()},30)})}
function logPre(){
return '<section class="card"><div class="tools" style="justify-content:space-between"><div><b>Working as: '+(USER?esc(USER):'not set')+'</b> '+(SEC.on?'<span class="note" style="margin:0">(login)</span>':'<button class="btn s" data-act="logwho">'+(USER?'Change name':'Set my name')+'</button>')+'</div><div class="tools"><span class="note" style="margin:0">Delete entries older than</span><input class="inp" id="log-days" type="number" value="90" min="1" style="width:80px;height:32px" aria-label="Days"><span class="note" style="margin:0">days</span><button class="btn s d" data-act="logtrim">Delete</button></div></div>'
+'<p class="note" style="margin:10px 0 0">Every “Save to Excel” adds what was added, changed or deleted since the page loaded the workbook. The name is the one entered on this computer (the browser cannot read the Windows user), so treat it as a team convention, not proof. Select rows with the checkboxes to delete single entries.</p></section>'}
const LOGACT={
oplog(el){uiOf('ActivityLog').q=el.dataset.n;location.hash='#activitylog'},
logwho(){askUser().then(ok=>{if(ok)route()})},
userok(){let v=($('u-name').value||'').trim();if(!v)return;const act=DB.Operators.filter(o=>o.Active!=='No');if(act.length){const m=act.find(o=>String(o.Name).toLowerCase()===v.toLowerCase());if(!m){toast('Pick a name from the Operators list (Settings → Operators).');return}v=String(m.Name)}USER=v;try{localStorage.setItem('infra-user',v)}catch(e){}closeForm();if(USERRES){USERRES(true);USERRES=null}},
usercancel(){closeForm();if(USERRES){USERRES(false);USERRES=null}},
logtrim(el){if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to delete';return}
const days=parseInt($('log-days').value);if(!(days>=1)){el.dataset.arm='';el.textContent='Delete';return}
const cut=ds(-days),n0=DB.ActivityLog.length;DB.ActivityLog=DB.ActivityLog.filter(r=>String(r.Time||'').slice(0,10)>=cut);
const n=n0-DB.ActivityLog.length;if(n)changed();route();toast(n+' log entr'+(n===1?'y':'ies')+' deleted')}};
