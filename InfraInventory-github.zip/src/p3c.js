
/* ---------- CSV export of the current view ---------- */
function viewRows(sheet){
const t=TV[sheet],u=uiOf(sheet);
let rows=DB[sheet].map((r,i)=>({r:r,i:i}));
rows=rows.filter(x=>fmatch(u,t,x.r));
rows=applyFilters(sheet,rows);
if(u.q){const q=u.q.toLowerCase();rows=rows.filter(x=>Object.keys(x.r).some(k=>k!=='Updated'&&String(x.r[k]).toLowerCase().includes(q)))}
rowsSort(rows,u);
return rows;
}
async function exportCsv(sheet,selOnly){
const t=TV[sheet],u=uiOf(sheet),sep=META.csvSep||';',rows=viewRows(sheet).filter(x=>!selOnly||selSet(sheet).has(x.r)),cols=t.show;
if(!rows.length){toast('Nothing to export. The current view has no rows.');return}
const q=v=>{let s=v==null?'':String(v);if(/^[=+@]/.test(s)||(/^-/.test(s)&&isNaN(Number(s))))s="'"+s;return(s.indexOf(sep)>=0||/["\n\r]/.test(s))?'"'+s.replace(/"/g,'""')+'"':s};
const lines=[cols.map(c=>q(labelOf(c))).join(sep)].concat(rows.map(x=>cols.map(c=>q(val(x.r,c))).join(sep)));
const name=sheet+(u.fm&&u.fm.length?'_'+u.fm.join('+'):u.f!=='All'?'_'+u.f:'')+'_'+ds(0)+'.csv',data='﻿'+lines.join('\r\n'),msg='Exported '+rows.length+' rows to '+name;
let dl=null;try{dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null}catch(e){dl=null}
if(dl){try{await dl.save({filename:name,data:data});toast(msg)}catch(e){if(!(e&&e.code==='declined'))toast('Export failed: '+((e&&(e.message||e.code))||'unknown'))}return}
try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'text/csv;charset=utf-8'}));a.download=name;document.body.appendChild(a);a.click();a.remove();toast(msg)}catch(e){toast('Download is not available in this view')}
}
