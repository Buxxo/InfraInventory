
/* ---------- rack: place, move, remove ---------- */
const PL_DEF={ESXi:2,Storage:6,Backup:4,ServerMI:2};
const PL_NEW=[['ESXi','New ESXi host'],['Storage','New storage array'],['Backup','New backup device'],['ServerMI','New physical server'],['RackDevices','New other device']];
function plNew(){return PL_NEW.concat(DB.DeviceTypes.filter(t=>t.Active!=='No').map(t=>['RackDevices','New '+String(t.Name).toLowerCase(),t.Name]))}
function plSize(sheet,type){return sheet==='RackDevices'?typeDefU(type):(PL_DEF[sheet]||2)}
function devKey(d){return d.sheet+'|'+d.i}
function unplaced(){return devices().filter(d=>!valid(d)||!d.dc||!d.rack)}
function fits(dc,rack,u,sz,skip){
if(!(u>=1)||!(sz>=1))return 'Enter a start U of 1 or more and a size of at least 1';
if(dcRacks(dc).indexOf(String(rack))<0)return (rack||'That rack')+' does not exist in '+dc+' (racks: '+(dcRacks(dc).join(', ')||'none, add them in Settings')+')';
if(u+sz-1>rackU(dc,rack))return 'U'+u+' plus '+sz+' U goes past U'+rackU(dc,rack)+', the top of '+rack;
const c=devices().find(d=>d.dc===dc&&d.rack===rack&&valid(d)&&devKey(d)!==skip&&u<=d.u+d.sz-1&&d.u<=u+sz-1);
return c?'U'+Math.max(u,c.u)+' is already used by '+c.name:'';
}
function firstFree(dc,rack,sz,skip){for(let u=1;u+sz-1<=rackU(dc,rack);u++){if(!fits(dc,rack,u,sz,skip))return u}return 1}
function openPlace(o){
const all=devices(),un=unplaced();
let opts,size;
if(o.key){
const d=all.find(x=>devKey(x)===o.key);size=valid(d)?d.sz:plSize(d.sheet,d.r.Type);
opts='<option value="'+o.key+'" data-size="'+size+'" selected>'+esc(d.name)+' · '+devLabel(d)+'</option>';
}else{
opts=un.map(d=>'<option value="'+devKey(d)+'" data-size="'+(isNaN(d.sz)?plSize(d.sheet,d.r.Type):d.sz)+'">'+esc(d.name)+' · '+devLabel(d)+' (unplaced)</option>').join('')+plNew().map(n=>'<option value="new|'+n[0]+(n[2]?'|'+esc(n[2]):'')+'" data-size="'+plSize(n[0],n[2])+'">'+esc(n[1])+'…</option>').join('');
size=un.length&&!isNaN(un[0].sz)?un[0].sz:(un.length?plSize(un[0].sheet,un[0].r.Type):2);
}
const u=o.u!=null?o.u:firstFree(o.dc,o.rack,size,o.key||'');
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Place a device in a rack" style="width:min(520px,100%)"><h2>'+(o.key?'Move or place device':'Place a device')+'</h2>'
+'<div class="fgrid"><label class="wide" for="pl-dev">Device<select class="inp" id="pl-dev"'+(o.key?' disabled':'')+'>'+opts+'</select></label>'
+'<label for="pl-dc">Data center<select class="inp" id="pl-dc">'+DCS.map(x=>'<option'+(x===o.dc?' selected':'')+'>'+x+'</option>').join('')+'</select></label>'
+'<label for="pl-rack">Rack<select class="inp" id="pl-rack">'+dcRacks(o.dc||DCS[0]).map(x=>'<option'+(x===o.rack?' selected':'')+'>'+esc(x)+'</option>').join('')+'</select></label>'
+'<label for="pl-u">Start U (lowest U the device uses)<input class="inp" id="pl-u" type="number" min="1" value="'+u+'"></label>'
+'<label for="pl-size">Size in U<input class="inp" id="pl-size" type="number" min="1" value="'+size+'"></label></div>'
+'<p class="note" style="margin:0">U1 is the bottom of the rack. The device takes Start U up to Start U + Size − 1. “New …” opens the inventory form with the position filled in. Device types, data centers and rack sizes are managed in Settings.</p>'
+'<div id="pl-err" class="note" style="color:var(--bad-fg)" role="alert"></div>'
+'<div class="acts"><span></span><div class="tools"><button class="btn" data-act="mclose">Cancel</button><button class="btn p" data-act="doplace">Place</button></div></div></div></div>';
const f=$('pl-u');if(f)f.focus();
}
function doPlace(){
const v=$('pl-dev').value,dc=$('pl-dc').value,rack=$('pl-rack').value,u=parseInt($('pl-u').value),sz=parseInt($('pl-size').value);
const isNew=v.indexOf('new|')===0;
const err=fits(dc,rack,u,sz,isNew?'':v);
if(err){$('pl-err').textContent=err;return}
if(isNew){const pp=v.split('|'),pre={DC:dc,Rack:rack,'U start':u,'U size':sz};if(pp[2])pre.Type=pp[2];if(pp[1]==='ServerMI')pre.Platform='Physical';closeForm();openForm(pp[1],null,pre);return}
const p=v.split('|'),r=DB[p[0]][+p[1]];
r.DC=dc;r.Rack=rack;r['U start']=u;r['U size']=sz;r.Updated=ds(0);
RK.dc=dc;RK.sel={sheet:p[0],i:+p[1]};
closeForm();changed();route();toast((r[SCHEMA[p[0]].key])+' placed in '+dc+' '+rack+' at U'+u);
}
function removeFromRack(sheet,i){
const r=DB[sheet][i],n=r[SCHEMA[sheet].key];
r.Rack='';r['U start']='';r['U size']='';r.Updated=ds(0);
RK.sel=null;changed();route();toast(n+' removed from the rack. It stays in the inventory as unplaced.');
}
