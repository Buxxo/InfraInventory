/* ---------- v2 shell: collapsible nav groups, command palette (Ctrl+K), section nav ---------- */
let NAVC={};try{NAVC=JSON.parse(localStorage.getItem('ii-navc')||'{}')||{}}catch(e){NAVC={}}
function navSave(){try{localStorage.setItem('ii-navc',JSON.stringify(NAVC))}catch(e){}}
const CK={q:'',i:0,items:[]};
function ckSources(){const o=[];
NAV.forEach(g=>g[1].forEach(v=>o.push({k:'page',t:v[1],s:g[0]||'Pages',go:'#'+v[0],ic:v[0]})));
[['ServerMI','Hostname','Server',['IP','OS']],['Clusters','Cluster','Failover cluster',['Cluster IP','Quorum type']],['ESXi','Hostname','ESXi host',['Cluster','DC']],['Storage','Array','Storage',['DC','Model']],['Backup','Device','Backup device',['DC','Type']],['RackDevices','Name','Other device',['Type','DC']],['Datastores','Datastore','Datastore',['Cluster','DC']],['ArrayVolumes','Volume','Array volume',['Array','LUN ID']],['DatastoreClusters','Datastore cluster','Datastore cluster',['DC','SDRS automation']],['DrsRules','Rule','DRS rule',['Cluster','Type']],['RemoteCopyGroups','Group','Remote copy group',['Source array','Target array']],['Contacts','Name','Contact',['Role','Company / team']],['KB','Title','KB article',['ID','Type']],['OpenIssues','Title','Open issue',['ID','Status']],['Issues','Title','DC issue',['ID','Status']]].forEach(a=>{const sh=a[0];if(!DB[sh])return;DB[sh].forEach((r,i)=>{const n=r[a[1]];if(n)o.push({k:'rec',t:String(n),s:a[2],d:a[3].map(c=>r[c]).filter(Boolean).join(' · '),sh:sh,i:i,ic:SHEET_VIEW[sh]||'servermi'})})});return o}
function ckFilter(){const q=CK.q.trim().toLowerCase(),all=ckSources();if(!q){CK.items=all.filter(x=>x.k==='page').slice(0,40);return}
const sc=x=>{const t=x.t.toLowerCase(),d=(x.d||'').toLowerCase();return t===q?0:t.indexOf(q)===0?1:t.indexOf(q)>=0?2:d.indexOf(q)>=0?3:9};
CK.items=all.map(x=>[sc(x),x]).filter(a=>a[0]<9).sort((a,b)=>a[0]-b[0]||(a[1].k==='page'?-1:1)).slice(0,40).map(a=>a[1])}
function ckList(){if(CK.i>=CK.items.length)CK.i=Math.max(0,CK.items.length-1);let last='';
return CK.items.length?CK.items.map((x,j)=>{const h=x.s!==last?'<div class="ckh">'+esc(x.s)+'</div>':'';last=x.s;return h+'<button class="cki'+(j===CK.i?' on':'')+'" data-act="ckgo" data-j="'+j+'"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">'+(IC[x.ic==='activitylog'?'log':x.ic]||IC.servermi)+'</svg><span class="ckt">'+esc(x.t)+'</span>'+(x.d?'<span class="ckd">'+esc(x.d)+'</span>':'')+'</button>'}).join(''):'<div class="ckempty">Nothing found for “'+esc(CK.q)+'”</div>'}
function openCk(){CK.q='';CK.i=0;ckFilter();
$('modal').innerHTML='<div class="modal cmdk" data-act="mbg"><div class="dlg ckdlg" role="dialog" aria-modal="true" aria-label="Search"><div class="ckin"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg><input id="ck-q" data-act="ckq" placeholder="Search pages, servers, hosts, arrays, datastores, contacts, articles…" autocomplete="off" aria-label="Search"><kbd>Esc</kbd></div><div class="ckl" id="ck-l" role="listbox">'+ckList()+'</div><div class="ckf"><span><kbd>↑</kbd><kbd>↓</kbd> move</span><span><kbd>Enter</kbd> open</span><span><kbd>Ctrl</kbd><kbd>K</kbd> anywhere</span></div></div></div>';
setTimeout(()=>{const i=$('ck-q');if(i)i.focus()},20)}
function ckDraw(){const l=$('ck-l');if(l){l.innerHTML=ckList();const on=l.querySelector('.cki.on');if(on&&on.scrollIntoView)on.scrollIntoView({block:'nearest'})}}
function ckGo(j){const x=CK.items[j];if(!x)return;closeForm();if(x.sh==='Clusters'){CLS.sel=x.t;location.hash='#clusters';return}if(x.k==='page'){location.hash=x.go;return}
const id=SHEET_VIEW[x.sh]||({Contacts:'contacts',KB:'kb',OpenIssues:'tracker',Issues:'issues'})[x.sh];
if(x.sh==='KB'||x.sh==='OpenIssues'||x.sh==='Issues'){location.hash='#'+id;return}
if(UI[x.sh])UI[x.sh].q=x.t;else if(TV[x.sh])uiOf(x.sh).q=x.t;location.hash='#'+id;setTimeout(()=>openForm(x.sh,x.i),80)}
document.addEventListener('keydown',e=>{
if((e.ctrlKey||e.metaKey)&&(e.key==='k'||e.key==='K')){e.preventDefault();if($('ck-q'))closeForm();else openCk();return}
if(e.target&&e.target.id==='ck-q'){if(e.key==='ArrowDown'){e.preventDefault();CK.i=Math.min(CK.items.length-1,CK.i+1);ckDraw()}else if(e.key==='ArrowUp'){e.preventDefault();CK.i=Math.max(0,CK.i-1);ckDraw()}else if(e.key==='Enter'){e.preventDefault();ckGo(CK.i)}}});
document.addEventListener('input',e=>{if(e.target&&e.target.id==='ck-q'){CK.q=e.target.value;CK.i=0;ckFilter();ckDraw()}});
document.addEventListener('click',e=>{const m=document.querySelectorAll('details.menu[open]');m.forEach(d=>{if(!d.contains(e.target))d.removeAttribute('open')})});
function postRender(){
if(CUR==='settings'){const secs=[...document.querySelectorAll('#view section.card')].map((s,i)=>{const h=s.querySelector('h2');if(!h)return null;s.id='set-'+i;return [s.id,h.textContent.trim()]}).filter(Boolean);
const hd=document.querySelector('#view .head');if(hd&&secs.length>2&&!document.querySelector('#view .subnav')){const nv=document.createElement('nav');nv.className='subnav';nv.setAttribute('aria-label','Settings sections');nv.innerHTML=secs.map(s=>'<a href="#" data-act="subgo" data-id="'+s[0]+'">'+esc(s[1])+'</a>').join('');hd.insertAdjacentElement('afterend',nv)}}}
const SHELLACT={
navgrp(el){const g=el.dataset.g;NAVC[g]=!NAVC[g];navSave();renderSide()},
ckopen(){openCk()},
ckgo(el){ckGo(+el.dataset.j)},
subgo(el){const s=$(el.dataset.id);if(s)s.scrollIntoView({behavior:'smooth',block:'start'})}};
