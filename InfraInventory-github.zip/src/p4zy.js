/* ===== List views: rich rows, split preview, cards, grouped cards, saved views, compare, density, quick actions ===== */
const LV_ON=['table','split','cards','grouped'],LV_LBL={table:'Table',split:'Split',cards:'Cards',grouped:'Grouped'};
let LVIEWS=(()=>{try{return JSON.parse(localStorage.getItem('infra-views')||'{}')||{}}catch(e){return {}}})();
function lvSave(){try{localStorage.setItem('infra-views',JSON.stringify(LVIEWS))}catch(e){}}
function isDense(){try{return document.documentElement.classList.contains('dense')}catch(e){return false}}
function dense(on){const h=document.documentElement;if(!h)return false;if(on===undefined)on=!h.classList.contains('dense');h.classList.toggle('dense',on);try{localStorage.setItem('infra-dense',on?'1':'0')}catch(e){}return on}
try{if(localStorage.getItem('infra-dense')==='1')document.documentElement.classList.add('dense')}catch(e){}
function rowTone(sheet,r){
if(sheet==='ServerMI'){try{const p=patchInfo(r);if(p.st==='Overdue')return 'bad';if(p.st==='Due soon')return 'warn';if(p.st==='Compliant')return 'ok'}catch(e){}return ''}
if(expired(r))return 'bad';const u=num(r['Used %']);if(r['Used %']!==undefined&&r['Used %']!==''&&u>=85)return 'bad';
if(r.State==='Failed'||r.State==='Predictive fail'||/^(Failed|Offline|Issue|Critical)$/.test(String(r.Status||r.Result||'')))return 'bad';
if(soon(r)||(r['Used %']!==''&&r['Used %']!==undefined&&u>=70))return 'warn';return ''}
function cellTone(c,r){if(c==='Support end'){const d=daysTo(r[c]);return d===null?'':d<0?'tn-bad':d<=90?'tn-warn':''}
if(c==='Last patched'){const d=daysTo(r[c]);return d!==null&&-d>120?'tn-warn':''}return ''}
function patchPill(sheet,r){if(sheet!=='ServerMI')return '';try{const p=patchInfo(r);if(p.left===undefined)return '';return '<span class="badge '+(p.left<0?'b-bad':p.left<=PWARN?'b-warn':'b-ok')+'">'+(p.left<0?'Overdue '+(-p.left)+' d':'Patch in '+p.left+' d')+'</span>'}catch(e){return ''}}
function qaHtml(sheet,i,r){const k=recKey(sheet,i);return '<span class="rqa" aria-label="Quick actions"><button type="button" class="qa" data-act="rowopen" data-sheet="'+sheet+'" data-i="'+i+'" title="Open the full form">✎</button>'+(RELSRC[sheet]?'<button type="button" class="qa" data-act="gorel" data-s="'+sheet+'" data-i="'+i+'" title="Relations">⌖</button>':'')+'<button type="button" class="qa" data-act="pinrec" data-s="'+sheet+'" data-i="'+i+'" title="Pin to home">'+(pinned(sheet,k)?'★':'☆')+'</button><button type="button" class="qa" data-act="dupe" data-sheet="'+sheet+'" data-i="'+i+'" title="Duplicate">⧉</button></span>'}
const SUMRE=/(GB|TB|vCPU|VMs|Disks|Drives|Count|kW|Power)/i;
function totalsHtml(sheet,rows){const t=TV[sheet],cs=t.show.filter(c=>{const d=SCHEMA[sheet].cols.find(x=>x.k===c);return d&&d.t==='num'&&SUMRE.test(c)&&!/%|Used|Free/i.test(c)}).slice(0,5);
if(!cs.length||!rows.length)return '';
return '<div class="tfoot"><span><b>'+rows.length+'</b> row'+(rows.length===1?'':'s')+' in view</span>'+cs.map(c=>'<span>Σ '+esc(labelOf(c,sheet))+' <b class="mono">'+(Math.round(rows.reduce((s,x)=>s+num(x.r[c]),0)*10)/10).toLocaleString()+'</b></span>').join('')+'</div>'}
function cardFields(sheet){const t=TV[sheet],key=SCHEMA[sheet].key;const sc=c=>SCHEMA[sheet].cols.find(x=>x.k===c)||{};
const cols=t.show.filter(c=>c!==key&&c!==t.filter&&c.charAt(0)!=='@');
const met=cols.filter(c=>sc(c).t==='num'&&SUMRE.test(c)&&!/%/.test(c)).slice(0,3);
const txt=cols.filter(c=>met.indexOf(c)<0&&sc(c).t!=='num').slice(0,5);return{met:met,txt:txt}}
function cardHtml(sheet,x,ss){const t=TV[sheet],r=x.r,i=x.i,key=SCHEMA[sheet].key,f=cardFields(sheet),tone=rowTone(sheet,r),sel=ss.has(r);
const used=r['Used %']!==undefined&&r['Used %']!==''?num(r['Used %']):null;
return '<div class="lcard'+(sel?' picked':'')+'" data-tone="'+tone+'" data-act="edit" data-sheet="'+sheet+'" data-i="'+i+'" tabindex="0"><div class="lch"><input type="checkbox" class="lsel" data-act="rowsel" data-sheet="'+sheet+'" data-i="'+i+'" aria-label="Select"'+(sel?' checked':'')+'><b>'+esc(r[key])+'</b>'+(t.filter&&r[t.filter]!==''?cellHtml(t.filter,r):'')+'</div>'
+(f.txt[0]&&r[f.txt[0]]!==''?'<div class="mut lcs">'+esc(r[f.txt[0]])+'</div>':'')
+(used!==null?'<div class="lcu"><div class="bar" style="flex:1"><i class="'+(used>=85?'b':used>=70?'w':'')+'" style="width:'+Math.min(100,used)+'%"></i></div><span class="mono">'+used+'%</span></div>':'')
+(f.met.length?'<div class="lcm">'+f.met.map(c=>'<div><small>'+esc(labelOf(c,sheet))+'</small><b class="mono">'+esc(r[c]===''?'—':r[c])+'</b></div>').join('')+'</div>':'')
+'<div class="lcr">'+f.txt.slice(1).map(c=>r[c]!==''&&r[c]!=null?'<span><small>'+esc(labelOf(c,sheet))+'</small> '+cellHtml(c,r)+'</span>':'').join('')+'</div>'
+'<div class="lcf">'+patchPill(sheet,r)+(r['Support end']?'<span class="note '+cellTone('Support end',r)+'">Support '+esc(String(r['Support end']).slice(0,10))+'</span>':'')+'</div>'+qaHtml(sheet,i,r)+'</div>'}
function groupCols(sheet){const t=TV[sheet];return t.show.filter(c=>{if(c.charAt(0)==='@')return false;const n=new Set(DB[sheet].map(r=>String(r[c]==null?'':r[c]))).size;return n>1&&n<=30})}
function groupedHtml(sheet,rows,u,ss){const gcs=groupCols(sheet),t=TV[sheet];if(!gcs.length)return '<div class="cardgrid">'+rows.map(x=>cardHtml(sheet,x,ss)).join('')+'</div>';
if(!u.gb||gcs.indexOf(u.gb)<0)u.gb=gcs.indexOf('Cluster')>=0?'Cluster':gcs.indexOf(t.filter)>=0?t.filter:gcs[0];
const g={};rows.forEach(x=>{const k=String(x.r[u.gb]==null||x.r[u.gb]===''?'(none)':x.r[u.gb]);(g[k]=g[k]||[]).push(x)});
const ks=Object.keys(g).sort((a,b)=>a==='(none)'?1:b==='(none)'?-1:a.localeCompare(b,undefined,{numeric:true})),col=u.gcol||(u.gcol={}),mc=cardFields(sheet).met[0];
return '<div class="lgroups">'+ks.map(k=>{const off=col[k];const sm=mc?'Σ '+labelOf(mc,sheet)+' '+Math.round(g[k].reduce((s,x)=>s+num(x.r[mc]),0)*10)/10:'';
return '<section class="lgrp"><button type="button" class="lgh" data-act="lgtog" data-sheet="'+sheet+'" data-g="'+esc(k)+'" aria-expanded="'+(!off)+'"><b>'+esc(k)+'</b><span class="note">'+g[k].length+' record'+(g[k].length===1?'':'s')+(sm?' · '+esc(sm):'')+'</span><i></i><span class="note">'+(off?'Expand ▾':'Collapse ▴')+'</span></button>'+(off?'':'<div class="cardgrid">'+g[k].map(x=>cardHtml(sheet,x,ss)).join('')+'</div>')+'</section>'}).join('')+'</div>'}
function splitHtml(sheet,rows,u,ss){LV.split=sheet;const t=TV[sheet],key=SCHEMA[sheet].key;u._rows=rows.map(x=>x.i);
if(u.sel==null||u._rows.indexOf(u.sel)<0)u.sel=u._rows[0];
const sub=c=>{const f=cardFields(sheet).txt[0];return f?String(DB[sheet][c][f]||''):''};
const list=rows.map(x=>{const r=x.r,tone=rowTone(sheet,r);return '<div class="spr'+(x.i===u.sel?' on':'')+'" data-act="splsel" data-sheet="'+sheet+'" data-i="'+x.i+'" tabindex="0"><i class="dot" data-tone="'+tone+'"></i><div><b>'+esc(r[key])+'</b><div class="note" style="margin:0">'+esc([sub(x.i),t.filter?r[t.filter]:''].filter(Boolean).join(' · '))+'</div></div>'+patchPill(sheet,r)+'</div>'}).join('');
const r=DB[sheet][u.sel],i=u.sel;let pv='';
if(r){const tone=rowTone(sheet,r),f=cardFields(sheet);
pv='<div class="spv" data-tone="'+tone+'"><div class="spvh"><div style="flex:1;min-width:0"><span class="eyebrow">'+esc(sLabel(sheet))+'</span><h2 style="margin:2px 0 0;font-size:24px">'+esc(r[key])+'</h2></div>'+patchPill(sheet,r)+'<button class="btn" data-act="gorel" data-s="'+sheet+'" data-i="'+i+'"'+(RELSRC[sheet]?'':' hidden')+'>Relations (R)</button><button class="btn p" data-act="edit" data-sheet="'+sheet+'" data-i="'+i+'">Edit ⏎</button></div>'
+(f.met.length?'<div class="lcm big">'+f.met.map(c=>'<div><small>'+esc(labelOf(c,sheet))+'</small><b class="mono">'+esc(r[c]===''?'—':r[c])+'</b></div>').join('')+'</div>':'')
+'<div class="spf">'+t.show.filter(c=>c!==key&&c.charAt(0)!=='@'&&r[c]!==''&&r[c]!=null).map(c=>'<div><span class="note">'+esc(labelOf(c,sheet))+'</span><span>'+cellHtml(c,r)+'</span></div>').join('')+'</div>'
+(typeof gBox==='function'?'<div style="margin-top:12px">'+gBox(sheet,i,680,true)+'</div>':'')+'</div>'}
return '<div class="splitl"><div class="splist" role="listbox" aria-label="Records">'+list+'</div>'+pv+'</div><p class="hint" style="margin:8px 14px">J / K or ↑ ↓ to move · Enter edit · R relations</p>'}
function listAlt(sheet,rows,u,ss,all){
const pgi=pgSlice(sheet,u,rows),vm=u.view;let body;
if(vm==='split')body=splitHtml(sheet,rows,u,ss);
else{const pr=pgi.rows;body=vm==='grouped'?groupedHtml(sheet,rows,u,ss):'<div class="cardgrid">'+pr.map(x=>cardHtml(sheet,x,ss)).join('')+'</div>'}
return bulkBar(sheet)+body+(vm==='cards'?pagerHtml(sheet,pgi,all):'')+totalsHtml(sheet,rows)}
function listBar(sheet){const u=uiOf(sheet),vm=u.view||'table',gcs=vm==='grouped'?groupCols(sheet):[];
const sv=(LVIEWS[sheet]||[]).length;
return (sheet==='DatastoreClusters'?dscBanner():'')+'<div class="lbar"><div class="chips" role="group" aria-label="View style">'+LV_ON.map(v=>'<button class="chip'+(vm===v?' on':'')+'" data-act="lview" data-sheet="'+sheet+'" data-v="'+v+'" aria-pressed="'+(vm===v)+'">'+LV_LBL[v]+'</button>').join('')+'</div>'
+(vm==='grouped'&&gcs.length?'<label class="note lbl">Group by <select class="inp" data-act="lgby" data-sheet="'+sheet+'">'+gcs.map(c=>'<option value="'+esc(c)+'"'+(c===(u.gb||'Cluster')?' selected':'')+'>'+esc(labelOf(c,sheet))+'</option>').join('')+'</select></label>':'')
+'<span style="flex:1"></span><button class="btn s" data-act="lcmopen" data-sheet="'+sheet+'" title="Pick several columns and copy them for Excel">Copy columns…</button><label class="note lbl">or one column <select class="inp" data-lcopy="'+sheet+'" aria-label="Copy one column"><option value="">choose…</option>'+TV[sheet].show.map(c=>'<option value="'+esc(c)+'">'+esc(labelOf(c,sheet))+'</option>').join('')+'<optgroup label="Distinct values">'+TV[sheet].show.map(c=>'<option value="u:'+esc(c)+'">'+esc(labelOf(c,sheet))+' (unique)</option>').join('')+'</optgroup></select></label><button class="btn s'+(LE.click?' p':'')+'" data-act="cellmode" aria-pressed="'+LE.click+'" title="Click a cell to edit it in place">Edit in place</button><button class="btn s" data-act="lvopen" data-sheet="'+sheet+'">Saved views'+(sv?' ('+sv+')':'')+' ▾</button><button class="btn s'+(isDense()?' p':'')+'" data-act="ldense" aria-pressed="'+isDense()+'" title="Compact rows">Compact</button></div>'}
/* ---------- compare ---------- */
function openCompare(sheet){const rs=selRows(sheet).slice(0,4);if(rs.length<2)return;const key=SCHEMA[sheet].key,cs=TV[sheet].show.filter(c=>c.charAt(0)!=='@');
const diff=c=>new Set(rs.map(r=>String(r[c]==null?'':r[c]))).size>1;
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Compare" style="width:min(980px,100%)"><h2>Compare '+rs.length+' records</h2><label class="note" style="display:flex;gap:6px;align-items:center"><input type="checkbox" id="cmp-d" data-act="cmpdiff"> Show only differences</label><div class="tw" style="max-height:62vh"><table class="cmpt"><thead><tr><th></th>'+rs.map(r=>'<th>'+esc(r[key])+'</th>').join('')+'</tr></thead><tbody>'+cs.map(c=>'<tr class="'+(diff(c)?'df':'')+'"><th scope="row">'+esc(labelOf(c,sheet))+'</th>'+rs.map(r=>'<td>'+(r[c]===''||r[c]==null?'<span class="note">—</span>':cellHtml(c,r))+'</td>').join('')+'</tr>').join('')+'</tbody></table></div><div class="acts"><span class="note">Highlighted rows differ.</span><div class="tools"><button class="btn p" data-act="mclose">Close</button></div></div></div></div>'}
/* ---------- saved views popover ---------- */
const LV={sheet:null,split:null};
function lvClose(){const p=$('vwpop');if(p){p.hidden=true;p.innerHTML=''}LV.sheet=null}
function lvDraw(){const p=$('vwpop');if(!p||!LV.sheet)return;const l=LVIEWS[LV.sheet]||[];
p.innerHTML='<div class="hfh"><b>Saved views</b><span class="note" style="margin:0">'+esc(sLabel(LV.sheet))+'</span></div><div class="hflist" style="min-height:0;max-height:240px">'+(l.length?l.map((v,j)=>'<div class="hfrow"><a href="#" class="hfv" data-act="lvapply" data-j="'+j+'">'+esc(v.n)+'</a><button type="button" class="btn s" data-act="lvdel" data-j="'+j+'" aria-label="Delete view '+esc(v.n)+'">×</button></div>').join(''):'<p class="note" style="padding:10px;margin:0">No saved views yet. Set filters, search, sort and view style, then save them here.</p>')+'</div><div style="display:flex;gap:6px"><input class="inp" id="vw-n" placeholder="Name this view…" maxlength="40" aria-label="View name" style="flex:1"><button type="button" class="btn s p" data-act="lvsave">Save</button></div><button type="button" class="btn s" data-act="lvreset">Reset to default view</button>'}
Object.assign(NEONACT,{
lview(el){const u=uiOf(el.dataset.sheet);u.view=el.dataset.v==='table'?'':el.dataset.v;route()},
lgby(el){uiOf(el.dataset.sheet).gb=el.value;redrawTable(el.dataset.sheet)},
lgtog(el){const u=uiOf(el.dataset.sheet),c=u.gcol||(u.gcol={});c[el.dataset.g]=!c[el.dataset.g];redrawTable(el.dataset.sheet)},
splsel(el){const u=uiOf(el.dataset.sheet);u.sel=+el.dataset.i;redrawTable(el.dataset.sheet)},
ldense(){dense();route()},
dupe(el){const s=el.dataset.sheet,r=DB[s][+el.dataset.i];if(!r)return;const c=Object.assign({},r);const key=SCHEMA[s].key;c[key]=String(r[key])+' (copy)';delete c.ID;openForm(s,null,c)},
bcmp(el){openCompare(el.dataset.sheet)},
cmpdiff(el){document.querySelectorAll('.cmpt tbody tr').forEach(tr=>{tr.hidden=el.checked&&!tr.classList.contains('df')})},
lvopen(el){if(LV.sheet===el.dataset.sheet){lvClose();return}LV.sheet=el.dataset.sheet;let p=$('vwpop');if(!p){p=document.createElement('div');p.id='vwpop';p.className='hfpop';p.style.width='320px';document.body.appendChild(p)}
lvDraw();p.hidden=false;const r=el.getBoundingClientRect();p.style.left=Math.max(8,Math.min(innerWidth-328,r.right-320))+'px';p.style.top=(r.bottom+6)+'px';setTimeout(()=>{const n=$('vw-n');if(n)n.focus()},0)},
lvsave(){const n=($('vw-n').value||'').trim();if(!n)return;const u=uiOf(LV.sheet),l=LVIEWS[LV.sheet]||(LVIEWS[LV.sheet]=[]);const s=JSON.parse(JSON.stringify({q:u.q,f:u.f,fm:u.fm||[],fl:u.fl,sk:u.sk,sd:u.sd,sx:u.sx||[],view:u.view||'',gb:u.gb||''}));const j=l.findIndex(v=>v.n===n);if(j>=0)l[j].s=s;else l.push({n:n,s:s});lvSave();lvDraw();toast('View “'+n+'” saved')},
lvapply(el){const l=LVIEWS[LV.sheet]||[],v=l[+el.dataset.j];if(!v)return;const u=uiOf(LV.sheet);Object.assign(u,JSON.parse(JSON.stringify(v.s)));u.open=false;u.pg=0;lvClose();route()},
lvdel(el){const l=LVIEWS[LV.sheet]||[];l.splice(+el.dataset.j,1);lvSave();lvDraw()},
lvreset(){const s=LV.sheet,t=TV[s];UI[s]=null;lvClose();route()}});
/* bulk set preview */
function bsPrev(){const e=$('bs-prev'),col=$('bs-col');if(!e||!col)return;const sheet=(col.dataset||{}).sheet,k=col.value,c=SCHEMA[sheet]&&SCHEMA[sheet].cols.find(x=>x.k===k),el=$('bs-val')&&$('bs-val').querySelector('[name]');if(!c||!el)return;
let nv=c.t==='chk'?(el.checked?'Yes':'No'):el.value.trim();const rs=selRows(sheet),m={};rs.forEach(r=>{const v=String(r[k]==null?'':r[k]);m[v]=(m[v]||0)+1});
const ch=rs.filter(r=>String(r[k]==null?'':r[k])!==nv).length;
e.innerHTML='<b>Preview</b> · '+ch+' of '+rs.length+' will change.<br><span class="note">Now: '+Object.keys(m).map(v=>esc(v===''?'(empty)':v)+' ×'+m[v]).join(', ')+' → <b>'+esc(nv===''?'(empty)':nv)+'</b></span>'}
const _bsRender=bsRender;bsRender=function(sheet){_bsRender(sheet);bsPrev()};
const _openBulkSet=openBulkSet;openBulkSet=function(sheet){_openBulkSet(sheet);const er=$('bs-err');if(er&&!$('bs-prev')){er.insertAdjacentHTML('beforebegin','<div id="bs-prev" class="bsprev" aria-live="polite"></div>');bsPrev()}};
if(typeof document!=='undefined'&&document.addEventListener){try{
document.addEventListener('input',e=>{if(e.target&&e.target.closest&&e.target.closest('#bs-val'))bsPrev()});
document.addEventListener('change',e=>{if(e.target&&e.target.closest&&e.target.closest('#bs-val'))bsPrev()});
document.addEventListener('mousedown',e=>{if(!LV.sheet)return;const p=$('vwpop');if(p&&!p.contains(e.target)&&!(e.target.closest&&e.target.closest('[data-act=lvopen]')))lvClose()},true);
document.addEventListener('keydown',e=>{if(LV.sheet&&e.key==='Escape'){lvClose();e.stopPropagation();return}
if(LV.sheet&&e.key==='Enter'&&e.target&&e.target.id==='vw-n'){e.preventDefault();NEONACT.lvsave();return}
const t=e.target,tag=t&&t.tagName;if(tag==='INPUT'||tag==='SELECT'||tag==='TEXTAREA'||(t&&t.isContentEditable)||e.ctrlKey||e.metaKey||e.altKey)return;
const sp=document.querySelector('.splitl');if(!sp||!LV.split||$('modal').children.length)return;const CUR=LV.split,u=uiOf(CUR);if(u.view!=='split'||!u._rows)return;const k=e.key.toLowerCase(),a=u._rows,p=a.indexOf(u.sel);
if(k==='j'||k==='arrowdown'){e.preventDefault();u.sel=a[Math.min(a.length-1,p+1)];redrawTable(CUR);const o=document.querySelector('.spr.on');if(o&&o.scrollIntoView)o.scrollIntoView({block:'nearest'})}
else if(k==='k'||k==='arrowup'){e.preventDefault();u.sel=a[Math.max(0,p-1)];redrawTable(CUR);const o=document.querySelector('.spr.on');if(o&&o.scrollIntoView)o.scrollIntoView({block:'nearest'})}
else if(k==='enter'&&u.sel!=null){e.preventDefault();openForm(CUR,u.sel)}
else if(k==='r'&&RELSRC[CUR]&&u.sel!=null){e.preventDefault();NEONACT.gorel({dataset:{s:CUR,i:String(u.sel)}})}});
}catch(e){}}
/* keep scroll position when the same page is redrawn (edit/save/select/filter) */
const _routeKeep=route;
route=function(){let y=0,inner=[],prev=CUR,hash=null;try{y=window.scrollY||0;inner=[].slice.call(document.querySelectorAll('#view .tw, #view .rackwrap, #view [data-keepscroll]')).map(e=>[e.scrollTop,e.scrollLeft])}catch(e){}
_routeKeep();
try{if(CUR===prev&&y>0){window.scrollTo(0,y);const els=document.querySelectorAll('#view .tw, #view .rackwrap, #view [data-keepscroll]');inner.forEach((p,i)=>{if(els[i]){els[i].scrollTop=p[0];els[i].scrollLeft=p[1]}})}}catch(e){}};

/* drag & drop column order in the Columns dialog */
let colDrag=null;
try{
document.addEventListener('dragstart',e=>{const r=e.target&&e.target.closest&&e.target.closest('tr.colrow');if(!r)return;colDrag={s:r.dataset.sheet,k:r.dataset.ck};r.classList.add('dragging');try{e.dataTransfer.setData('text/plain',colDrag.k);e.dataTransfer.effectAllowed='move'}catch(x){}});
document.addEventListener('dragover',e=>{const r=e.target&&e.target.closest&&e.target.closest('tr.colrow');if(!r||!colDrag||r.dataset.sheet!==colDrag.s)return;e.preventDefault();document.querySelectorAll('tr.colrow.over').forEach(x=>x.classList.remove('over'));r.classList.add('over')});
document.addEventListener('dragend',()=>{colDrag=null;document.querySelectorAll('tr.colrow.over,tr.colrow.dragging').forEach(x=>x.classList.remove('over','dragging'))});
document.addEventListener('drop',e=>{const r=e.target&&e.target.closest&&e.target.closest('tr.colrow');if(!r||!colDrag||r.dataset.sheet!==colDrag.s)return;e.preventDefault();const s=colDrag.s,k=colDrag.k,t=r.dataset.ck;colDrag=null;if(k!==t){moveColTo(s,k,t);openCols(s)}});
}catch(e){}
/* datastore clusters: create the ones named in Datastores */
function dscMissing(){const have=new Set(dscA().map(c=>String(c['Datastore cluster']).trim().toLowerCase())),m={};DB.Datastores.forEach(d=>{const n=String(d['Datastore cluster']||'').trim();if(n&&!have.has(n.toLowerCase()))(m[n]=m[n]||[]).push(d)});return m}
function dscBanner(){const m=dscMissing(),k=Object.keys(m);if(!k.length)return '';return '<div class="callout card" style="margin:0 0 10px;display:flex;gap:12px;align-items:center;flex-wrap:wrap"><span style="flex:1;min-width:240px"><b>'+k.length+' datastore cluster'+(k.length===1?'':'s')+' named in Datastores '+(k.length===1?'is':'are')+' not on this page yet.</b> <span class="note">'+esc(k.slice(0,4).join(', '))+(k.length>4?' …':'')+' · create them to see capacity, balance and checks per cluster.</span></span><button class="btn p" data-act="dscmk">Create '+k.length+' from datastores</button></div>'}
Object.assign(NEONACT,{dscmk(){const m=dscMissing(),k=Object.keys(m);if(!k.length)return;undoSnap('create datastore clusters');const top=(l,f)=>{const c={};l.forEach(d=>{const v=String(d[f]||'').trim();if(v)c[v]=(c[v]||0)+1});const e=Object.keys(c).sort((a,b)=>c[b]-c[a]);return e[0]||''};
k.forEach(n=>{const r={};SCHEMA.DatastoreClusters.cols.forEach(c=>{r[c.k]=''});r['Datastore cluster']=n;r.DC=top(m[n],'DC');r.vCenter=top(m[n],'vCenter');r.Updated=ds(0);dscA().push(r)});changed();route();toast(k.length+' datastore cluster'+(k.length===1?'':'s')+' created',true)}});
