
/* ---------- columns: add / show / remove from the page ---------- */
const CORE={};SHEETS.forEach(s=>{CORE[s]=new Set(SCHEMA[s].cols.map(c=>c.k))});
const REQ0={};SHEETS.forEach(s=>{REQ0[s]={};SCHEMA[s].cols.forEach(c=>{REQ0[s][c.k]=!!c.req})});
const SHOW0={};Object.keys(TV).forEach(s=>{SHOW0[s]=TV[s].show.slice()});
const TYPES=[['text','Text'],['num','Number'],['date','Date'],['sel','Dropdown'],['area','Long text']];
function rebuildHead(){SHEETS.forEach(s=>{HEAD[s]=SCHEMA[s].cols.map(c=>c.k).concat(['Updated'])})}
function hideCol(sheet,c){if(c.hidden)return;c.hidden=1;if(c.req){c.reqWas=1;delete c.req}if(TV[sheet])TV[sheet].show=TV[sheet].show.filter(x=>x!==c.k)}
function showCol(sheet,c){if(!c.hidden)return;delete c.hidden;if(c.reqWas){c.req=1;delete c.reqWas}}
function formCols(sheet){const S=SCHEMA[sheet],t=TV[sheet],live=S.cols.filter(c=>!c.hidden&&!c.att);if(!t)return live;const o=[];t.show.forEach(k=>{const c=live.find(x=>x.k===k);if(c)o.push(c)});live.forEach(c=>{if(o.indexOf(c)<0)o.push(c)});return o}
function revertSchema(){SHEETS.forEach(s=>{SCHEMA[s].cols=SCHEMA[s].cols.filter(c=>!c.custom);SCHEMA[s].cols.forEach(c=>{delete c.hidden;delete c.reqWas;delete c.label;if(REQ0[s][c.k])c.req=1;else delete c.req})});Object.keys(TV).forEach(s=>{TV[s].show=SHOW0[s].slice()});rebuildHead()}
function addColumn(sheet,d){
const S=SCHEMA[sheet],name=String(d.k||'').trim();
if(!name)return 'Enter a column name';
if(name.length>40)return 'Use 40 characters or fewer';
if(name.toLowerCase()==='updated'||name.charAt(0)==='@')return 'That name is reserved';
if(S.cols.some(c=>c.k.toLowerCase()===name.toLowerCase()))return 'This sheet already has a column named '+name;
const col={k:name,custom:1};
if(d.t&&d.t!=='text')col.t=d.t;
if(col.t==='sel'){const o=(Array.isArray(d.o)?d.o:String(d.o||'').split(',')).map(x=>String(x).trim()).filter(Boolean);if(!o.length)return 'Add at least one dropdown option, separated by commas';col.o=o}
if(d.req)col.req=1;
const ni=S.cols.findIndex(c=>c.k==='Notes');
if(ni>=0)S.cols.splice(ni,0,col);else S.cols.push(col);
if(d.show!==false&&TV[sheet])TV[sheet].show.push(name);
rebuildHead();return '';
}
function saveSchemaMeta(){
META.cols=[];SHEETS.forEach(s=>SCHEMA[s].cols.forEach(c=>{if(c.custom)META.cols.push({sheet:s,k:c.k,t:c.t||'text',o:c.o,req:!!c.req})}));
META.over={};SHEETS.forEach(s=>SCHEMA[s].cols.forEach(c=>{if(!c.custom&&(c.label||!!c.req!==!!REQ0[s][c.k]))META.over[s+'|'+c.k]={label:c.label||'',req:!!c.req}}));META.hidden=[];SHEETS.forEach(s=>SCHEMA[s].cols.forEach(c=>{if(c.hidden)META.hidden.push(s+'|'+c.k)}));META.show={};Object.keys(TV).forEach(s=>{META.show[s]=TV[s].show.slice()});persist();
}
function applySchema(){
(META.cols||[]).forEach(c=>{if(SCHEMA[c.sheet])addColumn(c.sheet,{k:c.k,t:c.t,o:c.o,req:c.req,show:false})});
(META.hidden||[]).forEach(key=>{const a=key.split('|'),c=SCHEMA[a[0]]&&SCHEMA[a[0]].cols.find(x=>x.k===a[1]);if(c)hideCol(a[0],c)});
if(META.over)Object.keys(META.over).forEach(key=>{const a=key.split('|'),c=SCHEMA[a[0]]&&SCHEMA[a[0]].cols.find(x=>x.k===a[1]);if(c){if(META.over[key].label)c.label=META.over[key].label;if(META.over[key].req)c.req=1;else delete c.req}});
if(META.show)Object.keys(META.show).forEach(s=>{if(TV[s]){const names=new Set(SCHEMA[s].cols.map(c=>c.k).concat(['@load','@sync','@use','@dsm','@dscap','@dsfree','@dsused','@dsspread','@dsiss','@dvm','@rcv','@rcu','@rci','@rcg','@dhost','@dst','@drs','@hgrp','@ghn','@ghr','@ghv','@vd','@cjobs','@crepl']));TV[s].show=META.show[s].filter(k=>names.has(k))}});
}
function typeLabel(c){return c.t==='num'?'Number':c.t==='date'?'Date':c.t==='area'?'Long text':c.t==='sel'?'Dropdown: '+c.o.join(', '):'Text'}
function colDef(sheet,k){return SCHEMA[sheet].cols.find(x=>x.k===k)||{k:k,computed:1}}
function moveColTo(sheet,from,to){const a=TV[sheet].show,fi=a.indexOf(from),ti=a.indexOf(to);if(fi<0||ti<0||fi===ti)return;a.splice(fi,1);a.splice(ti,0,from);saveSchemaMeta();changed();route()}
function openCols(sheet){
const S=SCHEMA[sheet],t=TV[sheet];
const live=S.cols.filter(c=>!c.hidden&&!c.att).map(c=>c.k),hid=S.cols.filter(c=>c.hidden);
const keys=t?t.show.concat(live.filter(k=>!t.show.includes(k))):live;
const rows=keys.map((k,i)=>{
const c=colDef(sheet,k),shown=!!t&&t.show.includes(k),si=t?t.show.indexOf(k):-1;
const mv=shown?'<button class="btn s" data-act="colmove" data-sheet="'+sheet+'" data-k="'+esc(k)+'" data-dir="-1" aria-label="Move '+esc(k)+' left"'+(si===0?' disabled':'')+'>←</button> <button class="btn s" data-act="colmove" data-sheet="'+sheet+'" data-k="'+esc(k)+'" data-dir="1" aria-label="Move '+esc(k)+' right"'+(si===t.show.length-1?' disabled':'')+'>→</button>':'';
return '<tr'+(shown?' class="colrow" draggable="true" data-ck="'+esc(k)+'" data-sheet="'+sheet+'"':'')+'><td>'+(shown?'<span class="grip" aria-hidden="true" title="Drag to reorder">⠿</span> <span class="mono note">'+(si+1)+'</span> ':'')+esc(c.computed?labelOf(c.k)+' (computed)':c.k)+(c.custom?' <span class="badge b-info">custom</span>':'')+(c.label?' <span class="note">· shown as “'+esc(c.label)+'”</span>':'')+'</td><td style="white-space:normal">'+esc(c.computed?'Computed':typeLabel(c))+'</td><td>'+(c.req?'Required':'')+'</td><td>'+(t?'<input type="checkbox" id="cs-'+i+'" data-act="colshow" data-sheet="'+sheet+'" data-k="'+esc(k)+'"'+(shown?' checked':'')+' aria-label="Show '+esc(k)+' in the table" style="width:20px;height:20px">':'<span class="note">form only</span>')+'</td><td>'+mv+'</td><td>'+(c.computed?'<span class="note">computed</span>':'<button class="btn s" data-act="coledit" data-sheet="'+sheet+'" data-k="'+esc(k)+'">Edit</button>'+(c.custom?' <button class="btn s d" data-act="colrm" data-sheet="'+sheet+'" data-k="'+esc(k)+'">Remove</button>':(k===S.key?' <span class="note">key</span>':' <button class="btn s d" data-act="colhide" data-sheet="'+sheet+'" data-k="'+esc(k)+'" title="Removes the column from the table and form. The data stays in the workbook and can be restored.">Delete</button>')))+'</td></tr>';
}).join('');
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Columns of '+esc(SCHEMA[sheet].label)+'" style="width:min(900px,100%)"><h2>Columns · '+esc(SCHEMA[sheet].label)+'</h2>'
+(t?'<p class="note" style="margin:0">Drag a column row up or down to reorder it (or use the arrows). You can also drag a column header in the table.</p>':'')
+'<div class="tw"><table><thead><tr><th>Column</th><th>Type</th><th>Required</th><th>Show in table</th><th>Move</th><th></th></tr></thead><tbody>'+rows+'</tbody></table></div>'
+(hid.length?'<div class="card" style="background:var(--surface2)"><h2>Deleted columns</h2><p class="note" style="margin:0 0 8px">These columns are hidden from the table and the form. Their data is still in the workbook, so nothing is lost. Restore brings a column back with its values.</p>'+hid.map(c=>'<div class="tools" style="justify-content:space-between;padding:4px 0"><span><b>'+esc(c.label||c.k)+'</b> <span class="note">'+esc(typeLabel(c))+'</span></span><button class="btn s" data-act="colrestore" data-sheet="'+sheet+'" data-k="'+esc(c.k)+'">Restore</button></div>').join('')+'</div>':'')
+'<div class="card" style="background:var(--surface2)"><h2>Add a column</h2><div class="fgrid"><label for="nc-name" class="req">Column name<input class="inp" id="nc-name" maxlength="40" placeholder="e.g. Criticality"></label><label for="nc-type">Type<select class="inp" id="nc-type">'+TYPES.map(x=>'<option value="'+x[0]+'">'+x[1]+'</option>').join('')+'</select></label><label for="nc-opts" class="wide">Dropdown options, separated by commas (Dropdown type only)<input class="inp" id="nc-opts" placeholder="Low, Medium, High"></label></div>'
+'<div class="tools" style="margin-top:12px"><label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="nc-req" style="width:18px;height:18px"> Required</label>'+(t?'<label style="display:flex;align-items:center;gap:8px"><input type="checkbox" id="nc-show" checked style="width:18px;height:18px"> Show in table</label>':'<span class="note">This sheet has no table, so the column appears in the form.</span>')+'<button class="btn p" data-act="coladd" data-sheet="'+sheet+'">Add column</button></div><div id="nc-err" class="note" style="color:var(--bad-fg);margin-top:8px" role="alert"></div></div>'
+'<p class="note" style="margin:0">New columns and the column order appear in the table, edit form, search, data quality and Data sources straight away. The next Save to Excel writes new headers into the sheet and records the setup and order in the _Schema sheet. The build script needs no change. Built-in columns can be renamed on screen and set to required, but not removed, because checks and layouts use them.</p>'
+'<div class="acts"><span></span><button class="btn" data-act="mclose">Close</button></div></div></div>';
}

function openColEdit(sheet,k){
const c=colDef(sheet,k);if(c.computed)return;
if(!c.custom){$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Edit column" style="width:min(520px,100%)"><h2>Edit column · '+esc(k)+'</h2><div class="fgrid"><label for="ce-label" class="wide">Displayed name<input class="inp" id="ce-label" maxlength="40" value="'+esc(c.label||'')+'" placeholder="'+esc(c.k)+'"></label></div><label style="display:flex;align-items:center;gap:8px;margin-top:10px"><input type="checkbox" id="ce-req" style="width:18px;height:18px"'+(c.req?' checked':'')+'> Required</label><p class="note" style="margin:8px 0 0">The displayed name is used in the table and the edit form. The Excel header stays “'+esc(c.k)+'”, because checks and layouts use it. Type and dropdown options of built-in columns are fixed here; options managed in Settings (environments, data centers, categories) are edited there.</p><div class="acts"><span></span><div class="tools"><button class="btn" data-act="colback" data-sheet="'+sheet+'">Cancel</button><button class="btn p" data-act="colsave" data-sheet="'+sheet+'" data-k="'+esc(k)+'">Save column</button></div></div></div></div>';return}
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Edit column" style="width:min(520px,100%)"><h2>Edit column · '+esc(k)+'</h2>'
+'<div class="fgrid"><label for="ce-name" class="req">Column name<input class="inp" id="ce-name" maxlength="40" value="'+esc(c.k)+'"></label><label for="ce-type">Type<select class="inp" id="ce-type">'+TYPES.map(x=>'<option value="'+x[0]+'"'+((c.t||'text')===x[0]?' selected':'')+'>'+x[1]+'</option>').join('')+'</select></label>'
+'<label for="ce-opts" class="wide">Dropdown options, separated by commas (Dropdown type only)<input class="inp" id="ce-opts" value="'+esc((c.o||[]).join(', '))+'"></label></div>'
+'<label style="display:flex;align-items:center;gap:8px;margin-top:10px"><input type="checkbox" id="ce-req" style="width:18px;height:18px"'+(c.req?' checked':'')+'> Required</label>'
+'<p class="note" style="margin:8px 0 0">Renaming moves the existing values to the new name. Existing values are kept when you change the type or the options.</p>'
+'<div id="ce-err" class="note" style="color:var(--bad-fg)" role="alert"></div>'
+'<div class="acts"><span></span><div class="tools"><button class="btn" data-act="colback" data-sheet="'+sheet+'">Cancel</button><button class="btn p" data-act="colsave" data-sheet="'+sheet+'" data-k="'+esc(k)+'">Save column</button></div></div></div></div>'}
function saveColEdit(sheet,k){
const S=SCHEMA[sheet],c=colDef(sheet,k);
if(!c.custom){const l=$('ce-label').value.trim();if(l&&l!==c.k)c.label=l;else delete c.label;if($('ce-req').checked)c.req=1;else delete c.req;saveSchemaMeta();changed();route();openCols(sheet);toast('Column updated');return}
const name=$('ce-name').value.trim(),t=$('ce-type').value,err=m=>{$('ce-err').textContent=m};
if(!name)return err('Enter a column name');if(name.length>40)return err('Use 40 characters or fewer');
if(name.toLowerCase()==='updated'||name.charAt(0)==='@')return err('That name is reserved');
if(name!==k&&S.cols.some(x=>x.k.toLowerCase()===name.toLowerCase()))return err('This sheet already has a column named '+name);
let o=null;if(t==='sel'){o=$('ce-opts').value.split(',').map(x=>x.trim()).filter(Boolean);if(!o.length)return err('Add at least one dropdown option')}
if(name!==k){c.k=name;DB[sheet].forEach(r=>{if(k in r){r[name]=r[k];delete r[k]}});if(TV[sheet])TV[sheet].show=TV[sheet].show.map(x=>x===k?name:x);if(UI[sheet]){if(UI[sheet].sk===k)UI[sheet].sk=name;UI[sheet].fl.forEach(f=>{if(f.k===k)f.k=name})}}
if(t==='text')delete c.t;else c.t=t;if(o)c.o=o;else delete c.o;if($('ce-req').checked)c.req=1;else delete c.req;
rebuildHead();saveSchemaMeta();changed();route();openCols(sheet);toast('Column updated')}
