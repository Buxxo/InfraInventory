
/* ---------- navigation + side card ---------- */
const IC={
clusters:'<circle cx="6" cy="6" r="2.6"/><circle cx="18" cy="6" r="2.6"/><circle cx="12" cy="18" r="2.6"/><path d="M8.4 7l2.4 8.6M15.6 7l-2.4 8.6M8.6 6h6.8"/>',
contacts:'<circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 4-6 8-6s8 2 8 6"/>',
agroups:'<circle cx="9" cy="8" r="3"/><circle cx="17" cy="9" r="2.5"/><path d="M3 19c0-3.5 3-5 6-5s6 1.5 6 5M15 14.5c3 0 6 1 6 4.5"/>',
activity:'<path d="M3 12h4l3-8 4 16 3-8h4"/>',
backupjobs:'<path d="M4 6h16M4 12h10M4 18h7"/><path d="M16 15l2 2 4-4"/>',
patching:'<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
overview:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
servermi:'<rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01"/>',
esxi:'<rect x="6" y="6" width="12" height="12" rx="2"/><path d="M9 2v4M15 2v4M9 18v4M15 18v4M2 9h4M2 15h4M18 9h4M18 15h4"/>',
storage:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
backup:'<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v5h5"/><path d="M12 8v4l3 2"/>',
dcmi:'<path d="M4 21V8l8-5 8 5v13"/><path d="M9 21v-6h6v6"/>',
racks:'<rect x="5" y="3" width="14" height="18" rx="1"/><path d="M5 9h14M5 15h14M9 6h.01M9 12h.01M9 18h.01"/>',
checks:'<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1M9 13l2 2 4-4"/>',
issues:'<path d="M12 3l10 18H2z"/><path d="M12 10v5M12 18h.01"/>',
otherdevices:'<rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M12 14V9M6 9h12M6 9V5M18 9V5M12 9V5"/>',
tracker:'<circle cx="12" cy="12" r="9"/><path d="M12 7v6M12 16.5h.01"/>',
kb:'<path d="M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2z"/><path d="M4 19V5M9 8h6M9 12h6"/>',
todo:'<path d="M9 6h11M9 12h11M9 18h11"/><path d="M3.5 6l1.2 1.2L7 5M3.5 12l1.2 1.2L7 11M3.5 18l1.2 1.2L7 17"/>',
stuff:'<path d="M3 6a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
serverdisks:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
drshostgroups:'<rect x="3" y="4" width="18" height="7" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7.5h.01M7 17h.01"/>',
drsrules:'<circle cx="6" cy="7" r="2.5"/><circle cx="18" cy="7" r="2.5"/><circle cx="12" cy="18" r="2.5"/><path d="M8.5 7h7M7.5 9l3.2 7M16.5 9l-3.2 7"/>',
datastoreclusters:'<ellipse cx="12" cy="5" rx="7" ry="2.6"/><path d="M5 5v5c0 1.4 3.1 2.6 7 2.6s7-1.2 7-2.6V5M2 15v4c0 1.4 4.5 2.6 10 2.6s10-1.200 10-2.600v-4"/>',
remotecopy:'<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
lunmap:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
arrayvolumes:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
datastores:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
patchevents:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
ports:'<rect x="3" y="8" width="18" height="9" rx="1.5"/><path d="M7 11v3M10.5 11v3M14 11v3M17.5 11v3"/>',
arrayhw:'<rect x="3" y="3" width="18" height="5" rx="1.5"/><rect x="3" y="10" width="18" height="5" rx="1.5"/><rect x="3" y="17" width="18" height="4" rx="1.5"/>',
disks:'<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1"/>',
calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M3 10h18M8 3v4M16 3v4"/>',
log:'<path d="M5 4h14v16H5z"/><path d="M8 9h8M8 13h8M8 17h5"/>',
catalyst:'<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6M4 12c0 1.7 3.6 3 8 3s8-1.3 8-3"/>',
repljobs:'<path d="M4 8h13l-3-3M20 16H7l3 3"/>',
dcdesign:'<rect x="3" y="4" width="7" height="7" rx="1"/><rect x="14" y="4" width="7" height="4" rx="1"/><rect x="3" y="15" width="18" height="5" rx="1"/>',
scripts:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9l3 3-3 3M12 15h5"/>',
myscripts:'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13l-2 2 2 2M13 13l2 2-2 2"/>',
scruns:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
wsfc:'<rect x="3" y="4" width="18" height="6" rx="1"/><rect x="3" y="14" width="18" height="6" rx="1"/><path d="M7 7h.01M7 17h.01"/>',
import:'<path d="M12 3v12M7 10l5 5 5-5"/><path d="M4 15v4a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-4"/>',
lifecycle:'<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2.5 2.5M9 2h6"/>',
relations:'<circle cx="12" cy="12" r="2.5"/><circle cx="5" cy="5" r="2"/><circle cx="19" cy="5" r="2"/><circle cx="5" cy="19" r="2"/><circle cx="19" cy="19" r="2"/><path d="M7 7l3.2 3.2M17 7l-3.2 3.2M7 17l3.2-3.2M17 17l-3.2-3.2"/>',
ipam:'<rect x="3" y="4" width="18" height="6" rx="1.5"/><rect x="3" y="14" width="18" height="6" rx="1.5"/><path d="M7 7h.01M7 17h.01M11 7h6M11 17h6"/>',
settings:'<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9l2.1 2.1M17 17l2.1 2.1M19.1 4.9L17 7M7 17l-2.1 2.1"/>',
quality:'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
sources:'<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1"/><path d="M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>'};
const TV_HW_PLACEHOLDER=0;
const NAV=[
['',[['overview','Overview'],['calendar','Calendar'],['stuff','Stuff'],['todo','To do & notes'],['kb','Knowledge base'],['tracker','Open issues'],['contacts','Contacts'],['agroups','Assignment groups'],['activity','DCSS activity']]],
['Inventory',[['servermi','ServersMI'],['serverdisks','Server disks'],['clusters','Failover clusters'],['patching','Patching'],['patchevents','Patch events'],['esxi','ESXi hosts'],['drsrules','DRS rules'],['drshostgroups','DRS host groups'],['storage','Storage'],['arrayhw','Array hardware'],['datastores','Datastores'],['datastoreclusters','Datastore clusters'],['arrayvolumes','Array volumes'],['lunmap','LUN map'],['remotecopy','Remote copy groups'],['backup','Backup'],['catalyst','Catalyst stores'],['backupjobs','Backup jobs'],['repljobs','Replication jobs'],['otherdevices','Other devices'],['lifecycle','Lifecycle'],['relations','Relations']]],
['Data center',[['dcmi','DCMI'],['checks','DC checks'],['issues','DC open issues'],['racks','DC rack layout'],['dcdesign','DC designer'],['ports','Ports & cabling'],['ipam','IP & VLANs'],['disks','Disks']]],
['System',[['quality','Data quality'],['import','Data import'],['wsfc','Collector'],['sources','Data sources'],['activitylog','Activity log'],['settings','Settings']]]];
/* pages merged into tabbed groups: one sidebar entry per group, every tab keeps its own route (#clusters, #drsrules, ...) */
const GRP={servermi:[['servermi','Servers'],['serverdisks','Server disks'],['clusters','Failover clusters']],patching:[['patching','Compliance'],['patchevents','Patch events']],esxi:[['esxi','ESXi hosts'],['drsrules','DRS rules'],['drshostgroups','DRS host groups']],storage:[['storage','Arrays'],['arrayhw','Array hardware'],['datastores','Datastores'],['datastoreclusters','Datastore clusters'],['arrayvolumes','Array volumes'],['lunmap','LUN map'],['remotecopy','Remote copy groups']],backup:[['backup','Backup devices'],['catalyst','Catalyst stores'],['backupjobs','Backup jobs'],['repljobs','Replication jobs']]};
const GOF={};Object.keys(GRP).forEach(g=>GRP[g].forEach(x=>GOF[x[0]]=g));
const GCNT={servermi:'ServerMI',serverdisks:'ServerDisks',clusters:'Clusters',patchevents:'PatchEvents',esxi:'ESXi',drsrules:'DrsRules',drshostgroups:'DrsHostGroups',storage:'Storage',datastores:'Datastores',datastoreclusters:'DatastoreClusters',arrayvolumes:'ArrayVolumes',remotecopy:'RemoteCopyGroups',backup:'Backup',catalyst:'Catalyst',backupjobs:'BackupJobs',repljobs:'ReplJobs'};
let GLAST={};try{GLAST=JSON.parse(localStorage.getItem('infra-gtab')||'{}')||{}}catch(e){}
function gtabs(id){const g=GOF[id];return '<div class="gtabs" role="tablist" aria-label="Sections">'+GRP[g].map(x=>{const n=GCNT[x[0]]&&DB[GCNT[x[0]]]?DB[GCNT[x[0]]].length:null;return '<a class="gtab'+(x[0]===id?' on':'')+'" role="tab" aria-selected="'+(x[0]===id)+'" href="#'+x[0]+'">'+esc(x[1])+(n!=null?' <span class="note">'+n+'</span>':'')+'</a>'}).join('')+'</div>'}
function gnote(id){const g=GOF[id];if(!g)return;if(GLAST[g]!==id){GLAST[g]=id;try{localStorage.setItem('infra-gtab',JSON.stringify(GLAST))}catch(e){}}}
let CUR='overview';
function sheetUpdated(s){let m='';(DB[s]||[]).forEach(r=>{if(r.Updated&&String(r.Updated)>m)m=String(r.Updated)});return m}
function checkMissingToday(){const t=ds(0);return DCS.filter(dc=>!DB.DCChecks.some(c=>c.DC===dc&&String(c.Date).slice(0,10)===t))}
function openIssues(){return DB.Issues.filter(i=>i.Status!=='Resolved')}
function renderSide(){
const q=qualityCount(),oi=openIssues().length;
const badge={quality:q,issues:oi,tracker:DB.OpenIssues.filter(r=>r.Status!=='Resolved'&&r.Status!=='Closed').length,activity:DB.DCSSActivity.filter(actionable).length,disks:DB.Disks.filter(r=>r.State==='Failed'||r.State==='Predictive fail').length};
const item=v=>'<a href="#'+(GRP[v[0]]&&GLAST[v[0]]&&GOF[GLAST[v[0]]]===v[0]?GLAST[v[0]]:v[0])+'"'+(v[0]===CUR||GOF[CUR]===v[0]?' class="on" aria-current="page"':'')+'><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true">'+IC[v[0]==='activitylog'?'log':v[0]]+'</svg><span>'+v[1]+'</span>'+(badge[v[0]]?'<em>'+badge[v[0]]+'</em>':'')+'</a>';
$('nav').innerHTML='<button class="navsearch" data-act="ckopen"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/></svg><span>Search…</span><kbd>Ctrl K</kbd></button>'+NAV.map(g=>{g=[g[0],g[1].filter(v=>!GOF[v[0]]||GOF[v[0]]===v[0])];if(!g[0])return '<div class="navg">'+g[1].map(item).join('')+'</div>';const has=g[1].some(v=>v[0]===CUR||GOF[CUR]===v[0]),shut=NAVC[g[0]]&&!has,cnt=g[1].reduce((a,v)=>a+(badge[v[0]]||0),0);
return '<button class="navlbl" data-act="navgrp" data-g="'+g[0]+'" aria-expanded="'+(!shut)+'"><span>'+g[0]+'</span>'+(shut&&cnt?'<em>'+cnt+'</em>':'')+'<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button><div class="navg"'+(shut?' hidden':'')+'>'+g[1].map(item).join('')+'</div>'}).join('');
const row=(l,s)=>{const u=sheetUpdated(s);const f=fresh(u);return '<div><span>'+l+'</span><span'+(f[0]==='b-bad'?' style="color:#FF9492"':f[0]==='b-warn'?' style="color:#FFC966"':'')+'>'+ago(u)+'</span></div>'};
secBar();$('fresh').innerHTML='<b>Data freshness</b><span class="mono" style="color:var(--side-muted)">'+esc(META.fileName||'inventory.xlsx')+'</span>'+row('ServersMI','ServerMI')+row('ESXi hosts','ESXi')+row('Storage','Storage')+row('Datastores','Datastores')+row('Backup','Backup')+row('DCMI','DCMI')+row('DC Checks','DCChecks')+'<span style="color:var(--side-muted);border-top:1px solid var(--line);padding-top:8px">Page built '+esc(META.loadedAt)+'</span>';
}
let RPOBJ=null,RPST=null;
function rootBar(){
if(typeof window.showDirectoryPicker!=='function')return '<div class="pending" role="status"><span><b>No project folder.</b> This browser cannot connect a folder. Use Edge or Chrome to save changes into the project folder.</span></div>';
if(!ROOT)return '<div class="pending" role="status"><span><b>Project folder not connected.</b> Changes are not saved to the project, photos stay in this browser and index.html is not rebuilt.</span><button class="btn s" data-act="rootconnect">Connect project folder</button></div>';
if(RPOBJ!==ROOT){RPOBJ=ROOT;RPST=null;rootPerm(false).then(ok=>{RPST=ok?'ok':'ask';renderPending()})}
if(RPST==='ask')return '<div class="pending" role="status"><span><b>Project folder “'+esc(ROOT.name)+'” needs permission again.</b></span><button class="btn s" data-act="rootreconnect">Reconnect</button><button class="btn s" data-act="rootchange">Change folder</button></div>';
if(!handle&&RPST==='ok')return '<div class="pending" role="status"><span><b>Inventory\\inventory.xlsx was not found in “'+esc(ROOT.name)+'”.</b> Pick the correct project folder.</span><button class="btn s" data-act="rootchange">Change folder</button></div>';
return ''}
/* sidebar badge: right after an edit show the last count and recompute the data-quality checks a moment later */
let QTIMER=null;
function qualityCount(){const n=v=>v.filter(c=>c.count>0).length,m=MEMO.quality;if(m&&m.k!==dkey()){clearTimeout(QTIMER);QTIMER=setTimeout(()=>{quality();renderSide()},350);return n(m.v)}return n(quality())}
function renderPending(){
$('pending').innerHTML=rootBar()+(dirty?'<div class="pending" role="status"><span><a href="#" data-act="pendview" style="color:inherit;text-decoration:underline;font-weight:600" title="See what changed">'+dirty+' unsaved change'+(dirty>1?'s':'')+'</a> not yet written to Excel</span><button class="btn s" data-act="pendview">Review</button><button class="btn s" data-act="penddiscard">Discard</button><button class="btn s" data-act="saveXlsx">Save to Excel</button></div>':'')+(dirty&&PFAIL?'<div class="pending" role="status"><span><b>No browser backup.</b> The inventory is too large for this browser\'s storage, so unsaved changes are lost if the tab closes or reloads. Save to Excel often.</span></div>':'');
}

/* ---------- table views ---------- */
const UI={};
const OKS=['On','Active','OK','Fresh','Done'],OFFS=['Off','Decom'],WARNS=['Maintenance','Warn','Degraded','Aging','Medium','Waiting','In progress'],BADS=['Fault','Alarm','Issue','High','Critical','Stale'];
function stCls(v){return OKS.includes(v)?'b-ok':OFFS.includes(v)?'b-off':WARNS.includes(v)?'b-warn':BADS.includes(v)?'b-bad':v==='New'||v==='Planned'?'b-info':v==='Low'?'b-off':(srvStatusCls(v)||actStatusCls(v))}
function srvStatusCls(v){const s=DB.ServerStatuses&&DB.ServerStatuses.find(x=>x.Name===v);return !s?null:s.Meaning==='Running'?'b-ok':s.Meaning==='Stopped'?'b-warn':'b-off'}
function actStatusCls(v){const s=DB.ActivityStatuses&&DB.ActivityStatuses.find(x=>x.Name===v);return s&&s.Actionable==='Yes'?'b-warn':'b-off'}
const ENV_CLS={Blue:'b-info',Green:'b-ok',Amber:'b-warn',Red:'b-bad',Grey:'b-off'};
function envRow(n){return DB.Environments.find(e=>e.Name===n)}
function envCls(n){const e=envRow(n);return e?(ENV_CLS[e.Color]||'b-off'):'b-off'}
function envProd(r){const e=envRow(r.Env);return !!e&&e.Production==='Yes'}
function rackRow(dc,rk){return DB.RackList.find(x=>x.DC===dc&&String(x.Rack)===String(rk))}
function dcRacks(dc){return DB.RackList.filter(r=>r.DC===dc).map(r=>String(r.Rack))}
function dcRackN(dc){return dcRacks(dc).length}
function rackU(dc,rk){const r=rackRow(dc,rk),n=r?parseInt(r['U count']):NaN;return n>=1?n:42}
function dcTotalU(dc){return dcRacks(dc).reduce((s,rk)=>s+rackU(dc,rk),0)}
function syncLayout(){const names=DB.DataCenters.map(d=>String(d.Name));DB.RackList.forEach(r=>{const v=String(r.DC||'');if(v&&names.indexOf(v)<0)names.push(v)});['ESXi','Storage','Backup','Datastores','DCMI','RackDevices','DCChecks','Issues'].forEach(s=>DB[s].forEach(r=>{const v=String(r.DC||'');if(v&&names.indexOf(v)<0)names.push(v)}));
DCS.length=0;names.forEach(n=>DCS.push(n));RACKS.length=0;DB.RackList.forEach(r=>{const v=String(r.Rack);if(RACKS.indexOf(v)<0)RACKS.push(v)});
DB.ESXi.concat(DB.Storage,DB.Backup,DB.RackDevices,DB.DCMI).forEach(r=>{const v=String(r.Rack||'');if(v&&RACKS.indexOf(v)<0)RACKS.push(v)});
const ic=SCHEMA.Issues.cols.find(c=>c.k==='Rack');if(ic)ic.o=['—'].concat(RACKS);
if(DCS.indexOf(RK.dc)<0)RK.dc=DCS[0]}
function cascadeRack(od,or,nd,nr){['ESXi','Storage','Backup','RackDevices','DCMI','Issues'].forEach(s=>DB[s].forEach(r=>{if(r.DC===od&&String(r.Rack)===String(or)){r.DC=nd;r.Rack=nr}}))}
function cascadeDC(o,n){['ESXi','Storage','Backup','Datastores','DCMI','RackDevices','DCChecks','Issues','RackList'].forEach(s=>DB[s].forEach(r=>{if(r.DC===o)r.DC=n}));if(RK.dc===o)RK.dc=n}
function rackDevCount(dc,rk){return ['ESXi','Storage','Backup','RackDevices'].reduce((n,s)=>n+DB[s].filter(r=>r.DC===dc&&String(r.Rack)===String(rk)&&parseInt(r['U start'])>=1).length,0)}
function btRow(n){return DB.BackupTypes.find(t=>t.Name===n)}
function btCounts(n){const t=btRow(n);return t?t['Counts as backup']!=='No':n!=='Exempt'}
function btCloud(n){const t=btRow(n);return t?t.Cloud==='Yes':n==='Cloud'}
function srvKind(r){const s=DB.ServerStatuses.find(x=>x.Name===r.Status);if(s)return s.Meaning||'Running';return r.Status==='Decom'?'Decommissioned':r.Status==='Off'?'Stopped':'Running'}
function syncServerStatuses(){const col=SCHEMA.ServerMI.cols.find(c=>c.k==='Status');if(!col)return;const names=DB.ServerStatuses.filter(t=>t.Active!=='No').map(t=>String(t.Name));DB.ServerMI.forEach(a=>{const v=String(a.Status||'');if(v&&names.indexOf(v)<0)names.push(v)});col.o=names}
function actionable(a){const s=DB.ActivityStatuses.find(x=>x.Name===a.Status);return !!s&&s.Actionable==='Yes'}
function syncActivityStatuses(){const col=SCHEMA.DCSSActivity.cols.find(c=>c.k==='Status');if(!col)return;const names=DB.ActivityStatuses.filter(t=>t.Active!=='No').map(t=>String(t.Name));DB.DCSSActivity.forEach(a=>{const v=String(a.Status||'');if(v&&names.indexOf(v)<0)names.push(v)});col.o=names}
function syncKBTypes(){const col=SCHEMA.KB.cols.find(c=>c.k==='Type');if(!col)return;const names=DB.KBTypes.filter(t=>t.Active!=='No').map(t=>String(t.Name));DB.KB.forEach(a=>{const v=String(a.Type||'');if(v&&names.indexOf(v)<0)names.push(v)});col.o=names;KB_TYPES.length=0;names.forEach(n=>KB_TYPES.push(n))}
function syncActivityTypes(){const col=SCHEMA.DCSSActivity.cols.find(c=>c.k==='Type');if(!col)return;const names=DB.ActivityTypes.filter(t=>t.Active!=='No').map(t=>String(t.Name));DB.DCSSActivity.forEach(a=>{const v=String(a.Type||'');if(v&&names.indexOf(v)<0)names.push(v)});col.o=names}
function syncBackupTypes(){const col=SCHEMA.BackupJobs.cols.find(c=>c.k==='Type');if(!col)return;const names=DB.BackupTypes.filter(t=>t.Active!=='No').map(t=>String(t.Name));DB.BackupJobs.forEach(j=>{const v=String(j.Type||'');if(v&&names.indexOf(v)<0)names.push(v)});col.o=names}
function envOrder(){return DB.Environments.filter(e=>e.Active!=='No').map(e=>String(e.Name))}
function syncEnvOptions(){[SCHEMA.Clusters].forEach(S=>{const c2=S&&S.cols.find(c=>c.k==='Env');if(c2){const n2=envOrder();(DB.Clusters||[]).forEach(r=>{const v=String(r.Env||'');if(v&&n2.indexOf(v)<0)n2.push(v)});c2.o=n2}});const col=SCHEMA.ServerMI.cols.find(c=>c.k==='Env');if(!col)return;const names=envOrder();DB.ServerMI.forEach(r=>{const v=String(r.Env||'');if(v&&names.indexOf(v)<0)names.push(v)});col.o=names}
const MONO=['Datastore','NAA ID','Array NAA','LUN ID','Array LUN ID','vCenter read','Array read','Hostname','Array','Device','IP','Serial','BMC IP','ESXi host','Rack','ID','Reading time'];
function load(r){return r['Limit kW']?Math.round(num(r['Power kW'])/num(r['Limit kW'])*100):0}
function dsSync(r){
const s=x=>String(x==null?'':x).trim().toLowerCase();
if(!s(r.Array)&&!s(r['Array volume']))return 'No array data';
if(!DB.Storage.some(a=>s(a.Array)===s(r.Array)))return 'Array not in Storage';
if(r.Type!=='NFS'){if(s(r['LUN ID'])!==s(r['Array LUN ID']))return 'LUN ID mismatch';if(s(r['NAA ID'])!==s(r['Array NAA']))return 'NAA mismatch'}
const a=num(r['Capacity TB']),b=num(r['Array size TB']);if(b&&Math.abs(a-b)/b>0.03)return 'Size mismatch';
return 'OK'}
function val(r,c){return c==='@cjobs'?catJobs(r).join('; '):c==='@crepl'?catRepl(r).join('; '):c==='@members'?DB.Contacts.filter(x=>x['Assignment group']===r.Group).length:c==='@load'?load(r):c==='@sync'?dsSync(r):c==='@use'?avUseText(r):/^@ds(m|cap|free|used|spread|iss)$/.test(c)?dscVal(c,r):/^@d(vm|host|st)$/.test(c)?drsVal(c,r):/^@rc(v|u|i)$/.test(c)?rcgVal(c,r):c==='@rcg'?rcgEff(r):c==='@drs'?drsSrv(r):c==='@hgrp'?hgOf(r).join('; '):c==='@ghn'?drsList(r.Hosts).length:c==='@ghr'?dhgRules(r).length:c==='@ghv'?dhgVms(r).length:c==='@vd'?sdVal(r):r[c]}
function ilo(v){v=String(v||'').trim();if(!v)return '';const h=/^https?:\/\//i.test(v)?v:'https://'+v;return '<a class="lnk" href="'+esc(h)+'" target="_blank" rel="noopener noreferrer" title="'+esc(h)+'">iLO ↗</a>'}
const REFCOL={'ESXi host':'ESXi','Failover cluster':'Clusters','Array':'Storage','Replica array':'Storage','Datastore cluster':'DatastoreClusters','Remote copy group':'RemoteCopyGroups','Array volume':'ArrayVolumes','Source array':'Storage','Target array':'Storage','Replica volume':'ArrayVolumes'};
function refIdx(v,sh){const k=RELSRC[sh][0],s=String(v).trim().toLowerCase();return DB[sh].findIndex(x=>String(x[k]).trim().toLowerCase()===s)}
function refLink(v,sh){const i=refIdx(v,sh);return i<0?'<a href="#" data-act="goto" data-v="relations" title="Not found in the inventory, open Relations">'+esc(v)+'</a>':'<a href="#" data-act="edit" data-sheet="'+sh+'" data-i="'+i+'" title="Open '+esc(v)+'">'+esc(v)+'</a>'}
function refList(v,sh){return String(v||'').split(/([;,\n]+)/).map(t=>/^[;,\n]+$/.test(t)?', ':(t.trim()?refLink(t.trim(),sh):'')).join('').replace(/^, |, $/g,'')}
function cellHtml(c,r){
const v=val(r,c);
if(c==='iLO URL')return ilo(v)||'<span class="note">—</span>';
if(c==='Last patched'){const p=patchInfo(r);return p.lp?'<span class="badge '+(PCLS[p.st]||'b-off')+'" title="'+p.st+'">'+esc(p.lp)+(p.age!=null?' · '+p.age+' d':'')+'</span>':'<span class="note">—</span>'}
if(c==='FW patched'){const d=daysTo(v);return d===null?'<span class="note">—</span>':esc(String(v).slice(0,10))+' <span class="note">· '+(-d)+' d ago</span>'}
if(c==='Support end'){const d=daysTo(v);if(d===null)return '<span class="note">—</span>';return d<0?'<span class="badge b-bad">Expired · '+esc(v)+'</span>':d<=90?'<span class="badge b-warn">'+esc(v)+' · '+d+' d</span>':'<span class="badge b-ok">'+esc(v)+'</span>'}
if(c==='@dst')return '<span class="badge '+(v==='OK'?'b-ok':v==='Violated'?'b-bad':v==='Check'?'b-warn':'b-off')+'">'+esc(v)+'</span>';
if((c==='@dvm'&&String(r.VMs||'').trim())||(c==='@dhost'&&drsEff(r).length)){const raw=c==='@dvm'?r.VMs:drsEff(r).join('; ');return '<span class="badge b-info">'+String(raw).split(/[;,\n]+/).filter(x=>x.trim()).length+'</span> '+refList(raw,c==='@dvm'?'ServerMI':'ESXi')}
if(c==='@vd')return sdCell(r);
if(c==='@drs'||c==='@hgrp')return v?esc(v):'<span class="note">—</span>';
if(c==='@rcg')return v?rcgLink(v):'<span class="note">—</span>';
if(c==='@dsiss'||c==='@rci')return v?'<span class="badge b-warn">'+v+'</span>':'<span class="badge b-ok">OK</span>';
if(c==='@use')return avUseHtml(r);
if(c==='@sync')return '<span class="badge '+(v==='OK'?'b-ok':v==='No array data'||v==='Array not in Storage'?'b-warn':'b-bad')+'">'+esc(v)+'</span>';
if(c==='@cjobs')return v?esc(v):'<span class="note">—</span>';
if(c==='@crepl')return v?esc(v):'<span class="badge b-warn">Not replicated</span>';
if(c==='Last result')return v===''?'':'<span class="badge '+(v==='OK'?'b-ok':v==='Warning'?'b-warn':v==='Failed'?'b-bad':'b-off')+'">'+esc(v)+'</span>';
if(c==='Replicated')return v===''?'':'<span class="badge '+(v==='Yes'?'b-info':'b-off')+'">'+esc(v)+'</span>';
if(c==='Exported to'){const n=String(v||'').split(/[;,\n]+/).filter(x=>x.trim()).length;return n?'<span class="badge b-info">'+n+'</span> '+refList(v,'ESXi'):'<span class="note">—</span>'}
if((c==='Hosts'||c==='VMs')&&r&&r.Rule!==undefined)return v?refList(v,c==='Hosts'?'ESXi':'ServerMI'):'<span class="note">—</span>';
if(REFCOL[c]&&v!==''&&v!=null&&!(c==='Array'&&r['Raw TB']!==undefined)){return refLink(v,REFCOL[c])}
if(c==='Active')return '<span class="badge '+(v==='No'?'b-off':'b-ok')+'">'+(v==='No'?'Inactive':'Active')+'</span>';
if((c==='Email'||c==='Email / DL')&&String(v).indexOf('@')>0)return '<a class="lnk" href="mailto:'+esc(v)+'">'+esc(v)+'</a>';
if(c==='Phone'||c==='Mobile'||c==='Phone / on-call')return v?'<span class="mono">'+esc(v)+'</span>':'';
if(c==='Env')return '<span class="badge '+envCls(v)+'">'+esc(v)+'</span>';
if(['Status','UPS','Cooling','Power','Fire/Leak','Doors','Result','Priority'].includes(c))return v===''?'':'<span class="badge '+stCls(v)+'">'+esc(v)+'</span>';
if(c==='Used %'||c==='@load'){const n=num(v);const k=n>=85?'b':n>=70?'w':'';return '<div style="display:flex;align-items:center;gap:8px;min-width:110px"><div class="bar" style="flex:1"><i class="'+k+'" style="width:'+Math.min(100,n)+'%"></i></div><span class="mono">'+n+'%</span></div>'}
if(c==='Inlet C'){const n=num(v);return '<span class="mono'+(n>=25?'" style="color:var(--bad-fg)':'')+'">'+n.toFixed(1)+'</span>'}
if(MONO.includes(c))return '<span class="mono">'+esc(v)+'</span>';
return esc(v);
}
function labelOf(c,sh){if(c==='@hgrp')return 'Host group';if(c==='@ghn')return 'Hosts';if(c==='@ghr')return 'Rules';if(c==='@ghv')return 'VMs here now';if(sh&&SCHEMA[sh]){const d=SCHEMA[sh].cols.find(x=>x.k===c);if(d&&d.label)return d.label}return c==='@cjobs'?'Backup jobs stored':c==='@crepl'?'Replicated to':c==='@members'?'Contacts':c==='@vd'?'VMDKs':c==='@load'?'Load %':c==='@sync'?'vCenter vs array':c==='@use'?'Used by':{'@dsm':'Datastores','@dscap':'Capacity','@dsfree':'Free','@dsused':'Used','@dsspread':'Spread','@dsiss':'Problems','@dvm':'VMs','@dhost':'Hosts','@dst':'Status','@drs':'DRS rules','@rcv':'Volumes','@rcu':'Used by','@rci':'Problems','@rcg':'Remote copy group'}[c]||c}
const soon=r=>{const d=daysTo(r['Support end']);return d!==null&&d<=90};
const expired=r=>{const d=daysTo(r['Support end']);return d!==null&&d<0};
const sum=(a,k)=>a.reduce((s,r)=>s+num(r[k]),0);
const r1=n=>Math.round(n*10)/10;
const TV={
Contacts:{id:'contacts',title:'Contacts',sub:'Person contacts for escalations, vendors and teams · sheet “Contacts”',add:'Add contact',filter:'Active',show:['Name','Company / team','Role','Email','Phone','Mobile','Assignment group','Active'],
kpis:d=>[{l:'Contacts',v:d.length,s:d.filter(r=>r.Active!=='No').length+' active'},{l:'Without email and phone',v:d.filter(r=>!r.Email&&!r.Phone&&!r.Mobile).length,s:'cannot be reached',c:d.some(r=>!r.Email&&!r.Phone&&!r.Mobile)?'w':''},{l:'Without a group',v:d.filter(r=>!r['Assignment group']).length,s:'no assignment group set'}]},
AssignGroups:{id:'agroups',title:'Assignment groups',sub:'Teams and queues that issues and activities are assigned to · sheet “AssignGroups”',add:'Add group',filter:'Active',show:['Group','Description','Manager','Email / DL','Phone / on-call','Support hours','Queue / tool','@members','Active'],
kpis:d=>[{l:'Groups',v:d.length,s:d.filter(r=>r.Active!=='No').length+' active'},{l:'Without a manager',v:d.filter(r=>!r.Manager).length,s:'set one for escalation',c:d.some(r=>!r.Manager)?'w':''},{l:'Without an email or on-call phone',v:d.filter(r=>!r['Email / DL']&&!r['Phone / on-call']).length,s:'no way to reach the group',c:d.some(r=>!r['Email / DL']&&!r['Phone / on-call'])?'w':''}]},
DCSSActivity:{id:'activity',title:'DCSS activity',sub:'Log of data center activities (changes, maintenance, visits, audits) kept so you can revisit them later · sheet “DCSSActivity”',add:'Log activity',filter:'Status',sort:['Date',-1],show:['ID','Date','Title','Type','DC','Performed by','Assignment group','Ticket / ref','Status'],
kpis:d=>{const n30=d.filter(r=>{const x=daysTo(r.Date);return x!==null&&x<=0&&x>=-30}).length,last=d.filter(r=>r.Status==='Done').sort((a,b)=>String(b.Date).localeCompare(String(a.Date)))[0];return[{l:'Activities logged',v:d.length,s:d.filter(r=>r.Status==='Done').length+' done'},{l:'Last 30 days',v:n30,s:'activities'},{l:'Planned or in progress',v:d.filter(r=>r.Status==='Planned'||r.Status==='In progress').length,s:'still to do'},{l:'Last completed',v:last?String(last.Date).slice(0,10):'—',s:last?ago(last.Date)+' · '+esc(last.Title):'Nothing yet'}]}},
ServerMI:{id:'servermi',title:'ServersMI',sub:'Server master inventory (virtual and physical) · sheet “ServersMI”',add:'Add server',filter:'Env',show:['Hostname','FQDN','vCenter name','IP','OS','Platform','Env','Cluster','Cluster/Standalone','Failover cluster','@hgrp','@drs','vCPU','RAM GB','Disk GB','@vd','Owner','Support end','Last patched','Last patch CRQ','FW patched','iLO URL','Status'],
kpis:d=>[{l:'Servers',v:d.length,s:d.filter(r=>srvKind(r)==='Running').length+' powered on'},{l:'Production',v:d.filter(envProd).length,s:Math.round(d.filter(envProd).length/(d.length||1)*100)+'% of inventory'},{l:'Support ends ≤ 90 days',v:d.filter(soon).length,s:d.filter(expired).length+' already expired',c:d.filter(soon).length?'w':''},{l:'Missing owner',v:d.filter(r=>!r.Owner).length,s:'Data quality',c:d.filter(r=>!r.Owner).length?'b':''}]},
ESXi:{id:'esxi',title:'ESXi hosts',sub:'All ESXi host details with data center and rack position · sheet “ESXi”',add:'Add host',filter:'DC',show:['Hostname','DC','Rack','U start','U size','Cluster','ESXi version','vCenter','CPU','RAM GB','VMs','BMC IP','iLO URL','Model','Serial','FW patched','Support end','Status'],
kpis:d=>[{l:'Hosts',v:d.length,s:d.filter(r=>r.Status==='Maintenance').length+' in maintenance'},{l:'Virtual machines',v:sum(d,'VMs'),s:'~'+r1(sum(d,'VMs')/(d.length||1))+' per host'},{l:'Total RAM',v:r1(sum(d,'RAM GB')/1024)+' TB',s:'across all hosts'},{l:'Support ends ≤ 90 days',v:d.filter(soon).length,s:d.filter(expired).length+' expired',c:d.filter(soon).length?'w':''}]},
Storage:{id:'storage',title:'Storage',sub:'SAN storage arrays with data center and rack position · sheet “Storage”',add:'Add array',filter:'DC',show:['Array','DC','Rack','U start','U size','Model','Serial','Firmware','Protocol','Raw TB','Usable TB','Used %','Controllers','iLO URL','FW patched','Support end','Status'],
kpis:d=>[{l:'Arrays',v:d.length,s:d.filter(r=>r.Status==='Degraded').length+' degraded',c:d.some(r=>r.Status==='Degraded')?'w':''},{l:'Raw capacity',v:sum(d,'Raw TB')+' TB',s:''},{l:'Usable capacity',v:sum(d,'Usable TB')+' TB',s:'avg used '+Math.round(sum(d,'Used %')/(d.length||1))+'%'},{l:'Arrays ≥ 85% used',v:d.filter(r=>num(r['Used %'])>=85).length,s:'Plan expansion',c:d.some(r=>num(r['Used %'])>=85)?'w':''}]},
ArrayParts:{id:'arrayparts',title:'Array components',sub:'Cages, controller nodes and service processors of storage arrays and backup devices · sheet “ArrayParts”. Use Array hardware for the bay view.',add:'Add component',filter:'Kind',show:['Part','Device','Kind','Cage ID','Profile','DC','Rack','U start','U size','Serial','State'],
kpis:d=>[{l:'Components',v:d.length,s:d.filter(r=>/enclosure/i.test(r.Kind)).length+' enclosures'},{l:'Not placed in a rack',v:d.filter(r=>r.Kind!=='Controller node'&&r.Kind!=='Controller enclosure'&&!(r.Rack&&r['U start']!=='')).length,s:'Set DC, rack and U',c:''},{l:'Degraded or failed',v:d.filter(r=>r.State==='Degraded'||r.State==='Failed').length,s:'',c:d.some(r=>r.State==='Failed')?'b':''}]},
Backup:{id:'backup',title:'Backup',sub:'Backup hardware with data center and rack position · sheet “Backup”',add:'Add device',filter:'DC',show:['Device','DC','Rack','U start','U size','Type','Model','Software','Capacity TB','Used %','Retention','Serial','iLO URL','FW patched','Support end','Status'],
kpis:d=>[{l:'Devices',v:d.length,s:d.filter(r=>r.Type==='Tape library').length+' tape library'},{l:'Capacity',v:sum(d,'Capacity TB')+' TB',s:''},{l:'Devices ≥ 85% used',v:d.filter(r=>num(r['Used %'])>=85).length,s:'Plan expansion',c:d.some(r=>num(r['Used %'])>=85)?'w':''},{l:'Support ends ≤ 90 days',v:d.filter(soon).length,s:d.filter(expired).length+' expired',c:d.filter(soon).length?'w':''}]},
Datastores:{id:'datastores',title:'Datastores',sub:'Datastores as read from vCenter, matched with the storage array (LUN IDs, size) · sheet “Datastores”. Columns Capacity to vCenter read come from vCenter, columns starting with “Array” come from the array.',add:'Add datastore',filter:'DC',show:['Datastore','DC','Cluster','Datastore cluster','Type','LUN ID','NAA ID','Capacity TB','Free TB','Used %','VMs','Array','Array volume','Remote copy group','Array LUN ID','Array size TB','@sync','vCenter read'],
kpis:d=>{const bad=d.filter(r=>dsSync(r)!=='OK'),full=d.filter(r=>num(r['Used %'])>=85);return[{l:'Datastores',v:d.length,s:d.filter(r=>r.Type==='NFS').length+' NFS'},{l:'Capacity (vCenter)',v:r1(sum(d,'Capacity TB'))+' TB',s:r1(sum(d,'Free TB'))+' TB free'},{l:'Used 85% or more',v:full.length,s:'Plan expansion',c:full.length?'w':''},{l:'vCenter vs array',v:bad.length,s:bad.length?'differences found':'all values match',c:bad.length?'w':'g'}]}},
RackDevices:{pre:()=>physBanner(),id:'otherdevices',title:'Other devices',sub:'Network and other rack devices with data center and rack position · sheet “RackDevices”. The types come from Settings.',add:'Add device',filter:'DC',show:['Name','Type','DC','Rack','U start','U size','Model','Serial','Support end','Status'],
kpis:d=>[{l:'Devices',v:d.length,s:new Set(d.map(r=>r.Type)).size+' types'},{l:'Not in a rack',v:d.filter(r=>!(parseInt(r['U start'])>=1)||!r.Rack).length,s:'Place them on the rack layout',c:d.some(r=>!(parseInt(r['U start'])>=1)||!r.Rack)?'w':''},{l:'Support ends ≤ 90 days',v:d.filter(soon).length,s:d.filter(expired).length+' expired',c:d.filter(soon).length?'w':''}]},
DCMI:{id:'dcmi',title:'DCMI',sub:'Data center master inventory and readings, one row per rack · sheet “DCMI”',add:'Add reading',filter:'DC',show:['DC','Rack','Power kW','Limit kW','@load','Inlet C','Humidity %','Reading time'],
kpis:d=>{const hot=d.filter(r=>load(r)>=80).length;return[{l:'IT load',v:r1(sum(d,'Power kW'))+' kW',s:'of '+r1(sum(d,'Limit kW'))+' kW rack limits'},{l:'Avg inlet temp',v:r1(sum(d,'Inlet C')/(d.length||1))+' °C',s:d.filter(r=>num(r['Inlet C'])>=25).length+' racks ≥ 25 °C',c:d.some(r=>num(r['Inlet C'])>=25)?'w':'g'},{l:'Avg humidity',v:r1(sum(d,'Humidity %')/(d.length||1))+' %',s:'Target 40–60 %'},{l:'Racks ≥ 80% power',v:hot,s:'of '+d.length+' racks',c:hot?'w':''}]},
pre:()=>heatHtml()},
PatchEvents:{id:'patchevents',title:'Patching events',sub:'Planned and finished patching windows, shown in the Overview calendar · sheet “PatchEvents”',add:'Add patching activity',filter:'Status',sort:['Date',-1],show:['ID','Date','End date','Title','CRQ','Status','Servers','In calendar','Notes'],
kpis:d=>[{l:'Events',v:d.length,s:d.filter(r=>r.Status==='Done').length+' done'},{l:'Planned',v:d.filter(r=>r.Status==='Planned'||r.Status==='In progress').length,s:'upcoming or running'},{l:'In calendar',v:d.filter(r=>r['In calendar']!=='No').length,s:'shown on Overview'}]},
NetPorts:{id:'netports',title:'Ports',sub:'All ports and cable connections · sheet “NetPorts”. Use Ports & cabling for the graphical view.',add:'Add port',filter:'State',show:['Device','Port','Kind','Speed','State','Remote device','Remote port','Cable','VLAN / purpose'],
kpis:d=>[{l:'Ports',v:d.length,s:new Set(d.map(r=>r.Device)).size+' devices'},{l:'Connected',v:d.filter(r=>r.State==='Connected').length,s:'with a cable'},{l:'Free',v:d.filter(r=>(r.State||'Free')==='Free').length,s:'available'}]},
Disks:{id:'disklist',title:'Disks',sub:'All disks · sheet “Disks”. Use Disks for the graphical bay view.',add:'Add disk',filter:'State',show:['Device','Drawer','Row','Slot','Type','Size TB','State','Model','Serial','Group / pool'],
kpis:d=>[{l:'Disks',v:d.length,s:new Set(d.map(r=>r.Device)).size+' devices'},{l:'Raw capacity',v:r1(sum(d.filter(r=>r.State!=='Empty'),'Size TB'))+' TB',s:'excluding empty slots'},{l:'Failed / predictive',v:d.filter(r=>r.State==='Failed'||r.State==='Predictive fail').length,s:'replace soon',c:d.some(r=>r.State==='Failed'||r.State==='Predictive fail')?'w':''}]},
ActivityLog:{id:'activitylog',title:'Activity log',sub:'When and by whom the workbook was changed, written on every Save to Excel · sheet “ActivityLog”. For internal team review.',add:'Add note',filter:'Action',sort:['Time',-1],show:['Time','User','Action','Sheet','Record','Details'],
kpis:d=>{const last=d.slice().sort((x,y)=>String(y.Time).localeCompare(String(x.Time)))[0];return[{l:'Entries',v:d.length,s:new Set(d.map(r=>r.User).filter(Boolean)).size+' people'},{l:'Last save',v:last?String(last.Time).slice(0,10):'—',s:last?(last.User||'unknown user'):'Nothing logged yet'},{l:'Deleted records',v:d.filter(r=>r.Action==='Deleted').length,s:'logged deletions',c:d.some(r=>r.Action==='Deleted')?'w':''}]},
pre:()=>logPre()},
Catalyst:{id:'catalyst',title:'Catalyst stores',sub:'StoreOnce Catalyst stores: which backup jobs write to them and where they are replicated · sheet “Catalyst”. Jobs come from Backup jobs (column Catalyst store), replication from Replication jobs or the Replica columns.',add:'Add store',filter:'Status',show:['Store','Appliance','DC','Capacity TB','Used %','Dedup ratio','@cjobs','@crepl','Status'],
kpis:d=>[{l:'Catalyst stores',v:d.length,s:new Set(d.map(r=>r.Appliance)).size+' appliances'},{l:'Capacity',v:r1(sum(d,'Capacity TB'))+' TB',s:'avg used '+Math.round(sum(d,'Used %')/(d.length||1))+'%'},{l:'Used 85% or more',v:d.filter(r=>num(r['Used %'])>=85).length,s:'Plan expansion',c:d.some(r=>num(r['Used %'])>=85)?'w':''},{l:'Not replicated',v:d.filter(r=>!catRepl(r).length).length,s:'no replica or copy job',c:d.some(r=>!catRepl(r).length)?'w':'g'}]},
Clusters:{id:'clusters',title:'Failover clusters',sub:'Microsoft failover clusters',add:'Add cluster',filter:'Env',show:['Cluster','Cluster IP','Env','DC','Purpose','Quorum type','Owner'],kpis:d=>[]},
Todos:{id:'todo',title:'To do & notes',sub:'Personal and shared to do items · sheet “Todos”',add:'Add item',filter:'Scope',show:['Text','Scope','Owner','Priority','Due','Done'],kpis:d=>[]},
ClusterNodes:{id:'clusternodes',title:'Cluster nodes',sub:'Nodes of the failover clusters',add:'Add node',filter:'Primary',show:['Cluster','Node','Primary','Note'],kpis:d=>[]},
ClusterRoles:{id:'clusterroles',title:'Cluster roles',sub:'Roles of the failover clusters',add:'Add role',filter:'Type',show:['Cluster','Role','Type','Virtual name','State','Owner node','Role IP','Drives'],kpis:d=>[]},
RemoteCopyGroups:{id:'remotecopy',title:'Remote copy groups',sub:'3PAR Remote Copy groups: which array replicates to which, the mode and the volumes in the group. Volumes, datastores and cluster RDM drives point to their group in the field Remote copy group · sheet “RemoteCopyGroups”.',add:'Add remote copy group',filter:'Mode',show:['Group','Source array','Target array','Mode','Sync period (min)','RPO target (min)','Status','@rcv','@rcu','@rci','Owner'],kpis:d=>[{l:'Groups',v:d.length,s:d.filter(g=>/async/i.test(g.Mode)).length+' asynchronous, '+d.filter(g=>/Sync/.test(g.Mode)&&!/async/i.test(g.Mode)).length+' synchronous'},{l:'Volumes in groups',v:avA().filter(v=>v['Remote copy group']).length,s:'array volumes'},{l:'Not started',v:d.filter(g=>g.Status&&g.Status!=='Started').length,s:'stopped or failed over',c:d.some(g=>g.Status&&g.Status!=='Started')?'b':'g'},{l:'With problems',v:d.filter(g=>rcgIssues(g).length).length,s:'see the checks column',c:'w'}]},
DrsRules:{id:'drsrules',title:'DRS rules',sub:'VMware DRS affinity and anti-affinity rules: which VMs stay together or apart, and which hosts VMs may run on · sheet “DrsRules”. DRS moves VMs around, so the current host is only compared with the rules, never stored here.',add:'Add DRS rule',filter:'Type',show:['Rule','Cluster','Type','Host group','Enabled','@dvm','@dhost','@dst','Owner'],kpis:d=>[{l:'DRS rules',v:d.length,s:d.filter(r=>drsK(r.Type)==='anti').length+' anti-affinity, '+d.filter(r=>drsK(r.Type)==='aff').length+' affinity'},{l:'VM-host rules',v:d.filter(r=>!/^(aff|anti)$/.test(drsK(r.Type))).length,s:'must / should run on or not'},{l:'Violated now',v:d.filter(r=>drsStatus(r)==='Violated').length,s:'current VM placement',c:d.some(r=>drsStatus(r)==='Violated')?'b':'g'},{l:'Need a look',v:d.filter(r=>drsStatus(r)==='Check').length+drsConflicts().length,s:'config problems, conflicts',c:'w'}]},
DrsHostGroups:{id:'drshostgroups',title:'DRS host groups',sub:'VMware DRS host groups: named sets of ESXi hosts used by VM-host rules, like VM groups but for hosts · sheet “DrsHostGroups”. VMs show the host group they run in, not the individual host.',add:'Add host group',filter:'Cluster',show:['Group','Cluster','vCenter','@ghn','@ghr','@ghv','Owner'],kpis:d=>[{l:'Host groups',v:d.length,s:new Set(d.map(r=>r.Cluster)).size+' clusters'},{l:'Unused',v:d.filter(r=>!dhgRules(r).length).length,s:'no rule uses them'},{l:'Need a look',v:d.filter(r=>dhgIssues(r).length).length,s:'config problems',c:d.some(r=>dhgIssues(r).length)?'b':'g'},{l:'Hosts covered',v:new Set([].concat(...d.map(r=>drsList(r.Hosts).map(shortN)))).size,s:'in at least one group'}]},
DatastoreClusters:{id:'datastoreclusters',title:'Datastore clusters',sub:'VMware datastore clusters (Storage DRS pods): which datastores belong together, SDRS settings and space balance · sheet “DatastoreClusters”. Assign datastores in the Datastore cluster field of each datastore.',add:'Add datastore cluster',filter:'DC',show:['Datastore cluster','DC','vCenter','SDRS automation','Space threshold %','@dsm','@dscap','@dsfree','@dsused','@dsspread','@dsiss'],kpis:d=>[{l:'Datastore clusters',v:d.length,s:DB.Datastores.filter(x=>x['Datastore cluster']).length+' datastores in a cluster'},{l:'Datastores not in a cluster',v:DB.Datastores.filter(x=>!x['Datastore cluster']&&x.Type!=='NFS').length,s:'VMFS, stand-alone'},{l:'Over threshold',v:d.filter(c=>dscMem(c['Datastore cluster']).some(x=>num(x.d['Used %'])>=(num(c['Space threshold %'])||80))).length,s:'clusters with a full member',c:'w'},{l:'With problems',v:d.filter(c=>dscIssues(c).length).length,s:'see the checks column'}]},
ArrayVolumes:{id:'arrayvolumes',title:'Array volumes',sub:'Volumes (LUNs) of the storage arrays, e.g. 3PAR, and what they are used for: cluster RDM drives, witnesses, datastores or server disks · sheet “ArrayVolumes”. Import them from the array on Data sources.',add:'Add volume',filter:'Array',show:['Volume','Array','Pool / CPG','Size GB','LUN ID','NAA ID','Replicated','Remote copy group','Replica array','Exported to','@use'],kpis:d=>avKpis(d)},
ClusterResources:{id:'clusterresources',title:'Cluster role resources',sub:'Resources inside the cluster roles: virtual names, IPs, disks, services, shares',add:'Add resource',filter:'Resource type',show:['Cluster','Role','Resource','Resource type','State','Owner node','Details'],kpis:d=>[]},
ClusterDisks:{id:'clusterdisks',title:'Cluster drives',sub:'Drives of the failover clusters',add:'Add drive',filter:'Type',show:['Cluster','Disk','Drive / mount','Size GB','Type','LUN ID','NAA ID','Datastore / array','Remote copy group','Role'],kpis:d=>[]},
ServerDisks:{id:'serverdisks',title:'Server disks',sub:'Every disk of every server: VMDKs, RDMs and direct LUNs · sheet “ServerDisks”. Open a server to see its own disks and compare their total with Disk GB.',add:'Add disk',filter:'Type',show:['Server','Disk','Drive / mount','Size GB','Type','Provisioning','Purpose','Datastore / array','Disk path','SCSI ID','LUN ID'],kpis:d=>[{l:'Disks',v:d.length,s:new Set(d.map(r=>shortN(r.Server))).size+' servers'},{l:'Total size',v:r1(sum(d,'Size GB')/1024)+' TB',s:'all listed disks'},{l:'VMDKs',v:d.filter(r=>r.Type==='VMDK').length,s:d.filter(r=>r.Provisioning==='Thin').length+' thin'},{l:'Size mismatches',v:sdIssues().length,s:'VMDK total vs Disk GB',c:sdIssues().length?'w':''}]},
ServerNics:{id:'servernics',title:'Network interfaces',sub:'Network interfaces of a server',add:'Add interface',filter:'Purpose',show:['Server','Interface','Purpose','IP','Subnet / prefix','VLAN','DNS name','MAC','Port group / switch'],kpis:d=>[]},
ReplJobs:{id:'repljobs',title:'Replication jobs',sub:'Data Protector object copy and StoreOnce replication jobs: source, target and what they copy · sheet “ReplJobs”',add:'Add replication job',filter:'Last result',show:['Job','Type','Source appliance','Source store','Target appliance','Target store','Backup jobs replicated','Schedule','Copy retention','Last run','Last result','Active'],
kpis:d=>{const a=d.filter(r=>r.Active!=='No');return[{l:'Replication jobs',v:d.length,s:a.length+' active'},{l:'Last run failed',v:d.filter(r=>r['Last result']==='Failed').length,s:'check Data Protector',c:d.some(r=>r['Last result']==='Failed')?'b':'g'},{l:'With warnings',v:d.filter(r=>r['Last result']==='Warning').length,s:'',c:d.some(r=>r['Last result']==='Warning')?'w':'g'},{l:'Not run for 7+ days',v:a.filter(r=>{const x=daysTo(r['Last run']);return x===null||x<-7}).length,s:'or never run',c:a.some(r=>{const x=daysTo(r['Last run']);return x===null||x<-7})?'w':'g'}]}},
DCLayout:{id:'dclayoutlist',title:'DC designer blocks',sub:'All blocks of the DC designer · sheet “DCLayout”. Use DC designer to move them around.',add:'Add block',filter:'Kind',show:['DC','Block','Kind','X m','Y m','Width m','Height m','Rotation','Capacity kW','Locked','Rack'],
kpis:d=>[{l:'Blocks',v:d.length,s:new Set(d.map(r=>r.DC)).size+' data centers'},{l:'Racks',v:d.filter(r=>r.Kind==='Rack'||r.Kind==='Rack row').length,s:''},{l:'Containers',v:d.filter(r=>/^Container/.test(r.Kind)).length,s:''}]},
DCChecks:{id:'checks',title:'DC checks',sub:'Data center check log, entered by hand when you do a check (optional) · sheet “DCChecks”',add:'New check',filter:'DC',sort:['Date',-1],show:['Date','DC','Checked by','Temp C','Humidity %','UPS','Cooling','Power','Fire/Leak','Doors','Result','Notes'],
kpis:d=>{const last=d.slice().sort((x,y)=>String(y.Date).localeCompare(String(x.Date)))[0];return[{l:'Checks logged',v:d.length,s:'on '+(new Set(d.map(r=>String(r.Date).slice(0,10))).size)+' days'},{l:'Last check',v:last?String(last.Date).slice(0,10):'—',s:last?ago(last.Date)+' · '+(last.DC||''):'Nothing logged yet'},{l:'Checks with issues',v:d.filter(r=>r.Result==='Issue').length,s:'in the log',c:d.some(r=>r.Result==='Issue')?'w':''}]}}
};
function heatHtml(){
return '<div class="row">'+DCS.map(dc=>'<div class="card"><h2>Rack power load · '+dc+'</h2><div class="heat">'+dcRacks(dc).map(rk=>{const r=DB.DCMI.find(x=>x.DC===dc&&x.Rack===rk);if(!r)return '<div class="cell h1"><span class="mono">'+rk+'</span><span>no reading</span></div>';const l=load(r);const k=l>=80?'h4':l>=60?'h3':l>=40?'h2':'h1';return '<div class="cell '+k+'"><span class="mono">'+rk+'</span><b style="font-size:18px">'+l+'%'+(l>=80?' ▲':'')+'</b></div>'}).join('')+'</div></div>').join('')+'</div><div class="leg"><span><i style="background:var(--info-bg)"></i>&lt; 40%</span><span><i style="background:var(--h2c)"></i>40–59%</span><span><i style="background:var(--h3c)"></i>60–79%</span><span><i style="background:#B85C00"></i>≥ 80% ▲</span></div>';
}
function uiOf(s){if(!UI[s]){const t=TV[s];UI[s]={q:'',f:'All',fl:[],open:false,sk:t.sort?t.sort[0]:(t.show[0]||null),sd:t.sort?t.sort[1]:(s==='DCSSActivity'?-1:1)}}return UI[s]}
function tableView(sheet){
const t=TV[sheet],u=uiOf(sheet),d=DB[sheet];if(t.filter==='Env')syncEnvOptions();
const fo=['All'].concat(SCHEMA[sheet].cols.find(c=>c.k===t.filter).o);
const u0=sheetUpdated(sheet),fr=fresh(u0);
return '<div class="head"><div><h1>'+t.title+'</h1><p>'+t.sub+'</p><div class="meta"><span class="dot '+fr[0]+'"></span>Data as of '+(u0||'—')+' · '+ago(u0)+' <span class="sep">·</span> '+d.length+' row'+(d.length===1?'':'s')+'</div></div><div class="tools"><details class="menu"><summary class="btn"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M12 4v11M7 10l5 5 5-5M5 20h14"/></svg>Export</summary><div class="pop"><label class="note" for="csv-sep">CSV separator<select class="inp" id="csv-sep"><option value=";"'+((META.csvSep||';')===';'?' selected':'')+'>Semicolon ( ; ) for Excel EU</option><option value=","'+(META.csvSep===','?' selected':'')+'>Comma ( , )</option></select></label><button class="btn p" data-act="csv" data-sheet="'+sheet+'">Download CSV</button><span class="note">Uses the current filter, search, sort and columns.</span></div></details><button class="btn" data-act="cols" data-sheet="'+sheet+'"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16M15 4v16"/></svg>Columns</button><button class="btn p" data-act="add" data-sheet="'+sheet+'">+ '+t.add+'</button></div></div>'
+'<div class="kpis">'+t.kpis(d).map(k=>'<div class="kpi"><span>'+k.l+'</span><b>'+k.v+'</b><small class="'+(k.c||'')+'">'+(k.s||'&nbsp;')+'</small></div>').join('')+'</div>'
+(t.pre?t.pre():'')
+'<section class="card" style="padding:0"><div class="tools" style="padding:14px 16px;justify-content:space-between"><div class="chips" id="chips">'+chipsHtml(sheet,fo)+'</div><div class="tools"><button class="btn fbtn'+(u.open||u.fl.length?' p':'')+'" data-act="ftoggle" data-sheet="'+sheet+'" aria-expanded="'+(u.open?'true':'false')+'"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4 2v-8z"/></svg>Filters'+(u.fl.length?' ('+u.fl.length+')':'')+'</button>'+(u.fl.length?'<button class="btn" data-act="fclear" data-sheet="'+sheet+'">Clear filters ✕</button>':'')+'<input class="inp srch" id="q-'+sheet+'" type="search" data-act="q" data-sheet="'+sheet+'" placeholder="Search…" aria-label="Search '+t.title+'" value="'+esc(u.q)+'"></div></div>'+listBar(sheet)+'<div id="fsum">'+fsummaryHtml(sheet)+'</div>'+(u.open?fpanelHtml(sheet):'')+'<div class="tw" id="tbl">'+tableHtml(sheet)+'</div></section>'
+'<p class="hint">Click a value to edit it in place (Enter = next row, Tab = next cell, Esc = cancel), ✎ opens the full form · Shift+click a header = second sort · drag over cells (or Alt+click a header) then Ctrl+C copies them · drag a column header to move it · changes stay in the page until Save to Excel'+(DEMO?' · sample data':'')+'</p>';
}
function fmatch(u,t,r){return u.fm&&u.fm.length?u.fm.indexOf(String(r[t.filter]))>=0:(u.f==='All'||r[t.filter]===u.f)}
function chipsHtml(sheet,fo){const u=uiOf(sheet),fm=u.fm||[];return fo.map(o=>'<button class="chip'+((fm.length?fm.indexOf(o)>=0:u.f===o)?' on':'')+'" data-act="chip" data-sheet="'+sheet+'" data-v="'+esc(o)+'" title="Shift+click to select several">'+esc(o)+'</button>').join('')+(fo.length>2?'<span class="hint" style="margin:0 0 0 4px">Shift+click to pick several</span>':'')}

/* ---------- paging (keeps big sheets fast) ---------- */
let PGS=100;try{const v=parseInt(localStorage.getItem('ii-ps'),10);if(v>=0&&!isNaN(v))PGS=v}catch(e){}
function pgSlice(sheet,u,rows){const tot=rows.length,ps=PGS;if(!(ps>0)||tot<=ps){u.pg=0;return{rows:rows,tot:tot,ps:ps,pg:0,pages:1,a:1,b:tot}}
const sig=[u.f,(u.fm||[]).join(','),u.q,u.sk,u.sd,JSON.stringify(u.sx||[]),JSON.stringify(u.fl||[])].join('|');if(u.psig!==sig){u.psig=sig;u.pg=0}
const pages=Math.ceil(tot/ps),pg=Math.min(Math.max(u.pg||0,0),pages-1);u.pg=pg;
return{rows:rows.slice(pg*ps,pg*ps+ps),tot:tot,ps:ps,pg:pg,pages:pages,a:pg*ps+1,b:Math.min(tot,pg*ps+ps)}}
function pagerHtml(sheet,p,all){
const sh=' data-sheet="'+sheet+'"';
const cnt=p.pages>1?'Showing '+p.a+'–'+p.b+' of '+p.tot:'Showing '+p.tot+' of '+all;
const flt=p.tot<all&&p.pages>1?' (filtered from '+all+')':'';
let h='<div class="pager"><span class="note">'+cnt+flt+'</span>';
if(all>50||p.pages>1){h+='<span class="pgc">'+(p.pages>1?'<button class="btn s" data-act="pgfirst"'+sh+(p.pg?'':' disabled')+' aria-label="First page">«</button><button class="btn s" data-act="pgprev"'+sh+(p.pg?'':' disabled')+' aria-label="Previous page">‹ Prev</button><span class="note">Page '+(p.pg+1)+' of '+p.pages+'</span><button class="btn s" data-act="pgnext"'+sh+(p.pg<p.pages-1?'':' disabled')+' aria-label="Next page">Next ›</button><button class="btn s" data-act="pglast"'+sh+(p.pg<p.pages-1?'':' disabled')+' aria-label="Last page">»</button>':'')
+'<label class="note pgs">Rows per page <select class="inp" data-act="pgsize" aria-label="Rows per page">'+[50,100,250,500,1000,0].map(n=>'<option value="'+n+'"'+(PGS===n?' selected':'')+'>'+(n||'All')+'</option>').join('')+'</select></label></span>'}
return h+'</div>'}
function pgSet(sheet,fn){const u=uiOf(sheet);fn(u);redrawTable(sheet);const t=$('tbl');if(t&&t.scrollIntoView){const c=t.closest('.card');if(c&&c.getBoundingClientRect().top<0)c.scrollIntoView({block:'start'})}}
const PGACT={
pgfirst(el){pgSet(el.dataset.sheet,u=>{u.pg=0})},
pgprev(el){pgSet(el.dataset.sheet,u=>{u.pg=Math.max(0,(u.pg||0)-1)})},
pgnext(el){pgSet(el.dataset.sheet,u=>{u.pg=(u.pg||0)+1})},
pglast(el){pgSet(el.dataset.sheet,u=>{u.pg=1e9})},
pgsize(el){PGS=parseInt(el.value,10)||0;try{localStorage.setItem('ii-ps',String(PGS))}catch(e){}Object.keys(UI||{}).forEach(k=>{if(UI[k])UI[k].pg=0});const sh=(document.querySelector('[data-act=pgnext],[data-act=pgprev]')||{dataset:{}}).dataset.sheet;route()}};
function tableHtml(sheet){
const t=TV[sheet],u=uiOf(sheet),d=DB[sheet];
let rows=d.map((r,i)=>({r,i}));
rows=rows.filter(x=>fmatch(u,t,x.r));
rows=applyFilters(sheet,rows);
if(u.q){const q=u.q.toLowerCase();rows=rows.filter(x=>Object.keys(x.r).some(k=>k!=='Updated'&&String(x.r[k]).toLowerCase().includes(q)))}
rowsSort(rows,u);
if(!rows.length)return '<div class="empty">No rows match. Change the filter or add a row.</div>';
selPrune(sheet);const ss=selSet(sheet),allOn=rows.length>0&&rows.every(x=>ss.has(x.r));
if(u.view&&u.view!=='table')return listAlt(sheet,rows,u,ss,d.length);
const allRows=rows;const pgi=pgSlice(sheet,u,rows);rows=pgi.rows;
return bulkBar(sheet)+'<table class="hasSel"><thead><tr><th class="selc"><input type="checkbox" data-act="selall" data-sheet="'+sheet+'" aria-label="Select all rows in this view"'+(allOn?' checked':'')+'></th>'+t.show.map(c=>'<th scope="col" draggable="true" title="Click to sort, Shift+click to add a second / third sort, drag to move" data-act="sort" data-sheet="'+sheet+'" data-col="'+c+'">'+labelOf(c,sheet)+sortMark(u,c)+'<button type="button" class="hf'+(hfActive(sheet,c)?' on':'')+'" data-act="hfopen" data-sheet="'+sheet+'" data-col="'+esc(c)+'" aria-label="Filter '+esc(labelOf(c,sheet))+'" title="Filter this column">'+HF_SVG+'</button></th>').join('')+'</tr></thead><tbody>'+rows.map(x=>'<tr class="clk'+(ss.has(x.r)?' picked':'')+'" data-tone="'+rowTone(sheet,x.r)+'" tabindex="0" data-act="edit" data-sheet="'+sheet+'" data-i="'+x.i+'"><td class="selc"><input type="checkbox" data-act="rowsel" data-sheet="'+sheet+'" data-i="'+x.i+'" aria-label="Select row"'+(ss.has(x.r)?' checked':'')+'></td>'+t.show.map((c,ci)=>'<td'+(cellTone(c,x.r)?' class="'+cellTone(c,x.r)+'"':'')+'>'+cellHtml(c,x.r)+(ci===t.show.length-1?qaHtml(sheet,x.i,x.r):'')+'</td>').join('')+'</tr>').join('')+'</tbody></table>'+totalsHtml(sheet,allRows)+pagerHtml(sheet,pgi,d.length);
}
function redrawTable(sheet){const el=$('tbl');if(el)el.innerHTML=tableHtml(sheet);const fs=$('fsum');if(fs)fs.innerHTML=fsummaryHtml(sheet)}

/* ---------- edit form ---------- */
function nameOpts(sheet,k){const cn=clusterOpts(sheet,k);if(cn)return cn;return sheet==='Contacts'&&k==='Assignment group'||sheet==='DCSSActivity'&&k==='Assignment group'?DB.AssignGroups.filter(o=>o.Active!=='No').map(o=>String(o.Group)):sheet==='AssignGroups'&&k==='Manager'?DB.Contacts.filter(o=>o.Active!=='No').map(o=>String(o.Name)):(sheet==='ESXi'||sheet==='ServerMI')&&k==='Enclosure'?enclNames():(sheet==='Catalyst'&&(k==='Appliance'||k==='Replica appliance'))?DB.Backup.map(r=>String(r.Device)):(sheet==='Catalyst'&&k==='Replica store')||(sheet==='ReplJobs'&&(k==='Source store'||k==='Target store'))||(sheet==='BackupJobs'&&k==='Catalyst store')?DB.Catalyst.map(r=>String(r.Store)):(sheet==='NetPorts'&&(k==='Device'||k==='Remote device'))||(sheet==='Disks'&&k==='Device')?devList().map(d=>d.n):sheet==='DCSSActivity'&&k==='Performed by'?DB.Operators.filter(o=>o.Active!=='No').map(o=>String(o.Name)):null}
function fieldHtml(sheet,c,row,ro){
const id='f-'+sheet+'-'+c.k.replace(/[^A-Za-z0-9]/g,'_');const v=row[c.k]==null?'':row[c.k];
const cls=(c.req?'req':'')+(c.w?' wide':'')+(c.t==='area'?' wide':'');
if(c.t==='hosts')return hostPick(c,v);
if(c.t==='vms')return vmPick(c,v);
if(sheet==='ServerMI'&&CMB[c.k])return cmbField(c,v,id,cls);
if(LISTCMB[sheet+'.'+c.k])return lcField(sheet,c,v,id,cls);
let inp;const nopts=nameOpts(sheet,c.k);
if(nopts){const names=nopts.slice();if(v!==''&&names.indexOf(String(v))<0)names.push(String(v));inp='<select class="inp" id="'+id+'" name="'+esc(c.k)+'"><option value=""></option>'+names.map(o=>'<option'+(String(v)===o?' selected':'')+'>'+esc(o)+'</option>').join('')+'</select>'}
else if((sheet==='DCChecks'&&c.k==='Checked by')||(sheet==='OpenIssues'&&(c.k==='Assignee'||c.k==='Raised by'))||(sheet==='RackDevices'&&c.k==='Type')){const names=(sheet==='RackDevices'?DB.DeviceTypes:DB.Operators).filter(o=>o.Active!=='No').map(o=>String(o.Name));if(v!==''&&names.indexOf(String(v))<0)names.push(String(v));inp='<select class="inp" id="'+id+'" name="'+esc(c.k)+'"><option value="">'+(names.length?'':(sheet==='RackDevices'?'Add device types in Settings first':'Add operators in Settings first'))+'</option>'+names.map(o=>'<option'+(String(v)===o?' selected':'')+'>'+esc(o)+'</option>').join('')+'</select>'}
else if(c.t==='chk')return '<label class="chkrow" for="'+id+'"><input type="checkbox" id="'+id+'" name="'+esc(c.k)+'" value="Yes"'+((c.off?(String(v)==='Yes'||(c.k==='Blade'&&row&&row.Enclosure)):String(v)!=='No')?' checked':'')+'> '+esc(c.label||c.k)+'</label>';
else if(c.t==='sel')inp='<select class="inp" id="'+id+'" name="'+esc(c.k)+'">'+'<option value=""></option>'+c.o.map(o=>'<option'+(String(v)===o?' selected':'')+'>'+esc(o)+'</option>').join('')+'</select>';
else if(c.t==='area')inp='<textarea class="inp" rows="'+(c.k==='Notes'?7:3)+'" id="'+id+'" name="'+esc(c.k)+'">'+esc(v)+'</textarea>';
else inp='<input class="inp" id="'+id+'" name="'+esc(c.k)+'" type="'+(c.t==='num'?'number':c.t==='date'?'date':'text')+'"'+(c.t==='num'?' step="any"':'')+' value="'+esc(v)+'"'+(ro?' readonly':'')+'>';
return '<label class="'+cls+'" for="'+id+'">'+esc(c.label||c.k)+inp+'</label>';
}
function openForm(sheet,i,preset){
ATT.q=[];const S=SCHEMA[sheet],isNew=i==null;
const row=isNew?Object.assign({},preset||{}):DB[sheet][i];
if(isNew&&sheet==='ActivityLog'){row.Time=nowStr();row.User=USER;row.Action='Note'}
if(isNew&&sheet==='NetPorts'){row.State='Free'}
if(isNew&&sheet==='Disks'){row.State='OK'}
if(isNew&&sheet==='DCChecks'){row.Date=row.Date||ds(0);row.Result='OK'}
if(isNew&&sheet==='PatchEvents'){row.Date=row.Date||ds(0);row.Status='Planned'}
if(isNew&&(sheet==='DCChecks'||sheet==='PatchEvents'||sheet==='DCSSActivity'))row['In calendar']='Yes';
if(isNew&&sheet==='Issues'){row.Created=ds(0);row.Status='New';row.Priority='Medium';row.Rack='—'}
if(isNew&&(sheet==='Operators'||sheet==='DeviceTypes'||sheet==='Environments'))row.Active='Yes';
if(isNew&&sheet==='Environments'){row.Color='Blue';row.Production='No'}
if(isNew&&sheet==='BackupJobs'){row.Type=(SCHEMA.BackupJobs.cols.find(c=>c.k==='Type').o||[''])[0];row.Active='Yes'}
if(isNew&&sheet==='BackupTypes'){row.Active='Yes';row['Counts as backup']='Yes';row.Cloud='No'}
if(isNew&&sheet==='Contacts')row.Active='Yes'
if(isNew&&sheet==='AssignGroups')row.Active='Yes'
if(isNew&&(sheet==='ActivityTypes'||sheet==='KBTypes'||sheet==='CalCategories'||sheet==='HwProfiles'))row.Active='Yes';if(isNew&&sheet==='ArrayParts'){row.State='OK';if(!row.Device){const dv=hwDevices().find(d=>d.n===HWV.dev)||hwDevices()[0];if(dv)row.Device=dv.n}const dv2=hwDevices().find(d=>d.n===row.Device);if(dv2&&!row.DC){row.DC=dv2.dc||'';row.Rack=''}if(!row.Profile){const rl=row.Kind==='Controller enclosure'?'Controller enclosure':row.Kind==='Controller node'?'Controller node':row.Kind==='Service processor'?'Service processor':'Drive enclosure';const pf=(DB.HwProfiles||[]).find(x=>x.Role===rl&&x.Active!=='No');if(pf)row.Profile=pf.Profile}}if(isNew&&sheet==='CalCategories')row.Color='Blue';
if(isNew&&sheet==='ServerStatuses'){row.Active='Yes';row.Meaning='Running'}
if(isNew&&sheet==='ActivityStatuses'){row.Active='Yes';row.Actionable='No'}
if(isNew&&sheet==='DCSSActivity'){row.Date=row.Date||ds(0);row.Status=(DB.ActivityStatuses.find(x=>x.Name==='Done'&&x.Active!=='No')?'Done':(SCHEMA.DCSSActivity.cols.find(c=>c.k==='Status').o||[''])[0]);row.Type=(SCHEMA.DCSSActivity.cols.find(c=>c.k==='Type').o||[''])[0];row.DC=''}
if(isNew&&sheet==='RackList'){row.DC=RK.dc||DCS[0];row['U count']=42}
if(isNew&&sheet==='DeviceTypes'){row.Color='Slate';row['Default U']=1}
if(isNew&&sheet==='OpenIssues'){row.Created=ds(0);row.Status='New';row.Priority='Medium';row.Type='Task'}
if(isNew&&sheet==='KB'){row.Created=ds(0);row.Status='Draft';row.Version='1.0';row['Review due']=ds(180)}
const name=isNew?'New '+(TV[sheet]?TV[sheet].add.replace(/^Add |^New /,''):sheet==='Operators'?'operator':sheet==='DeviceTypes'?'device type':sheet==='Environments'?'environment':sheet==='DataCenters'?'data center':sheet==='BackupJobs'?'backup job':sheet==='BackupTypes'?'backup category':sheet==='ActivityTypes'?'activity type':sheet==='CalCategories'?'calendar category':sheet==='DrsHostGroups'?'host group':sheet==='HwProfiles'?'hardware profile':sheet==='ArrayParts'?'component':sheet==='KBTypes'?'article type':sheet==='ActivityStatuses'?'activity status':sheet==='ServerStatuses'?'server status':sheet==='RackDevices'?'device':sheet==='Links'?'link':sheet==='KB'?'article':'issue'):'Edit '+(row[S.key]||'');
$('modal').innerHTML='<div class="modal" data-act="mbg"><form class="dlg" id="frm" role="dialog" aria-modal="true" aria-label="'+esc(name)+'" data-sheet="'+sheet+'" data-i="'+(isNew?'':i)+'"><h2>'+esc(name)+'</h2><div class="fgrid">'+formCols(sheet).map(c=>fieldHtml(sheet,c,row,(sheet==='Issues'&&c.k==='ID')||((sheet==='KB'||sheet==='OpenIssues')&&(c.k==='ID'||c.k==='Files')))).join('')+'</div>'+sdBlock(sheet,row,isNew)+snBlock(sheet,row,isNew)+attBlock(sheet,row,isNew)+'<div id="ferr" class="note" style="color:var(--bad-fg)" role="alert"></div><div class="acts"><div>'+(isNew?'':'<button type="button" class="btn d" data-act="del">Delete</button>')+(!isNew&&RELSRC[sheet]?' <button type="button" class="btn" data-act="relgo" data-sheet="'+sheet+'" data-i="'+i+'" title="Everything linked to this record">Relations</button>':'')+(!isNew&&(sheet==='ServerMI'||sheet==='ESXi')?' <button type="button" class="btn" data-act="srvrdp" data-t="'+esc(row.FQDN||row.Hostname)+'" title="Open a Remote Desktop session">RDP</button>':'')+(!isNew&&sheet==='PatchEvents'&&row.Status!=='Done'?' <button type="button" class="btn" data-act="ptdone" data-i="'+i+'">Mark as done…</button>':'')+'</div><div class="tools"><button type="button" class="btn" data-act="mclose">Cancel</button><button type="submit" class="btn p">Save</button></div></div></form></div>';bladeSync($('frm'));srvSync($('frm'));
const f=$('frm').querySelector('input:not([readonly]),select');if(f)f.focus();FSIG=fsig($('frm'));if(sheet==='Clusters')quorumUI($('frm'));
}
let FSIG=null;
function fsig(f){const o=[];for(let i=0;i<f.elements.length;i++){const e=f.elements[i];if(!e.name||e.type==='button'||e.type==='submit'||e.type==='file')continue;o.push(e.name+'='+((e.type==='checkbox'||e.type==='radio')?(e.checked?1:0):e.value))}return o.join('\u0001')}
function closeForm(){FSIG=null;$('modal').innerHTML=''}
function tryClose(){const f=$('frm');if(f&&FSIG!==null&&fsig(f)!==FSIG&&!f.dataset.warn){f.dataset.warn='1';const e=$('ferr');if(e){e.textContent='You have unsaved changes. Press Cancel or Esc again to discard them (or click again).';try{e.scrollIntoView({block:'center'})}catch(x){}}return}closeForm()}
function submitForm(form){
const sheet=form.dataset.sheet,S=SCHEMA[sheet],iStr=form.dataset.i,isNew=iStr==='';
const base=isNew?{}:Object.assign({},DB[sheet][+iStr]);
const miss=[];
S.cols.forEach(c=>{const el=form.elements[c.k];if(!el)return;let v=c.t==='chk'?(el.checked?'Yes':'No'):el.value.trim();if(c.t==='num'&&v!=='')v=parseFloat(v);if(c.req&&(v===''||v==null))miss.push(c.k);base[c.k]=v});
if(sheet==='RackDevices'&&!isEncl(base)&&srvFind(base.Name)>=0){const s=DB.ServerMI[srvFind(base.Name)];$('ferr').innerHTML=esc(base.Name)+' is already in ServersMI as <b>'+esc(s.Hostname)+'</b>. Keep physical servers in ServersMI: set DC, Rack and U there.'+(isNew?'':' <button type="button" class="btn s p" data-act="physmerge" data-i="'+iStr+'">Merge into ServersMI</button>');return false}
if(miss.length){$('ferr').textContent='Fill in: '+miss.join(', ');return false}
if(base['End date']&&base.Date&&String(base['End date'])<String(base.Date)){$('ferr').textContent='End date is before the start date';return false}
if(sheet==='Environments'){const nm=String(base.Name),dup=DB.Environments.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This environment already exists';return false}}
if(sheet==='DataCenters'){const nm=String(base.Name),dup=DB.DataCenters.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This data center already exists';return false}}
if(sheet==='KBTypes'){const nm=String(base.Name),dup=DB.KBTypes.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This article type already exists';return false}}
if(sheet==='HwProfiles'){const nm=String(base.Profile),dup=DB.HwProfiles.some((x,i)=>String(x.Profile).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This profile already exists';return false}}
if(sheet==='ArrayParts'){const nm=String(base.Part),dup=DB.ArrayParts.some((x,i)=>String(x.Part).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='A component with this name already exists';return false}}
if(sheet==='CalCategories'){const nm=String(base.Name),dup=DB.CalCategories.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This category already exists';return false}}
if(sheet==='ActivityTypes'){const nm=String(base.Name),dup=DB.ActivityTypes.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This activity type already exists';return false}}
if(sheet==='BackupTypes'){const nm=String(base.Name),dup=DB.BackupTypes.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This category already exists';return false}}
if(sheet==='ServerStatuses'){const nm=String(base.Name),dup=DB.ServerStatuses.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This status already exists';return false}}
if(sheet==='ActivityStatuses'){const nm=String(base.Name),dup=DB.ActivityStatuses.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This status already exists';return false}}
if(sheet==='AssignGroups'){const nm=String(base.Group),dup=DB.AssignGroups.some((x,i)=>String(x.Group).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='This assignment group already exists';return false}}
if(sheet==='BackupJobs'){const nm=String(base.Job),dup=DB.BackupJobs.some((x,i)=>String(x.Job).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent='A job with this name already exists';return false}}
if(sheet==='RackList'){const nm=String(base.Rack),u=base['U count'],dup=DB.RackList.some((x,i)=>x.DC===base.DC&&String(x.Rack).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup){$('ferr').textContent=base.DC+' already has a rack named '+nm;return false}
if(!(u>=1&&u<=100&&u===Math.floor(u))){$('ferr').textContent='U count must be a whole number from 1 to 100';return false}
if(!isNew){const o=DB.RackList[+iStr],mx=Math.max(0,...['ESXi','Storage','Backup','RackDevices'].reduce((a,s)=>a.concat(DB[s].filter(r=>r.DC===o.DC&&String(r.Rack)===String(o.Rack)&&parseInt(r['U start'])>=1).map(r=>parseInt(r['U start'])+(parseInt(r['U size'])||1)-1)),[]));if(u<mx){$('ferr').textContent='A device in this rack reaches U'+mx+'. Move it first or use at least '+mx+' U.';return false}}}
if(sheet==='DeviceTypes'){const nm=String(base.Name),dup=DB.DeviceTypes.some((x,i)=>String(x.Name).toLowerCase()===nm.toLowerCase()&&(isNew||i!==+iStr));if(dup||['esxi host','storage array','backup device'].indexOf(nm.toLowerCase())>=0||nm.indexOf('|')>=0){$('ferr').textContent=nm.indexOf('|')>=0?'The name cannot contain |':'This type name already exists';return false}}
base.Updated=ds(0);
if(!isNew&&sheet==='RackList'){const o=DB.RackList[+iStr];if(o.DC!==base.DC||String(o.Rack)!==String(base.Rack))cascadeRack(o.DC,o.Rack,base.DC,base.Rack)}
if(!isNew&&sheet==='ServerStatuses'){const o=DB.ServerStatuses[+iStr];if(o.Name!==base.Name)DB.ServerMI.forEach(a=>{if(a.Status===o.Name)a.Status=base.Name})}
if(!isNew&&sheet==='ActivityStatuses'){const o=DB.ActivityStatuses[+iStr];if(o.Name!==base.Name)DB.DCSSActivity.forEach(a=>{if(a.Status===o.Name)a.Status=base.Name})}
if(!isNew&&sheet==='KBTypes'){const o=DB.KBTypes[+iStr];if(o.Name!==base.Name)DB.KB.forEach(a=>{if(a.Type===o.Name)a.Type=base.Name})}
if(!isNew&&sheet==='HwProfiles'){const o=DB.HwProfiles[+iStr];if(o.Profile!==base.Profile)DB.ArrayParts.forEach(a=>{if(a.Profile===o.Profile)a.Profile=base.Profile})}
if(!isNew&&sheet==='ArrayParts'){const o=DB.ArrayParts[+iStr];if(o.Part!==base.Part){DB.Disks.forEach(a=>{if(a.Enclosure===o.Part)a.Enclosure=base.Part});DB.ArrayParts.forEach(a=>{if(a.Enclosure===o.Part)a.Enclosure=base.Part})}}
if(!isNew&&sheet==='CalCategories'){const o=DB.CalCategories[+iStr];if(o.Name!==base.Name)['DCSSActivity','PatchEvents','DCChecks'].forEach(s=>DB[s].forEach(a=>{if(a['Calendar category']===o.Name)a['Calendar category']=base.Name}))}
if(!isNew&&sheet==='ActivityTypes'){const o=DB.ActivityTypes[+iStr];if(o.Name!==base.Name)DB.DCSSActivity.forEach(a=>{if(a.Type===o.Name)a.Type=base.Name})}
if(!isNew&&sheet==='BackupTypes'){const o=DB.BackupTypes[+iStr];if(o.Name!==base.Name)DB.BackupJobs.forEach(j=>{if(j.Type===o.Name)j.Type=base.Name})}
if(!isNew&&sheet==='AssignGroups'){const o=DB.AssignGroups[+iStr];if(o.Group!==base.Group){DB.Contacts.forEach(c=>{if(c['Assignment group']===o.Group)c['Assignment group']=base.Group});DB.DCSSActivity.forEach(c=>{if(c['Assignment group']===o.Group)c['Assignment group']=base.Group})}}
if(sheet==='PatchEvents'&&!base.ID){const n=Math.max(0,...DB.PatchEvents.map(x=>parseInt(String(x.ID).replace(/\D/g,''))||0))+1;base.ID='PAT-'+String(n).padStart(4,'0')}
if(sheet==='DCSSActivity'&&!base.ID){const n=Math.max(0,...DB.DCSSActivity.map(x=>parseInt(String(x.ID).replace(/\D/g,''))||0))+1;base.ID='ACT-'+String(n).padStart(4,'0')}
if(!isNew&&sheet==='BackupJobs'){const o=DB.BackupJobs[+iStr];if(o.Job!==base.Job)DB.BackupAssign.forEach(a=>{if(a.Job===o.Job)a.Job=base.Job})}
if(!isNew&&sheet==='ServerMI'){const o=DB.ServerMI[+iStr];if(o.Hostname!==base.Hostname)DB.BackupAssign.forEach(a=>{if(a.Server===o.Hostname)a.Server=base.Hostname})}
if(!isNew&&sheet==='DataCenters'){const o=DB.DataCenters[+iStr];if(o.Name!==base.Name)cascadeDC(o.Name,base.Name)}
if(sheet==='Issues'&&!base.ID){const n=Math.max(0,...DB.Issues.map(x=>parseInt(String(x.ID).replace(/\D/g,''))||0))+1;base.ID='DCI-'+String(n).padStart(4,'0')}
if(sheet==='OpenIssues'&&!base.ID){const n=Math.max(0,...DB.OpenIssues.map(x=>parseInt(String(x.ID).replace(/\D/g,''))||0))+1;base.ID='OI-'+String(n).padStart(4,'0')}
if(sheet==='OpenIssues'){const dn=base.Status==='Resolved'||base.Status==='Closed';if(dn&&!base.Resolved)base.Resolved=ds(0);if(!dn)base.Resolved=''}
if(sheet==='KB'&&!base.ID){const n=Math.max(0,...DB.KB.map(x=>parseInt(String(x.ID).replace(/\D/g,''))||0))+1;base.ID='KB-'+String(n).padStart(4,'0')}
{const be=bladeCheck(sheet,base,isNew?-1:+iStr);if(be){$('ferr').textContent=be;return false}}
{const ce=clusterCheck(sheet,base,isNew?-1:+iStr,form);if(ce){$('ferr').textContent=ce;return false}}
if(sheet==='PatchEvents'&&String(base.Servers||'').trim()&&form.dataset.warned!=='1'){const sc=ptScan(base.Servers);if(sc.no.length){form.dataset.warned='1';$('ferr').textContent='Not found in the inventory: '+sc.no.slice(0,15).join(', ')+'. Fix the names, or save again to keep them as typed.';return false}}
if(sheet==='PatchEvents'&&base.Status==='Done'&&base.CRQ&&String(base.Servers||'').trim()){const rs=ptApply(String(base.CRQ).trim(),String(base['End date']||base.Date).slice(0,10),/firmware/i.test(base.Notes||''),base.Servers,false);if(rs.n||rs.skip.length)setTimeout(()=>toast(ptMsg(rs,base.CRQ)),50)}
if(sheet==='ReplJobs'){const ap=n=>{const s=DB.Catalyst.find(x=>x.Store===n);return s?s.Appliance:''};if(base['Source store']&&!base['Source appliance'])base['Source appliance']=ap(base['Source store']);if(base['Target store']&&!base['Target appliance'])base['Target appliance']=ap(base['Target store'])}
if(!isNew&&sheet==='Catalyst'){const o=DB.Catalyst[+iStr];if(o.Store!==base.Store){DB.BackupJobs.forEach(j=>{if(j['Catalyst store']===o.Store)j['Catalyst store']=base.Store});DB.ReplJobs.forEach(j=>{if(j['Source store']===o.Store)j['Source store']=base.Store;if(j['Target store']===o.Store)j['Target store']=base.Store});DB.Catalyst.forEach(s=>{if(s['Replica store']===o.Store)s['Replica store']=base.Store})}}
if(sheet==='NetPorts')netSync(base,isNew?null:DB.NetPorts[+iStr]);
if(!isNew&&DEV_SRC.some(s=>s[0]===sheet))devRename(sheet,DB[sheet][+iStr][S.key],base[S.key]);
clusterBefore(sheet,base,isNew?null:DB[sheet][+iStr]);
if(isNew)DB[sheet].push(base);else DB[sheet][+iStr]=base;clusterAfter(sheet,base);
if(isNew&&ATT.q.length)attFlush(sheet,base);
closeForm();changed();route();toast((isNew?'Added ':'Saved ')+(base[S.key]||''));return base;
}
function deleteRow(form,btn){
if(!btn.dataset.arm){btn.dataset.arm='1';btn.textContent='Click again to delete';return}
const sheet=form.dataset.sheet,i=+form.dataset.i;const r=DB[sheet][i];
if(sheet==='ServerStatuses'&&DB.ServerMI.some(a=>a.Status===r.Name)){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='Servers still use this status. Set it to inactive instead.';return}
if(sheet==='ActivityStatuses'&&DB.DCSSActivity.some(a=>a.Status===r.Name)){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='Logged activities still use this status. Set it to inactive instead.';return}
if(sheet==='KBTypes'&&DB.KB.some(a=>a.Type===r.Name)){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='Articles still use this type. Set it to inactive instead.';return}
if(sheet==='HwProfiles'&&DB.ArrayParts.some(a=>a.Profile===r.Profile)){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='Components still use this profile. Set it to inactive instead.';return}
if(sheet==='ArrayParts'&&DB.Disks.some(a=>a.Enclosure===r.Part)){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='Disks are still assigned to this component. Reassign or delete them first.';return}
if(sheet==='CalCategories'&&['DCSSActivity','PatchEvents','DCChecks'].some(s=>DB[s].some(a=>a['Calendar category']===r.Name))){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='Events still use this category. Set it to inactive instead.';return}
if(sheet==='ActivityTypes'&&DB.DCSSActivity.some(a=>a.Type===r.Name)){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='Logged activities still use this type. Set it to inactive instead.';return}
if(sheet==='BackupTypes'&&DB.BackupJobs.some(j=>j.Type===r.Name)){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='Backup jobs still use this category. Change them first, or set the category to inactive.';return}
undoSnap('delete '+(r[SCHEMA[sheet].key]||'row'));clusterDel(sheet,r);
if(sheet==='NetPorts')netUnlink(r);
if(sheet==='ServerMI')DB.BackupAssign=DB.BackupAssign.filter(a=>a.Server!==r.Hostname);
if(sheet==='BackupJobs')DB.BackupAssign=DB.BackupAssign.filter(a=>a.Job!==r.Job);
if(sheet==='RackList'&&rackDevCount(r.DC,r.Rack)){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent=rackDevCount(r.DC,r.Rack)+' device(s) are placed in this rack. Move or remove them first.';return}
if(sheet==='DataCenters'&&(DB.RackList.some(x=>x.DC===r.Name)||devices().some(d=>d.dc===r.Name))){btn.dataset.arm='';btn.textContent='Delete';$('ferr').textContent='This data center still has racks or devices. Delete or move them first.';return}
if(sheet==='Issues')DB.Comments=DB.Comments.filter(c=>c.Issue!==r.ID);
if(sheet==='OpenIssues')DB.OIComments=DB.OIComments.filter(c=>c.Issue!==r.ID);
if(sheet==='KB')DB.KBComments=DB.KBComments.filter(c=>c.Article!==r.ID);
DB[sheet].splice(i,1);closeForm();changed();route();toast('Deleted '+(r[SCHEMA[sheet].key]||''),true);
}

/* ---------- Excel in / out ---------- */
function buildBook(){
const wb=XLSX.utils.book_new();
SHEETS.forEach(s=>{const aoa=[HEAD[s]].concat(DB[s].map(r=>HEAD[s].map(h=>r[h]==null?'':r[h])));XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(aoa),xn(s))});
const ca=[CHEAD].concat(DB.Comments.map(c=>[c.Issue,c.Time,c.Author,c.Text,(c.Files||[]).join(';')]));
XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(ca),'IssueComments');
XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([OHEAD].concat(DB.OIComments.map(c=>[c.Issue,c.Time,c.Author,c.Type,c.Text]))),'OIComments');
XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([KHEAD].concat(DB.KBComments.map(c=>[c.Article,c.Time,c.Author,c.Type,c.Text]))),'KBComments');
const sc=[['Sheet','Column','Type','Options','Required','Show','Core','Order','Label','Hidden']];SHEETS.forEach(s=>{SCHEMA[s].cols.forEach(c=>sc.push([xn(s),c.k,c.t||'text',(c.o||[]).join('|'),c.req?'yes':'no',TV[s]?(TV[s].show.includes(c.k)?'yes':'no'):'form',CORE[s].has(c.k)?'yes':'no',TV[s]&&TV[s].show.includes(c.k)?TV[s].show.indexOf(c.k)+1:'',c.label||'',c.hidden?'yes':'']));if(TV[s])TV[s].show.forEach((k,i)=>{if(!SCHEMA[s].cols.some(c=>c.k===k))sc.push([s,k,'computed','','no','yes','yes',i+1])})});
XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(sc),'_Schema');
return wb;
}
function savedOk(msg){dirty=0;PFAIL=false;SNAP=snap();baseSet();if($('modal').querySelector('[aria-label="Unsaved changes"]'))closeForm();PENDLOG=[];META.savedAt=nowStr();persist();renderPending();renderSide();if(CUR==='sources')route();toast(msg)}
const XLSX_TYPES=[{description:'Excel workbook',accept:{'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':['.xlsx']}}];
function idb(){return new Promise((res,rej)=>{try{const r=indexedDB.open('infra-inventory-handles',1);r.onupgradeneeded=()=>r.result.createObjectStore('h');r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)}catch(e){rej(e)}})}
async function keepHandle(h,k){try{const d=await idb();d.transaction('h','readwrite').objectStore('h').put(h,k||'main')}catch(e){}}
async function dropHandle(){try{const d=await idb();d.transaction('h','readwrite').objectStore('h').delete('main')}catch(e){}}
async function recallHandle(k){try{const d=await idb();return await new Promise(res=>{const q=d.transaction('h').objectStore('h').get(k||'main');q.onsuccess=()=>res(q.result||null);q.onerror=()=>res(null)})}catch(e){return null}}
let SAVE_ARMED=false;
function timeMs(s){const t=new Date(String(s||'').replace(' ','T')).getTime();return isNaN(t)?0:t}
async function saveExcel(saveAs){
if(typeof XLSX==='undefined'){toast('The Excel library did not load (vendor/xlsx.full.min.js).');return}
if(SEC.locked){toast('Log in first.');return}
if(!USER){if(!(await askUser()))return}
logChanges();
let buf=XLSX.write(buildBook(),{bookType:'xlsx',type:'array'});
if(SEC.on){try{buf=await secEncrypt(buf)}catch(e){toast('Encryption failed: '+(e&&e.message||e));return}}
let name=(handle&&handle.name)||META.fileName||'inventory.xlsx';if(!/\.xlsx$/i.test(name))name+='.xlsx';
if(ROOT&&!saveAs){
if(!(await rootPerm(true))){toast('Permission for the project folder is needed. Use Reconnect project folder.');return}
if(!handle||!STDIR){try{await rootWire()}catch(e){}}
if(!handle){try{handle=await(await ROOT.getDirectoryHandle('Inventory',{create:true})).getFileHandle('inventory.xlsx',{create:true})}catch(e){toast('Could not create Inventory/inventory.xlsx');return}}
}
if((saveAs||!handle)&&typeof window.showSaveFilePicker==='function'){
try{const h=await window.showSaveFilePicker({suggestedName:name,types:XLSX_TYPES});handle=h;META.fileName=h.name;SAVE_ARMED=false;META.diskMtime=0;keepHandle(h)}
catch(e){if(e&&e.name==='AbortError')return}
}
if(handle){
try{
if(handle.queryPermission){let p=await handle.queryPermission({mode:'readwrite'});if(p!=='granted')p=await handle.requestPermission({mode:'readwrite'});if(p!=='granted'){toast('No permission to write to '+handle.name+'. Use Save as… to pick the file again.');return}}
const f=await handle.getFile(),base=META.diskMtime||(timeMs(META.fileModified)?timeMs(META.fileModified)+61000:0);
if(base&&f.lastModified>base+1500&&!SAVE_ARMED){mgOpen(f);return}
SAVE_ARMED=false;
let bkn='';if(ROOT&&(!SEC.on||await secFileEnc(f))){try{bkn=await bkWrite(f)}catch(e){bkn=''}}
const w=await handle.createWritable();await w.write(buf);await w.close();BKL=null;
try{META.diskMtime=(await handle.getFile()).lastModified}catch(e){}
let extra='';if(ROOT){try{const r=await rebuildIndex(buf);extra=r==='ok'?' and index.html updated':r==='notemplate'?'. dashboard-template.html was not found, so index.html was not updated':'. The template has no data slots, so index.html was not updated'}catch(e){extra='. index.html could not be updated'}}
savedOk('Saved to '+handle.name+extra+(bkn?' · backup '+bkn:''));return
}catch(e){toast('Could not write to '+handle.name+'. Close it in Excel or use Save as… to pick another file.');return}
}
let dl=null;try{dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null}catch(e){dl=null}
if(dl){try{await dl.save({filename:name,data:buf});savedOk('Excel file saved');}catch(e){if(!(e&&e.code==='declined'))toast('Save failed: '+((e&&(e.message||e.code))||'unknown'))}return}
try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([buf],{type:'application/octet-stream'}));a.download=name;document.body.appendChild(a);a.click();a.remove();savedOk('Excel file downloaded. This browser cannot save in place, use Edge or Chrome.')}catch(e){toast('Download is not available in this view')}
}
function applyWorkbook(wb,info){
const norm=v=>v instanceof Date?fmt(v):v;
const nd={Comments:[],KBComments:[],OIComments:[]};let found=0,missing=[];
revertSchema();const sm={};const yes=v=>/^(yes|true|1)$/i.test(String(v==null?'':v));
if(wb.Sheets._Schema)XLSX.utils.sheet_to_json(wb.Sheets._Schema,{defval:''}).forEach(r=>{sm[(r.Sheet==='ServersMI'?'ServerMI':r.Sheet)+'|'+r.Column]=r});
SHEETS.forEach(s=>{const ws=wb.Sheets[xn(s)]||wb.Sheets[s];if(!ws){nd[s]=[];missing.push(s);return}found++;
(XLSX.utils.sheet_to_json(ws,{header:1,defval:''})[0]||[]).map(h=>String(h).trim()).forEach(h=>{if(!h||h==='Updated'||SCHEMA[s].cols.some(c=>c.k===h)||(s==='DataCenters'&&(h==='Racks'||h==='U per rack')))return;const sp=sm[s+'|'+h]||{};const sh=sp.Show==null||sp.Show===''||sp.Show==='form'?true:yes(sp.Show);if(addColumn(s,{k:h,t:sp.Type||'text',o:sp.Options?String(sp.Options).split('|'):'',req:yes(sp.Required),show:sh}))addColumn(s,{k:h,t:'text',show:true})});nd[s]=XLSX.utils.sheet_to_json(ws,{defval:''}).map(r=>{const o={};Object.keys(r).forEach(k=>{o[k]=norm(r[k])});return o})});
if(wb.Sheets.OIComments)nd.OIComments=XLSX.utils.sheet_to_json(wb.Sheets.OIComments,{defval:''}).map(r=>({Issue:r.Issue,Time:norm(r.Time),Author:r.Author,Type:r.Type||'Comment',Text:r.Text}));
if(wb.Sheets.KBComments)nd.KBComments=XLSX.utils.sheet_to_json(wb.Sheets.KBComments,{defval:''}).map(r=>({Article:r.Article,Time:norm(r.Time),Author:r.Author,Type:r.Type||'Comment',Text:r.Text}));
if(wb.Sheets.IssueComments)nd.Comments=XLSX.utils.sheet_to_json(wb.Sheets.IssueComments,{defval:''}).map(r=>({Issue:r.Issue,Time:norm(r.Time),Author:r.Author,Text:r.Text,Pics:[],Files:/^\d*$/.test(String(r.Photos).trim())?[]:String(r.Photos).split(';').map(x=>x.trim()).filter(Boolean)}));
Object.keys(TV).forEach(s=>{SCHEMA[s].cols.forEach(c=>{const sp=sm[s+'|'+c.k];if(!sp||sp.Show===''||sp.Show==null)return;const on=yes(sp.Show),sh=TV[s].show,i=sh.indexOf(c.k);if(on&&i<0)sh.push(c.k);if(!on&&i>=0)sh.splice(i,1)})});
Object.keys(TV).forEach(s=>{const ord=[];TV[s].show.forEach(k=>{const sp=sm[s+'|'+k];const n=sp?parseInt(sp.Order):NaN;if(!isNaN(n))ord.push([n,k])});if(ord.length){ord.sort((a,b)=>a[0]-b[0]);const names=ord.map(o=>o[1]);TV[s].show=names.concat(TV[s].show.filter(k=>names.indexOf(k)<0))}});
SHEETS.forEach(s=>{SCHEMA[s].cols.forEach(c=>{const sp=sm[s+'|'+c.k];if(!sp)return;if(sp.Label)c.label=String(sp.Label);if(CORE[s].has(c.k)&&yes(sp.Hidden)&&c.k!==SCHEMA[s].key)hideCol(s,c);if(CORE[s].has(c.k)&&sp.Required!==''&&sp.Required!=null){if(yes(sp.Required))c.req=1;else delete c.req}})});
if(!found)return{ok:false,missing:missing};
missing=missing.filter(x=>['Todos','DrsHostGroups','ArrayParts','BackupJobs','BackupAssign','Contacts','AssignGroups','DCSSActivity','PatchEvents','NetPorts','Disks','ActivityLog','KBTypes','Catalyst','ReplJobs','DCLayout','Scripts','ScriptRuns','AppSettings','Subnets','Clusters','ClusterNodes','ClusterRoles','ClusterResources','ClusterDisks','ServerDisks','ServerNics','ArrayVolumes','DatastoreClusters','DrsRules','RemoteCopyGroups'].indexOf(x)<0);
['Environments','DataCenters','BackupTypes','KBTypes','ActivityTypes','CalCategories','HwProfiles','ActivityStatuses','ServerStatuses'].forEach(s=>{if(!wb.Sheets[s]){nd[s]=defaultsFor(s);missing=missing.filter(x=>x!==s)}});
if(!wb.Sheets.RackList){missing=missing.filter(x=>x!=='RackList');if(wb.Sheets.DataCenters){nd.RackList=[];XLSX.utils.sheet_to_json(wb.Sheets.DataCenters,{defval:''}).forEach(r=>{const n=parseInt(r.Racks),u=parseInt(r['U per rack']);if(r.Name)nd.RackList=nd.RackList.concat(makeRacks(String(r.Name),n>=1?n:8,u>=1?u:42,'R',1,2))})}else nd.RackList=defaultRacks()}
DB=nd;DVER++;handle=info.handle||null;dirty=0;SNAP=snap();baseSet();PENDLOG=[];
META={stuff:META.stuff,source:info.name,fileName:info.name,loadedAt:nowStr(),fileModified:info.modified||null,savedAt:null,generated:info.generated||''};
saveSchemaMeta();try{sdSyncAll()}catch(e){}SEC.loaded=true;if(SEC.on)secSetUser();
return{ok:true,missing:missing};
}
async function importFile(f,h){
if(typeof XLSX==='undefined'){toast('The Excel library did not load (vendor/xlsx.full.min.js).');return}
try{
const wb=await xlsxRead(await f.arrayBuffer());
const lm=new Date(f.lastModified);
const r=applyWorkbook(wb,{name:f.name,modified:fmt(lm)+' '+pad(lm.getHours())+':'+pad(lm.getMinutes()),handle:h});
if(r.ok){META.diskMtime=f.lastModified;SAVE_ARMED=false;if(h)keepHandle(h);else{handle=null;dropHandle()}persist()}
if(!r.ok){toast('No known sheets found. Use the inventory.xlsx template.');return}
route();toast('Loaded '+f.name+(r.missing.length?' · missing sheets: '+r.missing.join(', '):''));
}catch(e){toast('Could not read that file as .xlsx')}
}
async function openExcel(){
if(window.showOpenFilePicker){try{const hs=await window.showOpenFilePicker({types:[{description:'Excel workbook',accept:{'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet':['.xlsx']}}]});await importFile(await hs[0].getFile(),hs[0]);return}catch(e){if(e&&e.name==='AbortError')return}}
$('filein').click();
}
