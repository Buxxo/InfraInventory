/* ===== Neon layer: richer Ctrl+K palette, relations graph on every record, personal home, draggable widgets ===== */
const NLS={g(k,d){try{const v=localStorage.getItem(k);return v?JSON.parse(v):d}catch(e){return d}},s(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}};
const PINS=NLS.g('infra-pins',[]),RECENT=NLS.g('infra-recent',[]);
let LAY=NLS.g('infra-home',{order:[],hide:[],span:{}});if(!LAY||typeof LAY!=='object'||!Array.isArray(LAY.order))LAY={order:[],hide:[],span:{}};if(!Array.isArray(LAY.hide))LAY.hide=[];if(!LAY.span)LAY.span={};
const HOME={edit:false};let GPARSE=false;
const recKey=(s,i)=>{const r=DB[s]&&DB[s][i];return r&&SCHEMA[s]&&SCHEMA[s].key?String(r[SCHEMA[s].key]==null?'':r[SCHEMA[s].key]):''};
const recFind=(s,k)=>DB[s]&&SCHEMA[s]&&SCHEMA[s].key?DB[s].findIndex(r=>String(r[SCHEMA[s].key])===k):-1;
const unesc=t=>String(t||'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'").replace(/&amp;/g,'&');
const pinned=(s,k)=>PINS.some(p=>p.t==='r'&&p.s===s&&p.k===k);
function pinToggle(s,k){const j=PINS.findIndex(p=>p.t==='r'&&p.s===s&&p.k===k);if(j>=0)PINS.splice(j,1);else PINS.unshift({t:'r',s:s,k:k});NLS.s('infra-pins',PINS);return j<0}
function pushRecent(s,i){const k=recKey(s,i);if(!k)return;const j=RECENT.findIndex(x=>x.s===s&&x.k===k);if(j>=0)RECENT.splice(j,1);RECENT.unshift({s:s,k:k});if(RECENT.length>12)RECENT.length=12;NLS.s('infra-recent',RECENT)}
const sLabel=s=>(SCHEMA[s]&&SCHEMA[s].label)||s;

/* ---------- palette: more sources, fuzzy match, actions, pins and recents ---------- */
const CK_EXTRA=['ServerDisks','Links','DCSSActivity','Subnets','PatchEvents','BackupJobs','Catalyst','ReplJobs','Disks','NetPorts','Clusters'];
const _ckSources=ckSources;
ckSources=function(){const o=_ckSources(),have={};o.forEach(x=>{if(x.sh)have[x.sh]=1});
CK_EXTRA.forEach(sh=>{if(have[sh]||!DB[sh]||!SCHEMA[sh]||!SCHEMA[sh].key)return;const kk=SCHEMA[sh].key;DB[sh].forEach((r,i)=>{const n=r[kk];if(n)o.push({k:'rec',t:String(n),s:sLabel(sh),d:[r.Cluster||r.DC||r.Server||'',r.Status||r.Type||''].filter(Boolean).join(' · '),sh:sh,i:i,ic:SHEET_VIEW[sh]||'servermi'})})});
o.forEach(x=>{if(x.k==='rec'){const r=DB[x.sh][x.i];x.h=((r&&(r.FQDN||''))+' '+(r&&r.IP||'')+' '+(r&&r.Role||'')+' '+(r&&r.Model||'')+' '+(r&&r.Serial||'')+' '+(r&&r['Cluster/Standalone']||'')).toLowerCase()}});
return o};
function ckActions(){const A=[];const a=(t,ic,f)=>A.push({k:'act',t:t,s:'Actions',ic:ic,f:f});
a('Save to Excel','import',()=>{saveExcel()});
a('New server','servermi',()=>openForm('ServerMI',null));
a('New DC issue','issues',()=>openForm('Issues',null));
a('New team task','tracker',()=>openForm('OpenIssues',null));
a('Customize home','overview',()=>{HOME.edit=true;if(CUR==='overview')route();else location.hash='#overview'});
a('Pin this page','overview',()=>{if(!PINS.some(p=>p.t==='v'&&p.v===CUR)){PINS.unshift({t:'v',v:CUR});NLS.s('infra-pins',PINS)}toast('Pinned to your home page')});
a('Collapse / expand sidebar','overview',()=>NEONACT.railtoggle());
a('Theme: dark','settings',()=>themePick('dark'));a('Theme: light','settings',()=>themePick('light'));
return A}
function themePick(m){const r=document.querySelector('input[name=theme][value='+m+']');if(r){r.checked=true;r.dispatchEvent(new Event('change',{bubbles:true}))}}
const _ckFilter=ckFilter;
ckFilter=function(){const q=CK.q.trim().toLowerCase(),all=ckSources();
if(!q){const out=[];PINS.forEach(p=>{if(p.t==='r'){const i=recFind(p.s,p.k);if(i>=0)out.push({k:'rec',t:p.k,s:'Pinned',d:sLabel(p.s),sh:p.s,i:i,ic:SHEET_VIEW[p.s]||'servermi'})}else{const v=NAV.reduce((a,g)=>a||g[1].find(x=>x[0]===p.v),null);if(v)out.push({k:'page',t:v[1],s:'Pinned',go:'#'+v[0],ic:v[0]})}});
RECENT.slice(0,6).forEach(p=>{const i=recFind(p.s,p.k);if(i>=0)out.push({k:'rec',t:p.k,s:'Recent',d:sLabel(p.s),sh:p.s,i:i,ic:SHEET_VIEW[p.s]||'servermi'})});
CK.items=out.concat(ckActions(),all.filter(x=>x.k==='page')).slice(0,60);return}
all.push.apply(all,ckActions());
const toks=q.split(/\s+/).filter(Boolean);
const sub=(t,n)=>{let j=0;for(let i=0;i<n.length&&j<t.length;i++)if(n[i]===t[j])j++;return j===t.length};
const sc=x=>{const t=x.t.toLowerCase(),hay=t+' '+(x.d||'').toLowerCase()+' '+(x.s||'').toLowerCase()+' '+(x.h||'');let s=0;
if(t===q)return 0;if(t.indexOf(q)===0)return 1;if(t.indexOf(q)>=0)return 2;
for(const w of toks){if(t.indexOf(w)>=0)s+=2;else if(hay.indexOf(w)>=0)s+=3;else if(w.length>=3&&sub(w,t))s+=5;else return 99}
return 3+s/10};
CK.items=all.map(x=>[sc(x),x]).filter(a=>a[0]<99).sort((a,b)=>a[0]-b[0]||(a[1].k==='page'?-1:a[1].k==='act'?0:1)).slice(0,50).map(a=>a[1])};
const _ckGo=ckGo;
ckGo=function(j){const x=CK.items[j];if(!x)return;
if(x.k==='act'){closeForm();setTimeout(x.f,0);return}
if(x.k==='rec'&&x.sh!=='Clusters'){const rel=CK.rel;CK.rel=false;closeForm();
if(rel&&RELSRC[x.sh]){REL.sh=x.sh;REL.i=x.i;if(CUR==='relations')route();else location.hash='#relations';return}
openForm(x.sh,x.i);return}
return _ckGo(j)};
const _openCk=openCk;
openCk=function(){_openCk();const f=document.querySelector&&document.querySelector('.ckf');if(f)f.insertAdjacentHTML('beforeend','<span><kbd>Shift</kbd><kbd>Enter</kbd> relations</span>')};

/* ---------- relations graph ---------- */
const GCOL=['#3DE0D0','#7C9BFF','#FFB547','#C77DFF','#FF7A90','#5CE08A','#4AC6FF','#F59E6B'];
function gParse(sh,i){const r=DB[sh][i],name=recKey(sh,i),groups=[];
if(RELSRC[sh]){const o={sh:REL.sh,i:REL.i};REL.sh=sh;REL.i=i;GPARSE=true;let h='';try{h=relView()}catch(e){h=''}GPARSE=false;REL.sh=o.sh;REL.i=o.i;
const re=/<section class="card relg"><h2>([^<]*?) <span class="note">\d+<\/span><\/h2>([\s\S]*?)<\/section>/g;let m;
while((m=re.exec(h))){const items=[],tr=/<a href="#" class="reltile" data-act="(?:relgo|edit)" data-sheet="(\w+)" data-i="(\d+)"><b>([^<]*)<\/b>(?:<span>([^<]*)<\/span>)?/g;let t;while((t=tr.exec(m[2])))items.push({s:t[1],i:+t[2],n:unesc(t[3]),sub:unesc(t[4])});if(items.length)groups.push({t:unesc(m[1]),items:items})}}
if(!groups.length&&name.length>1){const nl=name.toLowerCase(),by={};
Object.keys(DB).forEach(s=>{if(!Array.isArray(DB[s])||/Comments$|^_/.test(s)||!SCHEMA[s]||!SCHEMA[s].key)return;DB[s].forEach((x,k)=>{if(s===sh&&k===i)return;let hit=false;for(const c in x){const v=x[c];if(typeof v!=='string'||v.length>160||v.length<2)continue;if(v.trim().toLowerCase()===nl||(v.indexOf(',')>0||v.indexOf(';')>0||v.indexOf('\n')>0)&&v.split(/[,;\n]+/).some(p=>p.trim().toLowerCase()===nl)){hit=true;break}}
if(hit){(by[s]=by[s]||[]).push({s:s,i:k,n:recKey(s,k)||'(unnamed)',sub:''})}})});
Object.keys(by).forEach(s=>groups.push({t:sLabel(s),items:by[s]}))}
return groups}
function gBox(sh,i,W,fold){if(GPARSE||!SCHEMA[sh]||!DB[sh]||!DB[sh][i])return '';const name=recKey(sh,i);let groups=[];try{groups=gParse(sh,i)}catch(e){groups=[]}
const n=groups.reduce((a,g)=>a+g.items.length,0),pin=pinned(sh,name);
const bar='<div class="gbar"><b>Relations</b><span class="note">'+(n?n+' linked record'+(n>1?'s':''):'Nothing linked yet')+'</span><span style="flex:1"></span><button type="button" class="btn s" data-act="pinrec" data-s="'+sh+'" data-i="'+i+'">'+(pin?'★ Pinned':'☆ Pin')+'</button>'+(RELSRC[sh]&&CUR!=='relations'?'<button type="button" class="btn s" data-act="gorel" data-s="'+sh+'" data-i="'+i+'">Full view</button>':'')+'</div>';
if(!n)return '<div class="gbox">'+bar+'</div>';
if(fold)return '<details class="gbox gfold"><summary><b>Relations</b> <span class="note">'+n+' linked record'+(n>1?'s':'')+' · click to show the graph</span></summary>'+bar+gSvg(sh,i,groups,W||680)+'</details>';
return '<div class="gbox">'+bar+gSvg(sh,i,groups,W||680)+'</div>'}
function gSvg(sh,i,groups,W){const NW=W>800?230:196,NH=46,CW=W>800?190:150,MAX=CUR==='relations'?60:(W>800?4:3),GAP=10,GG=26,mid=W/2;
groups=groups.map((g,k)=>({t:g.t,c:GCOL[k%GCOL.length],items:g.items.slice(0,MAX),more:g.items.length-MAX,all:g.items.length}));
const ht=g=>20+(g.items.length+(g.more>0?1:0))*(NH+GAP);
const cols=[[],[]],hs=[0,0];groups.slice().sort((a,b)=>b.all-a.all).forEach(g=>{const c=hs[0]<=hs[1]?0:1;cols[c].push(g);hs[c]+=ht(g)+GG});
const H=Math.max(230,Math.max(hs[0],hs[1])+16),cy=H/2,cx=mid-CW/2;let out='',nodes='';
const cut=(s,n)=>{s=String(s);return s.length>n?s.slice(0,n-1)+'…':s};const mc=Math.floor((NW-24)/6.7);
cols.forEach((col,ci)=>{let y=12;const x=ci===0?10:W-NW-10;col.forEach(g=>{nodes+='<text class="gl" x="'+(x+2)+'" y="'+(y+9)+'" style="--gc:'+g.c+'">'+esc(cut(g.t,30))+'</text>';y+=20;
g.items.forEach(it=>{const ny=y,ay=ny+NH/2,x1=ci===0?cx:cx+CW,x2=ci===0?x+NW:x,dx=Math.abs(x1-x2)*.5;
out+='<path class="ge" style="--gc:'+g.c+'" d="M'+x1+' '+cy+' C'+(ci===0?x1-dx:x1+dx)+' '+cy+' '+(ci===0?x2+dx:x2-dx)+' '+ay+' '+x2+' '+ay+'"/>';
nodes+='<g class="gn" style="--gc:'+g.c+'" tabindex="0" role="link" data-act="gonode" data-s="'+it.s+'" data-i="'+it.i+'"><title>'+esc(it.n+(it.sub?' · '+it.sub:''))+'</title><rect x="'+x+'" y="'+ny+'" width="'+NW+'" height="'+NH+'" rx="12"/><text class="g1" x="'+(x+12)+'" y="'+(ny+(it.sub?20:28))+'">'+esc(cut(it.n,mc))+'</text>'+(it.sub?'<text class="g2" x="'+(x+12)+'" y="'+(ny+36)+'">'+esc(cut(it.sub,mc+4))+'</text>':'')+'</g>';y+=NH+GAP});
if(g.more>0){nodes+='<g class="gn gmore" style="--gc:'+g.c+'" tabindex="0" role="link" data-act="gorel" data-s="'+sh+'" data-i="'+i+'"><rect x="'+x+'" y="'+y+'" width="'+NW+'" height="'+NH+'" rx="12"/><text class="g2" x="'+(x+12)+'" y="'+(y+28)+'">+ '+g.more+' more in the full view</text></g>';y+=NH+GAP}
y+=GG-GAP+GAP})});
const nm=recKey(sh,i);
return '<svg class="gsvg" viewBox="0 0 '+W+' '+H+'" role="group" aria-label="Relations graph of '+esc(nm)+'">'+out+nodes+'<g class="gc"><rect x="'+cx+'" y="'+(cy-32)+'" width="'+CW+'" height="64" rx="16"/><text x="'+mid+'" y="'+(cy-4)+'" text-anchor="middle">'+esc(cut(nm,Math.floor(CW/8)))+'</text><text class="g2" x="'+mid+'" y="'+(cy+16)+'" text-anchor="middle">'+esc(sLabel(sh))+'</text></g></svg>'}
const _openForm=openForm;
openForm=function(sheet,i,preset){_openForm(sheet,i,preset);
try{if(i!=null&&i!==''&&SCHEMA[sheet]&&DB[sheet]&&DB[sheet][i]&&$('frm')){pushRecent(sheet,i);if(!$('frm').querySelector('.gbox'))$('frm').insertAdjacentHTML('beforeend',gBox(sheet,i,680,true))}}catch(e){}};

/* ---------- home: widgets, pins, recents ---------- */
function welcomeW(score,label,risks){const d=new Date(),h=d.getHours(),g=h<5?'Good night':h<12?'Good morning':h<18?'Good afternoon':'Good evening',nm=USER?', '+esc(String(USER).split(/\s+/)[0]):'';
const act=risks.filter(r=>r.sev===0).length;
const txt=score==null?'Load the inventory to see the health of the estate.':'Estate health is <b>'+score+'</b> ('+esc(label.toLowerCase())+'). '+(act?'<b style="color:var(--bad-c)">'+act+'</b> thing'+(act>1?'s need':' needs')+' attention now.':'Nothing needs urgent attention.');
return '<section class="card welcome"><div><span class="eyebrow">'+esc(d.toLocaleDateString(undefined,{weekday:'long',day:'numeric',month:'long',year:'numeric'}))+'</span><h2 class="wh">'+g+nm+'</h2><p>'+txt+'</p></div><div class="wq"><button class="btn" data-act="ckopen">Search · Ctrl K</button><button class="btn" data-act="wnew" data-s="ServerMI">+ Server</button><button class="btn" data-act="wnew" data-s="OpenIssues">+ Task</button></div></section>'}
function pinnedW(){const rows=PINS.map((p,j)=>{if(p.t==='r'){const i=recFind(p.s,p.k);if(i<0)return '';return '<div class="pinrow"><a href="#" data-act="gonode" data-s="'+p.s+'" data-i="'+i+'">'+esc(p.k)+'</a><span class="note">'+esc(sLabel(p.s))+'</span><button data-act="unpin" data-n="'+j+'" aria-label="Unpin '+esc(p.k)+'" title="Unpin">✕</button></div>'}
const v=NAV.reduce((a,g)=>a||g[1].find(x=>x[0]===p.v),null);return v?'<div class="pinrow"><a href="#'+v[0]+'">'+esc(v[1])+'</a><span class="note">Page</span><button data-act="unpin" data-n="'+j+'" aria-label="Unpin '+esc(v[1])+'" title="Unpin">✕</button></div>':''}).join('');
return '<section class="card"><h2>Pinned</h2>'+(rows||'<p class="note" style="margin:0">Open any record and press ☆ Pin, or use Ctrl K → “Pin this page”.</p>')+'</section>'}
function recentW(){const rows=RECENT.map(p=>{const i=recFind(p.s,p.k);return i<0?'':'<div class="pinrow"><a href="#" data-act="gonode" data-s="'+p.s+'" data-i="'+i+'">'+esc(p.k)+'</a><span class="note">'+esc(sLabel(p.s))+'</span></div>'}).filter(Boolean).slice(0,7).join('');
return '<section class="card"><h2>Recently opened</h2>'+(rows||'<p class="note" style="margin:0">Records you open show up here.</p>')+'</section>'}
const SPANS=[4,6,8,12],SPLBL={4:'⅓',6:'½',8:'⅔',12:'Full'};
function homeHtml(W){const ids=W.map(x=>x.id),by={};W.forEach(x=>by[x.id]=x);
const ord=LAY.order.filter(x=>by[x]).concat(ids.filter(x=>LAY.order.indexOf(x)<0));
let h='<div class="wgrid'+(HOME.edit?' editing':'')+'" id="wgrid">';
ord.forEach(id=>{const off=LAY.hide.indexOf(id)>=0;if(off&&!HOME.edit)return;const x=by[id],sp=LAY.span[id]||x.span;
h+='<div class="wdg'+(off?' off':'')+'" data-w="'+id+'" style="--sp:'+sp+'"'+(HOME.edit?' draggable="true"':'')+'>'+(HOME.edit?'<div class="wtb"><span class="wgrip" aria-hidden="true">⠿</span><b>'+esc(x.title)+'</b><button class="btn s" data-act="wmove" data-w="'+id+'" data-d="-1" aria-label="Move earlier">◀</button><button class="btn s" data-act="wmove" data-w="'+id+'" data-d="1" aria-label="Move later">▶</button><button class="btn s" data-act="wsize" data-w="'+id+'" title="Width">'+SPLBL[sp]+'</button><button class="btn s" data-act="whide" data-w="'+id+'">'+(off?'Show':'Hide')+'</button></div>':'')+x.html+'</div>'});
return h+'</div>'}
function layOrder(){const g=document.getElementById('wgrid');return g?Array.prototype.map.call(g.querySelectorAll('.wdg'),e=>e.dataset.w):LAY.order.slice()}
function laySave(){NLS.s('infra-home',LAY)}
const NEONACT={
gonode(el){const s=el.dataset.s,i=+el.dataset.i;if($('frm')){tryClose();if($('frm'))return}closeForm();openForm(s,i)},
gorel(el){const s=el.dataset.s,i=+el.dataset.i;if($('frm')){tryClose();if($('frm'))return}closeForm();REL.sh=s;REL.i=i;if(CUR==='relations')route();else location.hash='#relations';window.scrollTo(0,0)},
pinrec(el){const s=el.dataset.s,k=recKey(s,+el.dataset.i);if(!k)return;el.textContent=pinToggle(s,k)?'★ Pinned':'☆ Pin';if(CUR==='overview')setTimeout(()=>{if(!$('frm'))route()},0)},
unpin(el){PINS.splice(+el.dataset.n,1);NLS.s('infra-pins',PINS);route()},
wnew(el){openForm(el.dataset.s,null)},
homeedit(){HOME.edit=!HOME.edit;route()},
homereset(){LAY={order:[],hide:[],span:{}};laySave();route()},
wmove(el){const o=layOrder(),i=o.indexOf(el.dataset.w),j=i+ +el.dataset.d;if(i<0||j<0||j>=o.length)return;o.splice(j,0,o.splice(i,1)[0]);LAY.order=o;laySave();route()},
wsize(el){const id=el.dataset.w,cur=+(LAY.span[id]||(document.querySelector('[data-w="'+id+'"]')||{style:{}}).style.getPropertyValue('--sp')||12);LAY.span[id]=SPANS[(SPANS.indexOf(cur)+1)%SPANS.length];laySave();route()},
whide(el){const id=el.dataset.w,j=LAY.hide.indexOf(id);if(j>=0)LAY.hide.splice(j,1);else LAY.hide.push(id);laySave();route()},
railtoggle(){const h=document.documentElement,on=h.classList.toggle('rail');try{localStorage.setItem('infra-rail',on?'1':'0')}catch(e){}},
};
function neonPost(){if(CUR!=='overview')HOME.edit=false;
if(typeof document==='undefined'||!document.querySelectorAll)return;
document.querySelectorAll('#nav a').forEach(a=>{const s=a.querySelector('span');if(s)a.title=s.textContent})}
if(typeof document!=='undefined'&&document.addEventListener){try{
let dragId=null;
document.addEventListener('dragstart',e=>{const w=e.target&&e.target.closest&&e.target.closest('.wdg');if(!w||!HOME.edit)return;dragId=w.dataset.w;w.classList.add('drag');if(e.dataTransfer){e.dataTransfer.effectAllowed='move';try{e.dataTransfer.setData('text/plain',dragId)}catch(x){}}});
document.addEventListener('dragover',e=>{const w=e.target&&e.target.closest&&e.target.closest('.wdg');if(!w||!HOME.edit||!dragId)return;e.preventDefault();document.querySelectorAll('.wdg.over').forEach(x=>x.classList.remove('over'));if(w.dataset.w!==dragId)w.classList.add('over')});
document.addEventListener('drop',e=>{const w=e.target&&e.target.closest&&e.target.closest('.wdg');if(!w||!HOME.edit||!dragId)return;e.preventDefault();const t=w.dataset.w;if(t!==dragId){const o=layOrder(),a=o.indexOf(dragId),b=o.indexOf(t);o.splice(b,0,o.splice(a,1)[0]);LAY.order=o;laySave()}dragId=null;route()});
document.addEventListener('dragend',()=>{dragId=null;document.querySelectorAll('.wdg.drag,.wdg.over').forEach(x=>x.classList.remove('drag','over'))});
document.addEventListener('keydown',e=>{if(e.target&&e.target.id==='ck-q'&&e.key==='Enter')CK.rel=!!e.shiftKey;if(e.target&&e.target.classList&&e.target.classList.contains('gn')&&(e.key==='Enter'||e.key===' ')){e.preventDefault();const f=NEONACT[e.target.dataset.act];if(f)f(e.target)}},true);
}catch(e){}}

/* ===== Excel-style column filter popup (funnel in every column header) ===== */
const HF={sheet:null,col:null,sel:null,q:'',all:[],btn:null};
const HF_SVG='<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 5h18l-7 8v6l-4 2v-8z"/></svg>';
function hfActive(sheet,col){return uiOf(sheet).fl.some(f=>f.k===col&&!incomplete(f))}
function hfValues(sheet,col){const t=TV[sheet],u=uiOf(sheet),m={};
DB[sheet].forEach(r=>{if(t&&!fmatch(u,t,r))return;
if(u.fl.some(f=>f.k!==col&&!incomplete(f)&&!passF(f,r)))return;
if(u.q){const q=u.q.toLowerCase();if(!Object.keys(r).some(k=>k!=='Updated'&&String(r[k]).toLowerCase().includes(q)))return}
const x=val(r,col),v=x==null?'':String(x);m[v]=(m[v]||0)+1});
const cur=HF.sel?Array.from(HF.sel):[];cur.forEach(v=>{if(!(v in m))m[v]=0});
return Object.keys(m).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true})).map(v=>({v:v,c:m[v]}))}
function hfShown(){const q=HF.q.trim().toLowerCase();return q?HF.all.filter(d=>(d.v===''?'(empty)':d.v).toLowerCase().indexOf(q)>=0):HF.all}
function hfListHtml(){const sh=hfShown(),n=sh.filter(d=>HF.sel.has(d.v)).length,all=sh.length>0&&n===sh.length;
let h='<label class="hfrow hfall"><input type="checkbox" data-act="hfall"'+(all?' checked':'')+'> <b>'+(HF.q.trim()?'Select all results':'Select all')+'</b> <span class="note">'+n+' / '+sh.length+'</span></label>';
h+=sh.map((d,i)=>'<label class="hfrow'+(d.c?'':' zero')+'"><input type="checkbox" data-act="hfv" data-vi="'+HF.all.indexOf(d)+'"'+(HF.sel.has(d.v)?' checked':'')+'> <span class="hfv">'+(d.v===''?'<i>(empty)</i>':esc(d.v))+'</span> <span class="note">'+d.c+'</span></label>').join('');
return sh.length?h:'<p class="note" style="padding:12px">No values match “'+esc(HF.q)+'”.</p>'}
function hfFoot(){const none=HF.sel.size===0;const e=$('hf-apply');if(e)e.disabled=none;const c=$('hf-cnt');if(c)c.textContent=HF.sel.size+' of '+HF.all.length+' selected'}
function hfDraw(){const l=$('hf-list');if(l){l.innerHTML=hfListHtml();const a=l.querySelector('.hfall input');if(a){const sh=hfShown(),n=sh.filter(d=>HF.sel.has(d.v)).length;a.indeterminate=n>0&&n<sh.length}}hfFoot()}
function hfClose(){const p=$('hfpop');if(p){p.hidden=true;p.innerHTML=''}HF.sheet=null}
function hfOpen(sheet,col,btn){HF.sheet=sheet;HF.col=col;HF.q='';HF.btn=btn;HF.sel=null;HF.all=hfValues(sheet,col);
const u=uiOf(sheet),ex=u.fl.filter(f=>f.k===col&&!incomplete(f));
const inF=ex.find(f=>f.op==='in'&&Array.isArray(f.v));const custom=ex.find(f=>!(f.op==='in'&&Array.isArray(f.v)));
HF.sel=new Set(inF?HF.all.map(d=>d.v).filter(v=>inF.v.indexOf(v)>=0):HF.all.map(d=>d.v));
let p=$('hfpop');if(!p){p=document.createElement('div');p.id='hfpop';p.className='hfpop';p.setAttribute('role','dialog');document.body.appendChild(p)}
p.innerHTML='<div class="hfh"><b>'+esc(labelOf(col,sheet))+'</b><span class="hfs"><button type="button" class="btn s" data-act="hfsort" data-d="1" title="Sort A to Z">A→Z</button><button type="button" class="btn s" data-act="hfsort" data-d="-1" title="Sort Z to A">Z→A</button></span></div><div class="hfc"><button type="button" class="btn s" data-act="hfcopy" title="Copy this column as one value per line (selected rows only, if any are ticked)">Copy column</button><button type="button" class="btn s" data-act="hfcopyu" title="Copy the distinct values">Copy unique values</button></div>'
+(custom?'<p class="note hfw">A condition filter ('+esc(fdesc(custom))+') is active. Applying here replaces it.</p>':'')
+'<input class="inp" id="hf-q" type="search" placeholder="Search values…" aria-label="Search values" autocomplete="off"><div class="hflist" id="hf-list"></div>'
+'<div class="hff"><span class="note" id="hf-cnt"></span><span><button type="button" class="btn s" data-act="hfclear">Clear</button><button type="button" class="btn s p" id="hf-apply" data-act="hfapply">Apply</button></span></div>';
p.hidden=false;hfDraw();
const r=btn.getBoundingClientRect(),w=300;p.style.left=Math.max(8,Math.min(innerWidth-w-8,r.left))+'px';p.style.top=Math.min(r.bottom+6,innerHeight-420<0?8:innerHeight-420)+'px';
const q=$('hf-q');if(q)setTimeout(()=>q.focus(),0)}
Object.assign(NEONACT,{
hfopen(el){if(HF.sheet&&HF.btn===el){hfClose();return}hfOpen(el.dataset.sheet,el.dataset.col,el)},
hfv(el){const d=HF.all[+el.dataset.vi];if(!d)return;if(el.checked)HF.sel.add(d.v);else HF.sel.delete(d.v);hfDraw()},
hfall(el){hfShown().forEach(d=>{if(el.checked)HF.sel.add(d.v);else HF.sel.delete(d.v)});hfDraw()},
hfsort(el){const u=uiOf(HF.sheet),c=HF.col;u.sk=c;u.sd=+el.dataset.d;u.sx=[];const s=HF.sheet;hfClose();route()},
hfclear(){const u=uiOf(HF.sheet);u.fl=u.fl.filter(f=>f.k!==HF.col);hfClose();route()},
hfapply(){if(!HF.sel.size)return;const s=HF.sheet,u=uiOf(s),c=HF.col;u.fl=u.fl.filter(f=>f.k!==c);
if(HF.sel.size<HF.all.length)u.fl.push({k:c,op:'in',v:HF.all.map(d=>d.v).filter(v=>HF.sel.has(v)),v2:''});hfClose();route()}});
if(typeof document!=='undefined'&&document.addEventListener){try{
document.addEventListener('input',e=>{if(e.target&&e.target.id==='hf-q'){HF.q=e.target.value;hfDraw()}});
document.addEventListener('keydown',e=>{if(!HF.sheet)return;if(e.key==='Escape'){e.stopPropagation();e.preventDefault();const b=HF.btn;hfClose();if(b&&b.focus)b.focus()}else if(e.key==='Enter'&&e.target&&e.target.id==='hf-q'){e.preventDefault();NEONACT.hfapply()}},true);
document.addEventListener('mousedown',e=>{if(!HF.sheet)return;const p=$('hfpop');if(p&&!p.contains(e.target)&&!(e.target.closest&&e.target.closest('[data-act=hfopen]')))hfClose()},true);
window.addEventListener('scroll',e=>{if(HF.sheet&&!(e.target&&e.target.closest&&e.target.closest('#hfpop')))hfClose()},true);
window.addEventListener('resize',()=>{if(HF.sheet)hfClose()});
}catch(e){}}
