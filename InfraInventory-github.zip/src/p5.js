
/* ---------- data quality (computed from the data) ---------- */
function sevN(s){return s==='high'?0:s==='medium'?1:2}
function sevCls(s){return s==='high'?'b-bad':s==='medium'?'b-warn':'b-info'}
const SUP=[['ServerMI','Hostname','servermi'],['ESXi','Hostname','esxi'],['Storage','Array','storage'],['Backup','Device','backup'],['RackDevices','Name','otherdevices']];
function quality(){return memo('quality',qualityRaw)}
function qualityRaw(){
const out=[];
const add=(id,sev,title,where,items,view)=>out.push({id:id,sev:sev,title:title,where:where,count:items.length,items:items,view:view});
add('owner','high','Servers without an owner','ServersMI · column Owner',DB.ServerMI.filter(r=>!r.Owner).map(r=>r.Hostname),'servermi');
{const dd={};(DB.ServerNics||[]).forEach(r=>{const k=String(r['DNS name']||'').trim().toLowerCase();if(k)(dd[k]=dd[k]||[]).push(r.Server+' · '+r.Interface)});add('dnsdup','medium','Duplicate DNS names on network interfaces','Failover clusters · Network interfaces',Object.keys(dd).filter(k=>dd[k].length>1).map(k=>k+' · '+dd[k].join(', ')),'clusters')}
add('avconf','high','Array volume problems (RDM / FC drives, double use)','Array volumes · exported hosts, size, used twice',avOtherIssues(),'arrayvolumes');
add('avfree','low','Array volumes not used by anything','Array volumes · Used by',avUnused().map(v=>v.Volume+' · '+v.Array),'arrayvolumes');
add('dsc','medium','Datastore cluster problems','Datastore clusters · members, space, types',dscAllIssues(),'datastoreclusters');
add('standcl','medium','Cluster / Standalone does not match Failover cluster','ServersMI · Standalone with a failover cluster, or marked Cluster without one',DB.ServerMI.filter(r=>(isStand(r['Cluster/Standalone'])&&r['Failover cluster'])||(/^\s*cluster/i.test(r['Cluster/Standalone']||'')&&!r['Failover cluster']&&r.Status!=='Decom')).map(r=>r.Hostname+(r['Failover cluster']?' is Standalone but in '+r['Failover cluster']:' is marked Cluster but has no failover cluster')),'servermi');
add('vmdk','low','Server disks differ from Disk GB','Servers · Server disks vs Disk GB',sdIssues(),'serverdisks');
add('drs','high','DRS rule violations and problems','DRS rules · current placement vs affinity, anti-affinity and host rules',drsAllIssues(),'drsrules');
add('rcg','high','Remote copy group problems','Remote copy groups · arrays, status, volumes, drives in different groups',rcgAllIssues(),'remotecopy');
add('wsfc','high','Failover cluster problems','Failover clusters · nodes, quorum, drives',clAllIssues(),'clusters');
add('nobackup','medium','Servers without a backup job','Backup jobs · assignments vs ServersMI',DB.ServerMI.filter(r=>bjInfo(r).st==='No job').map(r=>r.Hostname),'backupjobs');
add('patchover','high','Servers overdue for patching','ServersMI · Last patched vs Environments · Patch days',DB.ServerMI.filter(r=>patchInfo(r).st==='Overdue').map(r=>r.Hostname+' · '+patchInfo(r).left*-1+' days over'),'patching');
add('patchnone','medium','Servers without a Last patched date','ServersMI · column Last patched',DB.ServerMI.filter(r=>patchInfo(r).st==='Unknown').map(r=>r.Hostname),'patching');
const mip={},mhn={};
DB.ServerMI.forEach(r=>{const ip=String(r.IP||'').trim(),hn=String(r.Hostname||'').trim().toLowerCase();if(ip)(mip[ip]=mip[ip]||[]).push(r.Hostname);if(hn)(mhn[hn]=mhn[hn]||[]).push(r.Hostname)});
add('dupip','high','Duplicate IP addresses','ServersMI · column IP',Object.keys(mip).filter(k=>mip[k].length>1).map(k=>k+' is used by '+mip[k].join(', ')),'servermi');
add('duphn','high','Duplicate hostnames','ServersMI · column Hostname',Object.keys(mhn).filter(k=>mhn[k].length>1).map(k=>k+' appears '+mhn[k].length+' times'),'servermi');
const ex=[],so=[];
SUP.forEach(s=>DB[s[0]].forEach(r=>{const d=daysTo(r['Support end']);if(d===null)return;if(d<0)ex.push(s[0]+' · '+r[s[1]]+' expired '+r['Support end']);else if(d<=90)so.push(s[0]+' · '+r[s[1]]+' ends in '+d+' d')}));
add('expired','high','Support already expired','Support end, all hardware and server sheets',ex,'servermi');
add('soon','medium','Support ends within 90 days','Support end, all hardware and server sheets',so,'servermi');
const all=devices(),ov=overlaps(all);
add('overlap','high','Devices overlapping in a rack','DC, Rack, U start, U size',ov.pairs.map(p=>p[0].name+' and '+p[1].name+' overlap in '+p[0].dc+' '+p[0].rack),'racks');
add('pos','medium','Devices without a valid rack position','DC, Rack, U start, U size (inside the racks and U range of its data center)',all.filter(d=>!valid(d)||!d.dc||!d.rack).map(d=>d.name+' · '+d.sheet),'racks');
const hosts=new Set(DB.ESXi.map(r=>String(r.Hostname)));
add('esxref','medium','Servers pointing to an unknown ESXi host','ServersMI · column ESXi host',DB.ServerMI.filter(r=>r['ESXi host']&&!hosts.has(String(r['ESXi host']))).map(r=>r.Hostname+' → '+r['ESXi host']),'servermi');
add('stale','medium','Sheets not updated for more than 30 days','Updated column of each sheet',Object.keys(SHEET_LABEL).filter(s=>fresh(sheetUpdated(s))[0]==='b-bad').map(s=>SHEET_LABEL[s]+' · last update '+ago(sheetUpdated(s))),'sources');
add('cap','medium','Storage, backup or datastore at 85% or more','Used %',DB.Storage.filter(r=>num(r['Used %'])>=85).map(r=>'Storage · '+r.Array+' '+r['Used %']+'%').concat(DB.Backup.filter(r=>num(r['Used %'])>=85).map(r=>'Backup · '+r.Device+' '+r['Used %']+'%')).concat(DB.Datastores.filter(r=>num(r['Used %'])>=85).map(r=>'Datastore · '+r.Datastore+' '+r['Used %']+'%')),'storage');
add('dssync','high','Datastore values differ between vCenter and the array','Datastores · LUN ID, NAA ID, capacity vs array',DB.Datastores.filter(r=>dsSync(r)!=='OK').map(r=>r.Datastore+' · '+dsSync(r)),'datastores');
add('dsread','medium','vCenter data older than 2 days','Datastores · vCenter read',DB.Datastores.filter(r=>{const d=daysTo(r['vCenter read']);return d===null||d<-2}).map(r=>r.Datastore+' · read '+(r['vCenter read']||'never')),'datastores');
add('kbreview','medium','Knowledge base articles past their review date','KB · Review due',DB.KB.filter(r=>r.Status!=='Outdated'&&daysTo(r['Review due'])!==null&&daysTo(r['Review due'])<0).map(r=>r.ID+' · '+r.Title+' · due '+r['Review due']),'kb');
add('kbres','low','Known issues without a resolution','KB · Resolution',DB.KB.filter(r=>r.Type==='Known issue'&&!String(r.Resolution||'').trim()).map(r=>r.ID+' · '+r.Title),'kb');
add('oiover','medium','Open issues past their due date','Open Issues · Due date',DB.OpenIssues.filter(r=>!oiDone(r)&&daysTo(r['Due date'])!==null&&daysTo(r['Due date'])<0).map(r=>r.ID+' · '+r.Title+' · due '+r['Due date']),'tracker');
add('oiown','medium','High priority open issues without an assignee','Open Issues · Assignee',DB.OpenIssues.filter(r=>!oiDone(r)&&(r.Priority==='High'||r.Priority==='Critical')&&!String(r.Assignee||'').trim()).map(r=>r.ID+' · '+r.Title),'tracker');
add('physdup','medium','Physical servers listed twice','Other devices · same name as a server in ServersMI',physDups().map(x=>x.r.Name+' = '+x.s.Hostname),'otherdevices');
add('nodcmi','low','Racks with devices but no DCMI reading','DCMI · DC and Rack',(function(){const k=new Set(DB.DCMI.map(r=>r.DC+'|'+r.Rack));const s=new Set();all.forEach(d=>{if(!d.dc||!d.rack)return;const x=d.dc+'|'+d.rack;if(!k.has(x))s.add(d.dc+' '+d.rack)});return Array.from(s)})(),'dcmi');
return out;
}
function completeness(sheet){
const cols=SCHEMA[sheet].cols,rows=DB[sheet];if(!rows.length)return{req:100,all:100};
const f=(cs)=>{if(!cs.length)return 100;let n=0;rows.forEach(r=>cs.forEach(c=>{if(r[c.k]!==''&&r[c.k]!=null)n++}));return Math.round(n/(rows.length*cs.length)*100)};
return{req:f(cols.filter(c=>c.req)),all:f(cols.filter(c=>c.k!=='Notes'&&c.k!=='ID'))};
}
function qualityView(){
const q=quality(),bad=q.filter(c=>c.count>0).sort((a,b)=>sevN(a.sev)-sevN(b.sev)),good=q.filter(c=>!c.count);
const total=bad.reduce((s,c)=>s+c.count,0);
const comp=Object.keys(SCHEMA).map(s=>({s:s,c:completeness(s)}));
return head('Data quality','Checks run automatically on every load and after every edit. Nothing here is typed in by hand.')
+'<div class="kpis"><div class="kpi"><span>Checks passed</span><b>'+good.length+' / '+q.length+'</b><small class="'+(bad.length?'w':'g')+'">'+(bad.length?bad.length+' need attention':'All clear')+'</small></div><div class="kpi"><span>Findings</span><b>'+total+'</b><small>across '+bad.length+' checks</small></div><div class="kpi"><span>High severity</span><b>'+bad.filter(c=>c.sev==='high').reduce((s,c)=>s+c.count,0)+'</b><small class="b">Fix first</small></div><div class="kpi"><span>Required fields filled</span><b>'+Math.round(comp.reduce((s,x)=>s+x.c.req,0)/comp.length)+'%</b><small>average over all sheets</small></div></div>'
+'<div class="row" style="align-items:flex-start"><section class="card" style="flex:2 1 460px"><h2>Findings</h2>'+(bad.length?bad.map(c=>'<div class="dq"><span class="badge '+sevCls(c.sev)+'" style="min-width:64px;justify-content:center">'+c.sev+'</span><div class="t"><b>'+esc(c.title)+'</b> <span class="badge b-off">'+c.count+'</span><div class="note">'+esc(c.where)+'</div><ul>'+c.items.slice(0,5).map(i=>'<li>'+esc(i)+'</li>').join('')+(c.items.length>5?'<li>and '+(c.items.length-5)+' more</li>':'')+'</ul></div><button class="btn s" data-act="goto" data-v="'+c.view+'">Open</button></div>').join(''):'<div class="empty">No findings.</div>')+'</section>'
+'<div style="flex:1 1 300px;display:flex;flex-direction:column;gap:16px"><section class="card"><h2>Completeness by sheet</h2>'+comp.map(x=>'<div class="bl"><div><span>'+(SHEET_LABEL[x.s]||x.s)+'</span><span class="mono">'+x.c.req+'% required · '+x.c.all+'% all</span></div><div class="bar"><i class="'+(x.c.req<90?'b':x.c.req<100?'w':'')+'" style="width:'+x.c.req+'%"></i></div></div>').join('')+'<p class="note" style="margin:0">Bar shows required fields. “All” counts every column except Notes.</p></section>'
+'<section class="card"><h2>Passed</h2>'+(good.length?good.map(c=>'<div style="display:flex;gap:8px;padding:5px 0"><span class="badge b-ok">OK</span><span>'+esc(c.title)+'</span></div>').join(''):'<div class="empty">Nothing passed yet.</div>')+'</section></div></div>';
}

/* ---------- data sources ---------- */
function sourcesView(){
const wm=handle?'Saved in place to “'+handle.name+'”, no download':(typeof window.showSaveFilePicker==='function'?'Save to Excel asks once where the file is, then saves in place':'Download of an updated workbook (this browser cannot save in place)');
const sheets=SHEETS.concat(['IssueComments','KBComments','OIComments','_Schema']);
const trs=sheets.map(s=>{
if(s==='_Schema')return '<tr><td><b>_Schema</b></td><td class="mono">'+SHEETS.reduce((n,x)=>n+SCHEMA[x].cols.length,0)+'</td><td class="mono">7 / 7</td><td>—</td><td>—</td><td><span class="badge b-off">Settings</span></td></tr>';
if(s==='OIComments')return '<tr><td><b>OIComments</b></td><td class="mono">'+DB.OIComments.length+'</td><td class="mono">'+OHEAD.length+' / '+OHEAD.length+'</td><td>—</td><td>—</td><td><span class="badge b-off">Log</span></td></tr>';
if(s==='KBComments')return '<tr><td><b>KBComments</b></td><td class="mono">'+DB.KBComments.length+'</td><td class="mono">'+KHEAD.length+' / '+KHEAD.length+'</td><td>—</td><td>—</td><td><span class="badge b-off">Log</span></td></tr>';
if(s==='IssueComments')return '<tr><td><b>IssueComments</b></td><td class="mono">'+DB.Comments.length+'</td><td class="mono">'+CHEAD.length+' / '+CHEAD.length+'</td><td>—</td><td>—</td><td><span class="badge b-off">Log</span></td></tr>';
const u=sheetUpdated(s),f=fresh(u);return '<tr><td><b>'+xn(s)+'</b></td><td class="mono">'+DB[s].length+'</td><td class="mono">'+HEAD[s].length+' / '+HEAD[s].length+'</td><td>'+(u||'—')+'</td><td>'+ago(u)+'</td><td><span class="badge '+f[0]+'">'+f[1]+'</span></td></tr>'}).join('');
const cols=SHEETS.map(s=>'<details style="border-top:1px solid var(--line2);padding:8px 0"><summary style="cursor:pointer;min-height:32px"><b>'+xn(s)+'</b> <span class="note">'+HEAD[s].length+' columns</span></summary><div class="chips" style="margin-top:8px">'+SCHEMA[s].cols.map(c=>'<span class="chip" style="cursor:default'+(c.req?';border-color:var(--accent)':'')+'">'+esc(c.k)+(c.req?' *':'')+(c.custom?' (custom)':'')+'</span>').join('')+'<span class="chip" style="cursor:default">Updated (auto)</span></div></details>').join('');
return head('Data sources','Where the data comes from, how fresh it is, and how it gets back into Excel.','<button class="btn" data-act="openXlsx">Open Excel…</button><button class="btn" data-act="saveAs">Save as…</button><button class="btn p" data-act="saveXlsx">Save to Excel</button>')
+'<section class="card"><div class="tools" style="justify-content:space-between"><div><h2 style="margin:0 0 4px">Project folder</h2><p class="note" style="margin:0">'+(typeof window.showDirectoryPicker!=='function'?'This browser cannot connect a folder. Use Edge or Chrome.':ROOT?'<span class="badge '+(handle?'b-ok':'b-warn')+'">'+(handle?'Connected':'Workbook not found')+'</span> <b>'+esc(ROOT.name)+'</b> · Inventory\\inventory.xlsx '+(handle?'found':'not found')+'. Save to Excel writes the workbook and refreshes index.html here.':'<span class="badge b-warn">Not connected</span> Connect the InfraInventory folder so Save writes the workbook, index.html and photos there.')+'</p></div>'+(typeof window.showDirectoryPicker==='function'?'<div class="tools">'+(ROOT?'<button class="btn" data-act="rootchange">Change folder</button>':'<button class="btn p" data-act="rootconnect">Connect project folder</button>')+'</div>':'')+'</div></section>'
+'<div class="row" style="align-items:flex-start"><section class="card"><h2>Workbook</h2><div class="fgrid" style="grid-template-columns:repeat(auto-fill,minmax(180px,1fr))">'+[['Source',META.source],['Page built',META.loadedAt],['File last modified',META.fileModified||'Not known for demo data'],['Last saved from this page',META.savedAt||'Not saved yet'],['Unsaved changes',dirty],['Project folder',ROOT?ROOT.name+' (index.html is rebuilt on every save)':'Not connected'],['Save mode',wm]].map(x=>'<label>'+x[0]+'<span style="color:var(--ink);font-size:14px">'+esc(x[1])+'</span></label>').join('')+'</div><div class="tools" style="margin-top:12px">'+rootBtn()+(handle?'<button class="btn" data-act="reloadxlsx">Reload from Excel</button>':'')+'</div></section>'
+bkHtml()+'<section class="card"><h2>How data moves</h2><p class="note flowh">Saving from the page</p><ol class="flow" style="margin-top:6px"><li>Edit in the page</li><li>Save to Excel</li><li>inventory.xlsx + index.html are written</li></ol><p class="note flowh" style="margin-top:18px">Editing in Excel</p><ol class="flow" style="margin-top:6px"><li>Edit in Excel</li><li>Open index.html</li><li>The newer workbook is loaded</li></ol><p class="note" style="margin:10px 0 0">Excel stays the database. With the project folder connected, every Save writes the workbook and refreshes index.html. If the workbook was changed in Excel, the page loads it when you open it (after you confirm folder access). No build script is needed.</p></section></div>'
+'<section class="card"><h2>Sheets</h2><div class="tw"><table><thead><tr><th>Sheet</th><th>Rows</th><th>Columns present</th><th>Last updated</th><th>Age</th><th>Status</th></tr></thead><tbody>'+trs+'</tbody></table></div></section>'
+'<div class="row" style="align-items:flex-start"><section class="card"><h2>Expected columns</h2>'+cols+'<p class="note" style="margin:10px 0 0">* required. To add a column, use the Columns button on any tab, or just add a header in Excel. Either way it shows up everywhere, and the setup is kept in the _Schema sheet.</p></section>'
+'<section class="card"><h2>Writing back to Excel</h2><div class="dq"><span class="badge b-ok">Best</span><div class="t"><b>Open the file in the page</b><div class="note">Edge or Chrome can open the xlsx with a file picker and write changes straight back. No server needed.</div></div></div><div class="dq"><span class="badge b-info">Fallback</span><div class="t"><b>Save a copy</b><div class="note">The page offers an updated xlsx to save. You replace the original yourself.</div></div></div><div class="dq"><span class="badge b-off">Team use</span><div class="t"><b>Tiny PowerShell web listener</b><div class="note">Serves the page and a save endpoint, so several people can edit the same workbook.</div></div></div></section></div>'
+'<section class="card"><h2>Folder structure</h2><pre>inventory/\n├─ index.html                 the generated dashboard\n├─ dashboard-template.html\n├─ Inventory/                 .xlsx files used as database\n├─ Issues/                    one folder per case (DCI-0001 …)\n│   └─ DCI-0001/              photos and files of the case\n└─ Stuff/                     .rds file and other helper files\n    ├─ KnowledgeBase/        one folder per article (KB-0001 …)\n    └─ OpenIssues/           one folder per issue (OI-0001 …)</pre></section>'
+'<section class="card"><div class="tools" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">Datastore collector (vCenter + array)</h2><button class="btn s" data-act="copy" data-target="pscode2">Copy</button></div><p class="note" style="margin:0 0 10px">The page cannot reach vCenter or the array by itself. This script runs on a schedule, reads datastores with PowerCLI, matches them with an array export by NAA ID and writes the Datastores sheet. Rebuild the page afterwards.</p><pre id="pscode2">'+esc(PS2)+'</pre></section>'

+(DEMO?'<section class="card"><h2>Demo controls</h2><p class="note" style="margin:0 0 10px">Edits in this demo are kept in your browser only. Reset brings back the built-in sample data, including a few planted errors for the data quality view.</p><button class="btn d" data-act="reset">Reset demo data</button></section>':'<section class="card"><h2>Local data</h2><p class="note" style="margin:0 0 10px">Until you use Save to Excel, edits are kept in this browser only. Clearing them empties the page, it does not touch the Excel file. Pasted photos in DC Open Issues are kept in this browser only.</p><button class="btn d" data-act="reset">Clear local data</button></section>');
}

const PS2=String.raw`# Collect-Datastores.ps1  (needs: VMware.PowerCLI, ImportExcel)  SAMPLE, test it in your environment first
# Reads datastores from every vCenter and matches them with an array export by NAA ID.
# ArrayLuns.csv comes from the storage array (CLI or report), columns: Array,Volume,LunId,Naa,SizeTB
param(
  [string[]]$VCenter  = @('vc-a.corp.example','vc-b.corp.example'),
  [string]$Xlsx       = '.\inventory.xlsx',
  [string]$ArrayCsv   = '.\Inventory\ArrayLuns.csv'
)
Connect-VIServer -Server $VCenter | Out-Null
$arr = @{}
Import-Csv $ArrayCsv | ForEach-Object { $arr[$_.Naa.ToLower()] = $_ }
$notes = @{}
try { Import-Excel $Xlsx -WorksheetName Datastores | ForEach-Object { $notes[$_.Datastore] = $_.Notes } } catch {}
$now = Get-Date -Format 'yyyy-MM-dd HH:mm'
$rows = foreach ($ds in Get-Datastore) {
  $naa = ''; $lun = ''
  if ($ds.Type -eq 'VMFS') {
    $naa = $ds.ExtensionData.Info.Vmfs.Extent[0].DiskName
    $h   = Get-VMHost -Datastore $ds | Select-Object -First 1
    $sl  = Get-ScsiLun -VmHost $h -CanonicalName $naa
    $lun = ((Get-ScsiLunPath -ScsiLun $sl | Select-Object -First 1).LunPath -split ':L')[-1]
  }
  $a   = $arr[$naa.ToLower()]
  $sum = $ds.ExtensionData.Summary
  [pscustomobject][ordered]@{
    'Datastore'      = $ds.Name
    'DC'             = (Get-Datacenter -Datastore $ds | Select-Object -First 1).Name
    'vCenter'        = ($ds.Uid -replace '.*@([^:]+):.*','$1')
    'Cluster'        = (Get-Cluster -Datastore $ds -ErrorAction SilentlyContinue | Select-Object -First 1).Name
    'Type'           = if ($ds.Type -eq 'VMFS') { 'VMFS' + $ds.FileSystemVersion.Split('.')[0] } else { $ds.Type }
    'NAA ID'         = $naa
    'LUN ID'         = $lun
    'Capacity TB'    = [math]::Round($sum.Capacity / 1TB, 2)
    'Free TB'        = [math]::Round($sum.FreeSpace / 1TB, 2)
    'Used %'         = [math]::Round(100 * ($sum.Capacity - $sum.FreeSpace) / $sum.Capacity)
    'Provisioned TB' = [math]::Round(($sum.Capacity - $sum.FreeSpace + $sum.Uncommitted) / 1TB, 2)
    'VMs'            = @($ds.ExtensionData.Vm).Count
    'Hosts'          = @($ds.ExtensionData.Host).Count
    'vCenter read'   = $now
    'Array'          = $a.Array
    'Array volume'   = $a.Volume
    'Array LUN ID'   = $a.LunId
    'Array NAA'      = $a.Naa
    'Array size TB'  = $a.SizeTB
    'Array read'     = (Get-Item $ArrayCsv).LastWriteTime.ToString('yyyy-MM-dd HH:mm')
    'Notes'          = $notes[$ds.Name]
    'Updated'        = Get-Date -Format 'yyyy-MM-dd'
  }
}
$rows | Export-Excel -Path $Xlsx -WorksheetName Datastores -ClearSheet -AutoSize
Disconnect-VIServer -Confirm:$false`;
function mvB(sheet,i){const n=DB[sheet].length;return '<button class="btn s" data-act="mvrow" data-sheet="'+sheet+'" data-i="'+i+'" data-dir="-1" aria-label="Move up"'+(i===0?' disabled':'')+'>↑</button> <button class="btn s" data-act="mvrow" data-sheet="'+sheet+'" data-i="'+i+'" data-dir="1" aria-label="Move down"'+(i>=n-1?' disabled':'')+'>↓</button> '}
function settingsView(){
const ops=DB.Operators.map((o,i)=>({o:o,i:i})),used=n=>DB.DCChecks.filter(c=>String(c['Checked by'])===String(n)).length,lg=n=>DB.ActivityLog.filter(r=>String(r.User)===String(n)).length;
const act=ops.filter(x=>x.o.Active!=='No').length;
return head('Settings','Lists used by the data entry forms. More settings will be added here later.','<button class="btn" data-act="sortaz" data-sheet="Operators" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="opadd">+ Add operator</button>')
+'<section class="card"><h2>Operators for DC checks</h2><p class="note" style="margin:0 0 12px">Active operators appear in the “Checked by” list of a new DC check and as comment authors in DC Open Issues. Set an operator to inactive instead of deleting, so old checks keep their name. Renaming does not change checks already logged. Stored in the “Operators” sheet.</p>'
+'<div class="kpis" style="margin-bottom:12px"><div class="kpi"><span>Active operators</span><b>'+act+'</b><small>'+(ops.length-act)+' inactive</small></div></div>'
+(ops.length?'<div class="tw"><table><thead><tr><th>Name</th><th>Username</th><th>Role / shift</th><th>Status</th><th>Checks logged</th><th>Saves in Activity log</th><th>Notes</th><th></th></tr></thead><tbody>'+ops.map(x=>'<tr><td><b>'+esc(x.o.Name)+'</b></td><td class="mono">'+esc(x.o.Username)+'</td><td>'+esc(x.o['Role / shift'])+'</td><td><span class="badge '+(x.o.Active==='No'?'b-off':'b-ok')+'">'+(x.o.Active==='No'?'Inactive':'Active')+'</span></td><td class="mono">'+used(x.o.Name)+'</td><td>'+(lg(x.o.Name)?'<button class="btn s" data-act="oplog" data-n="'+esc(x.o.Name)+'" title="Show these entries in the Activity log">'+lg(x.o.Name)+(lg(x.o.Name)===1?' entry':' entries')+'</button>':'<span class="note" style="margin:0">none</span>')+'</td><td style="white-space:normal">'+esc(x.o.Notes)+'</td><td>'+mvB('Operators',x.i)+'<button class="btn s" data-act="edit" data-sheet="Operators" data-i="'+x.i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No operators yet. Add the first one.</div>')
+'</section>'
+secCard()
+nicCard()
+dcCard()
+btCard()
+genCard()+atCard()+ccCard()+hpCard()+ktCard()+sortCard()
+ssCard()
+asCard()
+agCard()
+envCard()
+deviceTypesCard();
}
function dcCard(){
const dcs=DCS.map(n=>({n:n,i:DB.DataCenters.findIndex(d=>d.Name===n)}));
const dcT='<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Data centers</h2><button class="btn" data-act="sortaz" data-sheet="DataCenters" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="dcadd">+ Add data center</button></div>'
+'<p class="note" style="margin:0 0 12px">The sites that appear on the DC rack layout, DCMI and checks. Renaming a data center renames it everywhere (devices, racks, readings, checks). A data center can be deleted only when it has no racks and no devices.</p>'
+(dcs.length?'<div class="tw"><table><thead><tr><th>Data center</th><th>Racks</th><th>Total U</th><th>Devices</th><th>Notes</th><th></th></tr></thead><tbody>'+dcs.map(d=>'<tr><td><b>'+esc(d.n)+'</b></td><td class="mono">'+dcRackN(d.n)+'</td><td class="mono">'+dcTotalU(d.n)+'</td><td class="mono">'+devices().filter(x=>x.dc===d.n).length+'</td><td style="white-space:normal">'+esc(d.i>=0?DB.DataCenters[d.i].Notes:'')+'</td><td>'+(d.i>=0?''+mvB('DataCenters',d.i)+'<button class="btn s" data-act="edit" data-sheet="DataCenters" data-i="'+d.i+'">Edit</button>':'<span class="note">only in data</span>')+'</td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No data centers yet. Add at least one.</div>')
+'</section>';
rackGroup(false);const last={};DB.RackList.forEach((r,i)=>{last[r.DC]=i});const first={};DB.RackList.forEach((r,i)=>{if(first[r.DC]==null)first[r.DC]=i});
const rkT='<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Racks</h2><span class="tools"><button class="btn" data-act="racksort" title="Group by data center and sort the rack names naturally (R2 before R10)">Auto sort</button><button class="btn" data-act="rackbulk">Add several racks…</button><button class="btn p" data-act="rackadd">+ Add rack</button></span></div>'
+'<p class="note" style="margin:0 0 12px">Every rack of every data center: its name, how many U it has, and where it appears on the DC rack layout (▲ ▼ change the order). Renaming a rack renames it on all devices placed in it. A rack cannot be made smaller than its highest device and can be deleted only when empty.</p>'
+(DB.RackList.length?'<div class="tw"><table><thead><tr><th>Data center</th><th>Rack</th><th>U</th><th>Devices</th><th>Notes</th><th>Order</th><th></th></tr></thead><tbody>'+DB.RackList.map((r,i)=>'<tr><td>'+esc(r.DC)+'</td><td class="mono"><b>'+esc(r.Rack)+'</b></td><td class="mono">'+esc(r['U count'])+'</td><td class="mono">'+rackDevCount(r.DC,r.Rack)+'</td><td style="white-space:normal">'+esc(r.Notes)+'</td><td style="white-space:nowrap"><button class="btn s" data-act="rkorder" data-i="'+i+'" data-d="-1" aria-label="Move up"'+(first[r.DC]===i?' disabled':'')+'>▲</button> <button class="btn s" data-act="rkorder" data-i="'+i+'" data-d="1" aria-label="Move down"'+(last[r.DC]===i?' disabled':'')+'>▼</button></td><td><button class="btn s" data-act="edit" data-sheet="RackList" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No racks yet. Use Add several racks to create them.</div>')
+'</section>';
return dcT+rkT;
}
function openRackBulk(){
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Add several racks" style="width:min(520px,100%)"><h2>Add several racks</h2>'
+'<div class="fgrid"><label class="wide" for="rb-dc">Data center<select class="inp" id="rb-dc">'+DCS.map(x=>'<option'+(x===RK.dc?' selected':'')+'>'+esc(x)+'</option>').join('')+'</select></label>'
+'<label for="rb-n">How many racks<input class="inp" id="rb-n" type="number" min="1" max="60" value="4"></label>'
+'<label for="rb-u">U per rack<input class="inp" id="rb-u" type="number" min="1" max="100" value="42"></label>'
+'<label for="rb-p">Name prefix<input class="inp" id="rb-p" value="R"></label>'
+'<label for="rb-s">First number<input class="inp" id="rb-s" type="number" min="0" value="1"></label>'
+'<label for="rb-d">Digits (R01 = 2)<input class="inp" id="rb-d" type="number" min="0" max="4" value="2"></label></div>'
+'<p class="note" style="margin:0">Creates names like R01, R02, … Racks whose name already exists in that data center are skipped. Rename single racks afterwards with Edit.</p>'
+'<div id="rb-err" class="note" style="color:var(--bad-fg)" role="alert"></div>'
+'<div class="acts"><span></span><div class="tools"><button class="btn" data-act="mclose">Cancel</button><button class="btn p" data-act="rackbulkgo">Add racks</button></div></div></div></div>'}
function rackGroup(nat){const o=DCS.slice();DB.RackList.forEach(r=>{if(o.indexOf(r.DC)<0)o.push(r.DC)});const L=DB.RackList.map((r,i)=>({r:r,i:i}));L.sort((a,b)=>o.indexOf(a.r.DC)-o.indexOf(b.r.DC)||(nat?String(a.r.Rack).localeCompare(String(b.r.Rack),undefined,{numeric:true,sensitivity:'base'}):a.i-b.i));DB.RackList.splice(0,DB.RackList.length,...L.map(x=>x.r))}
function doRackBulk(){
const dc=$('rb-dc').value,n=parseInt($('rb-n').value),u=parseInt($('rb-u').value),p=$('rb-p').value,st=parseInt($('rb-s').value),pad=parseInt($('rb-d').value)||0;
if(!dc){$('rb-err').textContent='Add a data center first';return}
if(!(n>=1&&n<=60)||!(u>=1&&u<=100)||isNaN(st)){$('rb-err').textContent='Check the numbers: 1–60 racks, 1–100 U';return}
const have=dcRacks(dc).map(x=>x.toLowerCase());let added=0;
makeRacks(dc,n,u,p,st,pad).forEach(r=>{if(have.indexOf(String(r.Rack).toLowerCase())<0){DB.RackList.push(r);added++}});
rackGroup(false);closeForm();changed();route();toast(added+' racks added to '+dc+(added<n?' ('+(n-added)+' skipped, name already used)':''))}
function ssCard(){
const cnt=n=>DB.ServerMI.filter(a=>a.Status===n).length;
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Server statuses</h2><button class="btn" data-act="sortaz" data-sheet="ServerStatuses" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="ssadd">+ Add status</button></div>'
+'<p class="note" style="margin:0 0 12px">The choices for Status on the ServersMI tab. <b>Meaning</b> tells the reports how to treat it: Running counts as powered on, Stopped is off, Decommissioned is left out of patching and backup checks. Rename freely, existing servers follow.</p>'
+(DB.ServerStatuses.length?'<div class="tw"><table><thead><tr><th>Status</th><th>Meaning</th><th>Active</th><th>Servers</th><th>Notes</th><th></th></tr></thead><tbody>'+DB.ServerStatuses.map((t,i)=>'<tr><td><span class="badge '+(srvStatusCls(t.Name)||'b-off')+'">'+esc(t.Name)+'</span></td><td>'+esc(t.Meaning)+'</td><td>'+(t.Active==='No'?'<span class="badge b-off">Inactive</span>':'<span class="badge b-ok">Active</span>')+'</td><td class="mono">'+cnt(t.Name)+'</td><td style="white-space:normal">'+esc(t.Notes)+'</td><td>'+mvB('ServerStatuses',i)+'<button class="btn s" data-act="edit" data-sheet="ServerStatuses" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No statuses yet. Add at least one.</div>')
+'</section>';
}
function asCard(){
const cnt=n=>DB.DCSSActivity.filter(a=>a.Status===n).length;
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">DCSS activity statuses</h2><button class="btn" data-act="sortaz" data-sheet="ActivityStatuses" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="asadd">+ Add status</button></div>'
+'<p class="note" style="margin:0 0 12px">The choices for the Status of an entry on the DCSS Activity tab. A status marked <b>actionable</b> means work is still open: those activities are counted next to DCSS Activity in the left menu and listed on the Overview.</p>'
+(DB.ActivityStatuses.length?'<div class="tw"><table><thead><tr><th>Status</th><th>Actionable</th><th>Active</th><th>Activities</th><th>Notes</th><th></th></tr></thead><tbody>'+DB.ActivityStatuses.map((t,i)=>'<tr><td><span class="badge '+actStatusCls(t.Name)+'">'+esc(t.Name)+'</span></td><td>'+(t.Actionable==='Yes'?'<span class="badge b-warn">Actionable</span>':'<span class="note">no</span>')+'</td><td>'+(t.Active==='No'?'<span class="badge b-off">Inactive</span>':'<span class="badge b-ok">Active</span>')+'</td><td class="mono">'+cnt(t.Name)+'</td><td style="white-space:normal">'+esc(t.Notes)+'</td><td>'+mvB('ActivityStatuses',i)+'<button class="btn s" data-act="edit" data-sheet="ActivityStatuses" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No statuses yet. Add at least one.</div>')
+'</section>';
}
function agCard(){
const cnt=n=>DB.DCSSActivity.filter(a=>a['Assignment group']===n).length+DB.Contacts.filter(a=>a['Assignment group']===n).length;
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Assignment groups</h2><button class="btn" data-act="sortaz" data-sheet="AssignGroups" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="agadd">+ Add group</button></div>'
+'<p class="note" style="margin:0 0 12px">The groups offered as Assignment group on DCSS Activity and Contacts. Full details are on the Assignment groups tab. Set a group to inactive instead of deleting it. Renaming updates the activities and contacts.</p>'
+(DB.AssignGroups.length?'<div class="tw"><table><thead><tr><th>Group</th><th>Active</th><th>Used by</th><th></th></tr></thead><tbody>'+DB.AssignGroups.map((t,i)=>'<tr><td><b>'+esc(t.Group)+'</b></td><td>'+(t.Active==='No'?'<span class="badge b-off">Inactive</span>':'<span class="badge b-ok">Active</span>')+'</td><td class="mono">'+cnt(t.Group)+'</td><td>'+mvB('AssignGroups',i)+'<button class="btn s" data-act="edit" data-sheet="AssignGroups" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No groups yet.</div>')
+'</section>';
}
function ktCard(){
const cnt=n=>DB.KB.filter(a=>a.Type===n).length;
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Knowledge base types</h2><span class="tools"><button class="btn" data-act="sortaz" data-sheet="KBTypes" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button><button class="btn p" data-act="ktadd">+ Add type</button></span></div>'
+'<p class="note" style="margin:0 0 12px">The document types of the Knowledge base (SOP, How-to, Known issue…). Set a type to inactive instead of deleting it, so old articles keep it. Renaming updates the articles.</p>'
+(DB.KBTypes.length?'<div class="tw"><table><thead><tr><th>Type</th><th>Status</th><th>Articles</th><th>Notes</th><th></th></tr></thead><tbody>'+DB.KBTypes.map((t,i)=>'<tr><td><b>'+esc(t.Name)+'</b></td><td><span class="badge '+(t.Active==='No'?'b-off':'b-ok')+'">'+(t.Active==='No'?'Inactive':'Active')+'</span></td><td class="mono">'+cnt(t.Name)+'</td><td style="white-space:normal">'+esc(t.Notes)+'</td><td>'+mvB('KBTypes',i)+'<button class="btn s" data-act="edit" data-sheet="KBTypes" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No types yet. Add at least one.</div>')
+'</section>'}
function hpCard(){
const cnt=n=>DB.ArrayParts.filter(a=>a.Profile===n).length;
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Hardware profiles</h2><button class="btn p" data-act="hpadd">+ Add profile</button></div>'
+'<p class="note" style="margin:0 0 12px">Describe the physical layout of storage and backup hardware: how many magazines (bays) a cage has, how many sit in a row, how many disks per magazine and whether the bays are SFF or LFF. A new hardware generation is just a new profile. Used by Array hardware for the bay views.</p>'
+(DB.HwProfiles.length?'<div class="tw"><table><thead><tr><th>Profile</th><th>Role</th><th>U</th><th>Magazines</th><th>Per row</th><th>Disks / mag.</th><th>Bays</th><th>Status</th><th>Used</th><th></th></tr></thead><tbody>'+DB.HwProfiles.map((t,i)=>'<tr><td style="white-space:normal"><b>'+esc(t.Profile)+'</b><div class="note" style="margin:0">'+esc(t.Family)+'</div></td><td>'+esc(t.Role)+'</td><td class="mono">'+esc(t['U size'])+'</td><td class="mono">'+esc(t.Magazines)+'</td><td class="mono">'+esc(t['Mags per row'])+'</td><td class="mono">'+esc(t['Disks per magazine'])+'</td><td>'+esc(t['Bay form'])+'</td><td><span class="badge '+(t.Active==='No'?'b-off':'b-ok')+'">'+(t.Active==='No'?'Inactive':'Active')+'</span></td><td class="mono">'+cnt(t.Profile)+'</td><td>'+mvB('HwProfiles',i)+'<button class="btn s" data-act="edit" data-sheet="HwProfiles" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No profiles yet.</div>')+'</section>'}
function ccCard(){
const cnt=n=>CAL_SRC.reduce((s,x)=>s+DB[x.sheet].filter(a=>calCat(x,a)===n).length,0);
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Calendar categories</h2><span class="tools"><button class="btn" data-act="sortaz" data-sheet="CalCategories">Sort A–Z</button><button class="btn p" data-act="ccadd">+ Add category</button></span></div>'
+'<p class="note" style="margin:0 0 12px">The categories shown as filters and colours in the Calendar. Pick one in the “Calendar category” field of any activity, patching event or DC check; an event without one uses its default (DCSS Activity, Patching, DC checks). Set a category to inactive instead of deleting it. Renaming updates the events.</p>'
+(DB.CalCategories.length?'<div class="tw"><table><thead><tr><th>Category</th><th>Colour</th><th>Status</th><th>Events</th><th>Notes</th><th></th></tr></thead><tbody>'+DB.CalCategories.map((t,i)=>'<tr><td><b>'+esc(t.Name)+'</b></td><td><span class="ccdot" style="background:'+ccColor(t.Color)+'"></span> '+esc(t.Color)+'</td><td><span class="badge '+(t.Active==='No'?'b-off':'b-ok')+'">'+(t.Active==='No'?'Inactive':'Active')+'</span></td><td class="mono">'+cnt(t.Name)+'</td><td style="white-space:normal">'+esc(t.Notes)+'</td><td>'+mvB('CalCategories',i)+'<button class="btn s" data-act="edit" data-sheet="CalCategories" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No categories yet.</div>')+'</section>'}
function atCard(){
const cnt=n=>DB.DCSSActivity.filter(a=>a.Type===n).length;
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">DCSS activity types</h2><button class="btn" data-act="sortaz" data-sheet="ActivityTypes" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="atadd">+ Add type</button></div>'
+'<p class="note" style="margin:0 0 12px">The choices for the Type of an entry on the DCSS Activity tab. Set a type to inactive instead of deleting it, so old entries keep it. Renaming updates the logged activities.</p>'
+(DB.ActivityTypes.length?'<div class="tw"><table><thead><tr><th>Type</th><th>Status</th><th>Activities</th><th>Notes</th><th></th></tr></thead><tbody>'+DB.ActivityTypes.map((t,i)=>'<tr><td><b>'+esc(t.Name)+'</b></td><td><span class="badge '+(t.Active==='No'?'b-off':'b-ok')+'">'+(t.Active==='No'?'Inactive':'Active')+'</span></td><td class="mono">'+cnt(t.Name)+'</td><td style="white-space:normal">'+esc(t.Notes)+'</td><td>'+mvB('ActivityTypes',i)+'<button class="btn s" data-act="edit" data-sheet="ActivityTypes" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No types yet. Add at least one.</div>')
+'</section>';
}
function btCard(){
const cnt=n=>DB.BackupJobs.filter(j=>j.Type===n).length;
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Backup job categories</h2><button class="btn" data-act="sortaz" data-sheet="BackupTypes" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="btadd">+ Add category</button></div>'
+'<p class="note" style="margin:0 0 12px">The choices for the Type of a backup job. “Counts as backup” = No marks a category as an exemption (the server is not reported as unprotected). “Cloud” = Yes shows a ☁ badge and counts the server as also in a cloud job. Set a category to inactive instead of deleting it. Renaming updates the jobs.</p>'
+(DB.BackupTypes.length?'<div class="tw"><table><thead><tr><th>Category</th><th>Counts as backup</th><th>Cloud</th><th>Status</th><th>Jobs</th><th>Notes</th><th></th></tr></thead><tbody>'+DB.BackupTypes.map((t,i)=>'<tr><td><b>'+esc(t.Name)+'</b></td><td>'+esc(t['Counts as backup'])+'</td><td>'+(t.Cloud==='Yes'?'☁ Yes':'No')+'</td><td><span class="badge '+(t.Active==='No'?'b-off':'b-ok')+'">'+(t.Active==='No'?'Inactive':'Active')+'</span></td><td class="mono">'+cnt(t.Name)+'</td><td style="white-space:normal">'+esc(t.Notes)+'</td><td>'+mvB('BackupTypes',i)+'<button class="btn s" data-act="edit" data-sheet="BackupTypes" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No categories yet. Add at least one.</div>')
+'</section>';
}
function envCard(){
const cnt=n=>DB.ServerMI.filter(r=>r.Env===n).length;
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Environments (ServersMI)</h2><button class="btn" data-act="sortaz" data-sheet="Environments" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="envadd">+ Add environment</button></div>'
+'<p class="note" style="margin:0 0 12px">The choices for the Env column of ServersMI. “Production” decides what counts as production on the Overview and in the ServersMI KPIs. Patch within is the number of days a server in this environment may go without OS patching (used by Patching). Set an environment to inactive instead of deleting it. Renaming does not change servers that already use the old name, so change those servers too.</p>'
+(DB.Environments.length?'<div class="tw"><table><thead><tr><th>Environment</th><th>Badge</th><th>Production</th><th>Patch within</th><th>Status</th><th>Servers</th><th>Notes</th><th></th></tr></thead><tbody>'+DB.Environments.map((e,i)=>'<tr><td><b>'+esc(e.Name)+'</b></td><td><span class="badge '+(ENV_CLS[e.Color]||'b-off')+'">'+esc(e.Name)+'</span></td><td>'+esc(e.Production)+'</td><td class="mono">'+(parseInt(e['Patch days'])>=1?esc(e['Patch days'])+' days':'<span class="note">not set</span>')+'</td><td><span class="badge '+(e.Active==='No'?'b-off':'b-ok')+'">'+(e.Active==='No'?'Inactive':'Active')+'</span></td><td class="mono">'+cnt(e.Name)+'</td><td style="white-space:normal">'+esc(e.Notes)+'</td><td>'+mvB('Environments',i)+'<button class="btn s" data-act="edit" data-sheet="Environments" data-i="'+i+'">Edit</button></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No environments yet. Add at least one.</div>')
+'</section>';
}
function deviceTypesCard(){
const cnt=n=>DB.RackDevices.filter(r=>r.Type===n).length;
const built=[['ESXi host','ESXi hosts','esxi',DB.ESXi.length,'var(--u-esxi)'],['Storage array','Storage','storage',DB.Storage.length,'var(--u-stor)'],['Backup device','Backup','backup',DB.Backup.length,'var(--u-back)']];
const sw=c=>'<i style="display:inline-block;width:14px;height:14px;border-radius:3px;background:'+c+';vertical-align:-2px;margin-right:6px"></i>';
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Rack device types</h2><span class="tools">'+(DB.DeviceTypes.length?'':'<button class="btn" data-act="dtdefaults">Add common types</button>')+'<button class="btn" data-act="sortaz" data-sheet="DeviceTypes" title="Sort the list A to Z. The dropdown follows this order.">Sort A–Z</button> <button class="btn p" data-act="dtadd">+ Add device type</button></span></div>'
+'<p class="note" style="margin:0 0 12px">These are the kinds of devices you can put in a rack. The first three come from their own inventory tabs and cannot be changed. Add the others here (switch, firewall, PDU, patch panel and so on). Each one gets a color and a default height in U, then appears in “Place a device” on the DC rack layout and in the Other devices tab. Set a type to inactive instead of deleting it, so existing devices keep their color.</p>'
+'<div class="tw"><table><thead><tr><th>Type</th><th>Color</th><th>Default U</th><th>Source</th><th>Status</th><th>Devices</th><th></th></tr></thead><tbody>'
+built.map(b=>'<tr><td><b>'+b[0]+'</b></td><td>'+sw(b[4])+'fixed</td><td>—</td><td><a href="#'+b[2]+'">'+b[1]+' tab</a></td><td><span class="badge b-off">Built in</span></td><td class="mono">'+b[3]+'</td><td></td></tr>').join('')
+DB.DeviceTypes.map((t,i)=>'<tr><td><b>'+esc(t.Name)+'</b></td><td>'+sw(typeColor(t.Name))+esc(t.Color)+'</td><td class="mono">'+esc(t['Default U']||1)+'</td><td><a href="#otherdevices">Other devices tab</a></td><td><span class="badge '+(t.Active==='No'?'b-off':'b-ok')+'">'+(t.Active==='No'?'Inactive':'Active')+'</span></td><td class="mono">'+cnt(t.Name)+'</td><td>'+mvB('DeviceTypes',i)+'<button class="btn s" data-act="edit" data-sheet="DeviceTypes" data-i="'+i+'">Edit</button></td></tr>').join('')
+'</tbody></table></div></section>';
}

let STDIR=null;
const fmtT=d=>fmt(d)+' '+pad(d.getHours())+':'+pad(d.getMinutes());
function stuffList(){if(!META.stuff)META.stuff=DEMO?[{name:'jump-dc2a-mgmt.rdp',size:2048,modified:ds(-1)+' 08:05'},{name:'remote-servers.rds',size:4096,modified:ds(-3)+' 09:20'}]:[];return META.stuff}
async function stuffRefresh(){const out=[];for await(const e of STDIR.entries()){if(e[1].kind==='file'){const f=await e[1].getFile();out.push({name:e[0],size:f.size,modified:fmtT(new Date(f.lastModified))})}}out.sort((a,b)=>a.name.localeCompare(b.name));META.stuff=out;persist()}
async function stuffAdd(files){
let n=0;
try{
for(const f of files){
if(STDIR){const h=await STDIR.getFileHandle(f.name,{create:true}),w=await h.createWritable();await w.write(f);await w.close()}
else{const l=stuffList(),i=l.findIndex(x=>x.name===f.name),e={name:f.name,size:f.size,modified:fmtT(new Date())};if(i>=0)l[i]=e;else l.push(e);persist()}
n++}
if(STDIR)await stuffRefresh();
}catch(e){toast('Could not write the file. Check the folder permission.')}
route();if(n)toast(n+(n===1?' file ':' files ')+(STDIR?'saved to the Stuff folder':'added to the list. Copy it into the Stuff folder yourself.'));
}
async function stuffRemove(name){
try{if(STDIR){await STDIR.removeEntry(name);await stuffRefresh()}else{META.stuff=stuffList().filter(x=>x.name!==name);persist()}}catch(e){toast('Could not remove the file.');return}
route();toast(name+(STDIR?' deleted from the Stuff folder':' removed from the list. Delete the file in the folder too.'));
}
let TK=null;
function ticks(){if(!TK||TK.date!==ds(0)){TK={date:ds(0),names:[]};try{const o=JSON.parse(localStorage.getItem('infra-links-ticks')||'{}');if(o.date===TK.date&&Array.isArray(o.names))TK.names=o.names}catch(e){}}return TK.names}
function setTick(n,on){const a=ticks(),i=a.indexOf(n);if(on&&i<0)a.push(n);if(!on&&i>=0)a.splice(i,1);try{localStorage.setItem('infra-links-ticks',JSON.stringify(TK))}catch(e){}}
function lhref(u){u=String(u||'').trim();return /^https?:\/\//i.test(u)?u:'https://'+u}
function stuffView(){return STT==='rds'?head('Stuff','Generate a Remote Desktop Connection Manager file from the ServersMI list.')+rdsTabs()+rdsView():stuffViewMain()}
function stuffViewMain(){
const files=stuffList(),can=typeof window.showDirectoryPicker==='function';
const links=DB.Links.map((r,i)=>({r:r,i:i})).sort((a,b)=>String(a.r.Category||'~').localeCompare(String(b.r.Category||'~'))||String(a.r.Name).localeCompare(String(b.r.Name)));
const tk=ticks(),done=links.filter(x=>tk.indexOf(x.r.Name)>=0).length;
let cat=null;
const lrows=links.map(x=>{const r=x.r,c=r.Category||'Other',h=(c!==cat?'<tr><td colspan="5" style="background:var(--surface2);font-weight:600;font-size:12px;letter-spacing:.05em;text-transform:uppercase;color:var(--muted)">'+esc(c)+'</td></tr>':'');cat=c;
return h+'<tr><td style="width:44px"><input type="checkbox" data-act="lnkchk" data-n="'+esc(r.Name)+'"'+(tk.indexOf(r.Name)>=0?' checked':'')+' aria-label="Checked today: '+esc(r.Name)+'" style="width:20px;height:20px"></td><td><a class="lnk" data-act="lnkopen" data-n="'+esc(r.Name)+'" href="'+esc(lhref(r.URL))+'" target="_blank" rel="noopener noreferrer">'+esc(r.Name)+' ↗</a></td><td class="mono" style="max-width:340px"><span class="lnkaddr"><span>'+esc(r.URL)+'</span><button class="btn s icon" data-act="lnkcopy" data-u="'+esc(r.URL)+'" title="Copy address" aria-label="Copy '+esc(r.Name)+' address"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg></button></span></td><td style="white-space:normal">'+esc(r.Notes)+'</td><td><button class="btn s" data-act="edit" data-sheet="Links" data-i="'+x.i+'">Edit</button></td></tr>'}).join('');
return head('Stuff','Files from the Stuff folder and the links you go through on daily checks.')+rdsTabs()
+'<section class="card"><div class="tools" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">Files</h2><div class="tools">'+(can&&!STDIR?rootBtn():'')+'<button class="btn p" data-act="stadd">+ Add file</button><input type="file" id="stuff-file" aria-label="Add files" multiple hidden></div></div>'
+(STDIR?'<p class="note" style="margin:0 0 10px"><span class="badge b-ok">Connected</span> Adding and removing files changes the real Stuff folder.</p>':'<p class="note" style="margin:0 0 10px">'+(can?'Not connected to the project folder. Connect it once, then Add and Remove change the real files.':'This browser cannot write to folders. Use Edge or Chrome for that.')+' Without a connection, Add and Remove only change the list on this page: copy or delete the file in the folder yourself.</p>')
+(files.length?'<div class="tw"><table><thead><tr><th>File</th><th>Location</th><th>Size</th><th>Modified</th><th></th></tr></thead><tbody>'+files.map(f=>'<tr><td><b>'+esc(f.name)+'</b></td><td class="mono">Stuff/'+esc(f.name)+'</td><td>'+Math.max(1,Math.round(f.size/1024))+' KB</td><td>'+esc(f.modified)+'</td><td><div class="tools">'+(/\.(rdp|rdg|rds)$/i.test(f.name)?'<button class="btn p" data-act="stconnect" data-name="'+esc(f.name)+'">Connect</button><a class="btn s" href="Stuff/'+encodeURIComponent(f.name)+'" target="_blank" rel="noopener" title="Show the file content">View</a>':'<a class="btn p" href="Stuff/'+encodeURIComponent(f.name)+'" target="_blank" rel="noopener">Open</a>')+'<button class="btn s d" data-act="stdel" data-name="'+esc(f.name)+'">Remove</button></div></td></tr>').join('')+'</tbody></table></div>':'<div class="empty">No files yet. Use Add file.</div>')
+'<p class="note" style="margin:12px 0 0">Open is a normal link to <span class="mono">Stuff/&lt;file&gt;</span>. <b>Connect</b> on .rdp files hands the file to Remote Desktop (in Edge/Chrome choose “Always open files of this type” once in the download bar, then it opens straight away). '+(DEMO?'This preview has no Stuff folder, so Open only works in the real folder. The sample file is a placeholder.':'')+'</p></section>'
+'<section class="card"><div class="tools" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">Useful links</h2><div class="tools"><button class="btn p" data-act="lnkadd">+ Add link</button></div></div>'
+(links.length?'<div class="tw"><table><thead><tr><th>Today</th><th>Link</th><th>Address</th><th>Notes</th><th></th></tr></thead><tbody>'+lrows+'</tbody></table></div><p class="note" style="margin:12px 0 0">Opening a link ticks it for today. The ticks reset every day and stay in this browser only. Links themselves are saved in the “Links” sheet of the workbook. To remove a link, use Edit, then Delete.</p>':'<div class="empty">No links yet. Add the ones you check every day.</div>')+'</section>';
}

/* ---------- router + events ---------- */
const VIEWDEF={todo:todoView,drshostgroups:()=>tableView('DrsHostGroups'),arrayhw:hwView,arrayparts:()=>tableView('ArrayParts'),overview:overview,calendar:calendarView,servermi:()=>tableView('ServerMI'),serverdisks:()=>tableView('ServerDisks'),clusters:clustersView,arrayvolumes:()=>tableView('ArrayVolumes'),lunmap:lunMapView,remotecopy:()=>tableView('RemoteCopyGroups'),datastoreclusters:()=>tableView('DatastoreClusters'),drsrules:()=>tableView('DrsRules'),patching:patchView,patchevents:()=>tableView('PatchEvents'),catalyst:()=>tableView('Catalyst'),repljobs:()=>tableView('ReplJobs'),activitylog:()=>tableView('ActivityLog'),ports:portsView,disks:disksView,netports:()=>tableView('NetPorts'),disklist:()=>tableView('Disks'),contacts:()=>tableView('Contacts'),agroups:()=>tableView('AssignGroups'),activity:()=>tableView('DCSSActivity'),backupjobs:bjView,esxi:()=>tableView('ESXi'),storage:()=>tableView('Storage'),backup:()=>tableView('Backup'),dcmi:()=>tableView('DCMI'),racks:racksView,lifecycle:lifecycleView,ipam:ipView,relations:relView,import:importView,wsfc:wsfcView,dcdesign:dcdesignView,dclayoutlist:()=>tableView('DCLayout'),checks:()=>tableView('DCChecks'),issues:issuesView,stuff:stuffView,kb:kbView,otherdevices:()=>tableView('RackDevices'),tracker:oiView,quality:qualityView,sources:sourcesView,datastores:()=>tableView('Datastores'),settings:settingsView};
/* page transitions: tabs slide + fade in the tab direction (200 ms), page change rises (220 ms), first visit cascades */
const PGSEEN={};let PGLAST='';
function pgAnim(){
const id=CUR,prev=PGLAST;PGLAST=id;
if(!prev||prev===id)return;
try{
if(matchMedia('(prefers-reduced-motion: reduce)').matches)return;
const v=$('view');if(!v||!v.animate)return;
const kids=[].filter.call(v.children,e=>!e.classList.contains('gtabs'));if(!kids.length)return;
const g=GOF[id],ez='cubic-bezier(.2,.7,.2,1)';let ms=220;
if(g&&GOF[prev]===g){
const ts=GRP[g].map(x=>x[0]),dir=ts.indexOf(id)>ts.indexOf(prev)?1:-1;ms=200;
kids.forEach(k=>k.animate([{opacity:0,transform:'translateX('+(28*dir)+'px)'},{opacity:1,transform:'none'}],{duration:ms,easing:ez}));
}else{
const first=!PGSEEN[id];PGSEEN[id]=1;
let tg=kids;
if(first&&kids.length<4){const big=kids.slice().sort((a,b)=>b.children.length-a.children.length)[0];if(big&&big.children.length>=3&&big.children.length<=24)tg=[].slice.call(kids.filter(k=>k!==big)).concat([].slice.call(big.children))}
tg.forEach((k,i)=>k.animate([{opacity:0,transform:'translateY(14px)'},{opacity:1,transform:'none'}],{duration:ms,delay:first?Math.min(i,10)*35:0,easing:ez,fill:'backwards'}));
}
v.style.overflowX='hidden';setTimeout(()=>{v.style.overflowX=''},ms+500);
}catch(e){}
}
function route(){
const id=(location.hash||'#overview').slice(1);CUR=VIEWDEF[id]?id:'overview';
syncEnvOptions();syncBackupTypes();syncActivityTypes();syncKBTypes();syncActivityStatuses();syncServerStatuses();syncLayout();renderSide();renderPending();gnote(CUR);$('view').innerHTML=(GOF[CUR]?gtabs(CUR):'')+VIEWDEF[CUR]();postRender();neonPost();pgAnim();
if(CUR==='issues'){drawDraft();loadPics()}
}
const ACT={
sort(el){const u=uiOf(el.dataset.sheet),c=el.dataset.col;if(u.sk===c)u.sd=-u.sd;else{u.sk=c;u.sd=1}route()},
chip(el,e){const u=uiOf(el.dataset.sheet),v=el.dataset.v;if(e&&(e.shiftKey||e.ctrlKey||e.metaKey)&&v!=='All'){let fm=(u.fm||[]).slice();if(!fm.length&&u.f!=='All')fm=[u.f];const k=fm.indexOf(v);if(k>=0)fm.splice(k,1);else fm.push(v);u.fm=fm;u.f=fm.length?'__multi':'All'}else{u.fm=[];u.f=v}route()},
edit(el){openForm(el.dataset.sheet,+el.dataset.i)},
add(el){const s=el.dataset.sheet,u=uiOf(s),p={};if(s==='PatchEvents'){openPtBulk();return}if(u.fm&&u.fm.length===1)p[TV[s].filter]=u.fm[0];else if(u.f!=='All'&&u.f!=='__multi')p[TV[s].filter]=u.f;openForm(s,null,p)},
mclose(){tryClose()},
oisel(el){OS.sel=el.dataset.id;route()},
oif(el){OS[el.dataset.k]=el.dataset.v;route()},
oinew(){openForm('OpenIssues',null)},
oigokb(el){KS.sel=el.dataset.id;KS.q='';KS.type='All';KS.status='All'},
oikb(){const r=DB.OpenIssues.find(x=>x.ID===OS.sel);if(!r)return;openForm('KB',null,{Title:r.Title,Type:'Known issue',Category:r.Category,Resolution:r.Resolution,Summary:r.Description,Owner:r.Assignee||''})},
oicomment(){const r=DB.OpenIssues.find(x=>x.ID===OS.sel),t=$('oc-text').value.trim();if(!r)return;if(!t){toast('Write a comment first');return}DB.OIComments.push({Issue:r.ID,Time:nowStr(),Author:$('oc-author').value,Type:$('oc-type').value,Text:t});r.Updated=ds(0);changed();route()},
oires(el){const r=DB.OpenIssues.find(x=>x.ID===OS.sel),c=DB.OIComments[+el.dataset.ci];if(!r||!c)return;r.Resolution=c.Text;r.Updated=ds(0);changed();route();toast('Resolution updated from the comment')},
oifdel(el){const r=DB.OpenIssues.find(x=>x.ID===OS.sel);if(!r)return;if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to remove';return}const n=el.dataset.name;(async()=>{try{if(OIDIR){const d=await OIDIR.getDirectoryHandle(r.ID);await d.removeEntry(n)}}catch(e){toast('Could not delete the file in the folder.')}r.Files=kbFiles(r).filter(x=>x!==n).join('; ');r.Updated=ds(0);changed();route()})()},
async oiconnect(){try{OIDIR=await window.showDirectoryPicker({mode:'readwrite'});route();toast('Connected to the folder “'+OIDIR.name+'”. Pick Stuff/OpenIssues.')}catch(e){OIDIR=null}},
kbsel(el){KS.sel=el.dataset.id;route()},
kbf(el){KS[el.dataset.k]=el.dataset.v;route()},
kbnew(){openForm('KB',null)},
kbreview(){const r=DB.KB.find(x=>x.ID===KS.sel);if(!r)return;r['Last reviewed']=ds(0);r['Review due']=ds(180);r.Updated=ds(0);changed();route();toast(r.ID+' marked as reviewed')},
kbcomment(){const r=DB.KB.find(x=>x.ID===KS.sel),t=$('kc-text').value.trim();if(!r)return;if(!t){toast('Write a comment first');return}DB.KBComments.push({Article:r.ID,Time:nowStr(),Author:$('kc-author').value,Type:$('kc-type').value,Text:t});r.Updated=ds(0);changed();route()},
kbres(el){const r=DB.KB.find(x=>x.ID===KS.sel),c=DB.KBComments[+el.dataset.ci];if(!r||!c)return;r.Resolution=c.Text;r.Updated=ds(0);changed();route();toast('Resolution updated from the comment')},
kbfdel(el){const r=DB.KB.find(x=>x.ID===KS.sel);if(!r)return;if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to remove';return}const n=el.dataset.name;(async()=>{try{if(KBDIR){const d=await KBDIR.getDirectoryHandle(r.ID);await d.removeEntry(n)}}catch(e){toast('Could not delete the file in the folder.')}r.Files=kbFiles(r).filter(x=>x!==n).join('; ');r.Updated=ds(0);changed();route()})()},
async kbconnect(){try{KBDIR=await window.showDirectoryPicker({mode:'readwrite'});route();toast('Connected to the folder “'+KBDIR.name+'”. Pick Stuff/KnowledgeBase.')}catch(e){KBDIR=null}},
lnkadd(){openForm('Links',null)},
lnkopen(el){setTick(el.dataset.n,true);setTimeout(route,0)},
stadd(){const f=$('stuff-file');if(f)f.click()},
async stconnect(){try{STDIR=await window.showDirectoryPicker({mode:'readwrite'});await stuffRefresh();route();toast('Connected to the folder “'+STDIR.name+'”')}catch(e){STDIR=null}},
stdel(el){if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to remove';return}stuffRemove(el.dataset.name)},
opadd(){openForm('Operators',null)},
dtadd(){openForm('DeviceTypes',null)},
envadd(){openForm('Environments',null)},
btadd(){openForm('BackupTypes',null)},
atadd(){openForm('ActivityTypes',null)},ccadd(){openForm('CalCategories',null)},
ktadd(){openForm('KBTypes',null)},
asadd(){openForm('ActivityStatuses',null)},
ssadd(){openForm('ServerStatuses',null)},
agadd(){openForm('AssignGroups',null)},
bjadd(){openForm('BackupJobs',null)},
bjf(el){BJ.f=el.dataset.v;route()},
bjjobset(el){BJ.job=el.dataset.v;BJ.f='All';route()},
bjasv(el){openAssignServer(+el.dataset.i)},
bjajob(el){openAssignJob(+el.dataset.i)},
bjsave(){bjSave()},
bjcsv(){bjCsv()},
bjmsel(el){document.querySelectorAll('.bjrow').forEach(r=>{if(r.style.display!=='none')r.querySelector('input').checked=el.dataset.v==='1'})},
pstat(el){PT.f=el.dataset.v;route()},
penv(el){PT.env=el.dataset.v;route()},
ptbulk(){openPtBulk()},
ptbulkgo(){doPtBulk()},
ptdone(el){openPtDone(+el.dataset.i)},ptdonego(){doPtDone()},ptodaygo(){doPtToday()},
ptoday(el){openPtToday(+el.dataset.i)},ptoday_old(el){const r=DB.ServerMI[+el.dataset.i];if(!r)return;r['Last patched']=ds(0);r.Updated=ds(0);changed();route();toast(r.Hostname+': Last patched set to today')},
pcsv(){patchCsv()},
dcadd(){openForm('DataCenters',null)},
rackadd(){if(!DCS.length){toast('Add a data center first');return}openForm('RackList',null)},
rackbulk(){if(!DCS.length){toast('Add a data center first');return}openRackBulk()},
rackbulkgo(){doRackBulk()},
racksort(){rackGroup(true);changed();route();toast('Racks sorted by data center and name')},
rkorder(el){const i=+el.dataset.i,d=+el.dataset.d,a=DB.RackList[i];let j=i+d;while(j>=0&&j<DB.RackList.length&&DB.RackList[j].DC!==a.DC)j+=d;if(j<0||j>=DB.RackList.length)return;DB.RackList[i]=DB.RackList[j];DB.RackList[j]=a;changed();route()},
dtdefaults(){defaultDT().forEach(t=>{if(!DB.DeviceTypes.some(x=>x.Name===t.Name))DB.DeviceTypes.push(t)});changed();route()},
rootconnect(){rootConnect()},
rootreconnect(){rootReconnect()},
rootchange(){rootConnect()},
selall(el){const sh=el.dataset.sheet,s=selSet(sh),rows=viewRows(sh);if(el.checked)rows.forEach(x=>s.add(x.r));else rows.forEach(x=>s.delete(x.r));redrawTable(sh)},
rowsel(el,e){e.stopPropagation();const sh=el.dataset.sheet,r=DB[sh][+el.dataset.i],s=selSet(sh);if(el.checked)s.add(r);else s.delete(r);redrawTable(sh)},
bclear(el){selSet(el.dataset.sheet).clear();redrawTable(el.dataset.sheet)},
bset(el){openBulkSet(el.dataset.sheet)},
bsgo(el){bsApply(el.dataset.sheet)},
bdel(el){bulkDelete(el.dataset.sheet,el)},
bcsv(el){exportCsv(el.dataset.sheet,true)},

attdel(el){attRemove(el.dataset.sheet,el.dataset.n,el)},
attq(el){ATT.q.splice(+el.dataset.k,1);const fm=$('frm');if(fm)$('att-box').innerHTML=attInner(fm.dataset.sheet,{},fm.dataset.i==='')},
mvrow(el){const sh=el.dataset.sheet,i=+el.dataset.i,d=+el.dataset.dir,a=DB[sh],j=i+d;if(j<0||j>=a.length)return;const t=a[i];a[i]=a[j];a[j]=t;changed();route()},
sortaz(el){const sh=el.dataset.sheet,k=SCHEMA[sh].key;DB[sh].sort((x,y)=>String(x[k]||'').localeCompare(String(y[k]||''),undefined,{numeric:true,sensitivity:'base'}));changed();route();toast('Sorted A to Z. The dropdowns follow this order.')},
async reloadxlsx(el){if(!handle){toast('Connect the project folder or open the workbook first');return}if(dirty>0&&!el.dataset.arm){el.dataset.arm='1';el.textContent='Discard unsaved changes? Click again';return}try{if(ROOT&&!(await rootPerm(true))){toast('Permission for the project folder is needed');return}await importFile(await handle.getFile(),handle)}catch(e){toast('Could not read the workbook')}},
saveAs(){saveExcel(true)},
ftoggle(el){const u=uiOf(el.dataset.sheet);u.open=!u.open;route()},
fadd(el){const s=el.dataset.sheet,u=uiOf(s);u.fl.push(newFilter(s,fcols(s)[0].k));u.open=true;route()},
frm(el){uiOf(el.dataset.sheet).fl.splice(+el.dataset.fi,1);route()},
fclear(el){uiOf(el.dataset.sheet).fl=[];route()},
fpreset(el){const s=el.dataset.sheet,u=uiOf(s),p=presets(s)[+el.dataset.pi];if(!p)return;const ix=presetOn(s,p);if(ix>=0)u.fl.splice(ix,1);else{u.fl.push(JSON.parse(JSON.stringify(p.f)));u.open=true}route()},
colmove(el){const s=el.dataset.sheet,k=el.dataset.k,d=+el.dataset.dir,a=TV[s].show,i=a.indexOf(k),j=i+d;if(i<0||j<0||j>=a.length)return;a.splice(i,1);a.splice(j,0,k);saveSchemaMeta();changed();route();openCols(s)},
csv(el){exportCsv(el.dataset.sheet)},
rkplace(el){openPlace({dc:RK.dc,rack:el.dataset.rack})},
rkfree(el){openPlace({dc:RK.dc,rack:el.dataset.rack,u:+el.dataset.u})},
rkmove(el){const d=devices().find(x=>x.sheet===el.dataset.sheet&&x.i===+el.dataset.i);if(d)openPlace({key:devKey(d),dc:d.dc||RK.dc,rack:d.rack||dcRacks(d.dc||RK.dc)[0],u:valid(d)?d.u:undefined})},
rkremove(el){removeFromRack(el.dataset.sheet,+el.dataset.i)},
doplace(){doPlace()},
cols(el){openCols(el.dataset.sheet)},
colshow(el){const s=el.dataset.sheet,k=el.dataset.k,sh=TV[s].show,i=sh.indexOf(k);if(el.checked&&i<0)sh.push(k);if(!el.checked&&i>=0)sh.splice(i,1);saveSchemaMeta();changed();route()},
coladd(el){const s=el.dataset.sheet;const err=addColumn(s,{k:$('nc-name').value,t:$('nc-type').value,o:$('nc-opts').value,req:$('nc-req').checked,show:$('nc-show')?$('nc-show').checked:false});if(err){$('nc-err').textContent=err;return}saveSchemaMeta();changed();route();openCols(s);toast('Column added. It is written to Excel on the next save.')},
coledit(el){openColEdit(el.dataset.sheet,el.dataset.k)},
colback(el){openCols(el.dataset.sheet)},
colsave(el){saveColEdit(el.dataset.sheet,el.dataset.k)},
colhide(el){if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to delete';return}const s=el.dataset.sheet,c=SCHEMA[s].cols.find(x=>x.k===el.dataset.k);if(!c)return;hideCol(s,c);if(UI[s]){if(UI[s].sk===c.k)UI[s].sk=TV[s]?TV[s].show[0]:null;UI[s].fl=UI[s].fl.filter(f=>f.k!==c.k)}saveSchemaMeta();changed();route();openCols(s);toast('Column deleted from the table and form. Data kept, you can restore it.')},
colrestore(el){const s=el.dataset.sheet,c=SCHEMA[s].cols.find(x=>x.k===el.dataset.k);if(!c)return;showCol(s,c);if(TV[s]&&TV[s].show.indexOf(c.k)<0)TV[s].show.push(c.k);saveSchemaMeta();changed();route();openCols(s);toast('Column restored')},
colrm(el){if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to remove';return}const s=el.dataset.sheet,k=el.dataset.k;SCHEMA[s].cols=SCHEMA[s].cols.filter(c=>c.k!==k);if(TV[s])TV[s].show=TV[s].show.filter(x=>x!==k);if(UI[s]&&UI[s].sk===k)UI[s].sk=null;if(UI[s])UI[s].fl=UI[s].fl.filter(f=>f.k!==k);DB[s].forEach(r=>{delete r[k]});rebuildHead();saveSchemaMeta();changed();route();openCols(s);toast('Column removed')},
mbg(el,e){if(e.target===el)tryClose()},
del(el){deleteRow($('frm'),el)},
saveXlsx(){saveExcel()},
openXlsx(){openExcel()},
reset(el){if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to reset';return}resetDemo();toast(DEMO?'Demo data restored':'Local data cleared')},
goto(el){if(location.hash==='#'+el.dataset.v)route();else location.hash=el.dataset.v},
rkdc(el){RK.dc=el.dataset.v;if(CUR!=='racks')location.hash='racks';else route()},
rkdev(el){RK.sel={sheet:el.dataset.sheet,i:+el.dataset.i};route()},
issel(el){IS.sel=el.dataset.id;DRAFT.pics=[];route()},
isf(el){IS.f=el.dataset.v;route()},
isnew(){openForm('Issues',null)},
async addcmt(){
const cur=DB.Issues.find(i=>i.ID===IS.sel);if(!cur)return;
const text=$('cm-text').value.trim();
if(!text&&!DRAFT.pics.length){toast('Write a comment or attach a photo');return}
const cm={Issue:cur.ID,Time:nowStr(),Author:$('cm-author').value,Text:text,Pics:DRAFT.pics.slice(),Files:[]};let msg='Comment added';
if(cm.Pics.length){if(ROOT&&await rootPerm(true)){try{cm.Files=await savePicFiles(cur.ID,cm.Pics);cm.Pics=[];msg='Comment added. '+cm.Files.length+' photo'+(cm.Files.length>1?'s':'')+' saved in Issues/'+cur.ID}catch(e){msg='Comment added, but the photos could not be written to the folder. They stay in this browser only.'}}else msg='Comment added. Photos stay in this browser only until you connect the project folder.'}
DB.Comments.push(cm);cur.Updated=ds(0);DRAFT.pics=[];changed();route();toast(msg);
},
rmpic(el){DRAFT.pics.splice(+el.dataset.i,1);drawDraft()},
zoom(el){$('modal').innerHTML='<div class="modal" data-act="mbg"><img id="zimg" alt="Photo" style="max-width:100%;max-height:92vh;border-radius:8px"></div>';$('zimg').src=el.src},
copy(el){
const node=$(el.dataset.target),t=node.textContent;
const fallback=()=>{const r=document.createRange();r.selectNodeContents(node);const s=window.getSelection();s.removeAllRanges();s.addRange(r);toast('Selected. Press Ctrl+C to copy.')};
if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).then(()=>toast('Copied'),fallback);else fallback();
}
};
ACT.undo=()=>undoDo();
ACT.menu=el=>{const s=document.querySelector('.side'),o=s.classList.toggle('open');document.querySelectorAll('.mbtn[data-act=menu]').forEach(b=>b.setAttribute('aria-expanded',String(o)))};
Object.assign(ACT,CALACT,PORTACT,ENCLACT,LOGACT,HPACT,DCPACT,SRTACT,SHELLACT,CTACT,PHYSACT,STUFFACT,IMPACT,LCACT,PGACT,CLACT,DRSACT,LEACT,NEONACT,WSACT,PDACT,TDACT,SECACT,RDSACT,NICACT);
document.addEventListener('click',e=>{const el=e.target.closest('[data-act]');if(!el||/^avm(arr2?|from|to)$/.test(el.dataset.act))return;if(el.tagName==='A'&&el.getAttribute('href')==='#')e.preventDefault();const f=ACT[el.dataset.act];if(f)f(el,e)});
document.addEventListener('submit',e=>{if(e.target.id!=='frm')return;e.preventDefault();const sheet=e.target.dataset.sheet;const r=submitForm(e.target);if(r&&sheet==='Issues'&&r.ID){IS.sel=r.ID;route()}});
let QT=0;
document.addEventListener('input',e=>{if(e.target.name==='Cluster/Standalone'&&e.target.form&&e.target.form.id==='frm')srvStand(e.target.form);const el=e.target,a=el.dataset&&el.dataset.act;if(a==='dcpq'){dcpSearch(el);return}if(a==='pvq'){PV.q=el.value;const p=el.selectionStart;route();const n=document.querySelector('[data-act=pvq]');if(n){n.focus();try{n.setSelectionRange(p,p)}catch(x){}}}else if(a==='oiq'){OS.q=el.value;const l=$('oi-list');if(l)l.innerHTML=oiList()}else if(a==='bjq'){BJ.q=el.value;const l=$('bj-list');if(l)l.innerHTML=bjServerTable()}else if(a==='bjmq'){const q=el.value.toLowerCase();document.querySelectorAll('.bjrow').forEach(r=>{r.style.display=r.dataset.t.indexOf(q)>=0?'':'none'})}else if(a==='pbprev'){ptPreview()}else if(a==='pq'){PT.q=el.value;const l=$('pt-list');if(l)l.innerHTML=patchTable()}else if(a==='kbq'){KS.q=el.value;const l=$('kb-list');if(l)l.innerHTML=kbList()}else if(a==='q'){const sh=el.dataset.sheet;uiOf(sh).q=el.value;clearTimeout(QT);QT=setTimeout(()=>redrawTable(sh),DB[sh].length>400?220:30)}else if(a==='fval'||a==='fval2'){const s=el.dataset.sheet,f=uiOf(s).fl[+el.dataset.fi];if(f){f[a==='fval'?'v':'v2']=el.value;redrawTable(s)}}});
document.addEventListener('change',e=>{
const el=e.target;
if(el.dataset&&el.dataset.act==='devsel'){const o=el.dataset.v==='ports'?PV:DV;o[el.dataset.f]=el.dataset.f==='per'?+el.value:el.value;route();return}
if(el.name==='Quorum type'&&el.form&&el.form.id==='frm'){quorumUI(el.form);return}
if(el.dataset&&el.dataset.act==='pgsize'){PGACT.pgsize(el);return}
if(el.dataset&&/^avm(arr2?|from|to)$/.test(el.dataset.act)){DRSACT[el.dataset.act](el);return}
if(el.dataset&&el.dataset.act==='caljumpx'){calJump(el);return}
if(el.classList&&el.classList.contains('hpc')){hpSync(el);return}
if(impField(el)||mgPick(el)||relPick(el))return;
if(el.dataset&&el.dataset.act==='ctvis'){CTACT.ctvis(el);return}
if(el.dataset&&el.dataset.act==='srtf'){srtField(el);return}
if(el.dataset&&el.dataset.act==='dcpf'){dcpField(el);return}
if(el.dataset&&el.dataset.act==='irf'){const f=el.dataset.f;irSet(+el.dataset.i,f,el.type==='checkbox'?el.checked:el.value);if(typeof irRefresh==='function')irRefresh();if(f==='op'||(typeof IMP!=='undefined'&&IMP.step===3&&!IMP.done&&CUR==='import'))route();return}
if(el.dataset&&el.dataset.act==='dcpopt'){dcpOpt(el);return}
if(el.dataset&&el.dataset.act==='dcpprs'){dcpPrs(el);return}
if(el.dataset&&el.dataset.act==='dcpcolall'){dcpColAll(el);return}
if(el.dataset&&el.dataset.act==='pdprev'){ptdPrev();return}
if(el.name==='Blade'&&el.form&&el.form.id==='frm'){bladeSync(el.form);srvSync(el.form);return}
if(el.name==='Platform'&&el.form&&el.form.id==='frm'){srvSync(el.form);return}
if(/_sel$/.test(el.name||'')&&el.form&&el.form.id==='frm'&&((el.form.dataset.sheet==='ServerMI'&&CMB[el.name.replace(/_sel$/,'')])||LISTCMB[el.form.dataset.sheet+'.'+el.name.replace(/_sel$/,'')])){cmbSel(el);return}
if(el.id==='csv-sep'){META.csvSep=el.value;persist();return}
if(el.dataset&&el.dataset.act==='bscol'){bsRender(el.dataset.sheet);return}
if(el.id==='pl-dc'){$('pl-rack').innerHTML=dcRacks(el.value).map(x=>'<option>'+esc(x)+'</option>').join('');return}
if(el.id==='att-file'){const fl=Array.prototype.slice.call(el.files||[]);el.value='';if(fl.length)attPicked(fl);return}
if(el.id==='kb-file'){const fl=Array.prototype.slice.call(el.files||[]);el.value='';if(fl.length)kbAttach(fl);return}
if(el.id==='oi-file'){const fl=Array.prototype.slice.call(el.files||[]);el.value='';if(fl.length)oiAttach(fl);return}
if(el.id==='stuff-file'){const fl=Array.prototype.slice.call(el.files||[]);el.value='';if(fl.length)stuffAdd(fl);return}
const fa=el.dataset&&el.dataset.act;
if(fa==='oistatus'){const r=DB.OpenIssues.find(x=>x.ID===OS.sel);if(!r)return;r.Status=el.value;const dn=oiDone(r);r.Resolved=dn?(r.Resolved||ds(0)):'';r.Updated=ds(0);DB.OIComments.push({Issue:r.ID,Time:nowStr(),Author:'System',Type:'Update',Text:'Status changed to '+el.value});changed();route();if(dn&&!String(r.Resolution||'').trim())toast('Status set. Add a resolution so others can find the answer.');return}
if(fa==='bjjob'){BJ.job=el.value;route();return}
if(fa==='lnkchk'){setTick(el.dataset.n,el.checked);route();return}
if(fa==='fcol'){const s=el.dataset.sheet,u=uiOf(s),i=+el.dataset.fi;if(u.fl[i]){u.fl[i]=newFilter(s,el.value);route()}return}
if(fa==='fop'){const s=el.dataset.sheet,f=uiOf(s).fl[+el.dataset.fi];if(f){f.op=el.value;f.v=(f.op==='in'||f.op==='nin')?[]:'';f.v2='';route()}return}
if(fa==='fin'){const s=el.dataset.sheet,f=uiOf(s).fl[+el.dataset.fi],d=f?distinct(s,f.k)[+el.dataset.vi]:null;if(f&&d){if(!Array.isArray(f.v))f.v=[];const i=f.v.indexOf(d.v);if(el.checked&&i<0)f.v.push(d.v);if(!el.checked&&i>=0)f.v.splice(i,1);redrawTable(s);const sm=document.querySelector?document.querySelector('.fsum'):null}return}
if(el.id==='pl-dev'){const o=el.selectedOptions[0];if(o&&o.dataset.size)$('pl-size').value=o.dataset.size;return}
if(el.id==='cm-file'){const fs=Array.from(el.files);el.value='';addPics(fs);return}
if(el.dataset&&el.dataset.act==='isstatus'){const cur=DB.Issues.find(i=>i.ID===IS.sel);if(!cur)return;cur.Status=el.value;cur.Updated=ds(0);DB.Comments.push({Issue:cur.ID,Time:nowStr(),Author:'System',Text:'Status changed to '+el.value,Pics:[]});changed();route()}
});
document.addEventListener('paste',e=>{
if(e.target.id!=='cm-text')return;
const fs=[];const its=(e.clipboardData&&e.clipboardData.items)||[];
for(let i=0;i<its.length;i++){if(its[i].kind==='file'&&/^image\//.test(its[i].type))fs.push(its[i].getAsFile())}
if(fs.length){e.preventDefault();addPics(fs)}
});
document.addEventListener('keydown',e=>{
if(e.key==='Escape'&&$('modal').innerHTML){tryClose();return}
if(e.key==='Enter'&&e.target.tagName==='TR'&&e.target.dataset.act){e.preventDefault();e.target.click()}
});
let dragCol=null,dragSheet=null;
const thOf=e=>e.target&&e.target.closest?e.target.closest('th[data-col]'):null;
document.addEventListener('dragstart',e=>{const th=thOf(e);if(!th)return;dragCol=th.dataset.col;dragSheet=th.dataset.sheet;e.dataTransfer.setData('text/plain',dragCol);e.dataTransfer.effectAllowed='move'});
document.addEventListener('dragover',e=>{const th=thOf(e);if(th&&dragCol&&th.dataset.sheet===dragSheet){e.preventDefault();e.dataTransfer.dropEffect='move'}});
document.addEventListener('drop',e=>{const th=thOf(e);if(!th||!dragCol||th.dataset.sheet!==dragSheet)return;e.preventDefault();moveColTo(dragSheet,dragCol,th.dataset.col);dragCol=null});
document.addEventListener('dragend',()=>{dragCol=null});
window.addEventListener('hashchange',()=>{const s=document.querySelector('.side');if(s)s.classList.remove('open');route();window.scrollTo(0,0)});

/* ---------- boot ---------- */
loadState();applySchema();
window.addEventListener('beforeunload',e=>{if(dirty>0){e.preventDefault();e.returnValue=''}});
if(typeof indexedDB!=='undefined')recallHandle('root').then(h=>{if(h&&!ROOT&&typeof h.getDirectoryHandle==='function'){ROOT=h;rootPerm(false).then(ok=>{renderPending();if(ok)rootWire().then(()=>{autoLoadNewer();if(CUR==='sources'||CUR==='stuff'||CUR==='overview')route()}).catch(()=>{});else if(CUR==='sources')route()})}});
if(typeof indexedDB!=='undefined')recallHandle().then(h=>{if(h&&!handle&&typeof h.createWritable==='function'){handle=h;if(!META.fileName)META.fileName=h.name;if(CUR==='sources')route()}});
const fi=document.createElement('input');fi.type='file';fi.accept='.xlsx';fi.id='filein';fi.hidden=true;document.body.appendChild(fi);
fi.addEventListener('change',()=>{if(fi.files[0])importFile(fi.files[0],null);fi.value=''});
(function(){const root=document.documentElement;if(!root||!root.setAttribute)return;const mq=window.matchMedia?matchMedia('(prefers-color-scheme: dark)'):null;let mode='dark';
function apply(){const dark=mode==='dark'||(mode==='auto'&&mq&&mq.matches);if(dark)root.setAttribute('data-theme','dark');else root.removeAttribute('data-theme')}
try{mode=localStorage.getItem('infra-theme2')||'dark'}catch(e){}if(['light','dark','auto'].indexOf(mode)<0)mode='dark';
(document.querySelectorAll?document.querySelectorAll('input[name=theme]'):[]).forEach(r=>{r.checked=r.value===mode;r.addEventListener('change',()=>{if(!r.checked)return;mode=r.value;try{localStorage.setItem('infra-theme2',mode)}catch(e){}apply()})});
if(mq&&mq.addEventListener)mq.addEventListener('change',()=>{if(mode==='auto')apply()});apply()})();
SNAP=snap();baseSet();
route();
if(SEC.locked)secBoot();
})();
</script>
