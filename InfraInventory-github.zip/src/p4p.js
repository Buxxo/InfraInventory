/* ---------- Settings: sort & clean up sheet data, with consistency check and undo ---------- */
const SRT={sheet:'ServerMI',k1:'',d1:1,k2:'',d2:1,trim:false,empty:false},SUNDO={};
const sName=s=>(TV[s]&&TV[s].title)||s;
function sCols(s){return SCHEMA[s].cols.map(c=>c.k).filter(k=>k!=='Attachments'&&k.charAt(0)!=='@')}
function sCmp(k1,d1,k2,d2){const f=(a,b,k,d)=>{const x=String(a[k]==null?'':a[k]).trim(),y=String(b[k]==null?'':b[k]).trim();if(!x&&!y)return 0;if(!x)return 1;if(!y)return -1;return d*x.localeCompare(y,undefined,{numeric:true,sensitivity:'base'})};return (a,b)=>(k1?f(a,b,k1,d1):0)||(k2?f(a,b,k2,d2):0)}
function sSig(rows){return rows.map(r=>JSON.stringify(r)).sort()}
function sQual(){try{const o={};quality().forEach(q=>o[q.id]=q.count);return o}catch(e){return null}}
function sBlank(r){return Object.keys(r).every(k=>String(r[k]==null?'':r[k]).trim()==='')}
/* links between sheets: every cell token that equals a key value of another sheet, counted per source column and target sheet */
function sLinks(){const keys={};SHEETS.forEach(sh=>{const k=SCHEMA[sh].key;if(!k)return;DB[sh].forEach(r=>{const v=String(r[k]==null?'':r[k]).trim().toLowerCase();if(v.length>1){(keys[v]=keys[v]||new Set()).add(sh)}})});
const out={};SHEETS.forEach(sh=>{const cols=sCols(sh);DB[sh].forEach(r=>cols.forEach(c=>{const raw=r[c];if(raw==null||raw==='')return;String(raw).split(/[\n,;]+/).forEach(t=>{const v=t.trim().toLowerCase();const hit=v.length>1&&keys[v];if(hit)hit.forEach(tg=>{if(tg!==sh){const id=sName(sh)+' · '+c+' → '+sName(tg);out[id]=(out[id]||0)+1}})})}))});return out}
function sPages(){const o={},keep=CUR;Object.keys(VIEWDEF).forEach(id=>{try{CUR=id;o[id]=String(VIEWDEF[id]()).replace(/<[^>]*>/g,' ').replace(/[,;·|]/g,' ').split(/\s+/).filter(Boolean).sort().join(' ')}catch(e){o[id]=null}});CUR=keep;return o}
function sRun(commit){const s=SRT.sheet,objs=DB[s].slice(),vals=objs.map(o=>Object.assign({},o)),lk0=sLinks(),pg0=sPages(),q0=sQual();
let trimmed=0,dropped=0,list=objs.map((o,i)=>({o:o,i:i,v:Object.assign({},vals[i])}));
if(SRT.trim)list.forEach(x=>Object.keys(x.v).forEach(k=>{if(typeof x.v[k]==='string'&&x.v[k]!==x.v[k].trim()){x.v[k]=x.v[k].trim();trimmed++}}));
if(SRT.empty){const n=list.length;list=list.filter(x=>!sBlank(x.v));dropped=n-list.length}
if(SRT.k1||SRT.k2){const c=sCmp(SRT.k1,SRT.d1,SRT.k2,SRT.d2);list.sort((a,b)=>c(a.v,b.v)||a.i-b.i)}
const before=vals.map(v=>Object.assign({},v));
list.forEach(x=>{Object.keys(x.o).forEach(k=>delete x.o[k]);Object.assign(x.o,x.v)});DB[s].splice(0,DB[s].length,...list.map(x=>x.o));
const after=DB[s].map(r=>Object.assign({},r)),lk1=sLinks(),pg1=sPages(),q1=sQual(),pure=!trimmed&&!dropped,ck=[];
ck.push([before.length-dropped===after.length,'Row count: '+before.length+' before, '+after.length+' after'+(dropped?' ('+dropped+' empty rows removed)':'')]);
const tr=r=>{const o={};Object.keys(r).forEach(k=>o[k]=typeof r[k]==='string'&&SRT.trim?r[k].trim():r[k]);return o};
const exp=before.filter(r=>!(SRT.empty&&sBlank(tr(r)))).map(tr),same=JSON.stringify(sSig(exp))===JSON.stringify(sSig(after));
ck.push([same,same?'Every row is still present with identical content'+(trimmed?' ('+trimmed+' cells trimmed)':''):'Row content differs']);
const kk=a=>{const t=new Set();a.forEach(r=>Object.keys(r).forEach(k=>t.add(k)));return [...t].sort().join('|')};ck.push([kk(before)===kk(after),'Columns unchanged']);
const key=SCHEMA[s].key;if(key){const dup=l=>{const m={};let d=0;l.forEach(r=>{const v=String(r[key]||'').trim().toLowerCase();if(!v)return;if(m[v])d++;m[v]=1});return d};const d0=dup(before),d1=dup(after);ck.push([d1<=d0,'Duplicate '+key+' values: '+d0+' before, '+d1+' after'])}
const ids=Object.keys(Object.assign({},lk0,lk1)),badL=ids.filter(i=>pure?(lk0[i]||0)!==(lk1[i]||0):(lk1[i]||0)<(lk0[i]||0)),tot=ids.reduce((a,i)=>a+(lk0[i]||0),0);
ck.push([!badL.length,badL.length?'Links between sheets changed: '+badL.slice(0,4).join('; '):'Links between sheets intact: '+tot+' references across '+ids.length+' columns resolve exactly as before'+(pure?'':' (or better)')]);
const cntOf=t=>t===null?-1:t.split(' ').length,np=Object.keys(pg0).filter(i=>pg0[i]!==null).length,badP=Object.keys(pg0).filter(i=>pg0[i]!==null&&cntOf(pg0[i])!==cntOf(pg1[i])),difP=Object.keys(pg0).filter(i=>pg0[i]!==null&&pg0[i]!==pg1[i]);
ck.push([pure?!badP.length:true,pure?(badP.length?'Pages show different amounts of data: '+badP.slice(0,5).join(', '):'All '+np+' pages show the same data as before'+(difP.length?' ('+difP.length+' list the same items in a different order or cut-off)':'')):'Pages are re-rendered after clean-up ('+difP.length+' of '+np+' changed, expected for trim/remove)']);
if(q0&&q1){const bd=Object.keys(q0).filter(k=>q0[k]!==q1[k]);ck.push([pure?!bd.length:true,bd.length?'Data-quality results changed: '+bd.join(', ')+(pure?'':' (expected for clean-up)'):'Data-quality results unchanged'])}
const sample={old:before.slice(0,8),nw:after.slice(0,8)},ok=ck.every(c=>c[0]);
if(!(commit&&ok)){DB[s].splice(0,DB[s].length,...objs);objs.forEach((o,i)=>{Object.keys(o).forEach(k=>delete o[k]);Object.assign(o,vals[i])})}
else{SUNDO[s]={objs:objs,vals:vals};RK.sel=null;DPS.sel=null;closeForm()}
return {ck:ck,ok:ok,sample:sample}}
function sUndo(s){const u=SUNDO[s];if(!u)return;DB[s].splice(0,DB[s].length,...u.objs);u.objs.forEach((o,i)=>{Object.keys(o).forEach(k=>delete o[k]);Object.assign(o,u.vals[i])});delete SUNDO[s];RK.sel=null;DPS.sel=null}
function sortCard(){const s=SRT.sheet,cols=sCols(s),opt=(sel,all)=>(all?'<option value="">(none)</option>':'')+cols.map(c=>'<option'+(c===sel?' selected':'')+'>'+esc(c)+'</option>').join('');
if(cols.indexOf(SRT.k1)<0)SRT.k1='';if(cols.indexOf(SRT.k2)<0)SRT.k2='';
const dir=(k,d)=>'<select class="inp" data-act="srtf" data-f="'+k+'" aria-label="Direction"><option value="1"'+(d===1?' selected':'')+'>A → Z</option><option value="-1"'+(d===-1?' selected':'')+'>Z → A</option></select>';
return '<section class="card" style="margin-top:16px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><h2 style="margin:0">Sort &amp; clean up data</h2></div>'
+'<p class="note" style="margin:0 0 12px">Reorders the rows stored in a sheet (what you see first in the Excel file). Before anything is applied the dashboard does a trial run and checks that no row is lost or changed, the links between sheets (servers ↔ backup jobs, racks, hosts, ports …) resolve exactly as before, every page shows the same data and the data-quality results did not move. If a check fails nothing is changed. The last sort of each sheet can be undone until you reload.</p>'
+'<div class="fgrid"><label class="wide">Sheet<select class="inp" data-act="srtf" data-f="sheet">'+SHEETS.map(x=>'<option value="'+x+'"'+(x===s?' selected':'')+'>'+esc(sName(x))+' ('+DB[x].length+')</option>').join('')+'</select></label>'
+'<label>Sort by<select class="inp" data-act="srtf" data-f="k1">'+opt(SRT.k1,true)+'</select></label><label>Direction'+dir('d1',SRT.d1)+'</label>'
+'<label>Then by<select class="inp" data-act="srtf" data-f="k2">'+opt(SRT.k2,true)+'</select></label><label>Direction'+dir('d2',SRT.d2)+'</label></div>'
+'<label class="chkrow" style="margin-top:6px"><input type="checkbox" data-act="srtf" data-f="trim"'+(SRT.trim?' checked':'')+'> Trim leading and trailing spaces in all cells</label><label class="chkrow"><input type="checkbox" data-act="srtf" data-f="empty"'+(SRT.empty?' checked':'')+'> Remove rows that are completely empty</label>'
+'<div class="tools" style="margin-top:10px"><button class="btn p" data-act="srtprev">Check and preview</button>'+(SUNDO[s]?'<button class="btn" data-act="srtundo">Undo last sort of this sheet</button>':'')+'</div><div id="srt-out" style="margin-top:10px"></div>'+ucCard()+'</section>'}
function sPreview(){const s=SRT.sheet;if(!SRT.k1&&!SRT.k2&&!SRT.trim&&!SRT.empty){$('srt-out').innerHTML='<p class="note">Choose a column to sort by, or tick a clean-up option.</p>';return}
const r=sRun(false),show=SRT.k1||SRT.k2||'',kc=SCHEMA[s].key||sCols(s)[0],cs=[kc].concat(show&&show!==kc?[show]:[]);
const tbl=l=>'<table><tbody>'+l.map(x=>'<tr>'+cs.map(c=>'<td>'+esc(x[c])+'</td>').join('')+'</tr>').join('')+'</tbody></table>';
$('srt-out').innerHTML='<div>'+r.ck.map(c=>'<div>'+(c[0]?'<span class="badge b-ok">OK</span>':'<span class="badge b-bad">Failed</span>')+' '+esc(c[1])+'</div>').join('')+'</div>'
+'<div class="row" style="gap:16px;margin-top:8px;flex-wrap:wrap"><div class="tw" style="flex:1 1 220px"><b class="note">Now (first 8)</b>'+tbl(r.sample.old)+'</div><div class="tw" style="flex:1 1 220px"><b class="note">After (first 8)</b>'+tbl(r.sample.nw)+'</div></div>'
+'<div class="tools" style="margin-top:10px"><button class="btn p" data-act="srtgo"'+(r.ok?'':' disabled')+'>Apply to '+esc(sName(s))+'</button></div>'}
const SRTACT={
srtprev(){sPreview()},
srtgo(){const r=sRun(true);if(r.ok){changed();route();toast(sName(SRT.sheet)+': rows sorted and checked')}else{$('srt-out').insertAdjacentHTML('afterbegin','<div class="badge b-bad">A check failed, nothing was changed</div>')}},
srtundo(){if(!SUNDO[SRT.sheet])return;sUndo(SRT.sheet);changed();route();toast('Previous order restored')}};

/* ---------- unused (completely empty) columns: remove custom ones, hide built-in ones ---------- */
const UCF={core:false,sel:{}},UCUNDO=[];
let SRC_TXT=null;
function ucMentions(k){if(SRC_TXT==null){const sc=[...document.scripts].filter(x=>!x.src).map(x=>x.textContent).join('\n');SRC_TXT=sc}let n=0,i=-1;const q=["'"+k+"'",'"'+k+'"'];q.forEach(t=>{i=-1;while((i=SRC_TXT.indexOf(t,i+1))>=0)n++});return n}
function ucList(){const out=[];SHEETS.forEach(s=>{const S=SCHEMA[s];if(!DB[s].length)return;S.cols.forEach(c=>{if(c.hidden||c.att||c.computed||c.k===S.key||c.req)return;if(!c.custom&&!UCF.core)return;if(TV[s]&&TV[s].filter===c.k)return;if(DB[s].every(r=>String(r[c.k]==null?'':r[c.k]).trim()===''))out.push({s:s,k:c.k,custom:!!c.custom})})});return out}
function ucTrial(sel,commit){const lk0=sLinks(),pg0=sPages(),q0=sQual(),ck=[],snap=[];
const rowsSig=(s,k)=>JSON.stringify(DB[s].map(r=>{const o=Object.assign({},r);delete o[k];return o}));
const pre={};sel.forEach(x=>pre[x.s+'|'+x.k]=rowsSig(x.s,x.k));
const blank=sel.every(x=>DB[x.s].every(r=>String(r[x.k]==null?'':r[x.k]).trim()===''));
sel.forEach(x=>{const S=SCHEMA[x.s],c=S.cols.find(y=>y.k===x.k),t=TV[x.s];snap.push({s:x.s,k:x.k,c:c,idx:S.cols.indexOf(c),show:t?t.show.slice():null,had:DB[x.s].map(r=>x.k in r),ui:UI[x.s]?{sk:UI[x.s].sk,fl:UI[x.s].fl.slice()}:null,hid:!!c.hidden,req:c.req,reqWas:c.reqWas})});
const restore=()=>{snap.slice().reverse().forEach(z=>{const S=SCHEMA[z.s];if(S.cols.indexOf(z.c)<0)S.cols.splice(Math.min(z.idx,S.cols.length),0,z.c);if(z.hid)z.c.hidden=1;else delete z.c.hidden;if(z.req)z.c.req=z.req;else delete z.c.req;if(z.reqWas)z.c.reqWas=z.reqWas;else delete z.c.reqWas;if(TV[z.s]&&z.show)TV[z.s].show=z.show.slice();if(UI[z.s]&&z.ui){UI[z.s].sk=z.ui.sk;UI[z.s].fl=z.ui.fl}DB[z.s].forEach((r,i)=>{if(z.had[i]&&!(z.k in r))r[z.k]=''});});rebuildHead()};
ck.push([blank,blank?'All '+sel.length+' selected columns are empty in every row':'A selected column contains data. Nothing will be changed']);
if(blank){sel.forEach(x=>{const S=SCHEMA[x.s],c=S.cols.find(y=>y.k===x.k);
if(x.custom){S.cols=S.cols.filter(y=>y.k!==x.k);if(TV[x.s])TV[x.s].show=TV[x.s].show.filter(y=>y!==x.k);DB[x.s].forEach(r=>{delete r[x.k]})}
else{hideCol(x.s,c)}
if(UI[x.s]){if(UI[x.s].sk===x.k)UI[x.s].sk=TV[x.s]?TV[x.s].show[0]:null;UI[x.s].fl=UI[x.s].fl.filter(f=>f.k!==x.k)}});rebuildHead();
const rowsOk=sel.every(x=>pre[x.s+'|'+x.k]===rowsSig(x.s,x.k));ck.push([rowsOk,rowsOk?'All other data in those sheets is identical':'Other data changed']);
const hd=sel.every(x=>x.custom?HEAD[x.s].indexOf(x.k)<0:true)&&sel.every(x=>formCols(x.s).every(c=>c.k!==x.k));ck.push([hd,'Forms, tables and the Excel header no longer contain the column'+(sel.some(x=>!x.custom)?' (built-in ones are hidden, data and header kept)':'')]);
const lk1=sLinks(),ids=Object.keys(Object.assign({},lk0,lk1)),bad=ids.filter(i=>(lk0[i]||0)!==(lk1[i]||0));
ck.push([!bad.length,bad.length?'Links between sheets changed: '+bad.slice(0,3).join('; '):'Links between sheets intact: '+ids.reduce((a,i)=>a+(lk0[i]||0),0)+' references resolve exactly as before']);
const pg1=sPages(),words=new Set();sel.forEach(x=>{const c=snap.find(z=>z.s===x.s&&z.k===x.k).c;(String(x.k)+' '+(c.label||'')).split(/[\s,;·|]+/).forEach(w=>w&&words.add(w))});words.add('(custom)');
const cnt=t=>{const m={};(t||'').split(' ').forEach(w=>{if(w)m[w]=(m[w]||0)+1});return m};let badP=[];
Object.keys(pg0).forEach(id=>{if(pg0[id]===null||id==='settings')return;const stat=id==='quality'||id==='sources',num=w=>stat&&/^[\d.,%]+$/.test(w),a=cnt(pg0[id]),b=cnt(pg1[id]);let added=0,lost=0;Object.keys(b).forEach(w=>{if((b[w]||0)>(a[w]||0)&&!num(w))added++});Object.keys(a).forEach(w=>{if((a[w]||0)>(b[w]||0)&&!words.has(w)&&!num(w))lost++});if(added||lost){const ex=[];Object.keys(b).forEach(w=>{if((b[w]||0)>(a[w]||0)&&!num(w))ex.push('+'+w)});Object.keys(a).forEach(w=>{if((a[w]||0)>(b[w]||0)&&!words.has(w)&&!num(w))ex.push('-'+w)});badP.push(id+' ['+ex.slice(0,6).join(' ')+']')}});
ck.push([!badP.length,badP.length?'These pages lost something other than the column header: '+badP.slice(0,5).join(', '):'All pages show the same data, only the empty column is gone (counts of columns and completeness percentages on the Data quality and Data sources pages move, as expected)']);
const q1=sQual();if(q0&&q1){const bd=Object.keys(q0).filter(k=>q0[k]!==q1[k]);ck.push([!bd.length,bd.length?'Data-quality results changed: '+bd.join(', '):'Data-quality results unchanged'])}}
const ok=ck.every(c=>c[0]);
if(commit&&ok){UCUNDO.push(snap);saveSchemaMeta();return {ck:ck,ok:ok,snap:snap,commit:true}}
restore();return {ck:ck,ok:ok}}
function ucCard(){const L=ucList(),key=x=>x.s+'|'+x.k;
return '<div style="border-top:1px solid var(--line2);margin-top:18px;padding-top:14px"><h2 style="margin:0 0 6px;font-size:1.05em">Unused columns</h2><p class="note" style="margin:0 0 10px">Lists columns that are empty in every row. Custom columns you added are removed. Built-in columns are only hidden (data and Excel header are kept, you can restore them under Columns), because pages in the dashboard may read them. Key and required columns are never offered. Everything goes through the same trial run: links between sheets, all pages and data-quality results must stay identical.</p>'
+'<label class="chkrow"><input type="checkbox" data-act="ucopt"'+(UCF.core?' checked':'')+'> Also list built-in columns</label>'
+(L.length?'<div class="tw" style="margin-top:8px;max-height:320px"><table><thead><tr><th></th><th>Sheet</th><th>Column</th><th>Kind</th><th>Action</th></tr></thead><tbody>'+L.map(x=>'<tr><td><input type="checkbox" data-act="ucsel" data-k="'+esc(key(x))+'" aria-label="Select '+esc(x.k)+'"'+(UCF.sel[key(x)]?' checked':'')+'></td><td>'+esc(sName(x.s))+'</td><td><b>'+esc(x.k)+'</b></td><td>'+(x.custom?'<span class="badge b-info">custom</span>':'<span class="badge b-off">built-in · named '+ucMentions(x.k)+'× in the dashboard code</span>')+'</td><td>'+(x.custom?'Remove':'Hide')+'</td></tr>').join('')+'</tbody></table></div>'
+'<div class="tools" style="margin-top:10px"><button class="btn p" data-act="ucprev">Check selected columns</button>'+(UCUNDO.length?'<button class="btn" data-act="ucundo">Undo last removal</button>':'')+'</div>':'<p class="note" style="margin-top:8px">No empty columns found'+(UCF.core?'.':' among your custom columns. Tick the box above to include built-in columns.')+'</p>'+(UCUNDO.length?'<div class="tools"><button class="btn" data-act="ucundo">Undo last removal</button></div>':''))
+'<div id="uc-out" style="margin-top:10px"></div></div>'}
function ucSel(){const L=ucList();return L.filter(x=>UCF.sel[x.s+'|'+x.k])}
const UCACT={
ucopt(el){UCF.core=el.checked;const y=window.scrollY;route();window.scrollTo(0,y)},
ucsel(el){UCF.sel[el.dataset.k]=el.checked},
ucprev(){const sel=ucSel();if(!sel.length){$('uc-out').innerHTML='<p class="note">Tick the columns first.</p>';return}const r=ucTrial(sel,false);
$('uc-out').innerHTML=r.ck.map(c=>'<div>'+(c[0]?'<span class="badge b-ok">OK</span>':'<span class="badge b-bad">Failed</span>')+' '+esc(c[1])+'</div>').join('')+'<div class="tools" style="margin-top:10px"><button class="btn p" data-act="ucgo"'+(r.ok?'':' disabled')+'>Apply to '+sel.length+' column'+(sel.length===1?'':'s')+'</button></div>'},
ucgo(){const sel=ucSel(),r=ucTrial(sel,true);if(r.ok){UCF.sel={};changed();route();toast(sel.length+' column'+(sel.length===1?'':'s')+' removed or hidden, all checks passed')}else $('uc-out').insertAdjacentHTML('afterbegin','<div class="badge b-bad">A check failed, nothing was changed</div>')},
ucundo(){const snap=UCUNDO.pop();if(!snap)return;snap.slice().reverse().forEach(z=>{const S=SCHEMA[z.s];if(S.cols.indexOf(z.c)<0)S.cols.splice(Math.min(z.idx,S.cols.length),0,z.c);if(z.hid)z.c.hidden=1;else delete z.c.hidden;if(z.req)z.c.req=z.req;else delete z.c.req;if(z.reqWas)z.c.reqWas=z.reqWas;else delete z.c.reqWas;if(TV[z.s]&&z.show)TV[z.s].show=z.show.slice();DB[z.s].forEach((r,i)=>{if(z.had[i]&&!(z.k in r))r[z.k]=''})});rebuildHead();saveSchemaMeta();changed();route();toast('Columns restored')}};
Object.assign(SRTACT,UCACT);

function srtField(el){const f=el.dataset.f;if(f==='trim'||f==='empty')SRT[f]=el.checked;else if(f==='d1'||f==='d2')SRT[f]=parseInt(el.value);else SRT[f]=el.value;if(f==='sheet'){SRT.k1='';SRT.k2=''}const y=window.scrollY;route();window.scrollTo(0,y)}
