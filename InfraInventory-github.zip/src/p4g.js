
/* ---------- backup jobs: which server is under which job ---------- */
const BJ={f:'All',q:'',job:'All'};
function bjJobsOf(h){const ix=memo('bjAssign',()=>{const m=new Map();DB.BackupAssign.forEach(a=>{let l=m.get(a.Server);if(!l){l=[];m.set(a.Server,l)}l.push(a)});return m});return (ix.get(h)||[]).filter(a=>a.Server===h).map(a=>DB.BackupJobs.find(j=>j.Job===a.Job)||{Job:a.Job,Type:'?',missing:1})}
function bjInfo(r){
const js=bjJobsOf(r.Hostname),real=js.filter(j=>btCounts(j.Type)&&!j.missing);
const st=srvKind(r)==='Decommissioned'?'Decom':real.length?'Covered':js.some(j=>!j.missing&&!btCounts(j.Type))?'Exempt':'No job';
return{js:js,st:st,cloud:js.some(j=>!j.missing&&btCloud(j.Type))}}
const BJCLS={Covered:'b-ok','No job':'b-bad',Exempt:'b-off',Decom:'b-off'};
function bjBadge(j){return '<span class="badge '+(j.missing?'b-bad':btCloud(j.Type)?'b-info':!btCounts(j.Type)?'b-off':'b-ok')+'" title="'+esc(j.Type||'')+'">'+(btCloud(j.Type)?'☁ ':'')+esc(j.Job)+(j.Active==='No'?' (inactive)':'')+'</span>'}
function bjRows(){
let rows=DB.ServerMI.map((r,i)=>({r:r,i:i,b:bjInfo(r)}));
if(BJ.f==='No job')rows=rows.filter(x=>x.b.st==='No job');else if(BJ.f==='Covered')rows=rows.filter(x=>x.b.st==='Covered');else if(BJ.f==='Cloud')rows=rows.filter(x=>x.b.cloud);else if(BJ.f==='Exempt')rows=rows.filter(x=>x.b.st==='Exempt');
if(BJ.job!=='All')rows=rows.filter(x=>x.b.js.some(j=>j.Job===BJ.job));
if(BJ.q){const q=BJ.q.toLowerCase();rows=rows.filter(x=>['Hostname','IP','OS','Owner','Role'].some(k=>String(x.r[k]||'').toLowerCase().indexOf(q)>=0)||x.b.js.some(j=>String(j.Job).toLowerCase().indexOf(q)>=0))}
const o={'No job':0,Covered:1,Exempt:2,Decom:3};rows.sort((a,b)=>o[a.b.st]-o[b.b.st]||String(a.r.Hostname).localeCompare(String(b.r.Hostname)));return rows}
function bjServerTable(){
const rows=bjRows();if(!rows.length)return '<div class="empty">'+(DB.ServerMI.length?'No servers match this filter.':'No servers yet. Add them on the ServersMI tab, they appear here automatically.')+'</div>';
const O={'No job':0,Covered:1,Exempt:2,Decom:3};
return ctTable('bjservers',[
{k:'Server',v:x=>x.r.Hostname,h:x=>'<b>'+esc(x.r.Hostname)+'</b>',cls:'mono'},
{k:'Env',v:x=>x.r.Env,h:x=>cellHtml('Env',x.r)},
{k:'Platform',v:x=>x.r.Platform||'Virtual',h:x=>esc(x.r.Platform||'Virtual')},
{k:'Owner',v:x=>x.r.Owner,h:x=>esc(x.r.Owner)||'<span class="note">—</span>'},
{k:'Backup jobs',v:x=>x.b.js.map(j=>j.Job).join(', '),h:x=>'<div class="pillrow">'+(x.b.js.length?x.b.js.map(bjBadge).join(''):'<span class="note">none</span>')+'</div>',st:'white-space:normal'},
{k:'Status',v:x=>O[x.b.st],h:x=>'<span class="badge '+BJCLS[x.b.st]+'">'+x.b.st+'</span>'},
{k:'Note in ServersMI',v:x=>x.r.Backup,h:x=>'<span class="note">'+esc(x.r.Backup)+'</span>',st:'white-space:normal'},
{k:'',fix:1,h:x=>'<button class="btn s" data-act="bjasv" data-i="'+x.i+'">Assign jobs…</button>'}],rows)}
function bjJobsTable(){const rows=DB.BackupJobs.map((j,i)=>({j:j,i:i,n:DB.BackupAssign.filter(a=>a.Job===j.Job).length}));
return ctTable('bjjobs',[
{k:'Job',v:x=>x.j.Job,h:x=>'<b>'+esc(x.j.Job)+'</b>'},
{k:'Type',v:x=>x.j.Type,h:x=>'<span class="badge '+(btCloud(x.j.Type)?'b-info':!btCounts(x.j.Type)?'b-off':'b-ok')+'">'+(btCloud(x.j.Type)?'☁ ':'')+esc(x.j.Type)+'</span>'},
{k:'Level',v:x=>x.j['Backup level'],h:x=>esc(x.j['Backup level']||'')},
{k:'Software',v:x=>x.j.Software,h:x=>esc(x.j.Software)},
{k:'Target',v:x=>x.j.Target,h:x=>esc(x.j.Target)},
{k:'Catalyst store',v:x=>x.j['Catalyst store'],h:x=>esc(x.j['Catalyst store']||'')},
{k:'Schedule',v:x=>x.j.Schedule,h:x=>esc(x.j.Schedule)},
{k:'Retention',v:x=>x.j.Retention,h:x=>esc(x.j.Retention)},
{k:'Servers',v:x=>x.n,h:x=>'<a class="mono" href="#backupjobs" data-act="bjjobset" data-v="'+esc(x.j.Job)+'">'+x.n+'</a>'},
{k:'Status',v:x=>x.j.Active==='No'?1:0,h:x=>'<span class="badge '+(x.j.Active==='No'?'b-off':'b-ok')+'">'+(x.j.Active==='No'?'Inactive':'Active')+'</span>'},
{k:'',fix:1,h:x=>'<span style="white-space:nowrap"><button class="btn s" data-act="bjajob" data-i="'+x.i+'">Assign servers…</button> <button class="btn s" data-act="edit" data-sheet="BackupJobs" data-i="'+x.i+'">Edit</button></span>'}],rows)}
function bjView(){
const sv=DB.ServerMI.filter(r=>srvKind(r)!=='Decommissioned'),inf=sv.map(bjInfo),cov=inf.filter(b=>b.st==='Covered').length,none=inf.filter(b=>b.st==='No job').length,cl=inf.filter(b=>b.cloud).length,multi=inf.filter(b=>b.js.length>1).length;
const jobs=bjJobsTable();
const chips=['All','No job','Covered','Cloud','Exempt'].map(o=>'<button class="chip'+(BJ.f===o?' on':'')+'" data-act="bjf" data-v="'+o+'">'+o+'</button>').join('');
const jsel='<select class="inp" data-act="bjjob" aria-label="Filter by job" style="width:auto;max-width:260px"><option value="All">All jobs</option>'+DB.BackupJobs.map(j=>'<option'+(BJ.job===j.Job?' selected':'')+'>'+esc(j.Job)+'</option>').join('')+'</select>';
return head('Backup jobs','Which server is under which backup job. Define the jobs once, then assign servers to them. A server can be in several jobs, for example an on-site job and a cloud job.','<button class="btn" data-act="bjcsv">Export CSV</button><button class="btn p" data-act="saveXlsx">Save to Excel</button>')
+'<div class="kpis"><div class="kpi"><span>Servers with a backup job</span><b>'+(sv.length?Math.round(cov/sv.length*100)+'%':'—')+'</b><small class="'+(none?'w':'g')+'">'+cov+' of '+sv.length+' servers</small></div><div class="kpi"><span>Without a backup job</span><b>'+none+'</b><small class="'+(none?'b':'g')+'">'+(none?'assign a job or mark exempt':'all covered')+'</small></div><div class="kpi"><span>Also in a cloud job</span><b>'+cl+'</b><small>'+multi+' servers in more than one job</small></div><div class="kpi"><span>Backup jobs</span><b>'+DB.BackupJobs.length+'</b><small>'+DB.BackupJobs.filter(j=>j.Active==='No').length+' inactive</small></div></div>'
+'<section class="card"><div class="tools" style="justify-content:space-between;margin-bottom:8px"><h2 style="margin:0">Job specifications</h2><div class="tools">'+ctBtn('bjjobs')+'<button class="btn p" data-act="bjadd">+ Add job</button></div></div>'+(DB.BackupJobs.length?jobs:'<div class="empty">No jobs yet. Add each backup job once: name, type, target, schedule, retention. Categories (cloud, tape, exempt and so on) are managed in Settings.</div>')+'</section>'
+'<section class="card" style="padding:0"><div class="tools" style="padding:14px 16px;justify-content:space-between"><div class="chips">'+chips+'</div><div class="tools">'+ctBtn('bjservers')+jsel+'<input class="inp srch" type="search" data-act="bjq" value="'+esc(BJ.q)+'" placeholder="Search server, owner, job" aria-label="Search" style="max-width:260px"></div></div><div id="bj-list">'+bjServerTable()+'</div></section>'
+'<p class="note">The server list comes from the ServersMI tab. Assignments are saved in the sheet BackupAssign, job definitions in BackupJobs. Renaming a server or a job updates its assignments.</p>'}
function bjOpenModal(title,body,sub){
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="'+esc(title)+'" style="width:min(560px,100%)"><h2>'+esc(title)+'</h2>'+(sub?'<p class="note" style="margin:0">'+sub+'</p>':'')+body+'<div class="acts"><span></span><div class="tools"><button class="btn" data-act="mclose">Cancel</button><button class="btn p" data-act="bjsave">Save</button></div></div></div></div>'}
let BJM=null;
function openAssignServer(i){
const r=DB.ServerMI[i],mine=DB.BackupAssign.filter(a=>a.Server===r.Hostname).map(a=>a.Job);BJM={t:'s',h:r.Hostname};
if(!DB.BackupJobs.length){toast('Add a backup job first');return}
bjOpenModal('Backup jobs for '+r.Hostname,'<div class="vals" style="flex-direction:column;align-items:stretch;max-height:50vh;overflow:auto">'+DB.BackupJobs.map((j,k)=>'<label style="display:flex;gap:10px;align-items:flex-start;padding:6px 0"><input type="checkbox" class="bj-cb" value="'+esc(j.Job)+'"'+(mine.indexOf(j.Job)>=0?' checked':'')+'><span><b>'+esc(j.Job)+'</b> '+bjBadge(j).replace(/>[^<]*<\/span>$/,'>'+esc(j.Type)+'</span>')+'<span class="note" style="display:block">'+[j.Target,j.Schedule,j.Retention].filter(Boolean).map(esc).join(' · ')+'</span></span></label>').join('')+'</div>','Tick every job this server is part of. Choose “Exempt” if it needs no backup.')}
function openAssignJob(i){
const j=DB.BackupJobs[i],mine=DB.BackupAssign.filter(a=>a.Job===j.Job).map(a=>a.Server);BJM={t:'j',j:j.Job};
bjOpenModal('Servers in “'+j.Job+'”','<div class="tools" style="margin:8px 0"><input class="inp" id="bj-mq" type="search" data-act="bjmq" placeholder="Search servers" aria-label="Search servers" style="flex:1"><button class="btn s" data-act="bjmsel" data-v="1">Select shown</button><button class="btn s" data-act="bjmsel" data-v="0">Clear shown</button></div><div class="vals" id="bj-ml" style="flex-direction:column;align-items:stretch;max-height:46vh;overflow:auto">'+DB.ServerMI.map(r=>'<label class="bjrow" style="display:flex;gap:10px;padding:5px 0" data-t="'+esc((r.Hostname+' '+(r.Owner||'')+' '+(r.Env||'')+' '+(r.OS||'')).toLowerCase())+'"><input type="checkbox" class="bj-cb" value="'+esc(r.Hostname)+'"'+(mine.indexOf(r.Hostname)>=0?' checked':'')+'><span class="mono">'+esc(r.Hostname)+'</span><span class="note">'+esc(r.Env||'')+' · '+esc(r.OS||'')+'</span></label>').join('')+'</div>','Tick the servers that belong to this job.')}
function bjSave(){
if(!BJM)return;const on=Array.prototype.slice.call(document.querySelectorAll('.bj-cb')).filter(c=>c.checked).map(c=>c.value),off=Array.prototype.slice.call(document.querySelectorAll('.bj-cb')).filter(c=>!c.checked).map(c=>c.value);
if(BJM.t==='s'){DB.BackupAssign=DB.BackupAssign.filter(a=>a.Server!==BJM.h);on.forEach(j=>DB.BackupAssign.push({Server:BJM.h,Job:j,Notes:'',Updated:ds(0)}))}
else{DB.BackupAssign=DB.BackupAssign.filter(a=>!(a.Job===BJM.j&&(off.indexOf(a.Server)>=0)));on.forEach(h=>{if(!DB.BackupAssign.some(a=>a.Server===h&&a.Job===BJM.j))DB.BackupAssign.push({Server:h,Job:BJM.j,Notes:'',Updated:ds(0)})})}
BJM=null;closeForm();changed();route();toast('Backup assignments saved')}
async function bjCsv(){
const rows=bjRows(),sep=META.csvSep||';';if(!rows.length){toast('Nothing to export');return}
const q=v=>{let s=v==null?'':String(v);if(/^[=+@]/.test(s)||(/^-/.test(s)&&isNaN(Number(s))))s="'"+s;return(s.indexOf(sep)>=0||/["\n\r]/.test(s))?'"'+s.replace(/"/g,'""')+'"':s};
const lines=[['Server','Env','Platform','Owner','Status','Jobs','Job types'].map(q).join(sep)].concat(rows.map(x=>[x.r.Hostname,x.r.Env,x.r.Platform||'Virtual',x.r.Owner,x.b.st,x.b.js.map(j=>j.Job).join(' + '),x.b.js.map(j=>j.Type).join(' + ')].map(q).join(sep)));
const name='BackupJobs_'+ds(0)+'.csv',data='﻿'+lines.join('\r\n'),msg='Exported '+rows.length+' rows to '+name;
let dl=null;try{dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null}catch(e){dl=null}
if(dl){try{await dl.save({filename:name,data:data});toast(msg)}catch(e){if(!(e&&e.code==='declined'))toast('Export failed')}return}
try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'text/csv;charset=utf-8'}));a.download=name;document.body.appendChild(a);a.click();a.remove();toast(msg)}catch(e){toast('Download is not available in this view')}}
