/* ===== Array volumes (3PAR etc.): LUNs exported to ESXi hosts, used as RDM cluster drives, datastores or server disks ===== */
function naaKey(x){return String(x==null?'':x).toLowerCase().replace(/^naa\./,'').replace(/[^0-9a-f]/g,'')}
function avA(){return DB.ArrayVolumes||(DB.ArrayVolumes=[])}
function avIdx(){return memo('avIdx',avIdxRaw)}
function avIdxRaw(){const n=new Map(),l=new Map();avA().forEach((v,i)=>{const k=naaKey(v['NAA ID']);if(k&&!n.has(k))n.set(k,i);const lk=shortN(v.Array)+'|'+String(v['LUN ID']==null?'':v['LUN ID']).trim();if(String(v['LUN ID']||'').trim()&&!l.has(lk))l.set(lk,i)});return{n:n,l:l}}
function avFindIn(ix,arr,naa,lun){const k=naaKey(naa);if(k&&ix.n.has(k))return ix.n.get(k);const ls=String(lun==null?'':lun).trim();if(!k&&ls&&arr){const r=ix.l.get(shortN(arr)+'|'+ls);if(r!=null)return r}return -1}
function avFind(arr,naa,lun){const i=avFindIn(avIdx(),arr,naa,lun);if(i>=0){const v=avA()[i],k=naaKey(naa);if(!v||(k?naaKey(v['NAA ID'])!==k:String(v['LUN ID']==null?'':v['LUN ID']).trim()!==String(lun==null?'':lun).trim()))return avFindIn(avIdxRaw(),arr,naa,lun)}return i}
function srvShortIdx(){return memo('srvShort',()=>{const m=new Map();DB.ServerMI.forEach(x=>{const k=shortN(x.Hostname);if(!m.has(k))m.set(k,x)});return m})}
function srvCluster(name){const k=shortN(name);let s=srvShortIdx().get(k);if(s&&shortN(s.Hostname)!==k)s=DB.ServerMI.find(x=>shortN(x.Hostname)===k);return s&&s['Failover cluster']||''}
let AVC=null;
function avRepl(v){const g=v['Remote copy group']?rcgA().find(x=>x.Group===v['Remote copy group']):null;if(g){const me=shortN(v.Array),src=shortN(g['Source array']),tgt=shortN(g['Target array']),o=me===src?g['Target array']:me===tgt?g['Source array']:'';if(o)return{arr:String(o),lun:String(v['Replica LUN ID']||v['LUN ID']||'').trim(),name:String(v['Replica volume']||v.Volume),grp:g.Group}}return v.Replicated==='Yes'&&v['Replica array']?{arr:String(v['Replica array']),lun:String(v['Replica LUN ID']||v['LUN ID']||'').trim(),name:String(v['Replica volume']||v.Volume)}:null}
function avPartIdx(){return memo('avPart',()=>{const vol=new Map(),naa=new Map(),put=(m,k,i)=>{let a=m.get(k);if(!a){a=[];m.set(k,a)}a.push(i)};avA().forEach((x,i)=>{const a=shortN(x.Array);put(vol,a+'|'+shortN(x.Volume),i);const k=naaKey(x['NAA ID']);if(k)put(naa,a+'|'+k,i)});return{vol:vol,naa:naa}})}
function avPartner(v){const r=avRepl(v);if(!r)return -1;const nk=naaKey(v['NAA ID']),ix=avPartIdx(),a=shortN(r.arr),A=avA();let best=-1;const tryL=l=>{if(!l)return;for(const i of l){const x=A[i];if(!x||x===v)continue;if(shortN(x.Array)!==a)continue;if(shortN(x.Volume)===shortN(r.name)||(nk&&naaKey(x['NAA ID'])===nk)){if(best<0||i<best)best=i;break}}};tryL(ix.vol.get(a+'|'+shortN(r.name)));if(nk)tryL(ix.naa.get(a+'|'+nk));return best}
/* uses of every volume: Map(volume row) -> [{kind,label,sh,i,owner}] */
function avUsage(){if(AVC)return AVC;const ix=avIdx(),m=new Map();avA().forEach(v=>m.set(v,[]));const rev=new Map(),put=(i,u)=>{if(i>=0){m.get(avA()[i]).push(u);if(u.row)rev.set(u.row,avA()[i])}};m.rev=rev;
clA('ClusterDisks').forEach((r,i)=>{put(avFindIn(ix,r['Datastore / array'],r['NAA ID'],r['LUN ID']),{kind:'Cluster drive',label:r.Cluster+' · '+r.Disk,sh:'ClusterDisks',i:i,row:r,owner:'c:'+r.Cluster})});
clA('Clusters').forEach((c,i)=>{if(/RDM/.test(c['Quorum type']||''))put(avFindIn(ix,c['Witness datastore / array'],c['Witness NAA'],c['Witness LUN ID']),{kind:'Cluster witness',label:c.Cluster+' · witness',sh:'Clusters',i:i,owner:'c:'+c.Cluster})});
clA('ServerDisks').forEach((r,i)=>{if(!isRdm(r.Type)&&!/FC/.test(r.Type||''))return;const cl=srvCluster(r.Server);put(avFindIn(ix,r['Datastore / array'],r['NAA ID'],r['LUN ID']),{kind:'Server disk',label:r.Server+' · '+r.Disk,sh:'ServerDisks',i:i,row:r,owner:cl?'c:'+cl:'s:'+shortN(r.Server)})});
DB.Datastores.forEach((d,i)=>{let k=naaKey(d['Array NAA'])||naaKey(d['NAA ID']),j=k&&ix.n.has(k)?ix.n.get(k):-1;if(j<0&&d['Array volume']){const vn=shortN(d['Array volume']);j=avA().findIndex(v=>shortN(v.Volume)===vn&&(!d.Array||shortN(v.Array)===shortN(d.Array)))}put(j,{kind:'Datastore',label:d.Datastore,sh:'Datastores',i:i,row:d,owner:'d:'+d.Datastore})});
avA().forEach((p,pi)=>{if(!m.get(p).length)return;const j=avPartner(p);if(j>=0){const q=avA()[j];if(!m.get(q).length)m.get(q).push({kind:'Replica',label:'replica of '+p.Volume+' ('+p.Array+')',sh:'ArrayVolumes',i:pi,owner:'r:'+p.Volume})}});
AVC=m;setTimeout(()=>{AVC=null},0);return m}
function avUses(v){return avUsage().get(v)||[]}
function avUseText(v){let u=avUses(v);const co=u.filter(x=>x.kind!=='Server disk'&&x.owner.indexOf('c:')===0).map(x=>x.owner);u=u.filter(x=>!(x.kind==='Server disk'&&co.indexOf(x.owner)>=0));if(!u.length)return 'Unassigned';const g={};u.forEach(x=>{(g[x.kind]=g[x.kind]||[]).push(x.label)});return Object.keys(g).map(k=>k+': '+g[k].join(', ')).join(' · ')}
function avOwners(v){const o=[];avUses(v).forEach(x=>{if(x.kind==='Replica')return;if(o.indexOf(x.owner)<0)o.push(x.owner)});return o}
/* hosts: tokens of "Exported to" (host, "set:name", ESXi cluster) */
function avTokens(v){return String(v['Exported to']||'').split(/[\n,;]+/).map(t=>shortN(t.replace(/^\s*(set|host|hostset|cluster)\s*:/i,'').trim())).filter(Boolean)}
function avHostOk(v,host){const t=avTokens(v);if(!t.length)return true;const hn=shortN(host),h=memo('esxShort',()=>{const m=new Map();DB.ESXi.forEach(x=>{const k=shortN(x.Hostname);if(!m.has(k))m.set(k,x)});return m}).get(hn);return t.indexOf(hn)>=0||!!(h&&h.Cluster&&t.indexOf(shortN(h.Cluster))>=0)}
function avHosts(v){const t=avTokens(v);return DB.ESXi.map((h,i)=>({h:h,i:i})).filter(x=>t.indexOf(shortN(x.h.Hostname))>=0||(x.h.Cluster&&t.indexOf(shortN(x.h.Cluster))>=0))}
/* check one RDM / FC drive against the array volumes; servers = server names that must see the LUN */
function avCheckDisk(r,arr,label,servers){const o=[];if(!avA().length)return o;if(!isRdm(r.Type)&&!/FC/.test(r.Type||''))return o;
const naa=naaKey(r['NAA ID']),lun=String(r['LUN ID']==null?'':r['LUN ID']).trim();if(!naa&&!lun)return o;
const i=avFind(arr,r['NAA ID'],lun);
if(i<0){if(!arr||memo('avArrSet',()=>new Set(avA().map(v=>shortN(v.Array)))).has(shortN(arr)))o.push({sev:'medium',t:label+' (LUN '+(lun||naa)+') is not among the array volumes'+(arr?' of '+arr:'')});return o}
const v=avA()[i],a=num(r['Size GB']),b=num(v['Size GB']);
if(a>0&&b>0&&Math.abs(a-b)>Math.max(1,b*0.05))o.push({sev:'low',t:label+': size '+a+' GB differs from array volume '+v.Volume+' ('+b+' GB)'});
if(naa&&lun&&String(v['LUN ID']||'').trim()&&String(v['LUN ID']).trim()!==lun)o.push({sev:'low',t:label+': LUN ID '+lun+' differs from array volume '+v.Volume+' (LUN '+v['LUN ID']+')'});
const miss=[];(servers||[]).forEach(sn=>{let s=srvShortIdx().get(shortN(sn));if(s&&shortN(s.Hostname)!==shortN(sn))s=null;if(s&&s.Platform!=='Physical'&&s['ESXi host']&&!avHostOk(v,s['ESXi host']))miss.push(shortN(s['ESXi host']))});
if(miss.length)o.push({sev:'high',t:label+': volume '+v.Volume+' is not exported to ESXi host '+[...new Set(miss)].join(', ')+' (exported to: '+(v['Exported to']||'—')+')'});
return o}
function avClusterIssues(c,d){const o=[];
d.disks.forEach(x=>{avCheckDisk(x.r,x.r['Datastore / array'],'Drive '+x.r.Disk,d.nodes.map(n=>n.r.Node)).forEach(i=>o.push(i))});
if(/RDM/.test(c['Quorum type']||''))avCheckDisk({Type:'RDM - physical','NAA ID':c['Witness NAA'],'LUN ID':c['Witness LUN ID']},c['Witness datastore / array'],'Witness disk',d.nodes.map(n=>n.r.Node)).forEach(i=>o.push(i));
return o}
function avOtherIssues(){const o=[];
clA('ServerDisks').forEach(r=>{if(srvCluster(r.Server))return;avCheckDisk(r,r['Datastore / array'],r.Server+' · '+r.Disk,[r.Server]).forEach(i=>o.push(i.t))});
avA().forEach((v,vi)=>{const r=avRepl(v);if(!r)return;const known=memo('stoSet',()=>new Set(DB.Storage.map(a=>shortN(a.Array)))).has(shortN(r.arr));if(!known)o.push(v.Volume+' ('+v.Array+'): replica array '+r.arr+' is not in Storage');
const j=avPartner(v);if(j>=0){const q=avA()[j];if(avPartner(q)===vi&&String(v.Array)>String(q.Array))return;const a=String(q['LUN ID']||'').trim();if(r.lun&&a&&a!==r.lun)o.push(v.Volume+': LUN '+(v['LUN ID']||'?')+' on '+v.Array+' but LUN '+a+' on '+q.Array+' (replicas should use the same LUN)');const s1=num(v['Size GB']),s2=num(q['Size GB']);if(s1>0&&s2>0&&Math.abs(s1-s2)>Math.max(1,s1*0.02))o.push(v.Volume+': size '+s1+' GB on '+v.Array+' but '+s2+' GB on '+q.Array)}
else if(r.lun){const li=avIdx().l.get(shortN(r.arr)+'|'+r.lun),x=li!=null?avA()[li]:null;if(x)o.push(v.Volume+' ('+v.Array+'): its replica would use LUN '+r.lun+' on '+r.arr+', which volume '+x.Volume+' already has')}});
avA().forEach(v=>{const ow=avOwners(v);if(ow.length>1)o.push(v.Volume+' ('+v.Array+') is used by more than one owner: '+avUses(v).map(x=>x.kind+' '+x.label).join(', '))});
return o}
function avUnused(){return avA().filter(v=>!avUses(v).length)}
/* page extras */
function avKpis(d){const un=d.filter(v=>!avUses(v).length),rdm=d.filter(v=>avUses(v).some(x=>x.kind==='Cluster drive'||x.kind==='Cluster witness')),ds=d.filter(v=>avUses(v).some(x=>x.kind==='Datastore')),cf=d.filter(v=>avOwners(v).length>1);
return[{l:'Array volumes',v:d.length,s:r1(sum(d,'Size GB')/1024)+' TB'},{l:'Cluster RDM',v:rdm.length,s:'drives and witnesses'},{l:'Datastores',v:ds.length,s:'backing VMFS / NFS'},{l:'Not used by anything',v:un.length,s:un.length?'check if still needed':'all in use',c:un.length?'w':'g'},{l:'Used twice',v:cf.length,s:cf.length?'conflict':'no conflicts',c:cf.length?'b':'g'}]}
function avRel(sh,r,G,facts,name){
const volTile=(v,i)=>relTile('ArrayVolumes',i,v.Volume,[v.Array,v['Size GB']?v['Size GB']+' GB':'',v['LUN ID']?'LUN '+v['LUN ID']:''].filter(Boolean).join(' · '));
if(sh==='ArrayVolumes'){const ai=DB.Storage.findIndex(s=>shortN(s.Array)===shortN(r.Array));facts=[r.Array,r['Pool / CPG'],r['Size GB']?r['Size GB']+' GB':'',r['LUN ID']?'LUN '+r['LUN ID']:'',r.Provisioning,r['NAA ID']];
G.push(relGroup('Storage array',ai>=0?[relTile('Storage',ai,DB.Storage[ai].Array,[DB.Storage[ai].Model,DB.Storage[ai].DC].filter(Boolean).join(' · '))]:[],r.Array?esc(r.Array)+' is not in Storage':'No array'));
{const rp=avRepl(r),j=avPartner(r),rev=avA().map((x,i)=>({x:x,i:i})).filter(t=>t.x!==r&&avPartner(t.x)===REL.i);const tl=[];if(j>=0)tl.push(relTile('ArrayVolumes',j,avA()[j].Volume,[avA()[j].Array,'LUN '+(avA()[j]['LUN ID']||'?')].join(' · ')));rev.forEach(t=>{if(t.i!==j)tl.push(relTile('ArrayVolumes',t.i,t.x.Volume,'replicates to this volume · '+t.x.Array+' · LUN '+(t.x['LUN ID']||'?')))});if(rp&&j<0)tl.push('<div class="reltile static"><b>'+esc(rp.name)+'</b><span>on '+esc(rp.arr)+(rp.lun?' · LUN '+esc(rp.lun)+' (assumed same)':'')+' · no volume row yet</span></div>');G.push(relGroup('Replica',tl,'Not replicated'))}
const u=avUses(r);G.push(relGroup('Used by',u.map(x=>relTile(x.sh,x.i,x.label,x.kind)),'Not used by anything'));
const cls=[...new Set(u.filter(x=>x.owner.indexOf('c:')===0).map(x=>x.owner.slice(2)))];G.push(relGroup('Failover cluster',cls.map(n=>{const ci=clA('Clusters').findIndex(c=>c.Cluster===n);return ci>=0?relTile('Clusters',ci,n,clQuorum(clA('Clusters')[ci])):''}).filter(Boolean),'Not a cluster drive'));
const hs=avHosts(r);G.push(relGroup('Exported to ESXi hosts',hs.map(x=>relTile('ESXi',x.i,x.h.Hostname,x.h.Cluster||'')),r['Exported to']?'No ESXi host in the inventory matches “'+esc(r['Exported to'])+'”':'Export not recorded'));
const nodes=[];u.forEach(x=>{if(x.owner.indexOf('c:')===0)clA('ClusterNodes').forEach(n=>{if(n.Cluster===x.owner.slice(2)){const j=srvFind(n.Node);if(j>=0&&!nodes.some(t=>t.j===j))nodes.push({j:j,n:n})}})});
G.push(relGroup('Servers that see it (cluster nodes)',nodes.map(t=>relTile('ServerMI',t.j,t.n.Node,(t.n.Primary==='Yes'?'primary · ':'')+(DB.ServerMI[t.j]['ESXi host']||'')))));
const iss=[];if(u.length)u.forEach(x=>{if(x.sh==='ClusterDisks'){const cd=clA('ClusterDisks')[x.i];avCheckDisk(cd,cd['Datastore / array'],'This volume',clData(cd.Cluster).nodes.map(n=>n.r.Node)).forEach(t=>iss.push(t))}});
if(avOwners(r).length>1)iss.push({sev:'high',t:'Used by more than one owner'});G.push(relGroup('Checks',iss.map(i=>'<div class="reltile static"><b>'+esc(i.t)+'</b><span>'+i.sev+'</span></div>'),'All checks pass'))}
if(sh==='Storage'){const vs=avA().map((v,i)=>({v:v,i:i})).filter(x=>shortN(x.v.Array)===shortN(name));
if(vs.length){const un=vs.filter(x=>!avUses(x.v).length).length;facts=facts.concat([vs.length+' volumes'+(un?', '+un+' unused':'')]);G.push(relGroup('Volumes on this array',vs.slice(0,60).map(x=>relTile('ArrayVolumes',x.i,x.v.Volume,[x.v['Size GB']?x.v['Size GB']+' GB':'',x.v['LUN ID']?'LUN '+x.v['LUN ID']:'',avUses(x.v).length?avUses(x.v)[0].label:'unassigned'].filter(Boolean).join(' · '))).concat(vs.length>60?['<div class="reltile static"><b>+ '+(vs.length-60)+' more</b><span>open the Array volumes page</span></div>']:[])))}}
if(sh==='ESXi'){const vs=avA().map((v,i)=>({v:v,i:i})).filter(x=>avTokens(x.v).length&&avHostOk(x.v,name));if(vs.length)G.push(relGroup('Array volumes exported to this host',vs.slice(0,60).map(x=>volTile(x.v,x.i))))}
if(sh==='Datastores'){const vs=avA().map((v,i)=>({v:v,i:i})).filter(x=>avUses(x.v).some(u=>u.sh==='Datastores'&&u.i===REL.i));if(vs.length)G.push(relGroup('Array volume',vs.map(x=>volTile(x.v,x.i))))}
if(sh==='Clusters'||sh==='ServerMI'){const seen=[],add=(r2,arr)=>{const i=avFind(arr,r2['NAA ID'],r2['LUN ID']);if(i>=0&&seen.indexOf(i)<0)seen.push(i)};
if(sh==='Clusters'){clData(name).disks.forEach(x=>add(x.r,x.r['Datastore / array']));if(/RDM/.test(r['Quorum type']||''))add({'NAA ID':r['Witness NAA'],'LUN ID':r['Witness LUN ID']},r['Witness datastore / array'])}
else clA('ServerDisks').filter(x=>shortN(x.Server)===shortN(name)).forEach(x=>add(x,x['Datastore / array']));
if(avA().length)G.push(relGroup('Array volumes (LUNs)',seen.map(i=>volTile(avA()[i],i)),'None of the RDM / FC drives matches an array volume'))}
return facts}
/* ===== Datastore clusters (vSphere Storage DRS pods) ===== */
function dscA(){return DB.DatastoreClusters||(DB.DatastoreClusters=[])}
function dscMem(n){return DB.Datastores.map((d,i)=>({d:d,i:i})).filter(x=>String(x.d['Datastore cluster']||'')===String(n))}
function dscStats(c){const m=dscMem(c['Datastore cluster']),cap=sum(m.map(x=>x.d),'Capacity TB'),fr=sum(m.map(x=>x.d),'Free TB'),u=m.map(x=>num(x.d['Used %'])).filter(v=>!isNaN(v));
return{n:m.length,cap:cap,free:fr,used:cap>0?Math.round((cap-fr)/cap*100):0,spread:u.length>1?Math.max.apply(null,u)-Math.min.apply(null,u):0,min:u.length?Math.min.apply(null,u):0,max:u.length?Math.max.apply(null,u):0}}
function dscIssues(c){const o=[],add=(sev,t)=>o.push({sev:sev,t:t}),m=dscMem(c['Datastore cluster']),st=dscStats(c),th=num(c['Space threshold %'])||80;
if(!m.length){add('medium','No datastores in this datastore cluster');return o}
if(m.length===1)add('low','Only one datastore, nothing to balance');
const ty=[...new Set(m.map(x=>x.d.Type).filter(Boolean))];
if(ty.some(t=>/VMFS/.test(t))&&ty.some(t=>t==='NFS'))add('high','Mixes VMFS and NFS datastores ('+ty.join(', ')+'), which vSphere does not allow in one datastore cluster');
else if(ty.length>1)add('low','Mixed datastore types: '+ty.join(', '));
const vc=[...new Set(m.map(x=>x.d.vCenter).filter(Boolean))];if(vc.length>1)add('high','Members are in different vCenters: '+vc.join(', '));
if(c.vCenter&&vc.some(v=>shortN(v)!==shortN(c.vCenter)))add('medium','Some members are not in vCenter '+c.vCenter);
const cl=[...new Set(m.map(x=>x.d.Cluster).filter(Boolean))];if(cl.length>1)add('medium','Members are used by different ESXi clusters ('+cl.join(', ')+'): all hosts should see all members');
if(c.DC&&m.some(x=>x.d.DC&&x.d.DC!==c.DC))add('low','Some members are in another DC than '+c.DC);
m.forEach(x=>{if(num(x.d['Used %'])>=th)add('medium',x.d.Datastore+' is '+x.d['Used %']+'% used (threshold '+th+'%)')});
if(st.spread>25)add('low','Space is unbalanced: '+st.min+'% to '+st.max+'% used'+(c['SDRS automation']==='Fully automated'?' although SDRS is fully automated':''));
const rp=m.filter(x=>x.d.Replicated==='Yes').length;if(rp&&rp<m.length)add('low','Only '+rp+' of '+m.length+' members are replicated');
return o}
function dscAllIssues(){const o=[],names=dscA().map(c=>String(c['Datastore cluster']));dscA().forEach(c=>dscIssues(c).forEach(i=>o.push(c['Datastore cluster']+' · '+i.t)));
DB.Datastores.forEach(d=>{const n=d['Datastore cluster'];if(n&&names.indexOf(String(n))<0)o.push(d.Datastore+' is in datastore cluster '+n+', which is not defined on the Datastore clusters page')});return o}
function dscVal(c,r){const s=dscStats(r);return c==='@dsm'?s.n:c==='@dscap'?r1(s.cap)+' TB':c==='@dsfree'?r1(s.free)+' TB':c==='@dsused'?s.used+'%':c==='@dsspread'?(s.n>1?s.spread+' pts':'—'):c==='@dsiss'?dscIssues(r).length:''}
function dscRel(sh,r,G,facts,name){
if(sh==='DatastoreClusters'){const m=dscMem(name),st=dscStats(r);facts=[r.DC,r.vCenter,r['SDRS automation'],r['Space threshold %']?'threshold '+r['Space threshold %']+'%':'',st.n+' datastores',r1(st.cap)+' TB · '+st.used+'% used'];
G.push(relGroup('Datastores in this cluster',m.map(x=>relTile('Datastores',x.i,x.d.Datastore,[x.d.Type,x.d['Used %']!==''?x.d['Used %']+'% used':'',x.d.Array].filter(Boolean).join(' · '))),'No datastores assigned'));
const cls=[...new Set(m.map(x=>x.d.Cluster).filter(Boolean))],hs=DB.ESXi.map((h,i)=>({h:h,i:i})).filter(x=>cls.indexOf(x.h.Cluster)>=0);
G.push(relGroup('ESXi hosts that use it ('+cls.join(', ')+')',hs.map(x=>relTile('ESXi',x.i,x.h.Hostname,x.h.Cluster||'')),'No ESXi cluster recorded'));
const ar=[...new Set(m.map(x=>x.d.Array).filter(Boolean))];G.push(relGroup('Storage arrays',ar.map(a=>{const ai=DB.Storage.findIndex(s=>shortN(s.Array)===shortN(a));return ai>=0?relTile('Storage',ai,a,'Storage array'):'<div class="reltile static"><b>'+esc(a)+'</b></div>'}),'None'));
const vols=[];m.forEach(x=>avA().forEach((v,i)=>{if(avUses(v).some(u=>u.sh==='Datastores'&&u.i===x.i)&&!vols.some(t=>t.i===i))vols.push({v:v,i:i})}));if(avA().length)G.push(relGroup('Array volumes behind the members',vols.map(t=>relTile('ArrayVolumes',t.i,t.v.Volume,[t.v.Array,t.v['Size GB']?t.v['Size GB']+' GB':''].filter(Boolean).join(' · ')))));
G.push(relGroup('Datastore cluster checks',dscIssues(r).map(i=>'<div class="reltile static"><b>'+esc(i.t)+'</b><span>'+i.sev+'</span></div>'),'All checks pass'))}
if(sh==='Datastores'&&r['Datastore cluster']){const ci=dscA().findIndex(c=>String(c['Datastore cluster'])===String(r['Datastore cluster']));
G.push(relGroup('Datastore cluster',ci>=0?[relTile('DatastoreClusters',ci,r['Datastore cluster'],[dscA()[ci]['SDRS automation'],dscStats(dscA()[ci]).n+' datastores'].filter(Boolean).join(' · '))]:[],'Datastore cluster '+esc(r['Datastore cluster'])+' is not defined'));
G.push(relGroup('Other datastores in the cluster',dscMem(r['Datastore cluster']).filter(x=>x.d!==r).map(x=>relTile('Datastores',x.i,x.d.Datastore,(x.d['Used %']!==''?x.d['Used %']+'% used':'')))))}
return facts}
function dscCheck(sheet,b,idx){if(sheet==='DatastoreClusters'){const nm=String(b['Datastore cluster']||'').trim().toLowerCase();if(dscA().some((r,i)=>i!==idx&&String(r['Datastore cluster']).trim().toLowerCase()===nm))return 'A datastore cluster with this name already exists.'}return ''}
/* ===== DRS rules: VM-VM affinity / anti-affinity and VM-host rules (DRS moves VMs, rules say where they may run) ===== */
const DRST=['VMs together (affinity)','VMs separate (anti-affinity)','VMs must run on hosts','VMs should run on hosts','VMs must not run on hosts','VMs should not run on hosts'];
function drsA(){return DB.DrsRules||(DB.DrsRules=[])}
function drsK(t){t=String(t||'');return /together/.test(t)?'aff':/separate/.test(t)?'anti':/must not/.test(t)?'mustnot':/should not/.test(t)?'shouldnot':/must run/.test(t)?'must':/should run/.test(t)?'should':''}
function drsList(v){return String(v||'').split(/[;,\n]+/).map(x=>x.trim()).filter(Boolean)}
function drsVms(r){return drsList(r.VMs).map(n=>{const i=srvFind(n);return{n:n,i:i,s:i>=0?DB.ServerMI[i]:null}})}
function drsHost(s){return s&&s.Platform!=='Physical'&&s['ESXi host']?shortN(s['ESXi host']):''}
/* ===== DRS host groups: named sets of ESXi hosts; a VM-host rule uses one group (plus optional single hosts) ===== */
function dhgA(){return DB.DrsHostGroups||(DB.DrsHostGroups=[])}
function dhgFind(n){return dhgA().find(g=>String(g.Group)===String(n))}
function drsEff(r){const g=r['Host group']?dhgFind(r['Host group']):null,o=drsList(g?g.Hosts:'');drsList(r.Hosts).forEach(h=>{if(!o.some(x=>shortN(x)===shortN(h)))o.push(h)});return o}
function dhgRules(g){return drsA().filter(r=>r['Host group']===g.Group)}
function dhgOf(host){const k=shortN(host);return k?dhgA().filter(g=>drsList(g.Hosts).some(h=>shortN(h)===k)):[]}
function hgOf(s){const h=s&&s.Platform!=='Physical'&&s['ESXi host']?s['ESXi host']:'';return dhgOf(h).map(g=>g.Group)}
function dhgVms(g){const k=drsList(g.Hosts).map(shortN);return DB.ServerMI.map((s,i)=>({s:s,i:i})).filter(x=>x.s.Platform!=='Physical'&&x.s['ESXi host']&&k.indexOf(shortN(x.s['ESXi host']))>=0)}
function dhgIssues(g){const o=[],hs=drsList(g.Hosts);if(!hs.length)o.push({sev:'high',t:'Group has no hosts'});hs.forEach(h=>{const e=DB.ESXi.find(x=>shortN(x.Hostname)===shortN(h));if(!e)o.push({sev:'medium',t:'Host '+h+' is not in the ESXi hosts'});else if(g.Cluster&&e.Cluster&&e.Cluster!==g.Cluster)o.push({sev:'medium',t:'Host '+h+' is in cluster '+e.Cluster+', the group is for '+g.Cluster})});if(!dhgRules(g).length)o.push({sev:'low',t:'No rule uses this group'});return o}
function dhgRename(o,n){if(!o)return;dhgA().forEach(g=>{const l=drsList(g.Hosts);if(!l.some(x=>shortN(x)===shortN(o)))return;g.Hosts=l.map(x=>shortN(x)===shortN(o)?n:x).filter(Boolean).join('; ')})}
function drsOn(r){return r.Enabled!=='No'}
function drsIssues(r){const o=[],add=(sev,t,v)=>o.push({sev:sev,t:t,viol:!!v}),k=drsK(r.Type),vms=drsVms(r),hs=drsEff(r),hk=hs.map(shortN),vh=k==='aff'||k==='anti';
if(!k)add('high','Rule type not set');
if(r.Enabled==='No')add('low','Rule is disabled');
vms.forEach(x=>{if(!x.s)add('medium','VM '+x.n+' is not in ServersMI');else{if(x.s.Platform==='Physical')add('medium',x.n+' is a physical server');if(r.Cluster&&x.s.Cluster&&x.s.Cluster!==r.Cluster)add('medium',x.n+' is in cluster '+x.s.Cluster+', the rule is for '+r.Cluster)}});
if(vh){if(vms.length<2)add('medium','Needs at least two VMs');if(hs.length)add('low','Hosts are ignored by '+(k==='aff'?'affinity':'anti-affinity')+' rules')}
else{if(!vms.length)add('medium','No VMs in the rule');if(!hs.length)add('high','No hosts in the rule'+(r['Host group']?' (host group '+r['Host group']+' is empty or missing)':''));if(r['Host group']&&!dhgFind(r['Host group']))add('high','Host group '+r['Host group']+' does not exist');else if(r['Host group']&&r.Cluster&&dhgFind(r['Host group']).Cluster&&dhgFind(r['Host group']).Cluster!==r.Cluster)add('medium','Host group '+r['Host group']+' belongs to cluster '+dhgFind(r['Host group']).Cluster);
hs.forEach(h=>{const e=DB.ESXi.find(x=>shortN(x.Hostname)===shortN(h));if(!e)add('medium','Host '+h+' is not in the ESXi hosts');else if(r.Cluster&&e.Cluster&&e.Cluster!==r.Cluster)add('medium','Host '+h+' is in cluster '+e.Cluster+', the rule is for '+r.Cluster)});
if((k==='must'||k==='should')&&hs.length===1)add('low','Only one allowed host: no failover target')}
if(k==='anti'&&r.Cluster){const n=DB.ESXi.filter(h=>h.Cluster===r.Cluster).length;if(n&&vms.length>n)add('high',vms.length+' VMs must be apart but cluster '+r.Cluster+' has only '+n+' hosts')}
if(drsOn(r)){
if(k==='aff'){const p=vms.filter(x=>drsHost(x.s)),u=[...new Set(p.map(x=>drsHost(x.s)))];if(u.length>1)add('medium','Not together: '+p.map(x=>x.n+' on '+drsHost(x.s)).join(', '),1)}
if(k==='anti'){const m={};vms.forEach(x=>{const h=drsHost(x.s);if(h)(m[h]=m[h]||[]).push(x.n)});Object.keys(m).forEach(h=>{if(m[h].length>1)add('high',m[h].join(' and ')+' run on the same host '+h,1)})}
if(k==='must'||k==='should')vms.forEach(x=>{const h=drsHost(x.s);if(h&&hk.indexOf(h)<0)add(k==='must'?'high':'medium',x.n+' runs on '+h+', outside the allowed hosts',1)});
if(k==='mustnot'||k==='shouldnot')vms.forEach(x=>{const h=drsHost(x.s);if(h&&hk.indexOf(h)>=0)add(k==='mustnot'?'high':'medium',x.n+' runs on '+h+', which the rule excludes',1)})}
return o}
function drsStatus(r){if(r.Enabled==='No')return 'Disabled';const i=drsIssues(r);return i.some(x=>x.viol)?'Violated':i.length?'Check':'OK'}
function drsConflicts(){const o=[],P={aff:{},anti:{}};drsA().forEach(r=>{if(!drsOn(r))return;const k=drsK(r.Type);if(k!=='aff'&&k!=='anti')return;const v=drsList(r.VMs).map(shortN);for(let a=0;a<v.length;a++)for(let b=a+1;b<v.length;b++){const key=[v[a],v[b]].sort().join('|');(P[k][key]=P[k][key]||[]).push(r.Rule)}});
Object.keys(P.aff).forEach(k=>{if(P.anti[k])o.push(k.replace('|',' and ')+' are in affinity rule '+P.aff[k][0]+' and anti-affinity rule '+P.anti[k][0])});return o}
function drsAllIssues(){const o=[];drsA().forEach(r=>drsIssues(r).forEach(i=>o.push(r.Rule+' · '+i.t)));return o.concat(drsConflicts())}
function drsFor(name){const k=shortN(name);return drsA().map((r,i)=>({r:r,i:i})).filter(x=>drsList(x.r.VMs).some(v=>shortN(v)===k))}
function drsVal(c,r){return c==='@dvm'?drsList(r.VMs).length:c==='@dhost'?(drsEff(r).length||'—'):c==='@dst'?drsStatus(r):''}
function drsSrv(r){return drsFor(r.Hostname).filter(x=>drsOn(x.r)).map(x=>x.r.Rule).join('; ')}
/* WSFC nodes should be kept apart by an anti-affinity rule */
function drsNodeIssues(c,d){const o=[];if(!drsA().length)return o;const v=d.nodes.map(n=>clNodeInfo(n.r.Node)).filter(ni=>ni&&ni.s.Platform!=='Physical').map(ni=>shortN(ni.s.Hostname));if(v.length<2)return o;
const anti=drsA().filter(r=>drsOn(r)&&drsK(r.Type)==='anti').map(r=>drsList(r.VMs).map(shortN));
for(let a=0;a<v.length;a++)for(let b=a+1;b<v.length;b++)if(!anti.some(l=>l.indexOf(v[a])>=0&&l.indexOf(v[b])>=0))o.push({sev:'medium',t:'No DRS anti-affinity rule keeps '+v[a]+' and '+v[b]+' apart'});return o}
function drsVmTile(x,extra){return x.i>=0?relTile('ServerMI',x.i,x.n,[drsHost(x.s)?'on '+drsHost(x.s):'',extra].filter(Boolean).join(' · ')):'<div class="reltile static"><b>'+esc(x.n)+'</b><span>not in ServersMI</span></div>'}
function drsRel(sh,r,G,facts,name){
const ruleTile=x=>relTile('DrsRules',x.i,x.r.Rule,[x.r.Type,drsStatus(x.r)].filter(Boolean).join(' · '));
if(sh==='ServerMI'){{const gs=hgOf(r).map(n=>{const gi=dhgA().findIndex(g=>g.Group===n);return relTile('DrsHostGroups',gi,n,dhgA()[gi].Cluster||'')});G.push(relGroup('Runs in host group',gs,r.Platform==='Physical'?'Physical server':'Its host is in no host group'))}const f=drsFor(name),ad=(act)=>'<button class="btn s" data-act="drsadd" data-n="'+esc(r.Hostname)+'" style="margin-top:8px">+ Add DRS rule</button>';
G.push(relGroup('DRS rules (affinity / anti-affinity)',f.map(ruleTile),'No DRS rule mentions this VM').replace(/<\/section>$/,ad()+'</section>'));
const sn=shortN(name),apart=[],tog=[],on=[],off=[],gon=[],goff=[];f.forEach(x=>{if(!drsOn(x.r))return;const k=drsK(x.r.Type),oth=drsVms(x.r).filter(v=>shortN(v.n)!==sn);
if(k==='anti')oth.forEach(v=>{if(!apart.some(t=>t.n===v.n))apart.push(v)});if(k==='aff')oth.forEach(v=>{if(!tog.some(t=>t.n===v.n))tog.push(v)});
if(k==='must'||k==='should')drsList(x.r.Hosts).forEach(h=>{if(!on.some(t=>t.h===h))on.push({h:h,k:k,rule:x.r.Rule})});if(k==='must'||k==='should'||k==='mustnot'||k==='shouldnot'){const gg=x.r['Host group']?dhgFind(x.r['Host group']):null;if(gg){const L=/not/.test(k)?goff:gon;if(!L.some(t=>t.g===gg.Group))L.push({g:gg.Group,k:k,rule:x.r.Rule})}}if(k==='mustnot'||k==='shouldnot')drsList(x.r.Hosts).forEach(h=>{if(!off.some(t=>t.h===h))off.push({h:h,k:k,rule:x.r.Rule})})});
const myh=drsHost(r),hostTile=t=>{const hi=DB.ESXi.findIndex(e=>shortN(e.Hostname)===shortN(t.h));return hi>=0?relTile('ESXi',hi,t.h,(/^must/.test(t.k)?'must':'should')+' · '+t.rule):'<div class="reltile static"><b>'+esc(t.h)+'</b><span>'+t.rule+'</span></div>'};
if(f.length){G.push(relGroup('Must run apart from (anti-affinity)',apart.map(v=>drsVmTile(v,drsHost(v.s)&&drsHost(v.s)===myh?'SAME HOST':'')),'None'));
G.push(relGroup('Kept together with (affinity)',tog.map(v=>drsVmTile(v,drsHost(v.s)&&drsHost(v.s)!==myh?'different host':'')),'None'));
const gT=t=>{const gi=dhgA().findIndex(g=>g.Group===t.g);return relTile('DrsHostGroups',gi,t.g,(/^must/.test(t.k)?'must':'should')+' · '+t.rule)};G.push(relGroup('Allowed host groups (VM-host rules)',gon.map(gT).concat(on.length?[]:[]),'No host group restriction'));if(on.length)G.push(relGroup('Allowed single hosts (VM-host rules)',on.map(hostTile)));if(goff.length)G.push(relGroup('Host groups it must not / should not run in',goff.map(gT)));
if(off.length)G.push(relGroup('Hosts it must not / should not run on',off.map(hostTile)))}}
if(sh==='DrsHostGroups'){const iss=dhgIssues(r);facts=[r.Cluster,drsList(r.Hosts).length+' hosts',dhgRules(r).length+' rules'];
G.push(relGroup('Hosts in the group',drsList(r.Hosts).map(h=>{const hi=DB.ESXi.findIndex(e=>shortN(e.Hostname)===shortN(h));return hi>=0?relTile('ESXi',hi,h,DB.ESXi[hi].Cluster||''):'<div class="reltile static"><b>'+esc(h)+'</b><span>not in ESXi hosts</span></div>'}),'No hosts'));
G.push(relGroup('Rules using this group',dhgRules(r).map(x=>relTile('DrsRules',drsA().indexOf(x),x.Rule,[x.Type,drsStatus(x)].filter(Boolean).join(' · '))),'No rule uses it'));
G.push(relGroup('VMs running in this group now',dhgVms(r).slice(0,80).map(x=>relTile('ServerMI',x.i,x.s.Hostname,'')),'No VM'));
G.push(relGroup('Group checks',iss.map(i=>'<div class="reltile static"><b>'+esc(i.t)+'</b><span>'+i.sev+'</span></div>'),'All checks pass'))}
if(sh==='DrsRules'){const vms=drsVms(r),iss=drsIssues(r);facts=[r.Cluster,r.Type,r.Enabled==='No'?'Disabled':'Enabled',drsStatus(r)];
G.push(relGroup('VMs in the rule',vms.map(x=>drsVmTile(x,'')),'No VMs'));
{const gi=r['Host group']?dhgA().findIndex(g=>g.Group===r['Host group']):-1;G.push(relGroup('Host group',gi>=0?[relTile('DrsHostGroups',gi,r['Host group'],drsList(dhgA()[gi].Hosts).length+' hosts')]:[],r['Host group']?'Host group '+esc(r['Host group'])+' does not exist':'No host group'))}
G.push(relGroup('Hosts in the rule',drsEff(r).map(h=>{const hi=DB.ESXi.findIndex(e=>shortN(e.Hostname)===shortN(h));return hi>=0?relTile('ESXi',hi,h,DB.ESXi[hi].Cluster||''):'<div class="reltile static"><b>'+esc(h)+'</b><span>not in ESXi hosts</span></div>'}),drsK(r.Type)==='aff'||drsK(r.Type)==='anti'?'Not used by this rule type':'No hosts'));
const ci=r.Cluster?DB.ESXi.map((h,i)=>({h:h,i:i})).filter(x=>x.h.Cluster===r.Cluster):[];G.push(relGroup('Hosts of cluster '+esc(r.Cluster||'—'),ci.map(x=>relTile('ESXi',x.i,x.h.Hostname,x.h.Model||'')),'No cluster recorded'));
const wc=[];vms.forEach(x=>{if(x.s&&x.s['Failover cluster']){const k=clA('Clusters').findIndex(c=>c.Cluster===x.s['Failover cluster']);if(k>=0&&!wc.some(t=>t.k===k))wc.push({k:k})}});G.push(relGroup('Failover clusters involved',wc.map(t=>relTile('Clusters',t.k,clA('Clusters')[t.k].Cluster,clQuorum(clA('Clusters')[t.k])))));
G.push(relGroup('Rule checks',iss.map(i=>'<div class="reltile static"><b>'+esc(i.t)+'</b><span>'+i.sev+(i.viol?' · violated now':'')+'</span></div>'),'All checks pass'))}
if(sh==='ESXi'){const hk=shortN(name),f=drsA().map((x,i)=>({r:x,i:i})).filter(x=>drsEff(x.r).some(h=>shortN(h)===hk));G.push(relGroup('DRS host groups',dhgOf(name).map(g=>relTile('DrsHostGroups',dhgA().indexOf(g),g.Group,g.Cluster||'')),'In no host group'));
G.push(relGroup('DRS rules naming this host',f.map(ruleTile),'No VM-host rule names this host'));
const here=DB.ServerMI.map((s,i)=>({s:s,i:i})).filter(x=>drsHost(x.s)===hk&&drsFor(x.s.Hostname).some(y=>drsOn(y.r)));
G.push(relGroup('VMs here that have DRS rules',here.map(x=>relTile('ServerMI',x.i,x.s.Hostname,drsFor(x.s.Hostname).filter(y=>drsOn(y.r)).map(y=>y.r.Rule).join(', ')))))}
if(sh==='Clusters'){const nn=clData(name).nodes.map(n=>shortN(n.r.Node)),seen=[];nn.forEach(n=>drsFor(n).forEach(x=>{if(!seen.some(t=>t.i===x.i))seen.push(x)}));G.push(relGroup('DRS rules for the nodes',seen.map(ruleTile),'No DRS rule covers the nodes'))}
return facts}
function drsCheck(sheet,b,idx){if(sheet==='DrsHostGroups'){const nm=String(b.Group||'').trim().toLowerCase();if(dhgA().some((r,i)=>i!==idx&&String(r.Group).trim().toLowerCase()===nm))return 'A host group with this name already exists.';if(!drsList(b.Hosts).length)return 'Select at least one host.';return ''}if(sheet!=='DrsRules')return '';const nm=String(b.Rule||'').trim().toLowerCase();if(drsA().some((r,i)=>i!==idx&&String(r.Rule).trim().toLowerCase()===nm))return 'A DRS rule with this name already exists.';
const k=drsK(b.Type);if((k==='aff'||k==='anti')&&drsList(b.VMs).length<2)return 'Select at least two VMs.';if(k&&k!=='aff'&&k!=='anti'&&(!drsList(b.VMs).length||(!drsList(b.Hosts).length&&!b['Host group'])))return 'Select the VMs and a host group (or hosts) for a VM-host rule.';return ''}
function vmPick(c,v){const cur=drsList(v),vms=DB.ServerMI.filter(s=>s.Status!=='Decom'&&s.Platform!=='Physical').map(s=>({n:String(s.Hostname),cl:String(s.Cluster||'(no cluster)')}));
cur.forEach(n=>{if(!vms.some(h=>shortN(h.n)===shortN(n)))vms.push({n:n,cl:'Not in ServersMI'})});const cls=Array.from(new Set(vms.map(h=>h.cl))).sort();
return '<div class="wide hostpick"><span class="note">'+esc(c.label||c.k)+' (<span id="hp-n">'+cur.length+'</span> selected)</span><input type="hidden" name="'+esc(c.k)+'" value="'+esc(cur.join('; '))+'">'
+'<div class="hpbox">'+cls.map(cl=>'<div class="hpg"><div class="tools" style="gap:8px"><b>'+esc(cl)+'</b><button type="button" class="btn s" data-act="hpcl" data-cl="'+esc(cl)+'">Toggle all</button></div><div class="hpl">'+vms.filter(h=>h.cl===cl).map(h=>'<label class="chkrow"><input type="checkbox" class="hpc" data-cl="'+esc(cl)+'" value="'+esc(h.n)+'"'+(cur.some(x=>shortN(x)===shortN(h.n))?' checked':'')+'> '+esc(h.n)+'</label>').join('')+'</div></div>').join('')+'</div></div>'}
const DRSACT={drsadd(el){const n=el.dataset.n,i=srvFind(n),s=i>=0?DB.ServerMI[i]:{};openForm('DrsRules',null,{Cluster:s.Cluster||'',Type:DRST[1],VMs:n,Enabled:'Yes'})}};
function drsRename(field,o,n){if(!o)return;drsA().forEach(r=>{const l=drsList(r[field]);if(!l.some(x=>shortN(x)===shortN(o)))return;r[field]=l.map(x=>shortN(x)===shortN(o)?n:x).filter(Boolean).join('; ')})}
/* ===== clickable "Used by" + LUN map ===== */
function avUseHtml(v){let u=avUses(v);if(!u.length)return '<span class="badge b-warn">Unassigned</span>';
const co=u.filter(x=>x.kind!=='Server disk'&&x.owner.indexOf('c:')===0).map(x=>x.owner);u=u.filter(x=>!(x.kind==='Server disk'&&co.indexOf(x.owner)>=0));
return u.map(x=>{let h;if(x.sh==='ClusterDisks'||x.sh==='Clusters'){const cn=x.owner.slice(2);h='<a href="#" data-act="clgoto" data-n="'+esc(cn)+'" title="Open failover cluster">'+esc(cn)+'</a>'+(x.sh==='Clusters'?' · witness':' · '+esc(x.label.split(' · ').slice(1).join(' · ')))}
else if(x.kind==='Replica')h='<a href="#" data-act="relgo" data-sheet="ArrayVolumes" data-i="'+x.i+'">'+esc(x.label)+'</a>';
else if(x.sh==='Datastores')h='<a href="#" data-act="relgo" data-sheet="Datastores" data-i="'+x.i+'">'+esc(x.label)+'</a> · datastore';
else{const si=srvFind(x.label.split(' · ')[0]);h=si>=0?'<a href="#" data-act="relgo" data-sheet="ServerMI" data-i="'+si+'">'+esc(x.label)+'</a>':esc(x.label)}
return '<span class="badge b-ok" style="margin-right:4px">'+h+'</span>'}).join('')}
const AVM={arr:'',from:0,to:255};
function avLunNum(v){const s=String(v==null?'':v).trim();return /^\d+$/.test(s)?parseInt(s,10):-1}
function avRanges(free){const o=[];let a=null,p=null;free.forEach(n=>{if(a===null){a=p=n}else if(n===p+1)p=n;else{o.push(a===p?''+a:a+'–'+p);a=p=n}});if(a!==null)o.push(a===p?''+a:a+'–'+p);return o}
function avOcc(arr){const by={},add=(n,e)=>{(by[n]=by[n]||[]).push(e)};
avA().forEach((v,i)=>{if(shortN(v.Array)!==shortN(arr))return;const n=avLunNum(v['LUN ID']);if(n>=0)add(n,{kind:'real',v:v,i:i})});
avA().forEach((p,pi)=>{const r=avRepl(p);if(!r||shortN(r.arr)!==shortN(arr)||avPartner(p)>=0)return;const n=avLunNum(r.lun);if(n>=0)add(n,{kind:'replica',v:p,i:pi})});return by}
function lunMapView(){const arrs=[...new Set(DB.Storage.map(s=>String(s.Array)).concat(avA().map(v=>String(v.Array))).filter(Boolean))].sort();
if(!AVM.arr||arrs.indexOf(AVM.arr)<0)AVM.arr=arrs[0]||'';
if(AVM.arr2===undefined){const m={};avA().forEach(v=>{const r=avRepl(v);if(r&&shortN(v.Array)===shortN(AVM.arr))m[r.arr]=(m[r.arr]||0)+1;if(r&&shortN(r.arr)===shortN(AVM.arr))m[v.Array]=(m[v.Array]||0)+1});const k=Object.keys(m).sort((a,b)=>m[b]-m[a])[0];AVM.arr2=k&&arrs.indexOf(k)>=0?k:''}
if(AVM.arr2&&(arrs.indexOf(AVM.arr2)<0||shortN(AVM.arr2)===shortN(AVM.arr)))AVM.arr2='';
const from=Math.max(0,AVM.from|0),to=Math.min(16383,Math.max(from,AVM.to|0)),A=avOcc(AVM.arr),B=AVM.arr2?avOcc(AVM.arr2):{};
const noLun=avA().map((v,i)=>({v:v,i:i})).filter(x=>shortN(x.v.Array)===shortN(AVM.arr)&&avLunNum(x.v['LUN ID'])<0);
let nA=0,nRep=0,nB=0,dup=0;const free=[];let cells='';
for(let n=from;n<=to;n++){const a=A[n],b=B[n];
if(a){nA++;const real=a.filter(e=>e.kind==='real'),rep=a.filter(e=>e.kind==='replica'),first=a[0],title='LUN '+n+' · '+a.map(e=>e.kind==='real'?e.v.Volume:'replica of '+e.v.Volume+' ('+e.v.Array+')').join(', ');
if(!real.length){nRep++;cells+='<button class="pt spare" data-act="relgo" data-sheet="ArrayVolumes" data-i="'+first.i+'" title="'+esc(title+' · replica, no volume row on this array')+'"><i>'+n+'</i><small>↔ '+esc(first.v.Volume)+'</small></button>'}
else{const bad=a.length>1;if(bad)dup++;const use=avUses(real[0].v),cl=bad?'down':use.length?'conn':'resv';cells+='<button class="pt '+cl+'" data-act="relgo" data-sheet="ArrayVolumes" data-i="'+real[0].i+'" title="'+esc(title+' · '+(bad?'USED TWICE':avUseText(real[0].v)))+'"><i>'+n+'</i><small>'+esc(real[0].v.Volume)+'</small></button>'}}
else if(b){nB++;cells+='<button class="pt oth" data-act="relgo" data-sheet="ArrayVolumes" data-i="'+b[0].i+'" title="'+esc('LUN '+n+' is taken on '+AVM.arr2+': '+(b[0].kind==='real'?b[0].v.Volume:'replica of '+b[0].v.Volume))+'"><i>'+n+'</i><small>on '+esc(AVM.arr2)+'</small></button>'}
else{free.push(n);cells+='<button class="pt free" data-act="avlunadd" data-n="'+n+'" title="LUN '+n+' is free'+(AVM.arr2?' on both arrays':'')+': click to add a volume"><i>'+n+'</i></button>'}}
const opts=(sel,none)=>(none?'<option value="">'+none+'</option>':'')+arrs.map(a=>'<option'+(a===sel?' selected':'')+'>'+esc(a)+'</option>').join('');
const rg=avRanges(free);
return head('LUN map','Which LUN IDs of an array are taken and which are free. Replicated volumes keep the same LUN on the partner array, so pick the partner to see only LUNs that are free on both. · from the sheet “ArrayVolumes”','<button class="btn" data-act="goto" data-v="arrayvolumes">Array volumes (list)</button>')
+'<section class="card"><div class="tools" style="margin-bottom:12px"><label class="note">Array<select class="inp" data-act="avmarr" style="min-width:180px">'+opts(AVM.arr)+'</select></label><label class="note">Keep free on<select class="inp" data-act="avmarr2" style="min-width:180px">'+opts(AVM.arr2,'— only this array —')+'</select></label><label class="note">From LUN<input class="inp" type="number" min="0" max="16383" data-act="avmfrom" value="'+from+'" style="width:90px"></label><label class="note">To LUN<input class="inp" type="number" min="0" max="16383" data-act="avmto" value="'+to+'" style="width:90px"></label>'
+'<span class="tools" style="margin-left:auto"><span class="badge b-ok">'+nA+' taken on '+esc(AVM.arr)+(nRep?' ('+nRep+' replica only)':'')+'</span>'+(AVM.arr2?'<span class="badge b-info">'+nB+' more taken on '+esc(AVM.arr2)+'</span>':'')+'<span class="badge b-off">'+free.length+' free'+(AVM.arr2?' on both':'')+'</span>'+(dup?'<span class="badge b-bad">'+dup+' used twice</span>':'')+'</span></div>'
+(arrs.length?'<div class="pending ok" style="margin-bottom:12px"><span><b>Next free LUN'+(AVM.arr2?' on both arrays':'')+': '+(free.length?free[0]:'none in this range')+'</b>'+(free.length?' · free: '+esc(rg.slice(0,14).join(', '))+(rg.length>14?' …':''):'')+'</span></div>':'')
+(arrs.length?'<div class="pgrid dk" style="--n:16">'+cells+'</div>':'<div class="empty">No arrays yet. Add volumes on the Array volumes page.</div>')
+'<p class="note" style="margin:10px 0 0">Green = used by a cluster drive, datastore or server disk · amber = volume not used by anything · blue ↔ = replica of a volume on the other array (no row of its own) · red = LUN ID used twice · dashed = taken only on the other array · grey = free. A 3PAR sets LUN numbers per host export; the map uses the LUN ID recorded on each volume, so check the array before reusing one.</p></section>'
+(noLun.length?'<section class="card"><h2>Volumes without a LUN ID</h2><div class="reltiles">'+noLun.map(x=>relTile('ArrayVolumes',x.i,x.v.Volume,'no LUN ID')).join('')+'</div></section>':'')}
Object.assign(DRSACT,{clgoto(el){CLS.sel=el.dataset.n;closeForm();if(CUR==='clusters')route();else location.hash='#clusters';window.scrollTo(0,0)},
avlunadd(el){openForm('ArrayVolumes',null,Object.assign({Array:AVM.arr,'LUN ID':el.dataset.n},AVM.arr2?{Replicated:'Yes','Replica array':AVM.arr2}:{}))},avmarr2(el){AVM.arr2=el.value;route()},
avmarr(el){AVM.arr=el.value;AVM.arr2=undefined;route()},avmfrom(el){AVM.from=parseInt(el.value)||0;route()},avmto(el){AVM.to=parseInt(el.value)||255;route()}});
function avLunCheck(sheet,b,idx,form){if(sheet!=='ArrayVolumes')return '';const n=String(b['LUN ID']==null?'':b['LUN ID']).trim();if(!n)return '';
if(avA().some((v,i)=>i!==idx&&shortN(v.Array)===shortN(b.Array)&&String(v.Volume).toLowerCase()===String(b.Volume).toLowerCase()))return 'This array already has a volume with this name.';
const o=avA().find((v,i)=>i!==idx&&shortN(v.Array)===shortN(b.Array)&&String(v['LUN ID']).trim()===n);if(o&&form&&form.dataset.warned!=='1'){form.dataset.warned='1';return 'LUN ID '+n+' is already used by volume '+o.Volume+' on '+b.Array+'. Save again to keep it anyway.'}return ''}
/* ===== Remote copy groups (3PAR) ===== */
function rcgA(){return DB.RemoteCopyGroups||(DB.RemoteCopyGroups=[])}
function rcgEff(row){const v=avUsage().rev.get(row);return String((v&&v['Remote copy group'])||row['Remote copy group']||'')}
function rcgLink(n){const i=rcgA().findIndex(g=>g.Group===n);return i>=0?'<a href="#" data-act="relgo" data-sheet="RemoteCopyGroups" data-i="'+i+'">'+esc(n)+'</a>':'<span class="badge b-warn" title="Not defined on the Remote copy groups page">'+esc(n)+'</span>'}
function rcgMembers(g){const n=g.Group;return{vols:avA().map((v,i)=>({v:v,i:i})).filter(x=>x.v['Remote copy group']===n),ds:DB.Datastores.map((d,i)=>({d:d,i:i})).filter(x=>rcgEff(x.d)===n),dk:clA('ClusterDisks').map((r,i)=>({r:r,i:i})).filter(x=>rcgEff(x.r)===n)}}
function rcgIssues(g){const o=[],add=(sev,t)=>o.push({sev:sev,t:t}),m=rcgMembers(g),has=a=>DB.Storage.some(s=>shortN(s.Array)===shortN(a));
if(g['Source array']&&g['Target array']&&shortN(g['Source array'])===shortN(g['Target array']))add('high','Source and target array are the same');
[['Source array',g['Source array']],['Target array',g['Target array']]].forEach(x=>{if(x[1]&&!has(x[1]))add('medium',x[0]+' '+x[1]+' is not in Storage')});
if(g.Status&&g.Status!=='Started')add('medium','Group status is '+g.Status);
if(/periodic/i.test(g.Mode||'')&&!num(g['Sync period (min)']))add('low','Periodic mode without a sync period');
if(num(g['RPO target (min)'])&&num(g['Sync period (min)'])&&num(g['Sync period (min)'])>num(g['RPO target (min)']))add('medium','Sync period '+g['Sync period (min)']+' min is longer than the RPO target '+g['RPO target (min)']+' min');
if(!m.vols.length&&!m.ds.length&&!m.dk.length)add('low','No volumes, datastores or drives in this group');
m.vols.forEach(x=>{const a=shortN(x.v.Array);if(a!==shortN(g['Source array'])&&a!==shortN(g['Target array']))add('medium','Volume '+x.v.Volume+' is on '+x.v.Array+', not on an array of this group')});
return o}
function rcgVal(c,g){const m=rcgMembers(g);if(c==='@rcv')return m.vols.length;if(c==='@rcu'){const cl=[...new Set(m.dk.map(x=>x.r.Cluster))];return [m.ds.length?m.ds.length+' datastore'+(m.ds.length>1?'s':''):'',cl.length?cl.length+' cluster'+(cl.length>1?'s':''):''].filter(Boolean).join(' · ')||'—'}return rcgIssues(g).length}
function rcgClusterIssues(c,d){const o=[];if(!rcgA().length)return o;const gs=d.disks.filter(x=>isRdm(x.r.Type)||/FC/.test(x.r.Type||'')).map(x=>({n:x.r.Disk,g:rcgEff(x.r)}));if(!gs.length)return o;
gs.forEach(x=>{if(x.g&&!rcgA().some(g=>g.Group===x.g))o.push({sev:'medium',t:'Drive '+x.n+' is in remote copy group '+x.g+', which is not defined'})});
const u=[...new Set(gs.map(x=>x.g))];if(u.length>1)o.push({sev:'medium',t:'Drives are in different remote copy groups ('+u.map(x=>x||'none').join(', ')+'): they would not fail over together'});return o}
function rcgAllIssues(){const o=[];rcgA().forEach(g=>rcgIssues(g).forEach(i=>o.push(g.Group+' · '+i.t)));DB.Datastores.forEach(d=>{const n=rcgEff(d);if(n&&!rcgA().some(g=>g.Group===n))o.push(d.Datastore+' is in remote copy group '+n+', which is not defined')});
dscA().forEach(c=>{const g=[...new Set(dscMem(c['Datastore cluster']).map(x=>rcgEff(x.d)))];if(g.length>1&&rcgA().length)o.push(c['Datastore cluster']+' · members are in different remote copy groups ('+g.map(x=>x||'none').join(', ')+')')});return o}
function rcgCheck(sheet,b,idx){if(sheet!=='RemoteCopyGroups')return '';const nm=String(b.Group||'').trim().toLowerCase();if(rcgA().some((r,i)=>i!==idx&&String(r.Group).trim().toLowerCase()===nm))return 'A remote copy group with this name already exists.';if(shortN(b['Source array'])===shortN(b['Target array']))return 'Source and target array must differ.';return ''}
function rcgRel(sh,r,G,facts,name){const gt=n=>{const i=rcgA().findIndex(g=>g.Group===n);return i>=0?relTile('RemoteCopyGroups',i,n,[rcgA()[i]['Source array']+' → '+rcgA()[i]['Target array'],rcgA()[i].Mode].filter(Boolean).join(' · ')):'<div class="reltile static"><b>'+esc(n)+'</b><span>not defined</span></div>'};
if(sh==='RemoteCopyGroups'){const m=rcgMembers(r);facts=[r['Source array']+' → '+r['Target array'],r.Mode,r.Status,r['Sync period (min)']?'every '+r['Sync period (min)']+' min':'',r['RPO target (min)']!==''&&r['RPO target (min)']!=null?'RPO '+r['RPO target (min)']+' min':''];
G.push(relGroup('Storage arrays',[r['Source array'],r['Target array']].map((a,k)=>{const ai=DB.Storage.findIndex(s=>shortN(s.Array)===shortN(a));return ai>=0?relTile('Storage',ai,a,k?'target':'source'):'<div class="reltile static"><b>'+esc(a||'—')+'</b><span>'+(k?'target':'source')+', not in Storage</span></div>'})));
G.push(relGroup('Array volumes',m.vols.slice(0,60).map(x=>relTile('ArrayVolumes',x.i,x.v.Volume,[x.v.Array,x.v['LUN ID']?'LUN '+x.v['LUN ID']:'',x.v['Size GB']?x.v['Size GB']+' GB':''].filter(Boolean).join(' · '))),'No volumes point to this group'));
G.push(relGroup('Datastores',m.ds.map(x=>relTile('Datastores',x.i,x.d.Datastore,[x.d.Array,x.d['Used %']!==''?x.d['Used %']+'% used':''].filter(Boolean).join(' · '))),'None'));
const cl=[...new Set(m.dk.map(x=>x.r.Cluster))];G.push(relGroup('Failover clusters (RDM drives)',cl.map(n=>{const ci=clA('Clusters').findIndex(c=>c.Cluster===n);return ci>=0?relTile('Clusters',ci,n,m.dk.filter(x=>x.r.Cluster===n).map(x=>x.r.Disk).join(', ')):'<div class="reltile static"><b>'+esc(n)+'</b></div>'}),'None'));
G.push(relGroup('Group checks',rcgIssues(r).map(i=>'<div class="reltile static"><b>'+esc(i.t)+'</b><span>'+i.sev+'</span></div>'),'All checks pass'))}
if(sh==='ArrayVolumes'&&r['Remote copy group'])G.push(relGroup('Remote copy group',[gt(r['Remote copy group'])]));
if(sh==='Datastores'){const n=rcgEff(r);if(n)G.push(relGroup('Remote copy group',[gt(n)]))}
if(sh==='Clusters'){const gs=[...new Set(clData(name).disks.map(x=>rcgEff(x.r)).filter(Boolean))];if(gs.length||rcgA().length)G.push(relGroup('Remote copy groups of the drives',gs.map(gt),'No drive is in a group'))}
if(sh==='Storage'){const gs=rcgA().map((g,i)=>({g:g,i:i})).filter(x=>shortN(x.g['Source array'])===shortN(name)||shortN(x.g['Target array'])===shortN(name));if(gs.length)G.push(relGroup('Remote copy groups',gs.map(x=>relTile('RemoteCopyGroups',x.i,x.g.Group,(shortN(x.g['Source array'])===shortN(name)?'source → '+x.g['Target array']:'target ← '+x.g['Source array'])+' · '+(x.g.Mode||'')))))}
return facts}
/* ===== Server disks (VMDKs per VM) ===== */
function sdIdx(){return memo('sdIdx',()=>{const m=new Map();DB.ServerDisks.forEach((r,i)=>{const k=shortN(r.Server);let a=m.get(k);if(!a){a=[];m.set(k,a)}a.push({r:r,i:i})});return m})}
function sdRows(name){const k=shortN(name);return (sdIdx().get(k)||[]).filter(x=>DB.ServerDisks[x.i]===x.r&&shortN(x.r.Server)===k)}
function sdCount(r){return true}
/* Disk GB of a server = total of all its disks (VMDK, RDM, FC) */
function sdSyncAll(){const t=new Map();(DB.ServerDisks||[]).forEach(r=>{const k=shortN(r.Server);if(!k)return;t.set(k,(t.get(k)||0)+(num(r['Size GB'])||0))});let n=0;DB.ServerMI.forEach(r=>{const k=shortN(r.Hostname);if(!t.has(k))return;const v=Math.round(t.get(k)*100)/100;if(String(r['Disk GB'])!==String(v)){r['Disk GB']=v;r.Updated=ds(0);n++}});return n}
function sdTot(rows){return rows.reduce((s,x)=>s+(sdCount(x.r)?(num(x.r['Size GB'])||0):0),0)}
function sdVal(r){const a=sdRows(r.Hostname);return a.length?a.length+' · '+sdTot(a)+' GB':''}
function sdDiff(r){const a=sdRows(r.Hostname);if(!a.length||r['Disk GB']===''||r['Disk GB']==null)return null;const t=sdTot(a),g=num(r['Disk GB']);return Math.abs(t-g)>1?{t:t,g:g}:null}
function sdCell(r){const a=sdRows(r.Hostname);if(!a.length)return '<span class="note">—</span>';const d=sdDiff(r);return '<span class="badge '+(d?'b-warn':'b-info')+'" title="'+(d?'Disk total '+d.t+' GB (RDM and FC disks not counted), Disk GB '+d.g:'Disk total matches Disk GB')+'">'+a.length+'</span> '+sdTot(a)+' GB'}
function sdIssues(){const o=[];DB.ServerMI.forEach(r=>{const d=sdDiff(r);if(d)o.push(r.Hostname+': disks total '+d.t+' GB, Disk GB says '+d.g+' GB')});return o}
function sdBlock(sheet,row,isNew){if(sheet!=='ServerMI'||isNew)return '';const a=sdRows(row.Hostname),d=sdDiff(row);
return '<div class="card" style="background:var(--surface2);margin-top:12px;padding:12px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><b>Disks <span class="note">'+a.length+(a.length?' · '+sdTot(a)+' GB total, all disks incl. RDM':'')+'</span></b><span class="tools">'+(d?'<button type="button" class="btn s" data-act="sdsum" data-v="'+d.t+'">Use '+d.t+' GB as Disk GB</button>':'')+'<button type="button" class="btn s" data-act="sdadd2" data-n="'+esc(row.Hostname)+'">+ Add disk</button></span></div>'
+(a.length?'<div class="tw"><table style="width:100%"><thead><tr><th>Disk</th><th>Mount</th><th>GB</th><th>Type</th><th>Provisioning</th><th>Datastore</th></tr></thead><tbody>'+a.map(x=>'<tr><td><a href="#" data-act="sdopen" data-i="'+x.i+'"><b>'+esc(x.r.Disk)+'</b></a></td><td class="mono">'+esc(x.r['Drive / mount']||'')+'</td><td class="mono">'+esc(x.r['Size GB']||'')+'</td><td>'+esc(x.r.Type||'')+'</td><td>'+esc(x.r.Provisioning||'')+'</td><td>'+esc(x.r['Datastore / array']||'')+'</td></tr>').join('')+'</tbody></table></div>':'<p class="note" style="margin:0">No disks recorded for this server.</p>')+'</div>'}
function sdDirty(){const f=$('frm');if(f&&FSIG!==null&&fsig(f)!==FSIG){const e=$('ferr');if(e)e.textContent='Save the server first, then open or add its disks.';return true}return false}
Object.assign(DRSACT,{sdopen(el){if(sdDirty())return;openForm('ServerDisks',+el.dataset.i)},sdadd2(el){if(sdDirty())return;const a=sdRows(el.dataset.n),n=a.length;openForm('ServerDisks',null,{Server:el.dataset.n,Type:'VMDK',Disk:'Hard disk '+(n+1),Provisioning:'Thin'})},
sdsum(el){const f=$('frm');if(f&&f.elements['Disk GB'])f.elements['Disk GB'].value=el.dataset.v}});
/* ===== Motion layer: page transitions, count-up, ripple, theme cross-fade ===== */
(function(){
if(typeof MutationObserver==='undefined'||typeof requestAnimationFrame==='undefined')return;
try{
const RM=window.matchMedia&&window.matchMedia('(prefers-reduced-motion:reduce)').matches;
const view=document.getElementById('view');if(!view||RM)return;
let pend=true,raf=0,busy=false;const bar=document.createElement('div');bar.id='rtbar';document.body.appendChild(bar);
window.addEventListener('hashchange',()=>{pend=true;bar.classList.remove('go');void bar.offsetWidth;bar.classList.add('go')});
function countUp(el){const t=el.textContent.trim(),m=t.match(/^([^\d-]*)(-?[\d,]*\.?\d+)(.*)$/);if(!m||el.children.length)return;const raw=m[2],dec=(raw.split('.')[1]||'').length,comma=raw.indexOf(',')>=0,to=parseFloat(raw.replace(/,/g,''));if(!isFinite(to)||to===0)return;
const t0=performance.now(),dur=650+Math.min(500,to);const f=n=>{let s=n.toFixed(dec);if(comma)s=Number(s).toLocaleString('en-US',{minimumFractionDigits:dec,maximumFractionDigits:dec});return m[1]+s+m[3]};
(function step(now){const p=Math.min(1,(now-t0)/dur),e=1-Math.pow(1-p,3);el.textContent=p>=1?t:f(to*e);if(p<1)requestAnimationFrame(step)})(t0)}
function play(){busy=true;try{[...view.children].slice(0,12).forEach((c,i)=>{c.style.setProperty('--i',i);c.classList.remove('vin');void c.offsetWidth;c.classList.add('vin')});
view.querySelectorAll('tbody tr').forEach((r,i)=>{if(i<22){r.style.setProperty('--i',i);r.classList.add('rin')}});
view.querySelectorAll('.kpi b,.dcnum b,.ringbox b,.big').forEach(countUp)}finally{setTimeout(()=>{busy=false},60)}}
new MutationObserver(()=>{if(busy||!pend)return;cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>{if(!view.children.length)return;pend=false;play()})}).observe(view,{childList:true});
document.addEventListener('pointerdown',e=>{const b=e.target.closest&&e.target.closest('.btn,.chip');if(!b||b.disabled||b.querySelector('.pop,.menu'))return;const r=b.getBoundingClientRect(),d=Math.max(r.width,r.height)*2,s=document.createElement('span');s.className='rip';s.style.cssText='width:'+d+'px;height:'+d+'px;left:'+(e.clientX-r.left-d/2)+'px;top:'+(e.clientY-r.top-d/2)+'px';b.classList.add('rip-host');b.appendChild(s);setTimeout(()=>{s.remove()},650)},{passive:true});
new MutationObserver(()=>{const h=document.documentElement;h.classList.add('tt');clearTimeout(h._tt);h._tt=setTimeout(()=>h.classList.remove('tt'),450)}).observe(document.documentElement,{attributes:true,attributeFilter:['data-theme']});
}catch(e){}
})();
