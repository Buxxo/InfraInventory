/* ---------- Stuff → RDS Generator (Remote Desktop Connection Manager .rdg) ---------- */
let STT='files';
const RDS_KEY='infra-rds-v1';
const RDS=(()=>{let s=null;try{s=JSON.parse(localStorage.getItem(RDS_KEY)||'null')}catch(e){}
s=s||{};s.q=s.q||'';s.env=s.env||'';s.role=s.role||'';s.onlyOn=s.onlyOn!==false;s.sel=s.sel||{};s.acc=s.acc||[];s.envAcc=s.envAcc||{};s.grpAcc=s.grpAcc||{};s.prev=false;
s.p=Object.assign({name:'Servers',by:'fqdn',port:'',console:false,size:'client',depth:'24',clip:true,drives:false,printers:false,audio:'Client',nocert:true,expanded:false,comment:'role'},s.p||{});return s})();
function rdsSave(){try{const c=JSON.parse(JSON.stringify(RDS));delete c.prev;delete c.q;localStorage.setItem(RDS_KEY,JSON.stringify(c))}catch(e){}}
const rdsX=v=>String(v==null?'':v).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const rdsB=v=>v?'True':'False';
function rdsOn(r){return RDS.sel[r.Hostname]!==undefined?!!RDS.sel[r.Hostname]:String(r.Status||'')==='On'}
function rdsRows(){return (DB.ServerMI||[]).filter(r=>String(r.Hostname||'').trim())}
function rdsFiltered(){const q=RDS.q.trim().toLowerCase();return rdsRows().filter(r=>(!RDS.onlyOn||String(r.Status||'')!=='Decom'&&String(r.Status||'')!=='Off'||RDS.sel[r.Hostname])&&(!RDS.env||r.Env===RDS.env)&&(!RDS.role||String(r.Role||'')===RDS.role)&&(!q||[r.Hostname,r.FQDN,r.IP,r.Role,r.Env,r.Cluster,r.Owner].join(' ').toLowerCase().indexOf(q)>=0))}
function rdsAddr(r){const by=RDS.p.by;const f=String(r.FQDN||'').trim(),h=String(r.Hostname||'').trim(),ip=String(r.IP||'').split(/[,;\s]+/)[0]||'';return by==='ip'?(ip||f||h):by==='host'?(h||f):(f||h)}
function rdsGroups(){const ENVO=['PROD','TEST','DEV','DR'],m=new Map();rdsRows().filter(rdsOn).forEach(r=>{const e=String(r.Env||'').trim()||'No env',ro=String(r.Role||'').trim()||'No role';if(!m.has(e))m.set(e,new Map());const g=m.get(e);if(!g.has(ro))g.set(ro,[]);g.get(ro).push(r)});
return [...m.keys()].sort((a,b)=>{const i=ENVO.indexOf(a),j=ENVO.indexOf(b);return (i<0?99:i)-(j<0?99:j)||a.localeCompare(b)}).map(e=>({env:e,roles:[...m.get(e).keys()].sort((a,b)=>a.localeCompare(b)).map(ro=>({role:ro,rows:m.get(e).get(ro).sort((a,b)=>String(a.Hostname).localeCompare(String(b.Hostname)))}))}))}
function rdsAccOpts(sel,first){return '<option value="">'+first+'</option>'+RDS.acc.map(a=>'<option value="'+esc(a.id)+'"'+(a.id===sel?' selected':'')+'>'+esc(a.label||a.user||'(unnamed)')+'</option>').join('')}
function rdsListHtml(){const rows=rdsFiltered();
return '<div class="tw" style="max-height:340px;overflow:auto"><table><thead><tr><th style="width:36px"></th><th>Hostname</th><th>FQDN</th><th>IP</th><th>Env</th><th>Role</th><th>Status</th></tr></thead><tbody>'
+(rows.length?rows.map(r=>'<tr><td><input type="checkbox" data-rds="sel" data-h="'+esc(r.Hostname)+'"'+(rdsOn(r)?' checked':'')+' aria-label="Include '+esc(r.Hostname)+'" style="width:18px;height:18px"></td><td><b>'+esc(r.Hostname)+'</b></td><td class="mono">'+esc(r.FQDN)+'</td><td class="mono">'+esc(r.IP)+'</td><td>'+esc(r.Env)+'</td><td>'+esc(r.Role)+'</td><td>'+esc(r.Status)+'</td></tr>').join(''):'<tr><td colspan="7"><div class="empty">No servers match.</div></td></tr>')+'</tbody></table></div>'}
function rdsCountHtml(){const n=rdsRows().filter(rdsOn).length;return '<span class="note" style="margin:0"><b>'+n+'</b> of '+rdsRows().length+' servers selected</span>'}
function rdsGroupsHtml(){const G=rdsGroups();if(!G.length)return '<div class="empty">Select servers first.</div>';
return '<div class="tw"><table><thead><tr><th>Group</th><th>Servers</th><th>Log in with</th></tr></thead><tbody>'+G.map(g=>{const n=g.roles.reduce((a,x)=>a+x.rows.length,0);
return '<tr style="background:var(--surface2)"><td><b>'+esc(g.env)+'</b></td><td>'+n+'</td><td><select class="inp" data-rds="envacc" data-e="'+esc(g.env)+'" aria-label="Account for '+esc(g.env)+'">'+rdsAccOpts(RDS.envAcc[g.env]||'','No account (ask each time)')+'</select></td></tr>'
+g.roles.map(x=>'<tr><td style="padding-left:28px">'+esc(x.role)+'</td><td>'+x.rows.length+'</td><td><select class="inp" data-rds="grpacc" data-k="'+esc(g.env+'|'+x.role)+'" aria-label="Account for '+esc(g.env+' '+x.role)+'">'+rdsAccOpts(RDS.grpAcc[g.env+'|'+x.role]||'','Same as '+esc(g.env))+'</select></td></tr>').join('')}).join('')+'</tbody></table></div>'}
function rdsPropsHtml(){const p=RDS.p,ck=(k,l)=>'<label class="chk" style="display:flex;gap:8px;align-items:center;min-height:32px"><input type="checkbox" data-rds="p.'+k+'"'+(p[k]?' checked':'')+' style="width:18px;height:18px"> '+l+'</label>',op=(k,v,l)=>'<option value="'+v+'"'+(String(p[k])===v?' selected':'')+'>'+l+'</option>';
return '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px 18px">'
+'<label class="fl">Connect to<select class="inp" data-rds="p.by">'+op('by','fqdn','FQDN (falls back to hostname)')+op('by','host','Hostname')+op('by','ip','IP address')+'</select></label>'
+'<label class="fl">Port<input class="inp" data-rds="p.port" inputmode="numeric" placeholder="'+rdpPort()+' (Settings)" value="'+esc(p.port)+'"></label>'
+'<label class="fl">Screen<select class="inp" data-rds="p.size">'+op('size','client','Same size as client area')+op('size','full','Full screen')+'</select></label>'
+'<label class="fl">Colour depth<select class="inp" data-rds="p.depth">'+op('depth','16','16 bit')+op('depth','24','24 bit')+op('depth','32','32 bit')+'</select></label>'
+'<label class="fl">Sound<select class="inp" data-rds="p.audio">'+op('audio','Client','Play on this computer')+op('audio','Remote','Play on the server')+op('audio','NoAudio','Do not play')+'</select></label>'
+'<label class="fl">Comment of each server<select class="inp" data-rds="p.comment">'+op('comment','role','Role')+op('comment','owner','Owner')+op('comment','none','None')+'</select></label></div>'
+'<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:2px 18px;margin-top:8px">'+ck('console','Connect to the admin (console) session')+ck('clip','Share clipboard')+ck('drives','Share local drives')+ck('printers','Share printers')+ck('nocert','Do not warn about the server certificate')+ck('expanded','Groups open when the file loads')+'</div>'}
function rdsView(){const A=RDS.acc,roles=[...new Set(rdsRows().map(r=>String(r.Role||'').trim()).filter(Boolean))].sort();
const accRows=A.length?A.map(a=>'<tr><td><input class="inp" data-rds="acc.'+a.id+'.label" value="'+esc(a.label)+'" placeholder="e.g. Domain admin" aria-label="Account label"></td><td><input class="inp" data-rds="acc.'+a.id+'.domain" value="'+esc(a.domain)+'" placeholder="DOMAIN" aria-label="Domain"></td><td><input class="inp" data-rds="acc.'+a.id+'.user" value="'+esc(a.user)+'" placeholder="user name" aria-label="User name" autocomplete="off"></td><td><button class="btn s d" data-act="rdsaccdel" data-id="'+esc(a.id)+'">Remove</button></td></tr>').join(''):'<tr><td colspan="4"><div class="empty">No accounts yet. Add the logins you use.</div></td></tr>';
return '<section class="card"><div class="tools" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">1. Servers</h2><div class="tools" id="rds-count">'+rdsCountHtml()+'</div></div>'
+'<div class="tools" style="margin-bottom:10px"><div class="srch"><input data-rds="q" id="rds-q" placeholder="Search servers…" value="'+esc(RDS.q)+'" aria-label="Search servers"></div>'
+'<select class="inp" data-rds="env" style="width:auto" aria-label="Environment"><option value="">All environments</option>'+['PROD','TEST','DEV','DR'].map(e=>'<option'+(RDS.env===e?' selected':'')+'>'+e+'</option>').join('')+'</select>'
+'<select class="inp" data-rds="role" style="width:auto;max-width:240px" aria-label="Role"><option value="">All roles</option>'+roles.map(e=>'<option'+(RDS.role===e?' selected':'')+'>'+esc(e)+'</option>').join('')+'</select>'
+'<label class="chk" style="display:flex;gap:6px;align-items:center"><input type="checkbox" data-rds="onlyOn"'+(RDS.onlyOn?' checked':'')+' style="width:18px;height:18px"> Hide Off / Decom</label>'
+'<button class="btn" data-act="rdsselvis">Select shown</button><button class="btn" data-act="rdsclrvis">Clear shown</button></div>'
+'<div id="rds-list">'+rdsListHtml()+'</div><p class="note" style="margin:8px 0 0">Servers with Status On are ticked at first. The list comes from the ServersMI sheet.</p></section>'
+'<section class="card"><div class="tools" style="justify-content:space-between;margin-bottom:10px"><h2 style="margin:0">2. Accounts and groups</h2><button class="btn p" data-act="rdsaccadd">+ Add account</button></div>'
+'<div class="tw"><table><thead><tr><th>Label</th><th>Domain</th><th>User name</th><th></th></tr></thead><tbody>'+accRows+'</tbody></table></div>'
+'<p class="note" style="margin:8px 0 12px">Servers are grouped by Env, then by Role. Choose the account for each group. A role set to “Same as …” uses the account of its environment. <b>Passwords are not written</b> into the file (Remote Desktop Connection Manager encrypts them with your Windows login, which cannot be done here): it asks once at the first connection and can remember it.</p>'
+'<div id="rds-groups">'+rdsGroupsHtml()+'</div></section>'
+'<section class="card"><h2 style="margin:0 0 10px">3. Connection properties</h2>'+rdsPropsHtml()+'</section>'
+'<section class="card"><h2 style="margin:0 0 10px">4. Generate</h2><div class="tools"><label class="fl" style="min-width:240px">File name<input class="inp" data-rds="p.name" value="'+esc(RDS.p.name)+'" aria-label="File name"></label>'
+'<button class="btn p" data-act="rdsgen" style="align-self:flex-end">Generate .rdg</button><button class="btn" data-act="rdsprev" style="align-self:flex-end">'+(RDS.prev?'Hide':'Show')+' XML</button></div>'
+'<p class="note" style="margin:10px 0 0">'+(STDIR?'The file is saved into the Stuff folder and appears in Files. ':'The file is downloaded (connect the project folder to save it into Stuff directly). ')+'Open it with Remote Desktop Connection Manager (File → Open). Generating again with the same name replaces the file.</p>'
+(RDS.prev?'<pre class="mono" style="max-height:360px;overflow:auto;margin:12px 0 0;white-space:pre">'+esc(rdsXml())+'</pre>':'')+'</section>'}
function rdsAccOf(id){return RDS.acc.find(a=>a.id===id)}
function rdsLogon(id){const a=rdsAccOf(id);if(!a||!String(a.user||'').trim())return '';return '<logonCredentials inherit="None"><profileName scope="Local">Custom</profileName><userName>'+rdsX(String(a.user).trim())+'</userName><password /><domain>'+rdsX(String(a.domain||'').trim())+'</domain></logonCredentials>'}
function rdsXml(){const p=RDS.p,port=parseInt(p.port)>0?parseInt(p.port):rdpPort(),G=rdsGroups(),nm=String(p.name||'Servers').replace(/\.rdg$/i,'')||'Servers';
let x='<?xml version="1.0" encoding="utf-8"?>\n<RDCMan programVersion="2.7" schemaVersion="3">\n  <file>\n    <credentialsProfiles />\n    <properties><expanded>True</expanded><name>'+rdsX(nm)+'</name></properties>\n'
+'    <connectionSettings inherit="None"><connectToConsole>'+rdsB(p.console)+'</connectToConsole><startProgram /><workingDir /><port>'+port+'</port><loadBalanceInfo /></connectionSettings>\n'
+'    <remoteDesktop inherit="None"><sameSizeAsClientArea>'+rdsB(p.size!=='full')+'</sameSizeAsClientArea><fullScreen>'+rdsB(p.size==='full')+'</fullScreen><colorDepth>'+rdsX(p.depth)+'</colorDepth></remoteDesktop>\n'
+'    <localResources inherit="None"><audioRedirection>'+rdsX(p.audio)+'</audioRedirection><audioRedirectionQuality>Dynamic</audioRedirectionQuality><keyboardHook>FullScreenClient</keyboardHook><redirectClipboard>'+rdsB(p.clip)+'</redirectClipboard><redirectDrives>'+rdsB(p.drives)+'</redirectDrives><redirectPrinters>'+rdsB(p.printers)+'</redirectPrinters><redirectPorts>False</redirectPorts><redirectSmartCards>False</redirectSmartCards><redirectPnpDevices>False</redirectPnpDevices></localResources>\n'
+(p.nocert?'    <securitySettings inherit="None"><authentication>0</authentication></securitySettings>\n':'');
G.forEach(g=>{x+='    <group>\n      <properties><expanded>'+rdsB(p.expanded)+'</expanded><name>'+rdsX(g.env)+'</name></properties>\n'+(RDS.envAcc[g.env]?'      '+rdsLogon(RDS.envAcc[g.env])+'\n':'');
g.roles.forEach(r=>{const own=RDS.grpAcc[g.env+'|'+r.role];x+='      <group>\n        <properties><expanded>'+rdsB(p.expanded)+'</expanded><name>'+rdsX(r.role)+'</name></properties>\n'+(own?'        '+rdsLogon(own)+'\n':'');
r.rows.forEach(s=>{const cm=p.comment==='role'?String(s.Role||''):p.comment==='owner'?String(s.Owner||''):'';x+='        <server>\n          <properties><displayName>'+rdsX(s.Hostname)+'</displayName><name>'+rdsX(rdsAddr(s))+'</name>'+(cm?'<comment>'+rdsX(cm)+'</comment>':'')+'</properties>\n        </server>\n'});
x+='      </group>\n'});x+='    </group>\n'});
return x+'  </file>\n  <connected />\n  <favorites />\n  <recentlyUsed />\n</RDCMan>\n'}
function rdsTabs(){const t=(id,l)=>'<button class="chip'+(STT===id?' on':'')+'" data-act="sttab" data-t="'+id+'" role="tab" aria-selected="'+(STT===id)+'">'+l+'</button>';return '<div class="chips" role="tablist" aria-label="Stuff sections" style="margin:0 0 14px">'+t('files','Files and links')+t('rds','RDS Generator')+'</div>'}
function rdsRefresh(){const l=$('rds-list'),g=$('rds-groups'),c=$('rds-count');if(l)l.innerHTML=rdsListHtml();if(g)g.innerHTML=rdsGroupsHtml();if(c)c.innerHTML=rdsCountHtml()}
function rdsSet(el,final){const k=el.dataset.rds,v=el.type==='checkbox'?el.checked:el.value;let m;
if(k==='q'){RDS.q=v;const l=$('rds-list');if(l)l.innerHTML=rdsListHtml();return}
if(k==='env'||k==='role'||k==='onlyOn'){RDS[k]=v;rdsSave();rdsRefresh();return}
if(k==='sel'){RDS.sel[el.dataset.h]=!!v;rdsSave();const g=$('rds-groups'),c=$('rds-count');if(g)g.innerHTML=rdsGroupsHtml();if(c)c.innerHTML=rdsCountHtml();return}
if(k==='envacc'){RDS.envAcc[el.dataset.e]=v;rdsSave();return}
if(k==='grpacc'){RDS.grpAcc[el.dataset.k]=v;rdsSave();return}
if((m=k.match(/^acc\.([^.]+)\.(label|domain|user)$/))){const a=rdsAccOf(m[1]);if(a){a[m[2]]=v;rdsSave();if(final){const g=$('rds-groups');if(g)g.innerHTML=rdsGroupsHtml()}}return}
if((m=k.match(/^p\.(.+)$/))){RDS.p[m[1]]=v;rdsSave();if(RDS.prev&&final)route()}}
document.addEventListener('input',e=>{const el=e.target;if(el&&el.dataset&&el.dataset.rds&&(el.tagName==='INPUT'&&el.type!=='checkbox'))rdsSet(el,false)});
document.addEventListener('change',e=>{const el=e.target;if(el&&el.dataset&&el.dataset.rds)rdsSet(el,true)});
const RDSACT={
sttab(el){STT=el.dataset.t==='rds'?'rds':'files';route()},
rdsaccadd(){RDS.acc.push({id:'a'+Date.now().toString(36),label:'',domain:'',user:''});rdsSave();route()},
rdsaccdel(el){const id=el.dataset.id;RDS.acc=RDS.acc.filter(a=>a.id!==id);Object.keys(RDS.envAcc).forEach(k=>{if(RDS.envAcc[k]===id)delete RDS.envAcc[k]});Object.keys(RDS.grpAcc).forEach(k=>{if(RDS.grpAcc[k]===id)delete RDS.grpAcc[k]});rdsSave();route()},
rdsselvis(){rdsFiltered().forEach(r=>{RDS.sel[r.Hostname]=true});rdsSave();route()},
rdsclrvis(){rdsFiltered().forEach(r=>{RDS.sel[r.Hostname]=false});rdsSave();route()},
rdsprev(){RDS.prev=!RDS.prev;route()},
async rdsgen(){const n=rdsRows().filter(rdsOn).length;if(!n){toast('Select at least one server');return}
let nm=String(RDS.p.name||'').trim().replace(/[\\/:*?"<>|]/g,'-')||'Servers';if(!/\.rdg$/i.test(nm))nm+='.rdg';
const xml=rdsXml();
if(STDIR){await stuffAdd([new File([xml],nm,{type:'text/xml'})]);toast(nm+' saved to the Stuff folder ('+n+' servers)')}
else if(dlBlob(nm,xml,'text/xml'))toast(nm+' downloaded ('+n+' servers)')}};
