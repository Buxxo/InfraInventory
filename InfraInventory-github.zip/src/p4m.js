/* ---------- Blade enclosures (CS700 / c7000 style) ---------- */
function isEncl(r){return parseInt(r['Bays across'])>=1&&parseInt(r['Bays down'])>=1}
function enclNames(){return DB.RackDevices.filter(isEncl).map(r=>String(r.Name))}
function inEncl(r){return !!r.Enclosure&&enclNames().indexOf(String(r.Enclosure))>=0}
function bayList(v){return String(v==null?'':v).split(/[,;+ ]+/).map(x=>parseInt(x)).filter(x=>x>=1)}
const BSRC=['ESXi','ServerMI'];
function isBlade(r){return r.Blade==='Yes'||inEncl(r)}
function bladeAt(enc,n){const ix=memo('bladeIdx',()=>{const m=new Map();for(const sh of BSRC)for(let i=0;i<DB[sh].length;i++){const h=DB[sh][i];if(!h.Enclosure)continue;bayList(h.Bay).forEach(b=>{const k=h.Enclosure+'|'+b;if(!m.has(k))m.set(k,{sheet:sh,i:i,r:h})})}return m});const x=ix.get(enc+'|'+n);if(x&&DB[x.sheet][x.i]===x.r&&x.r.Enclosure===enc&&bayList(x.r.Bay).indexOf(n)>=0)return x;if(x||DB.ServerMI.length<400){for(const sh of BSRC)for(let i=0;i<DB[sh].length;i++){const h=DB[sh][i];if(h.Enclosure===enc&&bayList(h.Bay).indexOf(n)>=0)return{sheet:sh,i:i,r:h}}}return null}
function bladeDev(sel){if(!sel||BSRC.indexOf(sel.sheet)<0)return null;const r=DB[sel.sheet][sel.i];if(!r||!inEncl(r))return null;const e=DB.RackDevices.find(x=>x.Name===r.Enclosure)||{};return{sheet:sel.sheet,i:sel.i,name:r.Hostname,t:sel.sheet==='ESXi'?'esxi':'srv',dc:r.DC||e.DC,rack:r.Rack||e.Rack,u:NaN,sz:NaN,r:r,blade:1}}
function bladeCheck(sheet,base,self){if(BSRC.indexOf(sheet)<0)return '';
const enc=String(base.Enclosure||'').trim(),bay=String(base.Bay||'').trim(),bl=base.Blade==='Yes';
if(!bl&&(enc||bay))return 'Only blade servers can be placed in an enclosure. Tick “Blade server”, or clear Enclosure and Bay.';
if(!enc&&!bay)return '';
const e=DB.RackDevices.find(x=>x.Name===enc&&isEncl(x));if(!e)return 'Choose an existing blade enclosure (Rack layout → Add blade enclosure).';
const N=parseInt(e['Bays across'])*parseInt(e['Bays down']),bays=bayList(bay);
if(!bays.length)return 'Enter the bay number (1–'+N+') for '+enc;
if(bays.some(n=>n>N))return enc+' has bays 1–'+N;
for(const sh of BSRC)for(let i=0;i<DB[sh].length;i++){if(sh===sheet&&i===self)continue;const h=DB[sh][i];if(h.Enclosure===enc){const c=bayList(h.Bay).filter(n=>bays.indexOf(n)>=0);if(c.length)return 'Bay '+c[0]+' of '+enc+' is already used by '+h.Hostname}}
return ''}
function bladeSync(f){if(!f||!f.elements||!f.elements.Blade||BSRC.indexOf(f.dataset.sheet)<0)return;const on=f.elements.Blade.checked;['Enclosure','Bay'].forEach(k=>{const e=f.elements[k];if(e){e.disabled=!on;if(!on)e.value=''}})}
function bladeFree(){const o=[];BSRC.forEach(sh=>DB[sh].forEach((r,i)=>{if(isBlade(r)&&!inEncl(r))o.push({sheet:sh,i:i,r:r})}));return o}
function openBayPick(enc,n){const e=DB.RackDevices.find(x=>x.Name===enc)||{},L=bladeFree();BP={enc:enc,n:n};
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Put a blade into bay '+n+'" style="width:min(520px,100%)"><h2>'+esc(enc)+' · bay '+n+'</h2>'
+(L.length?'<label for="bp-sel">Blade to put in this bay<select class="inp" id="bp-sel">'+L.map((x,j)=>'<option value="'+j+'">'+esc(x.r.Hostname)+' · '+(x.sheet==='ESXi'?'ESXi host':'server')+'</option>').join('')+'</select></label><p class="note" style="margin:6px 0 0">Only hosts and servers marked “Blade server” are offered. Tick Blade on a host or server to make it appear here.</p>':'<p class="note">No unassigned blades yet. Tick “Blade server” on an existing ESXi host or server (Edit), or create a new blade below.</p>')
+'<div id="bp-err" class="note" style="color:var(--bad-fg)" role="alert"></div><div class="acts"><div class="tools"><button class="btn" data-act="bpnew" data-s="ESXi">New ESXi blade…</button><button class="btn" data-act="bpnew" data-s="ServerMI">New standalone blade server…</button></div><div class="tools"><button class="btn" data-act="mclose">Cancel</button>'+(L.length?'<button class="btn p" data-act="bpgo">Put in bay '+n+'</button>':'')+'</div></div></div></div>';BPL=L}
let BP=null,BPL=[];
function enclCell(d,UH,hit,ln){
const r=d.r,A=parseInt(r['Bays across']),D=parseInt(r['Bays down']);let b='';
for(let n=1;n<=A*D;n++){const hh=bladeAt(r.Name,n),h=hh?hh.r:null;b+='<button class="bay'+(h?' on':'')+(h&&RK.sel&&RK.sel.sheet===hh.sheet&&RK.sel.i===hh.i?' sel':'')+'" data-act="rkbay" data-enc="'+esc(r.Name)+'" data-b="'+n+'" title="'+esc('Bay '+n+': '+(h?h.Hostname:'empty — click to put a blade in'))+'">'+(h?'<span class="bn">'+esc(h.Hostname)+'</span>':n)+'</button>'}
return '<div class="dev encl'+(hit?' hit':'')+(RK.sel&&RK.sel.sheet===d.sheet&&RK.sel.i===d.i?' sel':'')+'" style="grid-row:'+(UH+2-d.u-d.sz)+' / span '+d.sz+';--dc:'+devColor(d)+(ln===undefined?'':';width:50%;justify-self:'+(ln?'end':'start'))+'" data-act="rkdev" data-sheet="'+d.sheet+'" data-i="'+d.i+'" title="'+esc(d.name)+' · U'+d.u+(d.sz>1?'–U'+(d.u+d.sz-1):'')+'"><span class="en">'+esc(d.name)+'</span><div class="bays" style="--a:'+A+';--d:'+D+'">'+b+'</div></div>'}
function enclDetail(r){
const A=parseInt(r['Bays across']),D=parseInt(r['Bays down']);let rows='';
for(let n=1;n<=A*D;n++){const hh=bladeAt(r.Name,n);rows+='<tr><td class="mono">'+n+'</td><td>'+(hh?'<a href="#" data-act="rkbay" data-enc="'+esc(r.Name)+'" data-b="'+n+'">'+esc(hh.r.Hostname)+'</a> <span class="note">'+(hh.sheet==='ESXi'?'ESXi host':'server')+'</span>':'<span class="note" style="margin:0">empty</span>')+'</td><td style="text-align:right">'+(hh?'<button class="btn s" data-act="bprm" data-sheet="'+hh.sheet+'" data-i="'+hh.i+'">Remove from bay</button>':'<button class="btn s" data-act="rkbay" data-enc="'+esc(r.Name)+'" data-b="'+n+'">Put a blade here…</button>')+'</td></tr>'}
return '<h3 style="font-size:14px;margin:14px 0 6px">Bays ('+A+' across × '+D+' down)</h3><div class="tw"><table><thead><tr><th>Bay</th><th>Blade</th><th></th></tr></thead><tbody>'+rows+'</tbody></table></div>'}
const ENCLACT={
rkzoom(el){RK.z=+el.dataset.z;route()},
rkbay(el,e){const enc=el.dataset.enc,n=+el.dataset.b,hh=bladeAt(enc,n);
if(hh){RK.sel={sheet:hh.sheet,i:hh.i};route();return}openBayPick(enc,n)},
bpgo(){const x=BPL[+$('bp-sel').value];if(!x)return;const e=DB.RackDevices.find(y=>y.Name===BP.enc)||{};const t=Object.assign({},x.r,{Enclosure:BP.enc,Bay:String(BP.n),Blade:'Yes'});if(x.sheet==='ESXi'){t.DC=e.DC||t.DC;t.Rack=e.Rack||t.Rack}
const er=bladeCheck(x.sheet,t,x.i);if(er){$('bp-err').textContent=er;return}
Object.assign(x.r,t);x.r.Updated=ds(0);RK.sel={sheet:x.sheet,i:x.i};closeForm();changed();route();toast(x.r.Hostname+' put in '+BP.enc+', bay '+BP.n)},
bpnew(el){const e=DB.RackDevices.find(x=>x.Name===BP.enc)||{},s=el.dataset.s;openForm(s,null,s==='ESXi'?{Blade:'Yes',Enclosure:BP.enc,Bay:String(BP.n),DC:e.DC||RK.dc,Rack:e.Rack||''}:{Blade:'Yes',Platform:'Physical',Enclosure:BP.enc,Bay:String(BP.n)})},
bprm(el){const r=DB[el.dataset.sheet][+el.dataset.i];if(!r)return;r.Enclosure='';r.Bay='';r.Updated=ds(0);if(RK.sel&&RK.sel.sheet===el.dataset.sheet&&RK.sel.i===+el.dataset.i)RK.sel=null;changed();route();toast(r.Hostname+' removed from the enclosure')},
rkencl(){if(!DB.DeviceTypes.some(t=>t.Name==='Blade enclosure'))DB.DeviceTypes.push({Name:'Blade enclosure',Color:'Gold','Default U':10,Active:'Yes',Notes:'Blade chassis with bays, e.g. HPE CS700 / c7000',Updated:ds(0)});
openForm('RackDevices',null,{Name:'',Type:'Blade enclosure',DC:RK.dc,Model:'HPE CS700 (c7000)','U size':10,'Bays across':8,'Bays down':2})}};
