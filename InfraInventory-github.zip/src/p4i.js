
/* ---------- attachments on records (Attachments/<Sheet>/<record>/<file>) ---------- */
const ATT={q:[]},ATT_SHEETS=['ServerMI','ESXi','Storage','Backup','RackDevices','DCSSActivity','PatchEvents'];
const attList=r=>String(r.Attachments||'').split(';').map(x=>x.trim()).filter(Boolean);
const attSafe=s=>String(s==null?'':s).replace(/[\\\/:*?"<>|]+/g,'_').replace(/\s+/g,' ').trim().slice(0,80)||'item';
const attSheetDir=s=>attSafe(typeof xn==='function'?xn(s):s);
const attHref=(s,e)=>'Attachments/'+encodeURIComponent(attSheetDir(s))+'/'+e.split('/').map(encodeURIComponent).join('/');
function attInner(sheet,row,isNew){
const have=isNew?[]:attList(row),q=ATT.q;
return (ATDIR?'':'<p class="note" style="margin:0 0 6px">The project folder is not connected, so files cannot be stored yet. Connect it in Data sources.</p>')
+(have.length?have.map((e,k)=>'<div class="tools" style="justify-content:space-between;border-top:1px solid var(--line2);padding:5px 0"><a class="lnk" href="'+attHref(sheet,e)+'" target="_blank" rel="noopener">'+esc(e.split('/').pop())+' ↗</a><button type="button" class="btn s d" data-act="attdel" data-sheet="'+sheet+'" data-n="'+esc(e)+'">Remove</button></div>').join(''):'')
+(q.length?q.map((f,k)=>'<div class="tools" style="justify-content:space-between;border-top:1px solid var(--line2);padding:5px 0"><span>'+esc(f.name)+' <span class="note">· saved when you click Save</span></span><button type="button" class="btn s" data-act="attq" data-k="'+k+'">Drop</button></div>').join(''):'')
+(!have.length&&!q.length?'<p class="note" style="margin:0">No files yet.</p>':'')}
function attBlock(sheet,row,isNew){
if(ATT_SHEETS.indexOf(sheet)<0)return '';
return '<div class="card" style="background:var(--surface2);margin-top:12px;padding:12px"><div class="tools" style="justify-content:space-between;margin-bottom:6px"><b>Attachments</b><label class="btn s" for="att-file" style="cursor:pointer">+ Attach files</label><input type="file" id="att-file" multiple hidden></div><div id="att-box">'+attInner(sheet,row,isNew)+'</div></div>'}
async function attWrite(sheet,row,files){
if(!ATDIR){toast('Connect the project folder first (Data sources).');return 0}
const key=attSafe(row[SCHEMA[sheet].key]);let n=0;const names=attList(row);
try{const sd=await ATDIR.getDirectoryHandle(attSheetDir(sheet),{create:true}),d=await sd.getDirectoryHandle(key,{create:true});
for(const f of files){const h=await d.getFileHandle(f.name,{create:true}),w=await h.createWritable();await w.write(f);await w.close();const e=key+'/'+f.name;if(names.indexOf(e)<0)names.push(e);n++}}
catch(e){toast('Could not write the file. Check the folder permission.')}
if(n){row.Attachments=names.join('; ');row.Updated=ds(0);changed()}return n}
async function attFlush(sheet,row){const f=ATT.q.slice();ATT.q=[];const n=await attWrite(sheet,row,f);if(n)toast(n+(n===1?' file':' files')+' attached');route()}
async function attPicked(files){
const fm=$('frm');if(!fm)return;const sheet=fm.dataset.sheet,isNew=fm.dataset.i==='';
if(isNew){files.forEach(f=>ATT.q.push(f));if(!ATDIR)toast('Connect the project folder first, otherwise the files cannot be saved.')}
else{const row=DB[sheet][+fm.dataset.i];const n=await attWrite(sheet,row,files);if(n)toast(n+(n===1?' file':' files')+' attached')}
const b=$('att-box');if(b)b.innerHTML=attInner(sheet,isNew?{}:DB[sheet][+fm.dataset.i],isNew)}
async function attRemove(sheet,e,btn){
const fm=$('frm');if(!fm||fm.dataset.i==='')return;const row=DB[sheet][+fm.dataset.i];
if(!btn.dataset.arm){btn.dataset.arm='1';btn.textContent='Click again';return}
try{if(ATDIR){const p=e.split('/'),sd=await ATDIR.getDirectoryHandle(attSheetDir(sheet)),d=await sd.getDirectoryHandle(p[0]);await d.removeEntry(p[1])}}catch(x){}
row.Attachments=attList(row).filter(x=>x!==e).join('; ');row.Updated=ds(0);changed();$('att-box').innerHTML=attInner(sheet,row,false)}
