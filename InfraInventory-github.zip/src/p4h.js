/* ---------- Patching activity (only from Patch events) ---------- */
const PT_SRC=[['ServerMI','Hostname','Server'],['ESXi','Hostname','ESXi host'],['Storage','Array','Storage'],['Backup','Device','Backup device'],['RackDevices','Name','Other device']];
function ptParse(txt){const seen={},out=[];String(txt||'').split(/[\r\n\t,;]+|\s+/).forEach(t=>{t=t.trim().replace(/^["']|["']$/g,'');if(t&&!seen[t.toLowerCase()]){seen[t.toLowerCase()]=1;out.push(t)}});return out}
/* Servers are named <hostname>-<role>-<node>: the part before the first dash is the real hostname, so a pasted short name matches. */
function ptMatch(tok){
const t=tok.toLowerCase(),sh=t.split('.')[0],hits=[];
PT_SRC.forEach(s=>DB[s[0]].forEach((r,i)=>{
const ks=(s[0]==='ServerMI'?[r.Hostname,r.FQDN,r['vCenter name']]:[r[s[1]]]).map(x=>String(x||'').toLowerCase()).filter(Boolean);
let ok=ks.indexOf(t)>=0||ks.some(k=>k.split('.')[0]===sh&&(t.indexOf('.')<0||k.indexOf('.')<0));
if(!ok&&s[0]==='ServerMI'&&sh.indexOf('-')<0)ok=ks.some(k=>k.split('.')[0].split('-')[0]===sh);
if(ok)hits.push({sheet:s[0],i:i,name:String(r[s[1]])})}));
return hits}
function ptScan(txt){const toks=ptParse(txt),ok=[],no=[],multi=[],seen={};
toks.forEach(t=>{const h=ptMatch(t);if(!h.length){no.push(t);return}if(h.length>1)multi.push([t,h.length]);h.forEach(x=>{const k=x.sheet+'|'+x.i;if(!seen[k]){seen[k]=1;ok.push(x)}})});
return{toks:toks,ok:ok,no:no,multi:multi}}
function ptPreview(){const sc=ptScan($('pb-list').value),by={};sc.ok.forEach(x=>by[x.sheet]=(by[x.sheet]||0)+1);
$('pb-sum').innerHTML=sc.toks.length?'<b>'+sc.ok.length+'</b> matched'+(sc.ok.length?' ('+PT_SRC.filter(s=>by[s[0]]).map(s=>by[s[0]]+' '+s[2].toLowerCase()+(by[s[0]]>1?'s':'')).join(', ')+')':'')+(sc.no.length?' · <span style="color:var(--bad-fg)">'+sc.no.length+' not found: '+sc.no.slice(0,12).map(esc).join(', ')+(sc.no.length>12?' …':'')+'</span>':'')+(sc.multi.length?'<br><span class="note">Short names that matched several records: '+sc.multi.slice(0,6).map(m=>esc(m[0])+' ('+m[1]+')').join(', ')+'. All of them are updated.</span>':''):'<span class="note">Paste device names, one per line.</span>';
const b=$('pb-err');if(b)b.textContent='';const g=$('pb-go');if(g){g.dataset.ok='';g.textContent='Save patching activity'}return sc}
function openPtBulk(pre,date){
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Add patching activity" style="width:min(600px,100%)"><h2>Add patching activity</h2>'
+'<div class="fgrid"><label for="pb-crq">CRQ number<input class="inp" id="pb-crq" placeholder="CRQ000012345"></label><label for="pb-title">Title (optional)<input class="inp" id="pb-title" placeholder="Monthly patching PROD"></label>'
+'<label for="pb-date">Start date<input class="inp" id="pb-date" type="date" value="'+(date||ds(0))+'"></label><label for="pb-end">End date (optional)<input class="inp" id="pb-end" type="date"></label>'
+'<label for="pb-status">Status<select class="inp" id="pb-status"><option>Done</option><option>In progress</option><option>Planned</option></select></label>'
+'<label class="wide" for="pb-list">Devices (paste from Notepad or Excel)<textarea class="inp" id="pb-list" data-act="pbprev" rows="9" placeholder="server01&#10;server02-APP-NodeA&#10;esx-a01&#10;san-a01">'+esc(pre||'')+'</textarea></label></div>'
+'<div id="pb-sum" class="note" style="margin-top:6px"></div>'
+'<label class="chkrow" style="margin-top:6px"><input type="checkbox" id="pb-fw"> Firmware update (also set FW patched)</label><label class="chkrow"><input type="checkbox" id="pb-cal" checked> Show in the calendar</label>'
+'<p class="note" style="margin:6px 0 0">Searches ServersMI, ESXi hosts, Storage, Backup and Other devices. For servers the part of the name before the first dash is the hostname, so “server01” matches “server01-APP-NodeA”; FQDN and vCenter name match too. Status Done sets Last patched and Last patch CRQ on every matched device; Planned and In progress only create the calendar event.</p>'
+'<div id="pb-err" class="note" style="color:var(--bad-fg)" role="alert"></div>'
+'<div class="acts"><span></span><div class="tools"><button class="btn" data-act="mclose">Cancel</button><button class="btn p" data-act="ptbulkgo" id="pb-go">Save patching activity</button></div></div></div></div>';ptPreview();setTimeout(()=>{const c=$('pb-crq');if(c)c.focus()},30)}
function ptCur(x){const r=DB[x.sheet][x.i];return String(r['Last patched']||'').slice(0,10)}
function ptPlan(list,when,force){const sc=ptScan(list),up=[],skip=[];sc.ok.forEach(x=>{const c=ptCur(x);(c&&c>when&&!force?skip:up).push(x)});return {sc:sc,up:up,skip:skip}}
function ptApply(crq,when,fw,list,force){const p=ptPlan(list,when,force);p.up.forEach(x=>{const r=DB[x.sheet][x.i];r['Last patched']=when;r['Last patch CRQ']=crq;if(fw)r['FW patched']=when;r.Updated=ds(0)});return {n:p.up.length,skip:p.skip.map(x=>x.name+' ('+ptCur(x)+')')}}
function ptMsg(res,crq){return res.n+' devices updated with '+crq+(res.skip.length?' · '+res.skip.length+' skipped, they already have a newer date: '+res.skip.slice(0,5).join(', ')+(res.skip.length>5?' …':''):'')}
function openPtDone(i){const ev=DB.PatchEvents[i];if(!ev)return;PTD={i:i};
const when=ev['End date']||ev.Date||ds(0);
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Mark patching as done" style="width:min(680px,100%)"><h2>Mark as done · '+esc(ev.CRQ||ev.ID)+'</h2>'
+'<div class="fgrid"><label for="pd-date">Patched on<input class="inp" id="pd-date" type="date" value="'+esc(String(when).slice(0,10))+'" data-act="pdprev"></label><label for="pd-crq">CRQ / INC<input class="inp" id="pd-crq" value="'+esc(ev.CRQ||'')+'" data-act="pdprev"></label></div>'
+'<label class="chkrow" style="margin-top:6px"><input type="checkbox" id="pd-fw" data-act="pdprev"'+(/firmware/i.test(ev.Notes||'')?' checked':'')+'> Firmware update (also set FW patched)</label><label class="chkrow"><input type="checkbox" id="pd-force" data-act="pdprev"> Overwrite devices that already have a newer date</label>'
+'<div id="pd-sum" style="margin-top:8px"></div><div id="pd-err" class="note" style="color:var(--bad-fg)" role="alert"></div>'
+'<div class="acts"><span></span><div class="tools"><button class="btn" data-act="mclose">Cancel</button><button class="btn p" data-act="ptdonego" id="pd-go">Mark as done</button></div></div></div></div>';ptdPrev()}
let PTD=null;
function ptdPrev(){const ev=DB.PatchEvents[PTD.i],when=$('pd-date').value,p=ptPlan(ev.Servers,when,$('pd-force').checked),nf=p.sc.no;
$('pd-sum').innerHTML='<div class="tw" style="max-height:260px"><table><thead><tr><th>Device</th><th>Current Last patched</th><th>Current CRQ</th><th>Result</th></tr></thead><tbody>'
+p.sc.ok.map(x=>{const r=DB[x.sheet][x.i],sk=p.skip.indexOf(x)>=0;return '<tr><td class="mono">'+esc(x.name)+'</td><td>'+(esc(ptCur(x))||'<span class="note">—</span>')+'</td><td class="mono">'+(esc(r['Last patch CRQ'])||'<span class="note">—</span>')+'</td><td>'+(sk?'<span class="badge b-warn">Skipped: newer date on record</span>':'<span class="badge b-ok">Will be updated</span>')+'</td></tr>'}).join('')+nf.map(n=>'<tr><td class="mono">'+esc(n)+'</td><td colspan="2"></td><td><span class="badge b-bad">Not found</span></td></tr>').join('')+'</tbody></table></div>';
$('pd-go').textContent='Mark as done · update '+p.up.length+' device'+(p.up.length===1?'':'s')}
function doPtDone(){const ev=DB.PatchEvents[PTD.i],when=$('pd-date').value,crq=$('pd-crq').value.trim();
if(!when||!crq){$('pd-err').textContent='Enter the date and the CRQ / INC';return}
const res=ptApply(crq,when,$('pd-fw').checked,ev.Servers,$('pd-force').checked);
ev.Status='Done';ev.CRQ=crq;if(!ev['End date']&&when>ev.Date)ev['End date']=when;ev.Updated=ds(0);
closeForm();changed();route();toast(ptMsg(res,crq))}
function openPtToday(i){const r=DB.ServerMI[i];if(!r)return;PTT={i:i};
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Patched" style="width:min(420px,100%)"><h2>Patched · '+esc(r.Hostname)+'</h2>'
+'<div class="fgrid"><label for="pt-crq">CRQ / INC<input class="inp" id="pt-crq" placeholder="CRQ000012345" value="'+esc(r['Last patch CRQ']||'')+'"></label><label for="pt-date">Patched on<input class="inp" id="pt-date" type="date" value="'+ds(0)+'"></label></div>'
+'<div id="pt-err" class="note" style="color:var(--bad-fg)" role="alert"></div><div class="acts"><span></span><div class="tools"><button class="btn" data-act="mclose">Cancel</button><button class="btn p" data-act="ptodaygo" id="pt-go">Save</button></div></div></div></div>';setTimeout(()=>{const c=$('pt-crq');if(c){c.focus();c.select()}},30)}
let PTT=null;
function doPtToday(){const r=DB.ServerMI[PTT.i],crq=$('pt-crq').value.trim(),d=$('pt-date').value;if(!crq||!d){$('pt-err').textContent='Enter the CRQ / INC and the date';return}
const cur=String(r['Last patched']||'').slice(0,10),go=$('pt-go');
if(cur&&cur>d&&go.dataset.ok!=='1'){go.dataset.ok='1';go.textContent='Overwrite anyway';$('pt-err').textContent='This server already has a newer date ('+cur+(r['Last patch CRQ']?', '+r['Last patch CRQ']:'')+'). Click again to overwrite it with an older one.';return}
r['Last patched']=d;r['Last patch CRQ']=crq;r.Updated=ds(0);closeForm();changed();route();toast(r.Hostname+': patched '+d+' · '+crq)}
function doPtBulk(){const crq=$('pb-crq').value.trim(),d=$('pb-date').value,e=$('pb-end').value,st=$('pb-status').value;
if(!crq){$('pb-err').textContent='Enter the CRQ number';return}if(!d){$('pb-err').textContent='Enter the start date';return}
if(e&&e<d){$('pb-err').textContent='End date is before the start date';return}
const sc=ptScan($('pb-list').value);if(!sc.ok.length){$('pb-err').textContent='No device matched the inventory';return}
const go=$('pb-go');if(sc.no.length&&go.dataset.ok!=='1'){go.dataset.ok='1';go.textContent='Continue without the '+sc.no.length+' not found';$('pb-err').textContent='Not found in the inventory: '+sc.no.slice(0,15).join(', ')+(sc.no.length>15?' …':'')+'. Fix the names, or click again to continue without them.';return}
const fw=$('pb-fw').checked,when=e||d;
let res=null;if(st==='Done')res=ptApply(crq,when,fw,$('pb-list').value,false);
const n=Math.max(0,...DB.PatchEvents.map(x=>parseInt(String(x.ID).replace(/\D/g,''))||0))+1;
DB.PatchEvents.push({ID:'PAT-'+String(n).padStart(4,'0'),Date:d,'End date':e&&e>d?e:'',Title:$('pb-title').value.trim()||'Patching '+crq,CRQ:crq,Status:st,Servers:sc.ok.map(x=>x.name).join('\n'),'In calendar':$('pb-cal').checked?'Yes':'No',Notes:fw?'Firmware update':'',Updated:ds(0)});
closeForm();changed();route();toast(st==='Done'?ptMsg(res,crq):'Event saved ('+sc.ok.length+' devices)')}
