
/* ---------- column filters (several conditions, all must match) ---------- */
function fcols(sheet){
const o=SCHEMA[sheet].cols.map(c=>({k:c.k,t:c.t||'text',o:c.o}));
if(TV[sheet])TV[sheet].show.filter(k=>k.charAt(0)==='@').forEach(k=>o.push({k:k,t:k==='@load'?'num':'text'}));
o.push({k:'Updated',t:'date'});
return o;
}
function distinct(sheet,k){
const m={};DB[sheet].forEach(r=>{const x=val(r,k),v=x==null?'':String(x);m[v]=(m[v]||0)+1});
return Object.keys(m).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true})).map(v=>({v:v,c:m[v]}));
}
const OPL={contains:'contains',eq:'equals',ne:'does not equal',starts:'starts with',in:'is one of',nin:'is none of',empty:'is empty',nempty:'is not empty',gt:'> greater than',ge:'≥ at least',lt:'< less than',le:'≤ at most',between:'is between',on:'is on',before:'is before',after:'is after',dbetween:'is between',within:'is due within N days (or overdue)',older:'is older than N days'};
function opsFor(sheet,c){
const many=distinct(sheet,c.k).length>40;
let o;
if(c.t==='num')o=['ge','le','between','eq','ne','gt','lt','empty','nempty'];
else if(c.t==='date')o=['on','before','after','dbetween','within','older','empty','nempty'];
else if(c.t==='sel')o=['in','nin','empty','nempty'];
else o=many?['contains','eq','ne','starts','empty','nempty']:['contains','in','nin','eq','ne','starts','empty','nempty'];
if(c.t==='date'){const first=c.k==='Support end'?'within':c.k==='Updated'?'older':null;if(first){o=[first].concat(o.filter(x=>x!==first))}}
return o.map(x=>[x,OPL[x]]);
}
function newFilter(sheet,k){
const c=fcols(sheet).find(x=>x.k===k)||{k:k,t:'text'},op=opsFor(sheet,c)[0][0];
return{k:c.k,op:op,v:(op==='in'||op==='nin')?[]:'',v2:''};
}
function needsValue(f){return !(f.op==='empty'||f.op==='nempty')}
function incomplete(f){
if(!needsValue(f))return false;
if(f.op==='in'||f.op==='nin')return !(Array.isArray(f.v)&&f.v.length);
if(f.op==='between'||f.op==='dbetween')return (f.v==null||f.v==='')&&(f.v2==null||f.v2==='');
return f.v==null||f.v===''||Array.isArray(f.v);
}
function passF(f,r){
if(incomplete(f))return true;
const v=val(r,f.k),s=v==null?'':String(v),sl=s.toLowerCase(),n=parseFloat(s),d10=s.slice(0,10);
const a=parseFloat(f.v),b=parseFloat(f.v2);
switch(f.op){
case 'contains':return sl.indexOf(String(f.v).toLowerCase())>=0;
case 'starts':return sl.indexOf(String(f.v).toLowerCase())===0;
case 'eq':return c_eq(s,n,f.v);
case 'ne':return !c_eq(s,n,f.v);
case 'in':return f.v.indexOf(s)>=0;
case 'nin':return f.v.indexOf(s)<0;
case 'empty':return s.trim()==='';
case 'nempty':return s.trim()!=='';
case 'gt':return !isNaN(n)&&n>a;
case 'ge':return !isNaN(n)&&n>=a;
case 'lt':return !isNaN(n)&&n<a;
case 'le':return !isNaN(n)&&n<=a;
case 'between':return !isNaN(n)&&(isNaN(a)||n>=a)&&(isNaN(b)||n<=b);
case 'on':return d10===f.v;
case 'before':return d10!==''&&d10<f.v;
case 'after':return d10!==''&&d10>f.v;
case 'dbetween':return d10!==''&&(!f.v||d10>=f.v)&&(!f.v2||d10<=f.v2);
case 'within':{const dd=daysTo(s);return dd!==null&&dd<=a}
case 'older':{const dd=daysTo(s);return dd!==null&&-dd>a}
}
return true;
}
function c_eq(s,n,v){const m=parseFloat(v);if(!isNaN(n)&&!isNaN(m)&&String(n)===s.trim())return n===m;return s.toLowerCase()===String(v).toLowerCase()}
function applyFilters(sheet,rows){
const fl=uiOf(sheet).fl.filter(f=>!incomplete(f));
return fl.length?rows.filter(x=>fl.every(f=>passF(f,x.r))):rows;
}
function fdesc(f){
const col=labelOf(f.k),op=OPL[f.op].replace(/^[<>≥≤] /,'');
if(!needsValue(f))return col+' '+op;
if(f.op==='in'||f.op==='nin')return col+' '+op+' '+(f.v.length?f.v.map(x=>x===''?'(empty)':x).join(', '):'…');
if(f.op==='between'||f.op==='dbetween')return col+' '+op+' '+(f.v===''?'…':f.v)+' and '+(f.v2===''||f.v2==null?'…':f.v2);
const sym={gt:'>',ge:'≥',lt:'<',le:'≤'}[f.op];
return col+' '+(sym||op)+' '+(f.v===''?'…':f.v);
}
function fsummaryHtml(sheet){
const fl=uiOf(sheet).fl;if(!fl.length)return '';
return '<div class="fsum" aria-label="Active filters"><span class="note">Filters:</span>'+fl.map((f,i)=>'<span class="badge '+(incomplete(f)?'b-off':'b-info')+'" style="height:26px">'+esc(fdesc(f))+' <button class="btn s" style="min-height:22px;min-width:22px;padding:0 6px;margin-left:4px;font-size:15px;line-height:1;font-weight:700" title="Remove this filter" data-act="frm" data-sheet="'+sheet+'" data-fi="'+i+'" aria-label="Remove filter">×</button></span>').join('')+'<button class="btn s" data-act="fclear" data-sheet="'+sheet+'">Clear all</button></div>';
}
function presets(sheet){
const p=[],has=k=>SCHEMA[sheet].cols.some(c=>c.k===k);
if(has('Support end'))p.push({label:'Support ends within 90 days',f:{k:'Support end',op:'within',v:'90',v2:''}});
if(has('Owner'))p.push({label:'No owner',f:{k:'Owner',op:'empty',v:'',v2:''}});
if(has('Used %'))p.push({label:'Used 85% or more',f:{k:'Used %',op:'ge',v:'85',v2:''}});
if(sheet==='DCMI'){p.push({label:'Power load 80% or more',f:{k:'@load',op:'ge',v:'80',v2:''}});p.push({label:'Inlet 25 °C or more',f:{k:'Inlet C',op:'ge',v:'25',v2:''}})}
if(sheet==='Datastores')p.push({label:'vCenter and array differ',f:{k:'@sync',op:'nin',v:['OK'],v2:''}});
if(sheet==='Datastores'){p.push({label:'Not replicated',f:{k:'Replicated',op:'nin',v:['Yes'],v2:''}});p.push({label:'Not exported to any host',f:{k:'Exported to',op:'empty',v:'',v2:''}})}
if(sheet==='ArrayVolumes')p.push({label:'Not replicated',f:{k:'Replicated',op:'nin',v:['Yes'],v2:''}});
if(sheet==='ArrayVolumes')p.push({label:'Not used by anything',f:{k:'@use',op:'in',v:['Unassigned'],v2:''}});
if(sheet==='DCChecks')p.push({label:'Result is Issue',f:{k:'Result',op:'in',v:['Issue'],v2:''}});
if(has('Rack')&&has('U start'))p.push({label:'Not placed in a rack',f:{k:'Rack',op:'empty',v:'',v2:''}});
p.push({label:'Not updated for 30+ days',f:{k:'Updated',op:'older',v:'30',v2:''}});
return p;
}
function presetOn(sheet,p){return uiOf(sheet).fl.findIndex(f=>f.k===p.f.k&&f.op===p.f.op&&JSON.stringify(f.v)===JSON.stringify(p.f.v))}
function fpanelHtml(sheet){
const u=uiOf(sheet),cols=fcols(sheet);
const rows=u.fl.map((f,i)=>{
const c=cols.find(x=>x.k===f.k)||{k:f.k,t:'text'};
const ops=opsFor(sheet,c),at=' data-sheet="'+sheet+'" data-fi="'+i+'"';
let val='';
if(f.op==='in'||f.op==='nin'){
val='<div class="vals" role="group" aria-label="Values"><div class="valsbar"><button type="button" class="btn s" data-act="finall"'+at+' data-v="1">Select all</button><button type="button" class="btn s" data-act="finall"'+at+' data-v="0">Select none</button></div>'+distinct(sheet,f.k).map((d,vi)=>'<label><input type="checkbox" data-act="fin"'+at+' data-vi="'+vi+'"'+(Array.isArray(f.v)&&f.v.indexOf(d.v)>=0?' checked':'')+'> '+(d.v===''?'(empty)':esc(d.v))+' <span class="note">'+d.c+'</span></label>').join('')+'</div>';
}else if(needsValue(f)){
const tp=(c.t==='num'||f.op==='within'||f.op==='older')?'number':c.t==='date'?'date':'text';
val='<input class="inp" id="fv-'+sheet+'-'+i+'" type="'+tp+'"'+(tp==='number'?' step="any"':'')+' data-act="fval"'+at+' value="'+esc(f.v)+'" aria-label="Filter value"'+((f.op==='between'||f.op==='dbetween')?' placeholder="from"':'')+'>'
+((f.op==='between'||f.op==='dbetween')?'<input class="inp" id="fv2-'+sheet+'-'+i+'" type="'+tp+'"'+(tp==='number'?' step="any"':'')+' data-act="fval2"'+at+' value="'+esc(f.v2)+'" aria-label="Filter value to" placeholder="to">':'');
}
return '<div class="frow2"><select class="inp" data-act="fcol"'+at+' aria-label="Filter column">'+cols.map(x=>'<option value="'+esc(x.k)+'"'+(x.k===f.k?' selected':'')+'>'+esc(labelOf(x.k))+'</option>').join('')+'</select><select class="inp" data-act="fop"'+at+' aria-label="Filter condition">'+ops.map(o=>'<option value="'+o[0]+'"'+(o[0]===f.op?' selected':'')+'>'+o[1]+'</option>').join('')+'</select>'+val+'<button class="btn s" data-act="hfopen" data-sheet="'+sheet+'" data-col="'+esc(f.k)+'" title="Pick values from a list with search">Pick values…</button><button class="btn s" data-act="frm"'+at+' aria-label="Remove filter">×</button></div>';
}).join('');
return '<div class="fpanel">'+(rows||'<p class="note" style="margin:0">No filters yet. Add a condition, or use a preset. All conditions must match.</p>')+'<div class="tools"><button class="btn s" data-act="fadd" data-sheet="'+sheet+'">+ Add filter</button>'+(u.fl.length?'<button class="btn s" data-act="fclear" data-sheet="'+sheet+'">Clear all</button>':'')+'<span class="note">Presets (click again to remove):</span>'+presets(sheet).map((p,pi)=>'<button class="chip'+(presetOn(sheet,p)>=0?' on':'')+'" aria-pressed="'+(presetOn(sheet,p)>=0)+'" data-act="fpreset" data-sheet="'+sheet+'" data-pi="'+pi+'">'+esc(p.label)+'</button>').join('')+'</div></div>';
}
