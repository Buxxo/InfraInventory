/* ---------- DC designer (container data centers: floor plan with drag, resize, snapping, checks) ---------- */
const DKIND={'Container 40 ft':{w:12.19,h:2.44,c:'#5B6B82'},'Container 20 ft':{w:6.06,h:2.44,c:'#6B7B92'},'Rack':{w:0.6,h:1.2,c:'#6B7B92'},'Rack row':{w:6,h:1.2,c:'#3F7BDB'},'Network cabinet':{w:0.8,h:0.8,c:'#1C7C94'},'Cooling unit':{w:1.2,h:0.9,c:'#0F9D9A'},'Chiller':{w:3,h:2,c:'#2B8F8C'},'UPS / batteries':{w:1.5,h:1,c:'#4E7F1E'},'Power cabinet':{w:1,h:0.8,c:'#B85C00'},'Generator':{w:3,h:1.5,c:'#9A6B00'},'Door / entrance':{w:1,h:0.25,c:'#A3221B'},'Zone':{w:8,h:6,c:'#8FA3C0'},'Label':{w:3,h:0.8,c:'#5B6B82'}};
const DOUT={'Container 40 ft':1,'Container 20 ft':1,'Chiller':1,'Generator':1};
const DSKIP={'Zone':1,'Label':1,'Door / entrance':1};
const DRKK={'Rack':1,'Rack row':1};
const DCAPK={'Cooling unit':1,'Chiller':1,'UPS / batteries':1,'Generator':1,'Power cabinet':1};
const DPS={dc:'',sel:null,set:[],snap:0.5,z:1,heat:'kind',grid:true,dims:false,guides:true,hide:{},q:'',space:false,pasteN:0};
try{const p=JSON.parse(localStorage.getItem('infra-dcp')||'{}');if(p.snap!=null&&!isNaN(p.snap))DPS.snap=+p.snap;if(p.z>0)DPS.z=+p.z;if(/^(kind|power|u)$/.test(p.heat))DPS.heat=p.heat;['grid','dims','guides'].forEach(k=>{if(typeof p[k]==='boolean')DPS[k]=p[k]})}catch(e){}
function dsave(){try{localStorage.setItem('infra-dcp',JSON.stringify({snap:DPS.snap,z:DPS.z,heat:DPS.heat,grid:DPS.grid,dims:DPS.dims,guides:DPS.guides}))}catch(e){}}
let DRAG=null,DGUIDE=[],DMSG='',DCLIP=[],DCF=new Set(),DRAF=0;
const DU={u:[],r:[],cur:''};
const dn=(r,k)=>{const v=parseFloat(r[k]);return isNaN(v)?0:v};
const dkc=r=>r.Color||(DKIND[r.Kind]||{c:'#5B6B82'}).c;
const dr=v=>Math.round(v*1000)/1000;
const dsnap=v=>{const s=DPS.snap;v=s?Math.round(v/s)*s:v;return Math.round(v*100)/100};
const dlk=r=>r.Locked==='Yes';
const dhx=c=>/^#[0-9a-f]{6}$/i.test(c||'');
function dcpRows(){return DB.DCLayout.map((r,i)=>({r:r,i:i})).filter(x=>x.r.DC===DPS.dc)}
function drot(r){return(((parseInt(r.Rotation)||0)%360)+360)%360}
function dbox(r){const w=dn(r,'Width m'),h=dn(r,'Height m'),rot=drot(r),q=rot===90||rot===270,bw=q?h:w,bh=q?w:h,cx=dn(r,'X m')+w/2,cy=dn(r,'Y m')+h/2;return{x:cx-bw/2,y:cy-bh/2,w:bw,h:bh,ow:w,oh:h,rot:rot}}
function dsetBox(r,bx,by){const b=dbox(r);r['X m']=dr(bx+(b.w-b.ow)/2);r['Y m']=dr(by+(b.h-b.oh)/2)}
function dRot(a,v){const R={0:[1,0],90:[0,1],180:[-1,0],270:[0,-1]}[((a%360)+360)%360]||[1,0];return[v[0]*R[0]-v[1]*R[1],v[0]*R[1]+v[1]*R[0]]}
function dstamp(r){r.Updated=ds(0)}
/* ----- selection ----- */
function dsl(){return DPS.set.filter(i=>DB.DCLayout[i]&&DB.DCLayout[i].DC===DPS.dc)}
function dsetSel(a){DPS.set=a.slice();DPS.sel=a.length?a[a.length-1]:null;DMSG=''}
function dfix(){const a=dsl();if(DPS.sel==null){DPS.set=[];return}DPS.set=a;if(a.indexOf(DPS.sel)<0)DPS.sel=a.length?a[a.length-1]:null;if(DPS.sel==null)DPS.set=[]}
/* ----- undo / redo (whole layout snapshots) ----- */
function dsnapJ(){return JSON.stringify(DB.DCLayout)}
function dpush(j){DU.u.push(j||dsnapJ());if(DU.u.length>100)DU.u.shift();DU.r.length=0}
function dapply(j){const a=JSON.parse(j);DB.DCLayout.splice(0,DB.DCLayout.length,...a);changed()}
function dundo(){if(!DU.u.length){dmsg('Nothing to undo');return}DU.r.push(dsnapJ());dapply(DU.u.pop());dfix();dmsg('Undone');dcpFull()}
function dredo(){if(!DU.r.length){dmsg('Nothing to redo');return}DU.u.push(dsnapJ());dapply(DU.r.pop());dfix();dmsg('Redone');dcpFull()}
function dmsg(t){DMSG=t;const m=$('dcp-msg');if(m)m.textContent=t}
/* ----- helpers ----- */
function dname(base){const used=new Set(dcpRows().map(x=>String(x.r.Block)));if(!used.has(base))return base;let n=2;while(used.has(base+' '+n))n++;return base+' '+n}
function dmk(k,x,y,extra){const d=DKIND[k];return Object.assign({DC:DPS.dc,Block:dname(k),Kind:k,'X m':dr(x),'Y m':dr(y),'Width m':d.w,'Height m':d.h,Rotation:'0','Capacity kW':'',Locked:'No',Color:'',Rack:'',Notes:'',Updated:ds(0)},extra||{})}
function dfind(w,h){const rows=dcpRows().filter(x=>!DSKIP[x.r.Kind]).map(x=>dbox(x.r));let zx=1,zy=1,zw=70,zh=44;const z=dcpRows().find(x=>x.r.Kind==='Zone');if(z){const b=dbox(z.r);zx=b.x+0.5;zy=b.y+0.5;zw=b.w-1;zh=b.h-1}
const ok=(x,y)=>rows.every(b=>x+w+0.3<=b.x||b.x+b.w+0.3<=x||y+h+0.3<=b.y||b.y+b.h+0.3<=y);
for(let y=zy;y+h<=zy+zh;y+=0.5)for(let x=zx;x+w<=zx+zw;x+=0.5)if(ok(x,y))return[x,y];
for(let y=1;y<80;y+=0.5)for(let x=1;x<90;x+=0.5)if(ok(x,y))return[x,y];
let m=0;rows.forEach(b=>m=Math.max(m,b.y+b.h));return[2,m+1]}
/* ----- inventory data (power, U usage) ----- */
function dUsed(){return memo('dcpU',()=>{const m={};devices().forEach(d=>{if(!d.dc||d.rack==null||d.rack==='')return;const k=d.dc+'|'+d.rack;m[k]=(m[k]||0)+(d.sz>0?d.sz:1)});return m})}
function dRackInfo(rk){const pr=DB.DCMI.find(q=>q.DC===DPS.dc&&String(q.Rack)===String(rk)),tot=rackU(DPS.dc,rk),used=Math.min(tot,(dUsed()[DPS.dc+'|'+rk]||0));return{pr:pr,load:pr?load(pr):null,tot:tot,used:used,upct:tot?Math.round(used/tot*100):0}}
/* ----- problems and summary ----- */
function dconf(rows){const c=rows.filter(x=>!DSKIP[x.r.Kind]).map(x=>({i:x.i,k:x.r.Kind,b:dbox(x.r)})),out=[],E=0.02;
const ins=(s,o)=>s.b.x>=o.b.x-E&&s.b.y>=o.b.y-E&&s.b.x+s.b.w<=o.b.x+o.b.w+E&&s.b.y+s.b.h<=o.b.y+o.b.h+E;
for(let a=0;a<c.length;a++)for(let b=a+1;b<c.length;b++){const p=c[a],q=c[b];
const ix=Math.min(p.b.x+p.b.w,q.b.x+q.b.w)-Math.max(p.b.x,q.b.x),iy=Math.min(p.b.y+p.b.h,q.b.y+q.b.h)-Math.max(p.b.y,q.b.y);if(ix<=E||iy<=E)continue;
const po=!!DOUT[p.k],qo=!!DOUT[q.k];if(po&&!qo&&ins(q,p))continue;if(qo&&!po&&ins(p,q))continue;out.push([p.i,q.i])}return out}
function dprob(){const rows=dcpRows(),pairs=dconf(rows),cf=new Set();pairs.forEach(p=>{cf.add(p[0]);cf.add(p[1])});
const inv=dcRacks(DPS.dc),linked={},dang=[],dup=[];
rows.forEach(x=>{if(DRKK[x.r.Kind]&&x.r.Rack){const k=String(x.r.Rack);if(inv.indexOf(k)<0){dang.push(x.i);cf.add(x.i)}(linked[k]=linked[k]||[]).push(x.i)}});
Object.keys(linked).forEach(k=>{if(linked[k].length>1){dup.push([k,linked[k]]);linked[k].forEach(i=>cf.add(i))}});
const miss=inv.filter(k=>!linked[k]);return{pairs:pairs,cf:cf,dang:dang,dup:dup,miss:miss,n:pairs.length+dang.length+dup.length+miss.length}}
function dsum(){const rows=dcpRows();let ld=0,lim=0,n=0;const seen={};
rows.forEach(x=>{const r=x.r;if(!DRKK[r.Kind]||!r.Rack||seen[r.Rack])return;seen[r.Rack]=1;const pr=DB.DCMI.find(q=>q.DC===DPS.dc&&String(q.Rack)===String(r.Rack));if(pr){ld+=num(pr['Power kW']);lim+=num(pr['Limit kW']);n++}});
const cap={'Cooling units':[],'Chiller':[],'UPS':[],'Generator':[]};
rows.forEach(x=>{const c=num(x.r['Capacity kW']);if(!(c>0))return;const k=x.r.Kind;if(k==='Cooling unit')cap['Cooling units'].push(c);else if(k==='Chiller')cap.Chiller.push(c);else if(k==='UPS / batteries')cap.UPS.push(c);else if(k==='Generator')cap.Generator.push(c)});
return{load:Math.round(ld*10)/10,lim:lim,n:n,cap:cap}}
function dInside(cont,rows){const b=dbox(cont);return rows.filter(x=>(DRKK[x.r.Kind]||x.r.Kind==='Network cabinet')&&(()=>{const q=dbox(x.r),cx=q.x+q.w/2,cy=q.y+q.h/2;return cx>=b.x&&cx<=b.x+b.w&&cy>=b.y&&cy<=b.y+b.h})())}
/* ----- SVG ----- */
const dhc=p=>p>=80?'#cf3b3b':p>=60?'#d98a1c':p>=40?'#2F66C4':'#7C9BD6';
function dmatch(r){const q=DPS.q.trim().toLowerCase();return !!q&&(String(r.Block||'').toLowerCase().indexOf(q)>=0||String(r.Rack||'').toLowerCase().indexOf(q)>=0||String(r.Kind||'').toLowerCase().indexOf(q)>=0)}
function dcpSvg(exp){
const S=exp?24:24*DPS.z,all=dcpRows(),rows=all.filter(x=>!DPS.hide[x.r.Kind]),sel=exp?[]:dsl();
let mx=0,my=0,x0=1e9,y0=1e9;all.forEach(x=>{const b=dbox(x.r);mx=Math.max(mx,b.x+b.w);my=Math.max(my,b.y+b.h);x0=Math.min(x0,b.x);y0=Math.min(y0,b.y)});
let W=Math.max(60,mx+6),H=Math.max(36,my+6),ox=0,oy=0;
if(exp){if(!all.length){x0=0;y0=0;mx=20;my=10}ox=Math.max(0,x0-2);oy=Math.max(0,y0-2);W=mx+2-ox;H=my+2-oy}
const T=(n,f)=>exp?f:'var('+n+')',cInk=T('--ink','#1b2430'),cAcc=T('--accent','#0E1116'),cMut=T('--muted','#5b6b82'),cL=T('--line','#d3dae6'),cL2=T('--line2','#e8ecf3');
const order=k=>k==='Zone'?0:/^Container/.test(k)?1:k==='Label'?3:2;
const sorted=rows.slice().sort((a,b)=>order(a.r.Kind)-order(b.r.Kind));
const heat=DPS.heat,CF=exp?new Set():DCF;let g='',dim='';
sorted.forEach(x=>{const r=x.r,b=dbox(r),w=b.ow*S,h=b.oh*S,px=dn(r,'X m')*S,py=dn(r,'Y m')*S,rot=b.rot,isSel=sel.indexOf(x.i)>=0;
let fill=dkc(r),txt=String(r.Block||''),sub='',op=1;
const rl=DRKK[r.Kind]&&r.Rack;
if(rl){const ri=dRackInfo(r.Rack);if(heat==='power'&&ri.load!=null){fill=dhc(ri.load);sub=ri.load+'%'}else if(heat==='u'){fill=dhc(ri.upct);sub=ri.upct+'% U'}else if(ri.load!=null)sub=ri.load+'%';if(heat!=='kind'&&ri.load==null&&heat==='power')fill='#9aa5b5'}
else if(heat!=='kind'&&r.Kind!=='Zone'&&r.Kind!=='Label')op=.4;
const zone=r.Kind==='Zone',lab=r.Kind==='Label',cx=px+w/2,cy=py+h/2,thin=Math.min(w,h)<12;
const cont=/^Container/.test(r.Kind)&&h>=26,fs=cont?Math.min(11*(exp?1:Math.max(.8,DPS.z)),14):Math.max(8,Math.min(13*(exp?1:DPS.z),Math.min(w,h)*.6,w/Math.max(4,txt.length)*1.6)),showTxt=lab||zone||(w>=22&&h>=10&&txt.length*fs*.56<=w*1.05);
const flip=rot===180?' transform="rotate(180 '+cx+' '+cy+')"':'';
const bad=CF.has(x.i),hit=!exp&&dmatch(r);
let st=isSel?cAcc:bad?'#d6336c':exp?'rgba(0,0,0,.4)':'rgba(0,0,0,.35)';
const sw=isSel?2.5:bad?2:1;
g+='<g class="blk'+(dlk(r)?' lk':'')+'" data-i="'+x.i+'" transform="rotate('+rot+' '+cx+' '+cy+')"'+(op<1?' opacity="'+op+'"':'')+'><title>'+esc((r.Block||'')+' · '+r.Kind+' · '+dn(r,'Width m')+' × '+dn(r,'Height m')+' m'+(r.Rack?' · rack '+r.Rack:'')+(num(r['Capacity kW'])>0?' · '+r['Capacity kW']+' kW':'')+(dlk(r)?' · locked':''))+'</title>'
+(hit?'<rect x="'+(px-4)+'" y="'+(py-4)+'" width="'+(w+8)+'" height="'+(h+8)+'" rx="5" fill="none" stroke="#f5b301" stroke-width="3"/>':'')
+(zone?'<rect x="'+px+'" y="'+py+'" width="'+w+'" height="'+h+'" rx="6" fill="'+fill+'" fill-opacity=".12" stroke="'+(isSel?cAcc:fill)+'" stroke-width="'+sw+'" stroke-dasharray="6 4" pointer-events="stroke"/><rect x="'+px+'" y="'+py+'" width="'+w+'" height="'+Math.min(24,h)+'" fill="transparent" pointer-events="all"/>'
:lab?'<rect x="'+px+'" y="'+py+'" width="'+w+'" height="'+h+'" fill="transparent"'+(isSel?' stroke="'+cAcc+'" stroke-dasharray="4 3"':'')+'/>'
:'<rect x="'+px+'" y="'+py+'" width="'+w+'" height="'+h+'" rx="2" fill="'+fill+'" stroke="'+st+'" stroke-width="'+sw+'"'+(bad&&!isSel?' stroke-dasharray="5 3"':'')+'/>'+(thin?'<rect x="'+(px-5)+'" y="'+(py-5)+'" width="'+(w+10)+'" height="'+(h+10)+'" fill="transparent"/>':''))
+(showTxt?'<text x="'+(lab||zone||cont?px+6:cx)+'" y="'+(lab||zone?py+fs+3:cont?py+fs+1:cy+(sub?-1:fs*.35))+'" text-anchor="'+(lab||zone||cont?'start':'middle')+'" font-size="'+fs+'" fill="'+(lab||zone?cInk:'#fff')+'" pointer-events="none"'+flip+'>'+esc(txt)+'</text>':'')
+(showTxt&&sub&&!lab&&!zone?'<text x="'+cx+'" y="'+(cy+fs*.95)+'" text-anchor="middle" font-size="'+Math.max(7,fs*.75)+'" fill="#fff" fill-opacity=".85" pointer-events="none"'+flip+'>'+sub+'</text>':'')
+(dlk(r)&&!exp&&!lab?'<path d="M'+(px+w-11)+' '+(py+7)+'v-2a2.5 2.5 0 0 1 5 0v2M'+(px+w-12.5)+' '+(py+7)+'h8v6h-8z" fill="rgba(255,255,255,.85)" stroke="rgba(0,0,0,.55)" stroke-width="1" pointer-events="none"/>':'')
+(isSel&&sel.length===1&&!dlk(r)?'<rect class="rsz" data-h="se" x="'+(px+w-5)+'" y="'+(py+h-5)+'" width="10" height="10" fill="'+cAcc+'" stroke="#fff"/><rect class="rsz rse" data-h="e" x="'+(px+w-4)+'" y="'+(py+h/2-5)+'" width="8" height="10" rx="2" fill="'+cAcc+'" stroke="#fff"/><rect class="rsz rss" data-h="s" x="'+(px+w/2-5)+'" y="'+(py+h-4)+'" width="10" height="8" rx="2" fill="'+cAcc+'" stroke="#fff"/>':'')+'</g>';
if(DPS.dims&&!lab&&!zone&&r.Kind!=='Door / entrance'&&b.w*S>34)dim+='<text x="'+(b.x*S+2)+'" y="'+(b.y*S-3)+'" font-size="9" fill="'+cMut+'" pointer-events="none">'+dr(b.ow)+' × '+dr(b.oh)+' m</text>'});
let ov='';
if(!exp){
if(sel.length>1){let a=1e9,c=1e9,d=0,e=0;sel.forEach(i=>{const b=dbox(DB.DCLayout[i]);a=Math.min(a,b.x);c=Math.min(c,b.y);d=Math.max(d,b.x+b.w);e=Math.max(e,b.y+b.h)});ov+='<rect x="'+(a*S-3)+'" y="'+(c*S-3)+'" width="'+((d-a)*S+6)+'" height="'+((e-c)*S+6)+'" fill="none" stroke="'+cAcc+'" stroke-dasharray="5 3" pointer-events="none"/>'}
DGUIDE.forEach(l=>{ov+='<line x1="'+l[0]*S+'" y1="'+l[1]*S+'" x2="'+l[2]*S+'" y2="'+l[3]*S+'" stroke="#d6336c" stroke-width="1" stroke-dasharray="4 3" pointer-events="none"/>'});
if(DRAG&&DRAG.mode==='box'&&DRAG.moved){const a=Math.min(DRAG.x0,DRAG.x1),c=Math.min(DRAG.y0,DRAG.y1),w=Math.abs(DRAG.x1-DRAG.x0),h=Math.abs(DRAG.y1-DRAG.y0);ov+='<rect x="'+a*S+'" y="'+c*S+'" width="'+w*S+'" height="'+h*S+'" fill="'+cAcc+'" fill-opacity=".1" stroke="'+cAcc+'" stroke-dasharray="4 3" pointer-events="none"/>'}
if(DRAG&&DRAG.lab){const t=DRAG.lab.t,tw=t.length*6.4+12;ov+='<g pointer-events="none"><rect x="'+(DRAG.lab.x*S)+'" y="'+(DRAG.lab.y*S-24)+'" width="'+tw+'" height="18" rx="4" fill="#1b2430" fill-opacity=".88"/><text x="'+(DRAG.lab.x*S+6)+'" y="'+(DRAG.lab.y*S-11)+'" font-size="11" fill="#fff">'+esc(t)+'</text></g>'}}
let ax='';const step=exp?5:(DPS.z<.6?10:5);
for(let i=step;i<W+ox;i+=step){if(i<ox)continue;ax+='<text x="'+((i-ox)*S+3)+'" y="10" font-size="9" fill="'+cMut+'" pointer-events="none">'+i+(i===step?' m':'')+'</text>'}
for(let i=step;i<H+oy;i+=step){if(i<oy)continue;ax+='<text x="3" y="'+((i-oy)*S-3)+'" font-size="9" fill="'+cMut+'" pointer-events="none">'+i+'</text>'}
const defs='<defs><pattern id="dcg1" width="'+S+'" height="'+S+'" patternUnits="userSpaceOnUse"><path d="M '+S+' 0 L 0 0 0 '+S+'" fill="none" stroke="'+cL2+'" stroke-width="1"/></pattern><pattern id="dcg5" width="'+S*5+'" height="'+S*5+'" patternUnits="userSpaceOnUse" patternTransform="translate('+(-ox*S)+' '+(-oy*S)+')"><rect width="'+S*5+'" height="'+S*5+'" fill="'+(DPS.grid||exp?'url(#dcg1)':'none')+'"/><path d="M '+S*5+' 0 L 0 0 0 '+S*5+'" fill="none" stroke="'+cL+'" stroke-width="1"/></pattern></defs>';
if(exp){
const used={};all.forEach(x=>used[x.r.Kind]=(used[x.r.Kind]||0)+1);const ks=Object.keys(used),HD=44,LG=ks.length?30:0,tw=W*S,th=H*S;
let lg='',lx=8;ks.forEach(k=>{lg+='<rect x="'+lx+'" y="'+(HD+th+10)+'" width="10" height="10" rx="2" fill="'+(DKIND[k]||{c:'#888'}).c+'"/><text x="'+(lx+14)+'" y="'+(HD+th+19)+'" font-size="11" fill="#1b2430">'+esc(k)+' ('+used[k]+')</text>';lx+=24+k.length*6.3+String(used[k]).length*6});
return '<svg xmlns="http://www.w3.org/2000/svg" width="'+tw+'" height="'+(th+HD+LG)+'" viewBox="0 0 '+tw+' '+(th+HD+LG)+'" font-family="Segoe UI,Arial,sans-serif"><rect width="100%" height="100%" fill="#fff"/><text x="8" y="22" font-size="16" font-weight="600" fill="#1b2430">'+esc(DPS.dc)+' – floor plan</text><text x="8" y="38" font-size="11" fill="#5b6b82">'+ds(0)+' · 1 grid square = 1 m, heavy lines every 5 m</text><g transform="translate(0 '+HD+')">'+defs+'<rect width="'+tw+'" height="'+th+'" fill="url(#dcg5)" stroke="#d3dae6"/><g transform="translate('+(-ox*S)+' '+(-oy*S)+')">'+g+dim+'</g>'+ax+'</g>'+lg+'</svg>'}
return '<svg id="dcp-svg" width="'+W*S+'" height="'+H*S+'" viewBox="0 0 '+W*S+' '+H*S+'" tabindex="0" role="img" aria-label="Floor plan of '+esc(DPS.dc)+'">'+defs+'<rect id="dcp-bg" width="100%" height="100%" fill="url(#dcg5)"/>'+ax+g+dim+ov+'</svg>'}
/* ----- panels ----- */
function dcpKpi(){const rows=dcpRows(),cont=rows.filter(x=>/^Container/.test(x.r.Kind)),area=cont.reduce((a,x)=>a+dn(x.r,'Width m')*dn(x.r,'Height m'),0),rk=rows.filter(x=>DRKK[x.r.Kind]).length,P=dprob(),S=dsum();DCF=P.cf;
return '<div class="kpi"><span>Blocks</span><b>'+rows.length+'</b><small>'+(DU.u.length?DU.u.length+' undo step'+(DU.u.length===1?'':'s'):'&nbsp;')+'</small></div><div class="kpi"><span>Containers</span><b>'+cont.length+'</b><small>'+r1(area)+' m² of containers</small></div><div class="kpi"><span>Racks on plan</span><b>'+rk+'</b><small>'+dcRackN(DPS.dc)+' in inventory</small></div><div class="kpi"><span>IT load</span><b>'+S.load+' kW</b><small>'+(S.lim?'of '+S.lim+' kW rack limits':'no rack power linked')+'</small></div><div class="kpi"><span>Problems</span><b>'+P.n+'</b><small class="'+(P.n?'bad':'')+'">'+(P.n?'see the list on the right':'plan is consistent')+'</small></div>'}
function dcapRow(name,arr,ld,needN1){const tot=arr.reduce((a,b)=>a+b,0);if(!arr.length)return '<tr><td>'+name+'</td><td colspan="2" class="note">no capacity set</td></tr>';
const mx=Math.max.apply(null,arr),pct=ld?Math.round(ld/tot*100):0,n1=arr.length>1&&tot-mx>=ld,cls=ld>tot?'b-bad':(needN1&&!n1)?'b-warn':'b-ok';
return '<tr><td>'+name+'</td><td>'+r1(tot)+' kW <span class="note">('+arr.length+')</span></td><td><span class="badge '+cls+'">'+pct+'%'+(needN1?(n1?' · N+1 ok':' · no N+1'):'')+'</span></td></tr>'}
function dcpOverview(){const rows=dcpRows(),by={};rows.forEach(x=>by[x.r.Kind]=(by[x.r.Kind]||0)+1);const P=dprob(),S=dsum();
let h='<h2>Plan overview</h2>'+(Object.keys(by).length?'<div class="dcp-lgs">'+Object.keys(by).map(k=>'<button class="dcp-lg'+(DPS.hide[k]?' off':'')+'" data-act="dcpkind" data-k="'+esc(k)+'" title="Show / hide this type"><i style="background:'+(DKIND[k]||{c:'#888'}).c+'"></i>'+esc(k)+'<b>'+by[k]+'</b></button>').join('')+'</div>':'<p class="note">This data center has no blocks yet. Pick a type above and click Add block, or use Quick add.</p>');
h+='<h3 class="dcp-h">Power and cooling</h3><table class="dcp-t"><tbody><tr><td>IT load</td><td>'+S.load+' kW</td><td>'+(S.lim?'<span class="note">of '+S.lim+' kW</span>':'')+'</td></tr>'+dcapRow('Cooling units',S.cap['Cooling units'],S.load,true)+(S.cap.Chiller.length?dcapRow('Chiller',S.cap.Chiller,S.load,false):'')+dcapRow('UPS',S.cap.UPS,S.load,true)+dcapRow('Generator',S.cap.Generator,S.load,false)+'</tbody></table><p class="note" style="margin:6px 0 0">Set “Capacity kW” on cooling, UPS and generator blocks. Load comes from DCMI readings of the linked racks.</p>';
h+='<h3 class="dcp-h">Problems ('+P.n+')</h3>';
if(!P.n)h+='<p class="note" style="margin:0">No overlaps, no unlinked or missing racks.</p>';
else{h+='<div class="dcp-pl">';
P.pairs.slice(0,8).forEach(p=>{h+='<button class="btn s" data-act="dcpgo" data-i="'+p.join(',')+'">Overlap: '+esc(DB.DCLayout[p[0]].Block)+' × '+esc(DB.DCLayout[p[1]].Block)+'</button>'});
if(P.pairs.length>8)h+='<span class="note">+ '+(P.pairs.length-8)+' more overlaps</span>';
P.dang.forEach(i=>{h+='<button class="btn s" data-act="dcpgo" data-i="'+i+'">'+esc(DB.DCLayout[i].Block)+' links to rack “'+esc(DB.DCLayout[i].Rack)+'” which is not in Settings → Racks</button>'});
P.dup.forEach(d=>{h+='<button class="btn s" data-act="dcpgo" data-i="'+d[1].join(',')+'">Rack '+esc(d[0])+' is placed '+d[1].length+' times</button>'});
if(P.miss.length)h+='<button class="btn s p" data-act="dcpmissing">Add '+P.miss.length+' rack'+(P.miss.length===1?'':'s')+' from inventory that are not on the plan ('+esc(P.miss.slice(0,4).join(', '))+(P.miss.length>4?'…':'')+')</button>';
h+='</div>'}
h+='<details class="dcp-keys"><summary>Mouse and keyboard</summary><ul><li>Drag a block to move it, drag the handles to resize. Drag empty space to select several; Shift+click adds or removes.</li><li>Pink guides show alignment with other blocks; hold Alt to turn them off, Shift to keep one direction.</li><li>Arrow keys nudge (Shift = 1 m, Alt = 0.1 m). R rotate, L lock, Delete remove, Ctrl+Z / Ctrl+Y undo / redo, Ctrl+A select all, Ctrl+C / Ctrl+V / Ctrl+D copy, paste, duplicate.</li><li>Ctrl+wheel zooms at the cursor, Space+drag or middle button pans, F fits the plan.</li></ul></details>';return h}
function dcpFld(r,k,l,t,step,ro){return '<label>'+l+'<input class="inp" data-act="dcpf" data-f="'+k+'" type="'+(t||'text')+'"'+(step?' step="'+step+'"':'')+' value="'+esc(r[k]==null?'':r[k])+'"></label>'}
function dcpPanel(){const a=dsl();if(!a.length)return dcpOverview();
if(a.length>1){const rows=a.map(i=>DB.DCLayout[i]),by={};rows.forEach(r=>by[r.Kind]=(by[r.Kind]||0)+1);const lk=rows.filter(dlk).length;
return '<h2>'+a.length+' blocks selected</h2><p class="note" style="margin:0 0 8px">'+Object.keys(by).map(k=>by[k]+' × '+esc(k)).join(', ')+(lk?' · '+lk+' locked (they stay where they are)':'')+'</p>'
+'<div class="dcp-bg"><span class="note">Align</span><button class="btn s" data-act="dcpalign" data-m="l" title="Align left edges">⇤ Left</button><button class="btn s" data-act="dcpalign" data-m="cx" title="Center horizontally">↔ Center</button><button class="btn s" data-act="dcpalign" data-m="r" title="Align right edges">⇥ Right</button><button class="btn s" data-act="dcpalign" data-m="t" title="Align top edges">⤒ Top</button><button class="btn s" data-act="dcpalign" data-m="cy" title="Center vertically">↕ Middle</button><button class="btn s" data-act="dcpalign" data-m="b" title="Align bottom edges">⤓ Bottom</button></div>'
+'<div class="dcp-bg"><span class="note">Spread</span><button class="btn s" data-act="dcpdist" data-m="h"'+(a.length<3?' disabled':'')+'>Distribute horizontally</button><button class="btn s" data-act="dcpdist" data-m="v"'+(a.length<3?' disabled':'')+'>Distribute vertically</button></div>'
+'<div class="dcp-bg"><span class="note">Size</span><button class="btn s" data-act="dcpsame" data-m="w">Same width</button><button class="btn s" data-act="dcpsame" data-m="h">Same height</button></div>'
+'<label class="wide" style="display:block;margin:10px 0 0">Color for all<input class="inp" type="color" data-act="dcpcolall" value="#6b7b92" style="padding:2px;height:36px;width:100%"></label>'
+'<div class="tools" style="margin-top:12px"><button class="btn s" data-act="dcprot" title="Rotate the group around its center (R)">Rotate 90°</button><button class="btn s" data-act="dcpdup">Duplicate</button><button class="btn s" data-act="dcplock">'+(lk===a.length?'Unlock':'Lock')+'</button><button class="btn s d" data-act="dcpdel">Delete</button><button class="btn s" data-act="dcpsel0">Deselect</button></div>'}
const i=a[0],r=DB.DCLayout[i],rackLink=!!DRKK[r.Kind],cont=/^Container/.test(r.Kind);let info='';
if(rackLink&&r.Rack){const ri=dRackInfo(r.Rack);info='<p class="note" style="margin:8px 0 0">Rack '+esc(r.Rack)+': '+ri.used+' of '+ri.tot+' U used ('+ri.upct+'%)'+(ri.pr?' · power '+esc(ri.pr['Power kW'])+' of '+esc(ri.pr['Limit kW'])+' kW ('+ri.load+'%) · inlet '+esc(ri.pr['Inlet C'])+' °C':' · no DCMI reading')+'. <a href="#racks">Open rack layout</a></p>'}
else if(rackLink)info='<p class="note" style="margin:8px 0 0">Link a rack to see its power and U usage here.</p>';
if(cont){const ins=dInside(r,dcpRows()),ld=ins.reduce((s,x)=>{const pr=x.r.Rack&&DB.DCMI.find(q=>q.DC===DPS.dc&&String(q.Rack)===String(x.r.Rack));return s+(pr?num(pr['Power kW']):0)},0);info='<p class="note" style="margin:8px 0 0">Inside: '+ins.length+' rack/cabinet block'+(ins.length===1?'':'s')+(ins.length?' ('+esc(ins.slice(0,8).map(x=>x.r.Block).join(', '))+(ins.length>8?'…':'')+')':'')+' · IT load '+r1(ld)+' kW · floor area '+r1(dn(r,'Width m')*dn(r,'Height m'))+' m²</p>'}
const cp=DCAPK[r.Kind]?dcpFld(r,'Capacity kW',r.Kind==='UPS / batteries'?'Capacity (kW)':r.Kind==='Power cabinet'?'Rating (kW)':r.Kind==='Generator'?'Output (kW)':'Cooling capacity (kW)','number','1'):'';
return '<h2>'+esc(r.Block||'Block')+(dlk(r)?' <span class="badge b-off">locked</span>':'')+'</h2><div class="fgrid" style="grid-template-columns:repeat(2,minmax(0,1fr))">'
+'<label class="wide">Name<input class="inp" data-act="dcpf" data-f="Block" value="'+esc(r.Block||'')+'"></label>'
+'<label class="wide">Type<select class="inp" data-act="dcpf" data-f="Kind">'+Object.keys(DKIND).map(k=>'<option'+(r.Kind===k?' selected':'')+'>'+esc(k)+'</option>').join('')+'</select></label>'
+dcpFld(r,'X m','X (m)','number','0.1')+dcpFld(r,'Y m','Y (m)','number','0.1')+dcpFld(r,'Width m','Width (m)','number','0.1')+dcpFld(r,'Height m','Height (m)','number','0.1')
+'<label>Rotation<select class="inp" data-act="dcpf" data-f="Rotation">'+['0','90','180','270'].map(o=>'<option'+(String(drot(r))===o?' selected':'')+'>'+o+'</option>').join('')+'</select></label>'
+'<label>Color<span style="display:flex;gap:6px"><input class="inp" type="color" data-act="dcpf" data-f="Color" value="'+(dhx(dkc(r))?dkc(r):'#5b6b82')+'" style="padding:2px;height:40px;flex:1;min-width:0">'+(r.Color?'<button class="btn s" data-act="dcpcolor0" title="Back to the default color of this type">↺</button>':'')+'</span></label>'
+cp
+(rackLink?'<label class="wide">Linked rack (from Settings → Racks)<select class="inp" data-act="dcpf" data-f="Rack"><option value=""></option>'+dcRacks(r.DC).map(x=>'<option'+(String(r.Rack)===x?' selected':'')+'>'+esc(x)+'</option>').join('')+'</select></label>':'')
+'<label class="wide chkrow"><input type="checkbox" data-act="dcpf" data-f="Locked"'+(dlk(r)?' checked':'')+'> Locked (cannot be moved or resized by mistake)</label>'
+'<label class="wide">Notes<textarea class="inp" rows="3" data-act="dcpf" data-f="Notes">'+esc(r.Notes||'')+'</textarea></label></div>'+info
+(drot(r)?'<p class="note" style="margin:8px 0 0">X / Y / size are of the unrotated block; it is turned around its center.</p>':'')
+'<div class="tools" style="margin-top:12px"><button class="btn s" data-act="dcprot">Rotate 90°</button><button class="btn s" data-act="dcpdup">Duplicate</button><button class="btn s" data-act="dcplock">'+(dlk(r)?'Unlock':'Lock')+'</button><button class="btn s" data-act="dcpfront">To front</button><button class="btn s" data-act="dcpback">To back</button><button class="btn s d" data-act="dcpdel">Delete</button><button class="btn s" data-act="dcpsel0">Deselect</button></div>'}
function dcpStatus(){const m=$('dcp-msg');if(!m)return;if(DMSG){m.textContent=DMSG;return}const a=dsl();m.textContent=a.length===1?(DB.DCLayout[a[0]].Block+' · '+dr(dbox(DB.DCLayout[a[0]]).ow)+' × '+dr(dbox(DB.DCLayout[a[0]]).oh)+' m'):a.length>1?a.length+' blocks selected':'1 grid square = 1 m, heavy lines every 5 m. A 40 ft container is 12.19 × 2.44 m.'}
function dcpDraw(){const b=$('dcp-svgbox');if(b)b.innerHTML=dcpSvg()}
function dcpTbUpd(){const u=document.querySelector('[data-act=dcpundo]'),r=document.querySelector('[data-act=dcpredo]');if(u)u.disabled=!DU.u.length;if(r)r.disabled=!DU.r.length;const z=$('dcp-zp');if(z)z.textContent=Math.round(DPS.z*100)+'%'}
function dcpFull(){DU.cur=dsnapJ();const k=$('dcp-kpis');if(k)k.innerHTML=dcpKpi();dcpDraw();const p=$('dcp-panel');if(p)p.innerHTML=dcpPanel();dcpStatus();dcpTbUpd()}
function dcpLater(){if(DRAF)return;DRAF=requestAnimationFrame(()=>{DRAF=0;if(DRAG&&DRAG.mode!=='box'&&dcpRows().length<=150)DCF=dprob().cf;dcpDraw()})}
const DPRESET={'c8':'40 ft container + 8 racks + 2 cooling units','c4':'20 ft container + 4 racks + 1 cooling unit','row6':'Row of 6 racks','pow':'Power block (UPS, cabinet, generator)'};
function dcdesignView(){
if(!DPS.dc||DCS.indexOf(DPS.dc)<0)DPS.dc=DCS[0]||'';
if(DU.cur&&DU.cur!==dsnapJ()){DU.u.length=0;DU.r.length=0}
dfix();if(!DPS.fitted&&window.innerWidth<700){DPS.fitted=1;setTimeout(dfit,0)}
const q=DKIND;
return head('DC designer','Floor plan of a container data center. Add blocks (containers, racks, cooling, UPS…), drag them around, resize and rotate them. Saved in the sheet “DCLayout”.','<div class="chips">'+DCS.map(dc=>'<button class="chip'+(DPS.dc===dc?' on':'')+'" data-act="dcpdc" data-v="'+esc(dc)+'">'+esc(dc)+'</button>').join('')+'</div>')
+'<div class="kpis" id="dcp-kpis">'+dcpKpi()+'</div>'
+'<section class="card"><div class="tools dcp-tb"><select class="inp" id="dcp-kind" style="width:auto" aria-label="Block type">'+Object.keys(q).map(k=>'<option>'+esc(k)+'</option>').join('')+'</select><button class="btn p" data-act="dcpadd">+ Add block</button>'
+'<select class="inp" id="dcp-prs" data-act="dcpprs" style="width:auto" aria-label="Quick add"><option value="">Quick add…</option>'+Object.keys(DPRESET).map(k=>'<option value="'+k+'">'+esc(DPRESET[k])+'</option>').join('')+'</select>'
+'<input class="inp" id="dcp-q" data-act="dcpq" type="search" placeholder="Find block or rack…" aria-label="Find block" style="width:180px" value="'+esc(DPS.q)+'">'
+'<span class="tools" style="margin-left:auto"><button class="btn s" data-act="dcpundo" title="Undo (Ctrl+Z)"'+(DU.u.length?'':' disabled')+'>↶ Undo</button><button class="btn s" data-act="dcpredo" title="Redo (Ctrl+Y)"'+(DU.r.length?'':' disabled')+'>↷ Redo</button>'
+'<button class="btn s" data-act="dcpzoom" data-d="-1" aria-label="Zoom out">−</button><span class="note" style="margin:0;min-width:38px;text-align:center" id="dcp-zp">'+Math.round(DPS.z*100)+'%</span><button class="btn s" data-act="dcpzoom" data-d="1" aria-label="Zoom in">+</button><button class="btn s" data-act="dcpfit" title="Fit the plan in the window (F)">Fit</button>'
+'<select class="inp" data-act="dcpopt" data-o="snap" style="width:auto" aria-label="Snap to grid">'+[['0.1','Snap 0.1 m'],['0.5','Snap 0.5 m'],['1','Snap 1 m'],['0','No snap']].map(o=>'<option value="'+o[0]+'"'+(String(DPS.snap)===o[0]?' selected':'')+'>'+o[1]+'</option>').join('')+'</select>'
+'<details class="menu"><summary class="btn s">View</summary><div class="pop"><label class="note" for="dcp-heat">Color racks by<select class="inp" id="dcp-heat" data-act="dcpopt" data-o="heat"><option value="kind"'+(DPS.heat==='kind'?' selected':'')+'>Type</option><option value="power"'+(DPS.heat==='power'?' selected':'')+'>Power load</option><option value="u"'+(DPS.heat==='u'?' selected':'')+'>U usage</option></select></label>'
+'<label class="chkrow"><input type="checkbox" data-act="dcpopt" data-o="grid"'+(DPS.grid?' checked':'')+'> Show grid</label><label class="chkrow"><input type="checkbox" data-act="dcpopt" data-o="dims"'+(DPS.dims?' checked':'')+'> Show sizes</label><label class="chkrow"><input type="checkbox" data-act="dcpopt" data-o="guides"'+(DPS.guides?' checked':'')+'> Alignment guides</label></div></details>'
+'<details class="menu"><summary class="btn s">Export</summary><div class="pop"><button class="btn" data-act="dcpexp" data-k="svg">Download SVG</button><button class="btn" data-act="dcpexp" data-k="png">Download PNG</button><span class="note">Light background, with title, date and legend. Uses all blocks of '+esc(DPS.dc)+'.</span></div></details></span></div>'
+'<div class="row" style="align-items:flex-start;flex-wrap:wrap"><div style="flex:3 1 560px;min-width:0"><div class="dcp-box" id="dcp-svgbox">'+dcpSvg()+'</div><p class="note" style="margin:8px 0 0" id="dcp-msg">'+esc(DMSG)+'</p></div><div style="flex:1 1 300px;min-width:0" id="dcp-panel">'+dcpPanel()+'</div></div></section>'}
/* ----- editing operations ----- */
function dsel1(){return dsl().map(i=>({i:i,r:DB.DCLayout[i]}))}
function dgroup(items){let a=1e9,c=1e9,d=0,e=0;items.forEach(x=>{const b=dbox(x.r);a=Math.min(a,b.x);c=Math.min(c,b.y);d=Math.max(d,b.x+b.w);e=Math.max(e,b.y+b.h)});return{x:a,y:c,w:d-a,h:e-c}}
function dedit(fn,msg){const items=dsel1().filter(x=>!dlk(x.r));if(!items.length){dmsg(dsl().length?'Locked blocks cannot be changed. Unlock them first.':'Select a block first');dcpStatus();return}
dpush();fn(items);items.forEach(x=>dstamp(x.r));changed();if(msg)dmsg(msg);dcpFull()}
function dcopy(){const a=dsel1();if(!a.length)return;DCLIP=a.map(x=>JSON.parse(JSON.stringify(x.r)));DPS.pasteN=0;dmsg(a.length+' block'+(a.length===1?'':'s')+' copied')}
function dpaste(offs){if(!DCLIP.length){dmsg('Nothing copied yet');return}
DPS.pasteN++;const off=offs?1:DPS.pasteN,same=DCLIP[0].DC===DPS.dc,idx=[];dpush();
DCLIP.forEach(c=>{const n=Object.assign({},c,{DC:DPS.dc,Rack:'',Locked:'No',Updated:ds(0)});n.Block=dname(String(c.Block||c.Kind));if(same){n['X m']=dr(dn(c,'X m')+off);n['Y m']=dr(dn(c,'Y m')+off)}DB.DCLayout.push(n);idx.push(DB.DCLayout.length-1)});
dsetSel(idx);changed();dmsg(idx.length+' block'+(idx.length===1?'':'s')+' pasted');dcpFull()}
function ddel(){const a=dsel1();if(!a.length)return;const k=a.filter(x=>!dlk(x.r));if(!k.length){dmsg('Locked blocks are not deleted. Unlock them first.');dcpStatus();return}
dpush();const del=new Set(k.map(x=>x.i));const keep=DB.DCLayout.filter((r,i)=>!del.has(i));DB.DCLayout.splice(0,DB.DCLayout.length,...keep);dsetSel([]);changed();dmsg(k.length+' block'+(k.length===1?'':'s')+' deleted · Ctrl+Z brings '+(k.length===1?'it':'them')+' back');dcpFull()}
function drotate(){dedit(items=>{const g=dgroup(items),gx=g.x+g.w/2,gy=g.y+g.h/2;items.forEach(x=>{const b=dbox(x.r),c=dRot(90,[b.x+b.w/2-gx,b.y+b.h/2-gy]),nx=gx+c[0],ny=gy+c[1];x.r.Rotation=String((drot(x.r)+90)%360);x.r['X m']=dr(nx-b.ow/2);x.r['Y m']=dr(ny-b.oh/2)})},'Rotated 90°')}
function dtoggleLock(){const a=dsel1();if(!a.length)return;const all=a.every(x=>dlk(x.r));dpush();a.forEach(x=>{x.r.Locked=all?'No':'Yes';dstamp(x.r)});changed();dmsg(all?'Unlocked':'Locked '+a.length+' block'+(a.length===1?'':'s'));dcpFull()}
function dzorder(front){const a=dsel1();if(a.length!==1)return;dpush();const r=a[0].r;const rest=DB.DCLayout.filter(x=>x!==r);if(front)rest.push(r);else rest.unshift(r);DB.DCLayout.splice(0,DB.DCLayout.length,...rest);dsetSel([DB.DCLayout.indexOf(r)]);changed();dmsg(front?'Moved to front':'Moved to back');dcpFull()}
function dalign(m){dedit(items=>{const g=dgroup(items);items.forEach(x=>{const b=dbox(x.r);let nx=b.x,ny=b.y;if(m==='l')nx=g.x;else if(m==='r')nx=g.x+g.w-b.w;else if(m==='cx')nx=g.x+g.w/2-b.w/2;else if(m==='t')ny=g.y;else if(m==='b')ny=g.y+g.h-b.h;else if(m==='cy')ny=g.y+g.h/2-b.h/2;dsetBox(x.r,nx,ny)})},'Aligned')}
function ddist(m){const a=dsel1().filter(x=>!dlk(x.r));if(a.length<3){dmsg('Select at least three blocks to distribute');dcpStatus();return}
dedit(items=>{const H=m==='h',s=items.slice().sort((p,q)=>{const a=dbox(p.r),b=dbox(q.r);return H?a.x-b.x:a.y-b.y}),f=dbox(s[0].r),l=dbox(s[s.length-1].r);let tot=0;s.forEach(x=>{const b=dbox(x.r);tot+=H?b.w:b.h});const span=H?(l.x+l.w-f.x):(l.y+l.h-f.y),gap=(span-tot)/(s.length-1);let pos=H?f.x:f.y;s.forEach(x=>{const b=dbox(x.r);if(H)dsetBox(x.r,pos,b.y);else dsetBox(x.r,b.x,pos);pos+=(H?b.w:b.h)+gap})},'Distributed')}
function dsame(m){dedit(items=>{const p=items.find(x=>x.i===DPS.sel)||items[0],pb=dbox(p.r);items.forEach(x=>{if(x===p)return;const b=dbox(x.r),q=b.rot===90||b.rot===270;const k=(m==='w')!==q?'Width m':'Height m';x.r[k]=m==='w'?dr(pb.w):dr(pb.h)})},'Sizes matched to the last selected block')}
function dgo(ids){const a=ids.filter(i=>DB.DCLayout[i]);dsetSel(a);dcpFull();const bx=$('dcp-svgbox');if(bx&&a.length){const b=dbox(DB.DCLayout[a[0]]),S=24*DPS.z;bx.scrollLeft=Math.max(0,b.x*S-bx.clientWidth/2);bx.scrollTop=Math.max(0,b.y*S-bx.clientHeight/2)}}
function dzoom(z,cx,cy){const bx=$('dcp-svgbox');z=Math.max(.25,Math.min(4,Math.round(z*100)/100));if(z===DPS.z)return;let mxm=0,mym=0,px=0,py=0;if(bx){const R=bx.getBoundingClientRect();px=cx==null?bx.clientWidth/2:cx-R.left;py=cy==null?bx.clientHeight/2:cy-R.top;mxm=(bx.scrollLeft+px)/(24*DPS.z);mym=(bx.scrollTop+py)/(24*DPS.z)}
DPS.z=z;dsave();dcpDraw();if(bx){bx.scrollLeft=mxm*24*z-px;bx.scrollTop=mym*24*z-py}dcpTbUpd()}
function dfit(){const bx=$('dcp-svgbox');if(!bx)return;const rows=dcpRows();if(!rows.length)return;let a=1e9,c=1e9,d=0,e=0;rows.forEach(x=>{const b=dbox(x.r);a=Math.min(a,b.x);c=Math.min(c,b.y);d=Math.max(d,b.x+b.w);e=Math.max(e,b.y+b.h)});
const z=Math.min((bx.clientWidth-20)/((d-a+2)*24),(Math.max(420,bx.clientHeight)-20)/((e-c+2)*24));DPS.z=Math.max(.25,Math.min(4,Math.floor(z*100)/100));dsave();dcpDraw();bx.scrollLeft=Math.max(0,(a-1)*24*DPS.z);bx.scrollTop=Math.max(0,(c-1)*24*DPS.z);dcpTbUpd()}
function dpreset(k){const P=dprob();let miss=P.miss.slice();const take=()=>miss.length?miss.shift():'';
const spec=[];const rack=(x,y)=>{const rk=take();spec.push(dmk('Rack',x,y,{Block:rk||undefined,Rack:rk}))};
if(k==='c8'||k==='c4'){const n=k==='c8'?8:4,cw=k==='c8'?12.19:6.06,kind=k==='c8'?'Container 40 ft':'Container 20 ft',w=cw+(k==='c8'?3:1.6),f=dfind(w+1,3.4),x=f[0]+1.4,y=f[1];
spec.push(dmk(kind,x,y));for(let i=0;i<n;i++)rack(x+.6+i*1.4,y+.62);
spec.push(dmk('Cooling unit',x-1.4,y+.7,{Block:undefined,'Capacity kW':30}));if(k==='c8')spec.push(dmk('Cooling unit',x+cw+.2,y+.7,{Block:undefined,'Capacity kW':30}))}
else if(k==='row6'){const f=dfind(9.4,1.6);for(let i=0;i<6;i++)rack(f[0]+i*1.4,f[1])}
else if(k==='pow'){const f=dfind(6.5,2.5);spec.push(dmk('UPS / batteries',f[0],f[1],{'Capacity kW':60}),dmk('Power cabinet',f[0]+1.8,f[1]),dmk('Generator',f[0]+3.2,f[1],{'Capacity kW':100}))}
if(!spec.length)return;dpush();const idx=[];
spec.forEach(r=>{if(r.Block===undefined||r.Block==='')r.Block=dname(r.Kind==='Rack'?'Rack':r.Kind);else r.Block=dname(r.Block);r['X m']=dsnap(r['X m']);r['Y m']=dsnap(r['Y m']);DB.DCLayout.push(r);idx.push(DB.DCLayout.length-1)});
dsetSel(idx);changed();dmsg(idx.length+' blocks added');dcpFull()}
function dmissing(){const P=dprob();if(!P.miss.length)return;dpush();let y=0,x=2;const f=dfind(Math.min(P.miss.length,12)*1.4,1.6);x=f[0];y=f[1];const idx=[];
P.miss.forEach((rk,n)=>{const row=Math.floor(n/12),col=n%12;DB.DCLayout.push(dmk('Rack',dsnap(x+col*1.4),dsnap(y+row*2),{Block:dname(rk),Rack:rk}));idx.push(DB.DCLayout.length-1)});
dsetSel(idx);changed();dmsg(idx.length+' rack'+(idx.length===1?'':'s')+' added from inventory');dcpFull()}
function dcpExport(kind){const svg=dcpSvg(true),name='floorplan-'+DPS.dc+'-'+ds(0);
if(kind==='svg'){if(dlBlob(name+'.svg',svg,'image/svg+xml'))toast('Floor plan saved as SVG');return}
const m=/ width="([\d.]+)" height="([\d.]+)"/.exec(svg);if(!m)return;const w=+m[1],h=+m[2];
const img=new Image(),url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));
img.onload=()=>{try{const c=document.createElement('canvas');c.width=Math.round(w*2);c.height=Math.round(h*2);const g=c.getContext('2d');g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);g.drawImage(img,0,0,c.width,c.height);URL.revokeObjectURL(url);c.toBlob(b=>{if(b){if(dlBlob(name+'.png',b,'image/png'))toast('Floor plan saved as PNG')}else toast('PNG export is blocked in this browser, use SVG')},'image/png')}catch(e){toast('PNG export is blocked in this browser, use SVG')}};
img.onerror=()=>{URL.revokeObjectURL(url);toast('PNG export failed, use SVG')};img.src=url}
/* ----- pointer interaction ----- */
function dmeters(e,R){const S=24*DPS.z;return[(e.clientX-R.left)/S,(e.clientY-R.top)/S]}
document.addEventListener('pointerdown',e=>{
const svg=e.target.closest&&e.target.closest('#dcp-svg');if(!svg)return;
const bx=$('dcp-svgbox');
if(e.button===1||DPS.space){e.preventDefault();DRAG={mode:'pan',sx:e.clientX,sy:e.clientY,sl:bx.scrollLeft,st:bx.scrollTop};return}
if(e.button!==0)return;
const R=svg.getBoundingClientRect(),m=dmeters(e,R);
const h=e.target.classList&&e.target.classList.contains('rsz')?e.target.dataset.h:null;
const g=e.target.closest('.blk');
if(!g){const add=e.shiftKey||e.ctrlKey||e.metaKey;DRAG={mode:'box',R:R,x0:m[0],y0:m[1],x1:m[0],y1:m[1],add:add,base:add?dsl():[],moved:false};if(!add&&dsl().length){dsetSel([]);dcpFull()}try{svg.focus({preventScroll:true})}catch(x){}return}
const i=+g.dataset.i,r=DB.DCLayout[i];if(!r)return;e.preventDefault();
if(h&&dsl().length===1&&dsl()[0]===i&&!dlk(r)){const b=dbox(r),rot=b.rot,c=[b.x+b.w/2,b.y+b.h/2],v=dRot(rot,[-b.ow/2,-b.oh/2]);
DRAG={mode:'size',i:i,h:h,sx:e.clientX,sy:e.clientY,ow:b.ow,oh:b.oh,rot:rot,ax:c[0]+v[0],ay:c[1]+v[1],moved:false,pre:dsnapJ()};try{svg.focus({preventScroll:true})}catch(x){}return}
const tog=e.shiftKey||e.ctrlKey||e.metaKey;let cur=dsl();
if(tog){const k=cur.indexOf(i);if(k>=0)cur.splice(k,1);else cur.push(i);dsetSel(cur);dcpFull();try{svg.focus({preventScroll:true})}catch(x){}return}
if(cur.indexOf(i)<0){cur=[i];dsetSel(cur);dcpFull()}else if(DPS.sel!==i){DPS.sel=i;dcpFull()}
const items=cur.map(k=>({i:k,r:DB.DCLayout[k]})).filter(x=>!dlk(x.r));
if(items.length){const gb=dgroup(items);DRAG={mode:'move',sx:e.clientX,sy:e.clientY,items:items.map(x=>({i:x.i,b:dbox(x.r)})),gx:gb.x,gy:gb.y,gw:gb.w,gh:gb.h,moved:false,pre:dsnapJ(),gi:i,multi:cur.length>1}}
try{svg.focus({preventScroll:true})}catch(x){}});
function dsnapMove(nx,ny,alt){const S=24*DPS.z,thr=7/S;DGUIDE=[];
const others=dcpRows().filter(x=>!DPS.hide[x.r.Kind]&&x.r.Kind!=='Zone'&&x.r.Kind!=='Label'&&DRAG.items.every(it=>it.i!==x.i)).map(x=>dbox(x.r));
let gx=null,gy=null;
if(DPS.guides&&!alt){let bx=thr,by=thr,bxv=0,byv=0;const xs=[nx,nx+DRAG.gw/2,nx+DRAG.gw],ys=[ny,ny+DRAG.gh/2,ny+DRAG.gh];
others.forEach(o=>{[o.x,o.x+o.w/2,o.x+o.w].forEach(v=>xs.forEach(c=>{const d=Math.abs(c-v);if(d<bx-1e-9){bx=d;bxv=v-c}}));[o.y,o.y+o.h/2,o.y+o.h].forEach(v=>ys.forEach(c=>{const d=Math.abs(c-v);if(d<by-1e-9){by=d;byv=v-c}}))});
if(bx<thr){nx+=bxv;gx=1}if(by<thr){ny+=byv;gy=1}}
if(gx==null&&DPS.snap)nx=Math.round(nx/DPS.snap)*DPS.snap;if(gy==null&&DPS.snap)ny=Math.round(ny/DPS.snap)*DPS.snap;
nx=Math.max(0,nx);ny=Math.max(0,ny);
if(gx||gy){const xs=[nx,nx+DRAG.gw/2,nx+DRAG.gw],ys=[ny,ny+DRAG.gh/2,ny+DRAG.gh];
others.forEach(o=>{if(gx)[o.x,o.x+o.w/2,o.x+o.w].forEach(v=>{if(xs.some(c=>Math.abs(c-v)<1e-6))DGUIDE.push([v,Math.min(ny,o.y),v,Math.max(ny+DRAG.gh,o.y+o.h)])});if(gy)[o.y,o.y+o.h/2,o.y+o.h].forEach(v=>{if(ys.some(c=>Math.abs(c-v)<1e-6))DGUIDE.push([Math.min(nx,o.x),v,Math.max(nx+DRAG.gw,o.x+o.w),v])})})}
return[nx,ny]}
document.addEventListener('pointermove',e=>{if(!DRAG)return;const S=24*DPS.z,bx=$('dcp-svgbox');
if(DRAG.mode==='pan'){bx.scrollLeft=DRAG.sl-(e.clientX-DRAG.sx);bx.scrollTop=DRAG.st-(e.clientY-DRAG.sy);return}
if(DRAG.mode==='box'){DRAG.x1=(e.clientX-DRAG.R.left)/S;DRAG.y1=(e.clientY-DRAG.R.top)/S;if(Math.abs(DRAG.x1-DRAG.x0)+Math.abs(DRAG.y1-DRAG.y0)>.15)DRAG.moved=true;if(DRAG.moved)dcpLater();return}
let dx=(e.clientX-DRAG.sx)/S,dy=(e.clientY-DRAG.sy)/S;if(!DRAG.moved&&Math.abs(dx)+Math.abs(dy)<.08)return;DRAG.moved=true;
if(DRAG.mode==='move'){if(e.shiftKey){if(Math.abs(dx)>Math.abs(dy))dy=0;else dx=0}
const p=dsnapMove(DRAG.gx+dx,DRAG.gy+dy,e.altKey);DRAG.items.forEach(it=>dsetBox(DB.DCLayout[it.i],it.b.x+(p[0]-DRAG.gx),it.b.y+(p[1]-DRAG.gy)));DRAG.lab={x:p[0],y:p[1],t:'X '+dr(p[0])+' · Y '+dr(p[1])+' m'}}
else if(DRAG.mode==='size'){const r=DB.DCLayout[DRAG.i],R=dRot(-DRAG.rot,[dx,dy]);let w=DRAG.ow,h=DRAG.oh;if(DRAG.h!=='s')w=Math.max(.1,dsnap(DRAG.ow+R[0]));if(DRAG.h!=='e')h=Math.max(.1,dsnap(DRAG.oh+R[1]));
const c=dRot(DRAG.rot,[w/2,h/2]);r['Width m']=dr(w);r['Height m']=dr(h);r['X m']=dr(DRAG.ax+c[0]-w/2);r['Y m']=dr(DRAG.ay+c[1]-h/2);const b=dbox(r);DRAG.lab={x:b.x,y:b.y,t:dr(w)+' × '+dr(h)+' m'}}
dcpLater()});
document.addEventListener('pointerup',()=>{if(!DRAG)return;const d=DRAG;DRAG=null;DGUIDE=[];
if(d.mode==='pan')return;
if(d.mode==='box'){if(d.moved){const a=Math.min(d.x0,d.x1),c=Math.min(d.y0,d.y1),b=Math.max(d.x0,d.x1),e=Math.max(d.y0,d.y1),hit=dcpRows().filter(x=>!DPS.hide[x.r.Kind]).filter(x=>{const q=dbox(x.r);return q.x>=a-1e-6&&q.y>=c-1e-6&&q.x+q.w<=b+1e-6&&q.y+q.h<=e+1e-6}).map(x=>x.i);
const set=d.add?d.base.concat(hit.filter(i=>d.base.indexOf(i)<0)):hit;dsetSel(set)}dcpFull();return}
if(!d.moved&&d.mode==='move'&&d.multi){dsetSel([d.gi]);dcpFull();return}
if(d.moved){dpush(d.pre);const items=d.mode==='move'?d.items.map(it=>DB.DCLayout[it.i]):[DB.DCLayout[d.i]];items.forEach(dstamp);changed()}
dcpFull()});
document.addEventListener('wheel',e=>{if(CUR!=='dcdesign'||!(e.ctrlKey||e.metaKey))return;const bx=e.target.closest&&e.target.closest('#dcp-svgbox');if(!bx)return;e.preventDefault();dzoom(DPS.z*(e.deltaY<0?1.12:1/1.12),e.clientX,e.clientY)},{passive:false});
document.addEventListener('keyup',e=>{if(e.key===' '&&DPS.space){DPS.space=false;const s=$('dcp-svgbox');if(s)s.classList.remove('pan')}});
document.addEventListener('keydown',e=>{if(CUR!=='dcdesign')return;const t=e.target;
if(t&&t.id==='dcp-q'){if(e.key==='Enter'){e.preventDefault();const m=dcpRows().filter(x=>!DPS.hide[x.r.Kind]&&dmatch(x.r)).map(x=>x.i);if(m.length){dgo(m);dmsg(m.length+' block'+(m.length===1?'':'s')+' found')}else dmsg('Nothing found')}else if(e.key==='Escape'){t.value='';DPS.q='';dcpDraw()}return}
if(!(t===document.body||t.id==='dcp-svg'||t.tagName==='BUTTON'||(t.closest&&t.closest('#dcp-svgbox'))))return;
const k=e.key,ctrl=e.ctrlKey||e.metaKey;
if(k===' '&&t.tagName!=='BUTTON'){DPS.space=true;e.preventDefault();const s=$('dcp-svgbox');if(s)s.classList.add('pan');return}
if(ctrl&&/^[zZ]$/.test(k)){e.preventDefault();if(e.shiftKey)dredo();else dundo();return}
if(ctrl&&/^[yY]$/.test(k)){e.preventDefault();dredo();return}
if(ctrl&&/^[aA]$/.test(k)){e.preventDefault();dsetSel(dcpRows().filter(x=>!DPS.hide[x.r.Kind]).map(x=>x.i));dcpFull();return}
if(ctrl&&/^[cC]$/.test(k)){if(window.getSelection&&String(window.getSelection()))return;if(dsl().length){e.preventDefault();dcopy();dcpStatus()}return}
if(ctrl&&/^[vV]$/.test(k)){if(DCLIP.length){e.preventDefault();dpaste()}return}
if(ctrl&&/^[dD]$/.test(k)){e.preventDefault();if(dsl().length){dcopy();dpaste(1)}return}
if(ctrl)return;
if(k==='Delete'||k==='Backspace'){if(dsl().length){e.preventDefault();ddel()}return}
if(k==='Escape'){if(dsl().length){dsetSel([]);dcpFull()}return}
if(/^[rR]$/.test(k)){if(dsl().length)drotate();return}
if(/^[lL]$/.test(k)){if(dsl().length)dtoggleLock();return}
if(/^[fF0]$/.test(k)){dfit();return}
if(k==='+'||k==='='){dzoom(DPS.z*1.25);return}
if(k==='-'||k==='_'){dzoom(DPS.z/1.25);return}
const st=e.shiftKey?1:e.altKey?.1:(DPS.snap||.1);let dx=0,dy=0;
if(k==='ArrowLeft')dx=-st;else if(k==='ArrowRight')dx=st;else if(k==='ArrowUp')dy=-st;else if(k==='ArrowDown')dy=st;else return;
if(!dsl().length)return;e.preventDefault();
const items=dsel1().filter(x=>!dlk(x.r));if(!items.length){dmsg('Locked blocks cannot be moved');dcpStatus();return}
dpush();const g=dgroup(items),nx=Math.max(0,g.x+dx),ny=Math.max(0,g.y+dy);items.forEach(x=>{const b=dbox(x.r);dsetBox(x.r,b.x+(nx-g.x),b.y+(ny-g.y));dstamp(x.r)});changed();dcpFull()});
function dcpField(el){const r=DB.DCLayout[DPS.sel];if(!r)return;const f=el.dataset.f;let v=el.type==='checkbox'?(el.checked?'Yes':'No'):el.value;
if(f==='X m'||f==='Y m'||f==='Width m'||f==='Height m'||f==='Capacity kW'){v=parseFloat(v);if(isNaN(v))v='';else if(f!=='Capacity kW'){v=Math.max(f==='X m'||f==='Y m'?0:.1,v)}}
if(String(r[f]==null?'':r[f])===String(v))return;
dpush();r[f]=v;if(f==='Kind'&&!DRKK[v])r.Rack='';dstamp(r);changed();
if(/^(Kind|Rack|Locked|Rotation)$/.test(f))dcpFull();else{DU.cur=dsnapJ();const k=$('dcp-kpis');if(k)k.innerHTML=dcpKpi();dcpDraw();if(f==='Block'){const h=document.querySelector('#dcp-panel h2');if(h)h.textContent=r.Block||'Block'}dcpStatus();dcpTbUpd()}}
function dcpPrs(el){const k=el.value;el.value='';if(k)dpreset(k)}
function dcpColAll(el){dedit(items=>items.forEach(x=>x.r.Color=el.value),'Color set')}
function dcpSearch(el){DPS.q=el.value;dcpDraw()}
function dcpOpt(el){const o=el.dataset.o;if(o==='snap')DPS.snap=parseFloat(el.value);else if(o==='heat')DPS.heat=el.value;else DPS[o]=el.checked;dsave();dcpFull()}
const DCPACT={
dcpdc(el){DPS.dc=el.dataset.v;dsetSel([]);DU.u.length=0;DU.r.length=0;route()},
dcpadd(){const k=$('dcp-kind').value,d=DKIND[k],f=dfind(Math.max(d.w,.8)+.6,Math.max(d.h,.6)+.6);dpush();DB.DCLayout.push(dmk(k,dsnap(f[0]),dsnap(f[1])));dsetSel([DB.DCLayout.length-1]);changed();dmsg(k+' added');dcpFull()},
dcprot(){drotate()},
dcpdup(){dcopy();dpaste(1)},
dcpdel(){ddel()},
dcpsel0(){dsetSel([]);dcpFull()},
dcpzoom(el){dzoom(DPS.z*(+el.dataset.d>0?1.25:1/1.25))},
dcpfit(){dfit()},
dcpundo(){dundo()},dcpredo(){dredo()},
dcplock(){dtoggleLock()},dcpfront(){dzorder(true)},dcpback(){dzorder(false)},
dcpalign(el){dalign(el.dataset.m)},dcpdist(el){ddist(el.dataset.m)},dcpsame(el){dsame(el.dataset.m)},
dcpcolor0(){const r=DB.DCLayout[DPS.sel];if(!r)return;dpush();r.Color='';dstamp(r);changed();dcpFull()},
dcpkind(el){const k=el.dataset.k;DPS.hide[k]=!DPS.hide[k];if(DPS.hide[k])dsetSel(dsl().filter(i=>DB.DCLayout[i].Kind!==k));dcpFull()},
dcpgo(el){dgo(String(el.dataset.i).split(',').map(Number))},
dcpmissing(){dmissing()},
dcpexp(el){dcpExport(el.dataset.k)}};
