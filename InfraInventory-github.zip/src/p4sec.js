/* ---------- login portal + encrypted workbook ----------
   File format: "IVENC001" | u32 header length | header JSON | 12 byte IV | AES-256-GCM ciphertext of the .xlsx (header is authenticated).
   One random data key per workbook. Every login holds its own wrapped copy of that key (PBKDF2-SHA256 + AES-GCM). */
const SEC={on:false,locked:false,loaded:false,key:null,raw:null,kid:'',hdr:null,user:'',admin:false};
const SEC_MAGIC='IVENC001',SEC_IT=250000,secEnc=new TextEncoder(),secDec=new TextDecoder();
function sb64(u8){let s='';for(let i=0;i<u8.length;i+=0x8000)s+=String.fromCharCode.apply(null,u8.subarray(i,i+0x8000));return btoa(s)}
function sub64(s){const b=atob(s),u=new Uint8Array(b.length);for(let i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u}
function secIsEnc(u8){if(!u8||u8.length<24)return false;for(let i=0;i<8;i++)if(u8[i]!==SEC_MAGIC.charCodeAt(i))return false;return true}
function secSplit(u8){const dv=new DataView(u8.buffer,u8.byteOffset,u8.byteLength),hl=dv.getUint32(8,true),hb=u8.subarray(12,12+hl);return{hb:hb,hdr:JSON.parse(secDec.decode(hb)),iv:u8.subarray(12+hl,24+hl),ct:u8.subarray(24+hl)}}
async function secFileEnc(f){try{return secIsEnc(new Uint8Array(await f.slice(0,24).arrayBuffer()))}catch(e){return false}}
async function secKek(pw,salt,it){const b=await crypto.subtle.importKey('raw',secEnc.encode(pw),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt:salt,iterations:it},b,{name:'AES-GCM',length:256},false,['encrypt','decrypt'])}
const secAad=(u,a)=>secEnc.encode(u+'|'+(a?1:0));
async function secWrap(raw,user,pw,admin,it){const salt=crypto.getRandomValues(new Uint8Array(16)),iv=crypto.getRandomValues(new Uint8Array(12)),k=await secKek(pw,salt,it);const w=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:iv,additionalData:secAad(user,admin)},k,raw));return{u:user,a:admin?1:0,s:sb64(salt),i:sb64(iv),w:sb64(w)}}
async function secUnwrap(hdr,user,pw){const e=(hdr.users||[]).find(x=>x.u===user);if(!e)return null;try{const k=await secKek(pw,sub64(e.s),hdr.it);const raw=new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:sub64(e.i),additionalData:secAad(user,e.a)},k,sub64(e.w)));return{raw:raw,key:await crypto.subtle.importKey('raw',raw,'AES-GCM',false,['encrypt','decrypt']),admin:!!e.a}}catch(x){return null}}
async function secEncrypt(buf){const hb=secEnc.encode(JSON.stringify(SEC.hdr)),iv=crypto.getRandomValues(new Uint8Array(12));
const ct=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:iv,additionalData:hb},SEC.key,buf instanceof Uint8Array?buf:new Uint8Array(buf)));
const out=new Uint8Array(24+hb.length+ct.length);out.set(secEnc.encode(SEC_MAGIC),0);new DataView(out.buffer).setUint32(8,hb.length,true);out.set(hb,12);out.set(iv,12+hb.length);out.set(ct,24+hb.length);return out.buffer}
async function secDecrypt(p,key){return new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:p.iv,additionalData:p.hb},key,p.ct))}
function secSetUser(){if(!SEC.on||!SEC.user)return;const o=((typeof DB!=='undefined'&&DB.Operators)||[]).find(x=>String(x.Username||'').trim().toLowerCase()===SEC.user);USER=o&&o.Name?String(o.Name):SEC.user}
function secAdopt(r,hdr){SEC.on=true;SEC.key=r.key;SEC.raw=r.raw;SEC.kid=hdr.kid;SEC.hdr=JSON.parse(JSON.stringify(hdr));SEC.user=r.user;SEC.admin=r.admin;try{localStorage.setItem('infra-login',r.user)}catch(e){}secSetUser()}
/* the login screen. Resolves {key,raw,user,admin} or null when cancelled. */
let SECQ=Promise.resolve();
function secPrompt(hdr,title,cancel,temp){const p=SECQ.then(()=>{if(SEC.key&&SEC.kid===hdr.kid)return{same:1};return secAsk(hdr,title,cancel)});SECQ=p.catch(()=>{});return p}
function secAsk(hdr,title,cancel){return new Promise(res=>{
const d=document.createElement('div');d.id='secov';d.setAttribute('role','dialog');d.setAttribute('aria-modal','true');d.setAttribute('aria-label',title);
d.style.cssText='position:fixed;inset:0;z-index:99999;background:var(--bg);color:var(--ink);display:flex;align-items:center;justify-content:center;padding:16px;font-family:var(--font)';
let last='';try{last=localStorage.getItem('infra-login')||''}catch(e){}
d.innerHTML='<div class="card" style="width:min(400px,100%);margin:0"><h2 style="margin:0 0 4px">'+esc(title)+'</h2><p class="note" style="margin:0 0 14px">Master inventory is encrypted. Enter your user name and password.</p>'
+'<label class="fl">User name<input class="inp" id="sec-u" autocomplete="username" spellcheck="false" value="'+esc(last)+'"></label>'
+'<label class="fl" style="margin-top:10px">Password<input class="inp" id="sec-p" type="password" autocomplete="current-password"></label>'
+'<div id="sec-e" class="note" role="alert" style="margin:10px 0 0;min-height:18px;color:var(--bad-c)"></div>'
+'<div class="tools" style="margin-top:8px;justify-content:space-between"><span>'+(cancel?'<button class="btn" id="sec-c" type="button">Cancel</button>':'')+'</span><button class="btn p" id="sec-go" type="button">Log in</button></div></div>';
document.body.appendChild(d);
const U=d.querySelector('#sec-u'),P=d.querySelector('#sec-p'),E=d.querySelector('#sec-e'),G=d.querySelector('#sec-go');let busy=false;
async function go(){if(busy)return;const u=U.value.trim().toLowerCase();if(!u||!P.value){E.textContent='Enter user name and password.';return}
busy=true;G.disabled=true;G.textContent='Checking…';E.textContent='';
const r=await secUnwrap(hdr,u,P.value);busy=false;G.disabled=false;G.textContent='Log in';
if(!r){E.textContent='Wrong user name or password.';P.value='';P.focus();return}
r.user=u;d.remove();res(r)}
G.addEventListener('click',go);d.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();go()}if(e.key==='Escape'&&cancel){d.remove();res(null)}});
const c=d.querySelector('#sec-c');if(c)c.addEventListener('click',()=>{d.remove();res(null)});
setTimeout(()=>(U.value?P:U).focus(),30)})}
/* read a workbook (plain or encrypted). temp: do not take over the login of that file. */
async function xlsxRead(src,opt){let u8=src instanceof Uint8Array?src:new Uint8Array(src);opt=opt||{};
if(secIsEnc(u8)){if(!(window.crypto&&crypto.subtle))throw new Error('This browser has no WebCrypto');const p=secSplit(u8);let key=null;
const r=await secPrompt(p.hdr,opt.temp?'Open encrypted workbook':'Log in',!opt.boot,opt.temp);
if(!r)throw new Error('cancelled');
if(r.same)key=SEC.key;else{key=r.key;if(!opt.temp)secAdopt(r,p.hdr)}
u8=await secDecrypt(p,key)}
return XLSX.read(u8,{type:'array',cellDates:true})}
function secBootCheck(){if(typeof EMBED_XLSX!=='string'||EMBED_XLSX.length<40)return false;let h='';try{h=atob(EMBED_XLSX.slice(0,16))}catch(e){return false}
if(h.slice(0,8)!==SEC_MAGIC)return false;SEC.locked=true;DB=seed();try{localStorage.removeItem(LS)}catch(e){}return true}
async function secBoot(){try{const u8=sub64(EMBED_XLSX);
const wb=await xlsxRead(u8,{boot:true});
if(!SEC.loaded){const m=EMBED_META||{};if(Array.isArray(EMBED_STUFF))META.stuff=EMBED_STUFF;applyWorkbook(wb,{name:m.file||'inventory.xlsx',modified:m.modified||'',generated:m.generated||''})}
SEC.locked=false;SNAP=snap();baseSet();renderPending();renderSide();route()}catch(e){document.body.insertAdjacentHTML('beforeend','<div class="note" style="position:fixed;inset:0;z-index:99999;background:var(--bg);padding:24px">The encrypted workbook could not be opened: '+esc(e&&e.message||e)+'. Reload the page.</div>')}}
/* ---- Settings → Security ---- */
let SECDLG=null;
function secDlg(o){SECDLG=o;$('modal').innerHTML='<div class="modal"><div class="dlg" role="dialog" aria-modal="true" aria-label="'+esc(o.title)+'" style="width:min(460px,100%)"><h2>'+esc(o.title)+'</h2>'+(o.note?'<p class="note" style="margin:0 0 8px">'+o.note+'</p>':'')
+(o.fields||[]).map(f=>'<label class="fl" style="margin-top:8px">'+esc(f.l)+'<input class="inp" id="sd-'+f.id+'" type="'+(f.t||'text')+'" autocomplete="off" value="'+esc(f.v||'')+'"></label>').join('')
+'<div id="sd-e" class="note" role="alert" style="margin:8px 0 0;min-height:18px;color:var(--bad-c)"></div><div class="acts"><span></span><div class="tools"><button class="btn" data-act="secdlgx">Cancel</button><button class="btn p" data-act="secdlgok">'+esc(o.ok||'OK')+'</button></div></div></div></div>';
setTimeout(()=>{const e=$('sd-'+((o.fields||[])[0]||{}).id);if(e)e.focus()},30)}
const secPwOk=p=>typeof p==='string'&&p.length>=8;
async function secSave(msg){dirty=Math.max(1,dirty);renderPending();renderSide();route();await saveExcel();if(msg)toast(msg)}
const SECACT={
secon(){if(!(window.crypto&&crypto.subtle)){toast('This browser has no WebCrypto, encryption is not available here.');return}
secDlg({title:'Turn on login and encryption',ok:'Encrypt workbook',note:'Creates the global admin <b>admin</b>. This password is the only recovery: <b>if it and all other passwords are lost, the data cannot be opened.</b> Write it down and keep it safe.',fields:[{id:'p1',l:'Admin password (min. 8 characters)',t:'password'},{id:'p2',l:'Repeat password',t:'password'}],
go:async v=>{if(!secPwOk(v.p1))return 'Use at least 8 characters.';if(v.p1!==v.p2)return 'The passwords do not match.';
const raw=crypto.getRandomValues(new Uint8Array(32)),kid=sb64(crypto.getRandomValues(new Uint8Array(9)));
const hdr={v:1,kid:kid,it:SEC_IT,users:[await secWrap(raw,'admin',v.p1,true,SEC_IT)]};
const r=await secUnwrap(hdr,'admin',v.p1);r.user='admin';secAdopt(r,hdr);try{localStorage.removeItem(LS)}catch(e){}closeForm();await secSave('Encryption is on. The workbook was saved encrypted. Use “Delete unencrypted backups” in Settings → Security.')}})},
secadd(){if(!SEC.admin)return;secDlg({title:'Add login',ok:'Add',note:'The user name can be linked to an operator in the Operators table (column Username).',fields:[{id:'u',l:'User name (letters, digits . _ -)'},{id:'p1',l:'Start password (min. 8 characters)',t:'password'}],
go:async v=>{const u=(v.u||'').trim().toLowerCase();if(!/^[a-z0-9._-]{2,40}$/.test(u))return 'User name: 2–40 characters, letters, digits . _ -';if(SEC.hdr.users.some(x=>x.u===u))return 'That user name exists already.';if(!secPwOk(v.p1))return 'Use at least 8 characters.';
SEC.hdr.users.push(await secWrap(SEC.raw,u,v.p1,false,SEC.hdr.it));closeForm();await secSave('Login '+u+' added and saved.')}})},
secreset(el){if(!SEC.admin)return;const u=el.dataset.u;secDlg({title:'New password for '+u,ok:'Set password',fields:[{id:'p1',l:'New password (min. 8 characters)',t:'password'}],
go:async v=>{if(!secPwOk(v.p1))return 'Use at least 8 characters.';const i=SEC.hdr.users.findIndex(x=>x.u===u);if(i<0)return 'User not found.';SEC.hdr.users[i]=await secWrap(SEC.raw,u,v.p1,!!SEC.hdr.users[i].a,SEC.hdr.it);closeForm();await secSave('Password of '+u+' changed and saved.')}})},
secdel(el){if(!SEC.admin)return;const u=el.dataset.u;if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again';return}
SEC.hdr.users=SEC.hdr.users.filter(x=>x.u!==u||x.a);secSave('Login '+u+' removed and saved. Copies of the file made earlier still open with that password.')},
secpw(){secDlg({title:'Change my password',ok:'Change',fields:[{id:'o',l:'Current password',t:'password'},{id:'p1',l:'New password (min. 8 characters)',t:'password'},{id:'p2',l:'Repeat new password',t:'password'}],
go:async v=>{if(!(await secUnwrap(SEC.hdr,SEC.user,v.o)))return 'Current password is wrong.';if(!secPwOk(v.p1))return 'Use at least 8 characters.';if(v.p1!==v.p2)return 'The passwords do not match.';
const i=SEC.hdr.users.findIndex(x=>x.u===SEC.user);SEC.hdr.users[i]=await secWrap(SEC.raw,SEC.user,v.p1,SEC.admin,SEC.hdr.it);closeForm();await secSave('Password changed and saved.')}})},
secoff(el){if(!SEC.admin)return;if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again: workbook becomes readable for everyone';return}
SEC.on=false;SEC.key=null;SEC.raw=null;SEC.hdr=null;SEC.kid='';secSave('Encryption is off. The workbook was saved unencrypted.')},
async secbk(el){if(!SEC.admin)return;const d=await bkDir(false);if(!d){toast('No Backup folder found');return}let n=0,k=0;
for await(const e of d.entries()){if(e[1].kind==='file'&&/\.xlsx$/i.test(e[0])){const f=await e[1].getFile();if(await secFileEnc(f))k++;else{try{await d.removeEntry(e[0]);n++}catch(x){}}}}
BKL=null;toast(n+' unencrypted backup'+(n===1?'':'s')+' deleted, '+k+' encrypted kept');route()},
async seclogout(el){if(dirty>0&&!el.dataset.arm){el.dataset.arm='1';el.textContent='Unsaved changes will be lost. Click again';return}dirty=0;location.reload()},
async secdlgok(){const o=SECDLG;if(!o)return;const v={};(o.fields||[]).forEach(f=>{v[f.id]=$('sd-'+f.id).value});const b=document.querySelector('[data-act="secdlgok"]');if(b){b.disabled=true}
let err='';try{err=await o.go(v)}catch(e){err='Failed: '+(e&&e.message||e)}
if(err){const e=$('sd-e');if(e)e.textContent=err;if(b)b.disabled=false}},
secdlgx(){SECDLG=null;closeForm()}};
function secCard(){
const bk='<button class="btn" data-act="secbk" title="Deletes backup copies that are not encrypted">Delete unencrypted backups</button>';
if(!SEC.on)return '<section class="card"><h2>Security: login and encryption</h2><p class="note" style="margin:0 0 12px">Turns on a login screen and encrypts <b>inventory.xlsx</b> and the data embedded in <b>index.html</b>. Without a login nobody can read the data, even with direct file access. Each operator gets their own user name and password. One global admin (user <b>admin</b>) manages the logins and is the recovery account. Attachments, Stuff files and collector output are not encrypted. Use folder rights (NTFS) for those.</p><div class="tools"><button class="btn p" data-act="secon">Turn on login and encryption…</button></div></section>';
const us=SEC.hdr.users.map(u=>{const op=(DB.Operators||[]).find(o=>String(o.Username||'').trim().toLowerCase()===u.u);
return '<tr><td><b>'+esc(u.u)+'</b></td><td>'+(u.a?'Global admin':'User')+'</td><td>'+(op?esc(op.Name):'<span class="note" style="margin:0">no operator linked</span>')+'</td><td>'+(SEC.admin?'<button class="btn s" data-act="secreset" data-u="'+esc(u.u)+'">New password</button>'+(u.a?'':' <button class="btn s d" data-act="secdel" data-u="'+esc(u.u)+'">Remove</button>'):'')+'</td></tr>'}).join('');
return '<section class="card"><h2>Security: login and encryption</h2><p class="note" style="margin:0 0 12px">Encryption is <b>on</b>. Logged in as <b>'+esc(SEC.user)+'</b>'+(SEC.admin?' (global admin)':'')+'. The Activity log uses '+esc(USER)+'. Link a login to an operator with the Username column in the Operators table.</p>'
+'<div class="tw"><table><thead><tr><th>User name</th><th>Role</th><th>Operator</th><th></th></tr></thead><tbody>'+us+'</tbody></table></div>'
+'<div class="tools" style="margin-top:12px">'+(SEC.admin?'<button class="btn p" data-act="secadd">+ Add login</button> ':'')+'<button class="btn" data-act="secpw">Change my password</button> '+(SEC.admin?bk+' <button class="btn d" data-act="secoff">Turn off encryption</button> ':'')+'<button class="btn" data-act="seclogout">Log out</button></div>'
+'<p class="note" style="margin:10px 0 0">Roles only control what this page shows. Removing a login does not close copies of the file made earlier: change the folder rights for that. A lost admin password with no other working login means the data is gone.</p></section>'}

/* user + log out bar at the top of the side panel */
function secBar(){let e=$('secbar');if(!SEC.on){if(e)e.remove();return}
if(!e){e=document.createElement('div');e.id='secbar';const n=$('nav');n.parentNode.insertBefore(e,n)}
e.style.cssText='display:flex;align-items:center;gap:8px;margin:0 12px 10px;padding:8px 10px;border:1px solid var(--line);border-radius:8px;color:var(--side-ink)';
e.innerHTML='<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" aria-hidden="true"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/></svg><span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px" title="'+esc(SEC.user)+(SEC.admin?' (admin)':'')+'"><b>'+esc(USER||SEC.user)+'</b>'+(SEC.admin?'<br><small style="opacity:.65">global admin</small>':'')+'</span><button class="btn s" data-act="seclogout" title="Log out">Log out</button>'}
