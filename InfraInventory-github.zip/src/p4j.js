
/* ---------- bulk selection in lists ---------- */
const SELS={};
function selSet(sheet){return SELS[sheet]||(SELS[sheet]=new Set())}
function selPrune(sheet){const s=selSet(sheet);s.forEach(r=>{if(DB[sheet].indexOf(r)<0)s.delete(r)})}
function bulkBar(sheet){
selPrune(sheet);const n=selSet(sheet).size;if(!n)return '';
const sv=sheet==='ServerMI';
return '<div class="bulkbar" role="status"><b>'+n+' selected</b><button class="btn s" data-act="bset" data-sheet="'+sheet+'">Set a field…</button>'

+(n>=2&&n<=4?'<button class="btn s" data-act="bcmp" data-sheet="'+sheet+'">Compare</button>':'')+'<button class="btn s" data-act="bcsv" data-sheet="'+sheet+'">Export selected CSV</button><button class="btn s d" data-act="bdel" data-sheet="'+sheet+'">Delete</button><button class="btn s" data-act="bclear" data-sheet="'+sheet+'">Clear selection</button></div>'}
function selRows(sheet){selPrune(sheet);return DB[sheet].filter(r=>selSet(sheet).has(r))}
function bulkFields(sheet){return SCHEMA[sheet].cols.filter(c=>!c.hidden&&!c.att&&c.k!==SCHEMA[sheet].key&&!(sheet==='DCSSActivity'&&c.k==='ID'))}
function openBulkSet(sheet){
const n=selSet(sheet).size,cs=bulkFields(sheet);
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Set a field" style="width:min(520px,100%)"><h2>Set a field for '+n+' '+(n===1?'row':'rows')+'</h2>'
+'<div class="fgrid"><label class="wide" for="bs-col">Field<select class="inp" id="bs-col" data-act="bscol" data-sheet="'+sheet+'">'+cs.map(c=>'<option value="'+esc(c.k)+'">'+esc(c.label||c.k)+'</option>').join('')+'</select></label></div>'
+'<div class="fgrid" id="bs-val" style="margin-top:8px"></div>'
+'<p class="note" style="margin:8px 0 0">The value is written to every selected row. Leave it blank to clear the field. Nothing is saved to Excel until you click Save to Excel.</p>'
+'<div id="bs-err" class="note" style="color:var(--bad-fg)" role="alert"></div>'
+'<div class="acts"><span></span><div class="tools"><button class="btn" data-act="mclose">Cancel</button><button class="btn p" data-act="bsgo" data-sheet="'+sheet+'">Apply</button></div></div></div></div>';
bsRender(sheet)}
function bsRender(sheet){const k=$('bs-col').value,c=SCHEMA[sheet].cols.find(x=>x.k===k);if(!c)return;const h=fieldHtml(sheet,Object.assign({},c,{req:0,label:'New value'}),{},false);$('bs-val').innerHTML=h}
function bsApply(sheet){
const k=$('bs-col').value,c=SCHEMA[sheet].cols.find(x=>x.k===k),el=$('bs-val').querySelector('[name]');if(!c||!el)return;
let v=c.t==='chk'?(el.checked?'Yes':'No'):el.value.trim();if(c.t==='num'&&v!=='')v=parseFloat(v);
const rows=selRows(sheet);undoSnap('set '+(c.label||k));rows.forEach(r=>{r[k]=v;r.Updated=ds(0)});
closeForm();changed();route();toast((c.label||k)+' set for '+rows.length+(rows.length===1?' row':' rows'),true)}
function bulkDelete(sheet,btn){
const rows=selRows(sheet);if(!rows.length)return;
if(!btn.dataset.arm){btn.dataset.arm='1';btn.textContent='Click again to delete '+rows.length;return}
undoSnap('delete '+rows.length+(rows.length===1?' row':' rows'));rows.forEach(r=>clusterDel(sheet,r));
rows.forEach(r=>{
if(sheet==='ServerMI')DB.BackupAssign=DB.BackupAssign.filter(a=>a.Server!==r.Hostname);
if(sheet==='BackupJobs')DB.BackupAssign=DB.BackupAssign.filter(a=>a.Job!==r.Job);
if(sheet==='Issues')DB.Comments=DB.Comments.filter(c=>c.Issue!==r.ID);
if(sheet==='OpenIssues')DB.OIComments=DB.OIComments.filter(c=>c.Issue!==r.ID);
if(sheet==='KB')DB.KBComments=DB.KBComments.filter(c=>c.Article!==r.ID);
DB[sheet].splice(DB[sheet].indexOf(r),1)});
selSet(sheet).clear();changed();route();toast('Deleted '+rows.length+(rows.length===1?' row':' rows'),true)}
