
/* ---------- patching compliance ---------- */
const PT={f:'All',env:'All',q:''},PWARN=14;
function addDays(s,n){const t=new Date(String(s).slice(0,10)+'T00:00:00');t.setDate(t.getDate()+n);return fmt(t)}
function patchInfo(r){
if(srvKind(r)==='Decommissioned')return{st:'Excluded'};
const e=envRow(r.Env),sla=e?parseInt(e['Patch days']):NaN,lp=String(r['Last patched']||'').slice(0,10),dl=daysTo(lp);
if(!(sla>=1))return{st:'No SLA',lp:lp,age:dl===null?null:-dl};
if(dl===null)return{st:'Unknown',sla:sla};
const due=addDays(lp,sla),left=daysTo(due);
return{st:left<0?'Overdue':left<=PWARN?'Due soon':'Compliant',sla:sla,lp:lp,due:due,left:left,age:-dl}}
const PCLS={Compliant:'b-ok','Due soon':'b-warn',Overdue:'b-bad',Unknown:'b-off','No SLA':'b-off',Excluded:'b-off'};
function patchStats(rows){
const c={Compliant:0,'Due soon':0,Overdue:0,Unknown:0,'No SLA':0,Excluded:0};rows.forEach(r=>{c[patchInfo(r).st]++});
const sc=c.Compliant+c['Due soon']+c.Overdue;c.scored=sc;c.pct=sc?Math.round((c.Compliant+c['Due soon'])/sc*100):0;return c}
function patchRows(){
let rows=DB.ServerMI.map((r,i)=>({r:r,i:i,p:patchInfo(r)}));
if(PT.f!=='All')rows=rows.filter(x=>x.p.st===PT.f);
if(PT.env!=='All')rows=rows.filter(x=>x.r.Env===PT.env);
if(PT.q){const q=PT.q.toLowerCase();rows=rows.filter(x=>['Hostname','IP','OS','Owner','Role','Cluster'].some(k=>String(x.r[k]||'').toLowerCase().indexOf(q)>=0))}
const key=x=>x.p.left!=null?x.p.left:x.p.st==='Unknown'?-100000:x.p.st==='No SLA'?100000:200000;
rows.sort((a,b)=>key(a)-key(b));return rows}
function patchTable(){
const rows=patchRows();
if(!rows.length)return '<div class="empty">No servers match. '+(DB.ServerMI.length?'Change the filter.':'Add servers on the ServersMI tab first.')+'</div>';
const SO={Overdue:0,'Due soon':1,Unknown:2,'No SLA':3,Compliant:4,Excluded:5};
return ctTable('patching',[
{k:'Hostname',v:x=>x.r.Hostname,h:x=>'<b>'+esc(x.r.Hostname)+'</b>',cls:'mono'},
{k:'Env',v:x=>x.r.Env,h:x=>cellHtml('Env',x.r)},
{k:'OS',v:x=>x.r.OS,h:x=>esc(x.r.OS)},
{k:'Owner',v:x=>x.r.Owner,h:x=>esc(x.r.Owner)||'<span class="note">—</span>'},
{k:'Platform',v:x=>x.r.Platform||'Virtual',h:x=>esc(x.r.Platform||'Virtual')},
{k:'Last patched',v:x=>x.p.lp||'',h:x=>x.p.lp?esc(x.p.lp)+' <span class="note">· '+x.p.age+' d ago</span>':'<span class="note">not recorded</span>'},
{k:'CRQ',v:x=>x.r['Last patch CRQ'],h:x=>esc(x.r['Last patch CRQ'])||'<span class="note">—</span>',cls:'mono'},
{k:'FW patched',v:x=>x.r['FW patched']||'',h:x=>x.r.Platform==='Physical'?cellHtml('FW patched',x.r):'<span class="note">—</span>'},
{k:'SLA (days)',v:x=>x.p.sla||0,h:x=>String(x.p.sla||'—'),cls:'mono'},
{k:'Compliance expires',v:x=>x.p.due||'',h:x=>x.p.due?esc(x.p.due):'—'},
{k:'Days left',v:x=>x.p.left!=null?x.p.left:99999,h:x=>x.p.left!=null?(x.p.left<0?'<span style="color:var(--bad-fg)">'+x.p.left+'</span>':String(x.p.left)):'—',cls:'mono'},
{k:'Status',v:x=>SO[x.p.st],h:x=>'<span class="badge '+PCLS[x.p.st]+'">'+x.p.st+'</span>'},
{k:'',fix:1,h:x=>'<span style="white-space:nowrap"><button class="btn s" data-act="ptoday" data-i="'+x.i+'" title="Record a patch with CRQ / INC">Patched today</button> <button class="btn s" data-act="edit" data-sheet="ServerMI" data-i="'+x.i+'">Edit</button></span>'}],rows)}
function patchEnvTable(){
const names=DB.Environments.map(e=>e.Name);DB.ServerMI.forEach(r=>{if(r.Env&&names.indexOf(r.Env)<0)names.push(r.Env)});
return '<div class="tw"><table><thead><tr><th>Environment</th><th>Patch within (days)</th><th>Servers</th><th>Compliant</th><th>Due soon</th><th>Overdue</th><th>No date</th><th>Compliance</th></tr></thead><tbody>'+names.map(n=>{const e=envRow(n),rs=DB.ServerMI.filter(r=>r.Env===n),s=patchStats(rs),sla=e?parseInt(e['Patch days']):NaN;
return '<tr><td><span class="badge '+envCls(n)+'">'+esc(n)+'</span></td><td class="mono">'+(sla>=1?sla:'<span class="note">not set</span>')+'</td><td class="mono">'+rs.length+'</td><td class="mono">'+s.Compliant+'</td><td class="mono">'+s['Due soon']+'</td><td class="mono">'+(s.Overdue?'<b style="color:var(--bad-fg)">'+s.Overdue+'</b>':0)+'</td><td class="mono">'+s.Unknown+'</td><td style="min-width:140px">'+(s.scored?'<div class="bar"><i class="'+(s.pct<70?'b':s.pct<90?'w':'')+'" style="width:'+s.pct+'%"></i></div><span class="mono">'+s.pct+'%</span>':'<span class="note">—</span>')+'</td></tr>'}).join('')+'</tbody></table></div>'}
function patchView(){
const s=patchStats(DB.ServerMI),noSla=DB.Environments.filter(e=>e.Active!=='No'&&!(parseInt(e['Patch days'])>=1)).map(e=>e.Name);
const chips=['All','Overdue','Due soon','Compliant','Unknown','No SLA'].map(o=>'<button class="chip'+(PT.f===o?' on':'')+'" data-act="pstat" data-v="'+o+'">'+o+'</button>').join('');
const envs=['All'].concat(DB.Environments.map(e=>e.Name)).map(o=>'<button class="chip'+(PT.env===o?' on':'')+'" data-act="penv" data-v="'+esc(o)+'">'+esc(o)+'</button>').join('');
return head('Patching compliance','OS patching status per server. Each environment has a “patch within N days” rule (Settings → Environments). Expiry = Last patched + that rule. Decommissioned servers are not counted.','<button class="btn" data-act="pcsv">Export CSV</button><button class="btn p" data-act="saveXlsx">Save to Excel</button>')
+'<div class="kpis"><div class="kpi"><span>Compliance</span><b>'+(s.scored?s.pct+'%':'—')+'</b><small class="'+(s.scored&&s.pct<90?'w':'g')+'">'+(s.Compliant+s['Due soon'])+' of '+s.scored+' servers within their rule</small></div><div class="kpi"><span>Overdue</span><b>'+s.Overdue+'</b><small class="'+(s.Overdue?'b':'g')+'">patch rule exceeded</small></div><div class="kpi"><span>Expires within '+PWARN+' days</span><b>'+s['Due soon']+'</b><small class="'+(s['Due soon']?'w':'')+'">patch these next</small></div><div class="kpi"><span>No patch date</span><b>'+s.Unknown+'</b><small class="'+(s.Unknown?'w':'')+'">fill in Last patched · '+s['No SLA']+' have no rule</small></div></div>'
+(noSla.length?'<section class="card" style="border-color:var(--warn-fg)"><b>Set the patch rule for: '+noSla.map(esc).join(', ')+'.</b> <span class="note">Servers in these environments are shown as “No SLA” until you enter Patch days in Settings → Environments.</span> <button class="btn s" data-act="goto" data-v="settings">Open Settings</button></section>':'')
+'<section class="card"><h2>By environment</h2>'+patchEnvTable()+'</section>'
+'<section class="card" style="padding:0"><div class="tools" style="padding:14px 16px;justify-content:space-between"><div class="chips">'+chips+'</div><div class="tools">'+ctBtn('patching')+'<input class="inp srch" type="search" data-act="pq" value="'+esc(PT.q)+'" placeholder="Search hostname, IP, OS, owner" aria-label="Search servers" style="max-width:280px"></div></div><div class="tools" style="padding:0 16px 12px"><span class="note">Environment:</span><div class="chips">'+envs+'</div></div><div id="pt-list">'+patchTable()+'</div></section>'
+'<p class="note">Last patched is a column of ServersMI. “Patched today” sets it to today. Changes stay in this page until you save them to Excel.</p>'}
async function patchCsv(){
const rows=patchRows(),sep=META.csvSep||';';if(!rows.length){toast('Nothing to export');return}
const q=v=>{let s=v==null?'':String(v);if(/^[=+@]/.test(s)||(/^-/.test(s)&&isNaN(Number(s))))s="'"+s;return(s.indexOf(sep)>=0||/["\n\r]/.test(s))?'"'+s.replace(/"/g,'""')+'"':s};
const hd=['Hostname','Env','OS','Owner','Last patched','CRQ','SLA days','Compliance expires','Days left','Status'];
const lines=[hd.map(q).join(sep)].concat(rows.map(x=>[x.r.Hostname,x.r.Env,x.r.OS,x.r.Owner,x.p.lp||'',x.p.sla||'',x.p.due||'',x.p.left!=null?x.p.left:'',x.p.st].map(q).join(sep)));
const name='PatchCompliance_'+ds(0)+'.csv',data='﻿'+lines.join('\r\n'),msg='Exported '+rows.length+' rows to '+name;
let dl=null;try{dl=window.claude&&window.claude.use?await window.claude.use('downloads'):null}catch(e){dl=null}
if(dl){try{await dl.save({filename:name,data:data});toast(msg)}catch(e){if(!(e&&e.code==='declined'))toast('Export failed')}return}
try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:'text/csv;charset=utf-8'}));a.download=name;document.body.appendChild(a);a.click();a.remove();toast(msg)}catch(e){toast('Download is not available in this view')}}
