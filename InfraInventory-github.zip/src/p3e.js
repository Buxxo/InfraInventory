
/* ---------- project folder: Save writes the workbook and rebuilds index.html ---------- */
let ROOT=null,ATDIR=null;
const PH={x:'/*__'+'XLSX__*/null',m:'/*__'+'META__*/null',s:'/*__'+'STUFF__*/null'};
function b64(u8){let s='';for(let i=0;i<u8.length;i+=0x8000)s+=String.fromCharCode.apply(null,u8.subarray(i,i+0x8000));return btoa(s)}
const jsonSafe=o=>JSON.stringify(o).replace(/</g,'\\u003c');
async function rootPerm(ask){
if(!ROOT)return false;
try{let p=ROOT.queryPermission?await ROOT.queryPermission({mode:'readwrite'}):'granted';if(p!=='granted'&&ask&&ROOT.requestPermission)p=await ROOT.requestPermission({mode:'readwrite'});const ok=p==='granted';if(ok&&RPOBJ===ROOT&&RPST!=='ok'){RPST='ok';try{renderPending()}catch(x){}}return ok}catch(e){return false}
}
async function rootWire(){
const inv=await ROOT.getDirectoryHandle('Inventory',{create:true});
try{handle=await inv.getFileHandle('inventory.xlsx')}catch(e){handle=null}
const st=await ROOT.getDirectoryHandle('Stuff',{create:true});
ATDIR=await ROOT.getDirectoryHandle('Attachments',{create:true});STDIR=st;KBDIR=await st.getDirectoryHandle('KnowledgeBase',{create:true});OIDIR=await st.getDirectoryHandle('OpenIssues',{create:true});
try{await stuffRefresh()}catch(e){}
}
function rootBtn(){return typeof window.showDirectoryPicker!=='function'?'':ROOT?'<button class="btn" data-act="rootreconnect">Reconnect project folder</button>':'<button class="btn" data-act="rootconnect">Connect project folder</button>'}
async function rootConnect(){
if(typeof window.showDirectoryPicker!=='function'){toast('This browser cannot connect a folder. Use Edge or Chrome.');return}
const prevRoot=ROOT;try{ROOT=await window.showDirectoryPicker({mode:'readwrite',id:'infra-inventory'})}catch(e){ROOT=prevRoot;return}
keepHandle(ROOT,'root');
try{await rootWire()}catch(e){ROOT=prevRoot;toast('Could not use that folder.');return}
let loaded=false;
if(DB.Comments.some(c=>c.Pics&&c.Pics.length))await migratePics();
if(handle&&dirty===0){try{const f=await handle.getFile();if(f.size>0){await importFile(f,handle);loaded=true}}catch(e){}}
if(!loaded)route();
toast('Project folder connected: “'+ROOT.name+'”'+(loaded?'. Loaded Inventory/inventory.xlsx.':'.'))
}
async function autoLoadNewer(){
if(!handle||dirty>0)return;
try{const f=await handle.getFile(),base=META.diskMtime||(timeMs(META.fileModified)?timeMs(META.fileModified)+61000:0);if(base&&f.size>0&&f.lastModified>base){await importFile(f,handle);toast('Loaded the newer Inventory/inventory.xlsx from the project folder')}}catch(e){}
}
async function rootReconnect(){
if(await rootPerm(true)){try{await rootWire()}catch(e){}await migratePics();route();toast('Project folder reconnected');autoLoadNewer()}else toast('Permission was not given')
}
async function rebuildIndex(buf){
let tpl;try{tpl=await(await(await ROOT.getFileHandle('dashboard-template.html')).getFile()).text()}catch(e){return 'notemplate'}
if(tpl.indexOf(PH.x)<0)return 'badtemplate';
let mt=Date.now();try{mt=(await handle.getFile()).lastModified}catch(e){}
const meta={file:handle?handle.name:'inventory.xlsx',modified:fmtT(new Date(mt)),generated:fmtT(new Date())};
const stuff=(META.stuff||[]).map(f=>({name:f.name,size:f.size,modified:f.modified}));
const html=tpl.split(PH.x).join("'"+b64(new Uint8Array(buf))+"'").split(PH.m).join(jsonSafe(meta)).split(PH.s).join(jsonSafe(stuff));
const w=await(await ROOT.getFileHandle('index.html',{create:true})).createWritable();await w.write(html);await w.close();return 'ok'
}

/* ---------- DC issue photos: stored as files in Issues/<ID>/ ---------- */
const PIC_URL={};
function dataToBlob(u){const m=/^data:([^;]+);base64,(.*)$/.exec(u),b=atob(m[2]),a=new Uint8Array(b.length);for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i);return new Blob([a],{type:m[1]})}
async function picExists(dir,n){try{await dir.getFileHandle(n);return true}catch(e){return false}}
async function savePicFiles(issueId,pics){
const top=await ROOT.getDirectoryHandle('Issues',{create:true}),dir=await top.getDirectoryHandle(issueId,{create:true}),names=[],st=nowStr().replace(/\D/g,'').slice(0,12);
for(let i=0;i<pics.length;i++){let n=issueId+'_'+st+'_'+(i+1)+'.jpg',k=1;while(await picExists(dir,n))n=issueId+'_'+st+'_'+(i+1)+'_'+(++k)+'.jpg';
const w=await(await dir.getFileHandle(n,{create:true})).createWritable();await w.write(dataToBlob(pics[i]));await w.close();names.push(n)}
return names}
async function migratePics(){
let n=0;const cs=DB.Comments.filter(c=>c.Pics&&c.Pics.length&&c.Issue);
for(const c of cs){try{const names=await savePicFiles(c.Issue,c.Pics);c.Files=(c.Files||[]).concat(names);n+=c.Pics.length;c.Pics=[]}catch(e){}}
if(n){changed();toast(n+' photo'+(n>1?'s':'')+' moved into the Issues folder. Save to Excel to record the file names.')}return n}
async function loadPics(){
const imgs=Array.prototype.slice.call(document.querySelectorAll('img[data-pf]'));if(!imgs.length)return;
const ok=ROOT&&await rootPerm(false);
for(const im of imgs){const key=im.dataset.pf;
if(PIC_URL[key]){im.src=PIC_URL[key];continue}
if(!ok){const s=document.createElement('span');s.className='note';s.style.cssText='display:inline-block;padding:10px;border:1px dashed var(--line);border-radius:8px';s.textContent='Photo '+key.split('/')[1]+' · connect the project folder to view';im.replaceWith(s);continue}
try{const p=key.split('/'),top=await ROOT.getDirectoryHandle('Issues'),dir=await top.getDirectoryHandle(p[0]),f=await(await dir.getFileHandle(p[1])).getFile();PIC_URL[key]=URL.createObjectURL(f);im.src=PIC_URL[key]}
catch(e){const s=document.createElement('span');s.className='note';s.textContent='Photo file not found: '+key;im.replaceWith(s)}}}
