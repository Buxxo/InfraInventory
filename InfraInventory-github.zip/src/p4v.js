/* ---------- app settings (sheet AppSettings: Key / Value) ---------- */
function cfg(k,d){const r=(DB.AppSettings||[]).find(x=>x.Key===k);return r&&String(r.Value).trim()!==''?String(r.Value).trim():d}
function setCfg(k,v,n){if(!DB.AppSettings)DB.AppSettings=[];let r=DB.AppSettings.find(x=>x.Key===k);if(!r){r={Key:k,Value:'',Notes:n||'',Updated:ds(0)};DB.AppSettings.push(r)}if(String(r.Value)!==String(v)){r.Value=v;r.Updated=ds(0);changed()}}
function rdpPort(){const p=parseInt(cfg('RDP port','3389'));return p>0&&p<65536?p:3389}
function rdpAddr(h){return rdpPort()===3389?h:h+':'+rdpPort()}
function genCard(){return '<section class="card" style="margin-top:16px"><h2>General</h2><div class="fgrid" style="grid-template-columns:repeat(auto-fill,minmax(240px,1fr))"><label>Remote Desktop port<input class="inp mono" id="cfg-rdp" type="number" min="1" max="65535" value="'+rdpPort()+'"><span class="note">Used by the RDP button on servers and ESXi hosts (default 3389). Saved in the sheet “AppSettings”.</span></label><label>Workbook backups to keep<input class="inp mono" id="cfg-bk" type="number" min="0" max="100" value="'+bkKeep()+'"><span class="note">Copies of inventory.xlsx in Inventory\\Backup, made before every Save (0 = off).</span></label></div><div class="tools" style="margin-top:10px"><button class="btn p" data-act="cfgsave">Save settings</button></div></section>'}
/* ---------- Stuff helpers: copy to clipboard, RDP files ---------- */
function dlBlob(name,data,type){try{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([data],{type:type}));a.download=name;document.body.appendChild(a);a.click();a.remove();return true}catch(e){toast('Download blocked by the browser');return false}}
function clipCopy(t,msg){const done=()=>toast(msg||'Copied');const fb=()=>{const a=document.createElement('textarea');a.value=t;a.style.position='fixed';a.style.opacity='0';document.body.appendChild(a);a.select();try{document.execCommand('copy');done()}catch(e){toast('Copy failed, select the text manually')}a.remove()};
try{if(navigator.clipboard&&navigator.clipboard.writeText)navigator.clipboard.writeText(t).then(done,fb);else fb()}catch(e){fb()}}
async function stuffConnect(name){
if(STDIR){try{const f=await(await STDIR.getFileHandle(name)).getFile();if(dlBlob(name,await f.arrayBuffer(),'application/x-rdp'))toast('Opening '+name+'. If it only downloads, choose “Always open files of this type” once in the download bar.');return}catch(e){}}
const a=document.createElement('a');a.href='Stuff/'+encodeURIComponent(name);a.download=name;document.body.appendChild(a);a.click();a.remove();toast('Opening '+name+'. If it only downloads, choose “Always open files of this type” once in the download bar.')}
const STUFFACT={
cfgsave(){const p=parseInt($('cfg-rdp').value);if(!(p>0&&p<65536)){toast('Enter a port between 1 and 65535');return}setCfg('RDP port',String(p),'TCP port for Remote Desktop');const bk=parseInt($('cfg-bk').value);if(bk>=0&&bk<=100)setCfg('Backups to keep',String(bk),'Workbook copies in Inventory\\Backup');route();toast('Settings saved. Save to Excel to keep them.')},
stconnect(el){stuffConnect(el.dataset.name)},
lnkcopy(el){clipCopy(el.dataset.u,'Copied: '+el.dataset.u)},
srvrdp(el){const t=el.dataset.t,a=rdpAddr(t);if(dlBlob(t+'.rdp','full address:s:'+a+'\r\nprompt for credentials:i:1\r\nadministrative session:i:0\r\nscreen mode id:i:2\r\n','application/x-rdp'))toast('Opening Remote Desktop to '+a+'. If it only downloads, choose “Always open files of this type” once.')}};
