/* ---------- List features: edit in place, multi-column sort, select all in "is one of", copy a column ---------- */
const LE={click:true,sel:null};
try{const v=localStorage.getItem('infra-cellclick');if(v==='0')LE.click=false}catch(e){}
/* rows of a list exactly as shown (filter, search, sort), all pages */
function leRows(sheet){const t=TV[sheet],u=uiOf(sheet);let rows=DB[sheet].map((r,i)=>({r:r,i:i}));rows=rows.filter(x=>fmatch(u,t,x.r));rows=applyFilters(sheet,rows);
if(u.q){const q=u.q.toLowerCase();rows=rows.filter(x=>Object.keys(x.r).some(k=>k!=='Updated'&&String(x.r[k]).toLowerCase().includes(q)))}rowsSort(rows,u);return rows}
/* ---- copy one column ---- */
function leCopyCol(sheet,col,uniq){let rows=leRows(sheet);const ss=selSet(sheet);const picked=rows.filter(x=>ss.has(x.r));if(picked.length)rows=picked;
let vals=rows.map(x=>{const v=val(x.r,col);return v==null?'':String(v).replace(/\r?\n/g,' ')});if(uniq)vals=[...new Set(vals.filter(v=>v!==''))];
clipCopy(vals.join('\n'),'Copied '+vals.length+' value'+(vals.length===1?'':'s')+' of '+labelOf(col,sheet)+(picked.length?' (selected rows)':''))}
/* copy several columns (tab separated, pastes into Excel as columns) */
let LCM=null;
function lcmOpen(sheet){let saved=null;try{saved=JSON.parse(localStorage.getItem('infra-lcm-'+sheet)||'null')}catch(e){}const show=TV[sheet].show;LCM={sheet:sheet,cols:(saved&&saved.cols||[]).filter(c=>show.indexOf(c)>=0),hdr:saved?saved.hdr!==false:true};lcmDlg()}
function lcmDlg(){const s=LCM.sheet,rows=leRows(s),ss=selSet(s),n=rows.filter(x=>ss.has(x.r)).length;
$('modal').innerHTML='<div class="modal"><div class="dlg" role="dialog" aria-modal="true" aria-label="Copy columns" style="width:min(560px,100%)"><h2 style="margin:0">Copy columns</h2><p class="note" style="margin:0">'+(n?n+' selected row'+(n===1?'':'s'):rows.length+' row'+(rows.length===1?'':'s')+' in the current view')+' · columns in the order ticked · tab separated, paste straight into Excel.</p>'
+'<div class="tools"><button class="btn s" data-act="lcmall" data-v="1">All</button><button class="btn s" data-act="lcmall" data-v="0">None</button></div>'
+'<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:6px 12px;max-height:46vh;overflow:auto;padding:2px">'+TV[s].show.map(c=>'<label class="chkrow" style="grid-column:auto"><input type="checkbox" data-act="lcmtog" data-c="'+esc(c)+'"'+(LCM.cols.indexOf(c)>=0?' checked':'')+'> '+esc(labelOf(c,s))+'</label>').join('')+'</div>'
+'<label class="chkrow" style="grid-column:auto"><input type="checkbox" data-act="lcmhdr"'+(LCM.hdr?' checked':'')+'> Include header row</label>'
+'<div class="acts"><button class="btn" data-act="lcmclose">Cancel</button><button class="btn p" data-act="lcmgo">Copy</button></div></div></div>'}
function lcmGo(){const s=LCM.sheet;if(!LCM.cols.length){toast('Tick at least one column',true);return}let rows=leRows(s);const ss=selSet(s),pk=rows.filter(x=>ss.has(x.r));if(pk.length)rows=pk;
const cl=v=>v==null?'':String(v).replace(/[\t\r\n]+/g,' ');const out=[];if(LCM.hdr)out.push(LCM.cols.map(c=>cl(labelOf(c,s))).join('\t'));rows.forEach(x=>out.push(LCM.cols.map(c=>cl(val(x.r,c))).join('\t')));
try{localStorage.setItem('infra-lcm-'+s,JSON.stringify({cols:LCM.cols,hdr:LCM.hdr}))}catch(e){}
clipCopy(out.join('\n'),'Copied '+rows.length+' row'+(rows.length===1?'':'s')+' × '+LCM.cols.length+' column'+(LCM.cols.length===1?'':'s')+(pk.length?' (selected rows)':''));closeForm();LCM=null}
/* ---- editing in place ---- */
function leKind(sheet,col){const S=SCHEMA[sheet];if(!S||!col||col.charAt(0)==='@')return null;if(col===S.key||(TV[sheet]&&TV[sheet].show[0]===col))return null;/* the master value of a record is only changed in the full form */const c=S.cols.find(x=>x.k===col);if(!c||c.att||c.hidden||c.t==='hosts'||c.t==='vms')return null;
if((sheet==='ServerMI'&&typeof CMB!=='undefined'&&CMB[col])||LISTCMB[sheet+'.'+col])return{c:c,kind:'form'};
if(c.t==='chk')return{c:c,kind:'chk'};const no=nameOpts(sheet,col);if(no)return{c:c,kind:'sel',o:no};if(c.t==='sel')return{c:c,kind:'sel',o:c.o};
return{c:c,kind:c.t==='num'?'num':c.t==='date'?'date':'text'}}
function leCommit(sheet,i,col,v){openForm(sheet,i);const f=$('frm');if(!f)return false;const el=f.elements[col];if(!el){closeForm();return false}
if(el.type==='checkbox')el.checked=v==='Yes';else el.value=v;
const r=submitForm(f);if(!r){const e=$('ferr'),m=e?e.textContent:'Not saved';closeForm();toast(m||'Not saved',true);return false}return true}
function leStop(){LE.sel=null}
function leCancel(){const s=LE.ed;LE.ed=null;if(s)redrawTable(s.sheet)}
function leStart(td,jump){const tr=td.closest('tr[data-act=edit]');if(!tr)return false;const sheet=tr.dataset.sheet,i=+tr.dataset.i,t=TV[sheet];if(!t)return false;
const ci=[...tr.children].indexOf(td)-1;const col=t.show[ci];let k=leKind(sheet,col);
if(!k){return false}
if(k.kind==='form'){openForm(sheet,i);const f=$('frm'),se=f&&f.elements[col+'_sel'];if(!se){const el=f&&f.elements[col];if(el&&el.focus)el.focus();return true}
k={c:k.c,kind:'combo',o:[...se.options].map(o=>o.value==='__new__'?'':o.text).filter(Boolean)};closeForm()}
const row=DB[sheet][i],cur=row[col]==null?'':row[col];
if(k.kind==='chk'){leCommit(sheet,i,col,String(cur)==='Yes'?'No':'Yes');return true}
if(LE.ed)leCancel();
LE.ed={sheet:sheet,i:i,col:col,k:k,cur:cur};
const w=Math.max(80,td.getBoundingClientRect().width-4);let h;
if(k.kind==='sel'){const names=(k.o||[]).map(String);if(cur!==''&&names.indexOf(String(cur))<0)names.push(String(cur));h='<select class="inp cedit" aria-label="'+esc(labelOf(col,sheet))+'"><option value=""></option>'+names.map(o=>'<option'+(String(cur)===o?' selected':'')+'>'+esc(o)+'</option>').join('')+'</select>'}
else if(k.kind==='combo'){h='<input class="inp cedit" list="le-dl" aria-label="'+esc(labelOf(col,sheet))+'" value="'+esc(cur)+'"><datalist id="le-dl">'+k.o.map(o=>'<option value="'+esc(o)+'">').join('')+'</datalist>'}
else h='<input class="inp cedit" aria-label="'+esc(labelOf(col,sheet))+'" type="'+(k.kind==='num'?'number':k.kind==='date'?'date':'text')+'"'+(k.kind==='num'?' step="any"':'')+' value="'+esc(cur)+'">';
td.classList.add('editing');td.innerHTML=h;const el=td.querySelector('.cedit');el.style.minWidth=w+'px';el.focus();if(el.select&&el.tagName==='INPUT'&&el.type!=='date')el.select();
if(el.tagName==='SELECT'&&el.showPicker){try{el.showPicker()}catch(e){}}return true}
function leFinish(el,dir){const s=LE.ed;if(!s)return;const td=el.closest('td'),tr=td.closest('tr'),v=String(el.value).trim();LE.ed=null;
let nxt=null;if(dir){const cells=[...tr.children];const ci=cells.indexOf(td);
if(dir==='down'){const nt=tr.nextElementSibling;if(nt&&nt.dataset.act==='edit')nxt={i:+nt.dataset.i,ci:ci}}
else{let c2=ci+dir;while(c2>0&&c2<cells.length&&!leKind(s.sheet,TV[s.sheet].show[c2-1]))c2+=dir;if(c2>0&&c2<cells.length)nxt={i:s.i,ci:c2}}}
if(v===String(s.cur)){redrawTable(s.sheet);if(nxt)leGo(s.sheet,nxt);return}
if(s.k.kind==='num'&&v!==''&&isNaN(parseFloat(v))){toast('Enter a number',true);redrawTable(s.sheet);return}
const okk=leCommit(s.sheet,s.i,s.col,v);if(okk&&nxt)setTimeout(()=>leGo(s.sheet,nxt),0);else if(!okk)redrawTable(s.sheet)}
function leGo(sheet,n){const tr=document.querySelector('#tbl tr[data-act=edit][data-i="'+n.i+'"]');if(!tr||tr.dataset.sheet!==sheet)return;const td=tr.children[n.ci];if(td)leStart(td)}

/* ---- Excel-like range selection on every table of the page: drag over cells (or Alt+click a header for a whole column), Ctrl+C copies ---- */
const RG={a:null,b:null,tb:null,down:false,drag:false,supp:false};
const RGSEL='#view table tbody td';
function rgCells(){const tb=RG.tb;return tb&&tb.isConnected?[...tb.children].filter(tr=>tr.tagName==='TR').map(tr=>[...tr.children]):[]}
function rgRange(){const g=rgCells();if(!RG.a||!RG.b||!g.length)return null;return{g:g,r1:Math.min(RG.a.r,RG.b.r),r2:Math.max(RG.a.r,RG.b.r),c1:Math.min(RG.a.c,RG.b.c),c2:Math.max(RG.a.c,RG.b.c)}}
function rgEach(fn){const x=rgRange();if(!x)return;for(let r=x.r1;r<=x.r2&&r<x.g.length;r++){const row=[];for(let c=x.c1;c<=x.c2&&c<x.g[r].length;c++){const td=x.g[r][c];if(td.classList.contains('selc')||td.colSpan>1)continue;row.push(td)}if(row.length)fn(row)}}
function rgPaint(){document.querySelectorAll('td.rgsel').forEach(t=>t.classList.remove('rgsel'));rgEach(row=>row.forEach(td=>td.classList.add('rgsel')))}
function rgPos(td){const tr=td.closest('tr'),tb=tr&&tr.parentElement;if(!tb||tb.tagName!=='TBODY')return null;return{tb:tb,r:[...tb.children].indexOf(tr),c:[...tr.children].indexOf(td)}}
function rgText(){const out=[];rgEach(row=>out.push(row.map(td=>td.innerText.replace(/[\t\r\n]+/g,' ').trim()).join('\t')));return out.join('\n')}
function rgClear(){RG.a=RG.b=null;rgPaint()}
document.addEventListener('mousedown',e=>{if(e.button!==0)return;const td=e.target.closest&&e.target.closest(RGSEL);if(!td||td.classList.contains('selc')||td.classList.contains('editing')||(e.target.closest&&e.target.closest('input,select,textarea,button')))return;
const p=rgPos(td);if(!p)return;if(e.shiftKey&&RG.a&&RG.tb===p.tb){RG.b=p;rgPaint();e.preventDefault();RG.supp=true;return}if(RG.a)rgClear();RG.tb=p.tb;RG.down=true;RG.drag=false;RG.start=p;p.tb.classList.add('rgd')},true);
document.addEventListener('mousemove',e=>{if(!RG.down)return;const td=e.target.closest&&e.target.closest(RGSEL);if(!td)return;const p=rgPos(td);if(!p||p.tb!==RG.tb)return;if(!RG.drag){if(p.r===RG.start.r&&p.c===RG.start.c)return;RG.drag=true;if(LE.ed)leCancel()}
RG.a=RG.start;RG.b=p;try{getSelection().removeAllRanges()}catch(x){}rgPaint()},true);
document.addEventListener('mouseup',e=>{if(!RG.down)return;RG.down=false;if(RG.tb)RG.tb.classList.remove('rgd');if(RG.drag){RG.supp=true;setTimeout(()=>{RG.supp=false},0);const n=document.querySelectorAll('td.rgsel').length;toast(n+' cells selected. Ctrl+C copies them.')}},true);
document.addEventListener('click',e=>{if(RG.supp){RG.supp=false;e.stopImmediatePropagation();e.preventDefault()}},true);
document.addEventListener('copy',e=>{if(!RG.a||!RG.b)return;const a=document.activeElement;if(a&&/INPUT|TEXTAREA|SELECT/.test(a.tagName))return;const t=rgText();if(!t)return;e.clipboardData.setData('text/plain',t);e.preventDefault();toast('Copied '+t.split('\n').length+' row(s)')});
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&RG.a)rgClear()});
document.addEventListener('click',e=>{if(!e.altKey)return;const th=e.target.closest&&e.target.closest('#view table thead th');if(!th||th.classList.contains('selc'))return;const tb=th.closest('table').tBodies[0];if(!tb)return;const c=[...th.parentElement.children].indexOf(th);RG.tb=tb;const g=rgCells();if(!g.length)return;e.stopImmediatePropagation();e.preventDefault();RG.a={r:0,c:c};RG.b={r:g.length-1,c:c};rgPaint();toast('Column selected ('+g.length+' rows). Ctrl+C copies it.')},true);
/* clicks: capture so the row does not open its form */
document.addEventListener('click',e=>{const t=e.target;if(t.closest&&t.closest('.cedit')){e.stopPropagation();return}
if(!LE.click)return;const td=t.closest&&t.closest('#tbl tbody tr[data-act=edit] > td');if(!td||td.classList.contains('selc')||td.classList.contains('editing'))return;
if(e.ctrlKey||e.shiftKey||e.metaKey||e.altKey)return;if(t.closest('a,button,input,select,textarea,.rqa,label'))return;
if(window.getSelection&&String(window.getSelection()).length>0)return;
if(leStart(td)){e.stopPropagation();e.preventDefault()}},true);
document.addEventListener('keydown',e=>{const el=e.target;if(!el.classList||!el.classList.contains('cedit'))return;
if(e.key==='Escape'){e.preventDefault();e.stopPropagation();leCancel()}
else if(e.key==='Enter'&&el.tagName!=='SELECT'||e.key==='Enter'&&el.tagName==='SELECT'){e.preventDefault();e.stopPropagation();leFinish(el,'down')}
else if(e.key==='Tab'){e.preventDefault();e.stopPropagation();leFinish(el,e.shiftKey?-1:1)}},true);
document.addEventListener('change',e=>{const el=e.target;if(el.classList&&el.classList.contains('cedit')&&el.tagName==='SELECT'){e.stopPropagation();leFinish(el,0)}},true);
document.addEventListener('focusout',e=>{const el=e.target;if(el.classList&&el.classList.contains('cedit')&&el.tagName==='INPUT'){setTimeout(()=>{if(LE.ed&&document.body.contains(el)&&document.activeElement!==el)leFinish(el,0)},120)}},true);
/* copy column picker in the list bar */
document.addEventListener('change',e=>{const el=e.target;if(el.dataset&&el.dataset.lcopy){const c=el.value;el.selectedIndex=0;if(c==='@multi')lcmOpen(el.dataset.lcopy);else if(c)leCopyCol(el.dataset.lcopy,c.replace(/^u:/,''),/^u:/.test(c))}},true);
/* ---- multi-column sort ---- */
function rowSortCmp(k,d){return (a,b)=>{const x=val(a.r,k),y=val(b.r,k);const nx=parseFloat(x),ny=parseFloat(y);const c=(!isNaN(nx)&&!isNaN(ny)&&String(nx)===String(x)&&String(ny)===String(y))?nx-ny:String(x).localeCompare(String(y));return c*d}}
function rowsSort(rows,u){if(!u.sk)return;const cs=[rowSortCmp(u.sk,u.sd)].concat((u.sx||[]).map(s=>rowSortCmp(s.k,s.d)));rows.sort((a,b)=>{for(let i=0;i<cs.length;i++){const v=cs[i](a,b);if(v)return v}return 0})}
function sortMark(u,c){if(u.sk===c)return (u.sd>0?' ↑':' ↓')+((u.sx||[]).length?'<sup>1</sup>':'');const j=(u.sx||[]).findIndex(s=>s.k===c);return j>=0?(u.sx[j].d>0?' ↑':' ↓')+'<sup>'+(j+2)+'</sup>':''}
let LESHIFT=false;document.addEventListener('click',e=>{LESHIFT=!!e.shiftKey},true);
const LEACT={
rowopen(el){openForm(el.dataset.sheet,+el.dataset.i)},
cellmode(){LE.click=!LE.click;try{localStorage.setItem('infra-cellclick',LE.click?'1':'0')}catch(e){}route();toast(LE.click?'Click a cell to edit it in place. Use ✎ at the end of a row for the full form.':'Click a row to open its form. Double-click is not used.')},
sort(el){const u=uiOf(el.dataset.sheet),c=el.dataset.col;u.sx=u.sx||[];
if(LESHIFT&&u.sk&&u.sk!==c){const j=u.sx.findIndex(s=>s.k===c);if(j<0){if(u.sx.length<3)u.sx.push({k:c,d:1})}else if(u.sx[j].d>0)u.sx[j].d=-1;else u.sx.splice(j,1)}
else if(u.sk===c){u.sd=-u.sd}else{u.sk=c;u.sd=1;u.sx=[]}route()},
hfcopy(el){if(!HF.sheet)return;leCopyCol(HF.sheet,HF.col,false)},
hfcopyu(el){if(!HF.sheet)return;leCopyCol(HF.sheet,HF.col,true)},
finall(el){const s=el.dataset.sheet,f=uiOf(s).fl[+el.dataset.fi];if(!f)return;f.v=el.dataset.v==='1'?distinct(s,f.k).map(d=>d.v):[];route()}};

/* ---- unsaved changes: review what changed, discard all or per sheet ---- */
let BASE={};
function baseSet(){BASE={};Object.keys(DB).forEach(s=>{try{BASE[s]=JSON.stringify(DB[s])}catch(e){}})}
function pendDiff(){const out=[];if(!SNAP)return out;const now=snap();SHEETS.forEach(s=>{if(LOGHIDE[s])return;const a=SNAP[s]||new Map(),b=now[s]||new Map(),rec={s:s,label:SCHEMA[s].label,add:[],del:[],chg:[]};
b.forEach((c,k)=>{const o=a.get(k);if(!o)rec.add.push(k);else{const fs=[];Object.keys(c).concat(Object.keys(o)).forEach(h=>{if(fs.indexOf(h)<0&&(c[h]||'')!==(o[h]||''))fs.push(h)});if(fs.length)rec.chg.push([k,fs.map(h=>[h,o[h]||'',c[h]||''])])}});
a.forEach((c,k)=>{if(!b.has(k))rec.del.push(k)});if(rec.add.length+rec.del.length+rec.chg.length)out.push(rec)});return out}
const pdN=d=>d.reduce((n,r)=>n+r.add.length+r.del.length+r.chg.length,0);
function pendRestore(sheets){sheets.forEach(s=>{if(BASE[s]==null||!DB[s])return;const a=JSON.parse(BASE[s]);DB[s].splice(0,DB[s].length,...a)});
DVER++;const left=pendDiff();dirty=pdN(left);if(!left.length){dirty=0;PENDLOG=[]}persist();renderPending();renderSide();closeForm();route()}
function pendView(arm){const d=pendDiff(),n=pdN(d);const cut=v=>{v=String(v);return v.length>140?v.slice(0,138)+'…':v};
let h='<div class="modal"><div class="dlg" role="dialog" aria-modal="true" aria-label="Unsaved changes" style="width:min(900px,100%);max-height:88vh;display:flex;flex-direction:column"><h2>Unsaved changes'+(n?' ('+n+')':'')+'</h2><p class="note" style="margin:0 0 8px">What differs from the last saved or loaded workbook. Nothing here is in Excel yet.</p><div style="overflow:auto;flex:1;min-height:80px">';
if(!d.length)h+='<p class="note">No record changes found (the counter may come from settings or layout changes).</p>';
d.forEach(r=>{h+='<section class="card" style="margin:0 0 10px"><div class="tools" style="justify-content:space-between"><b>'+esc(r.label)+' <span class="note">'+r.add.length+' added · '+r.chg.length+' changed · '+r.del.length+' deleted</span></b><button class="btn s" data-act="penddsheet" data-s="'+r.s+'">Discard this sheet\'s changes</button></div>';
r.add.slice(0,100).forEach(k=>h+='<div style="padding:2px 0"><em class="badge b-ok">Added</em> '+esc(k)+'</div>');
r.chg.slice(0,100).forEach(x=>h+='<div style="padding:3px 0"><em class="badge b-warn">Changed</em> <b>'+esc(x[0])+'</b><div class="note" style="margin-left:6px">'+x[1].map(f=>esc(f[0])+': <s>'+esc(cut(f[1])||'∅')+'</s> → <b>'+esc(cut(f[2])||'∅')+'</b>').join('<br>')+'</div></div>');
r.del.slice(0,100).forEach(k=>h+='<div style="padding:2px 0"><em class="badge b-bad">Deleted</em> '+esc(k)+'</div>');
if(r.add.length>100||r.chg.length>100||r.del.length>100)h+='<p class="note" style="margin:4px 0 0">Only the first 100 of each kind are listed.</p>';h+='</section>'});
h+='</div><div class="acts" style="margin-top:10px"><button class="btn" data-act="penddiscard"'+(n||dirty?'':' disabled')+'>'+(arm?'Click again to discard everything':'Discard all unsaved changes')+'</button><div class="tools"><button class="btn" data-act="pendclose">Close</button><button class="btn p" data-act="saveXlsx">Save to Excel</button></div></div></div></div>';
$('modal').innerHTML=h}
const PDACT={pendview(){pendView(false)},pendclose(){closeForm()},
penddiscard(el){if(!dirty&&!pdN(pendDiff()))return;if(!el.dataset.arm){el.dataset.arm='1';el.textContent='Click again to discard everything';return}pendRestore(Object.keys(BASE));toast('Unsaved changes discarded')},
penddsheet(el){pendRestore([el.dataset.s]);const d=pendDiff();if(d.length)pendView(false);else toast('Unsaved changes discarded')}};
