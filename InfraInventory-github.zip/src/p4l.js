/* ---------- Ports & cabling, disks ---------- */
const DEV_SRC=[['ESXi','Hostname','ESXi host'],['Storage','Array','Storage'],['Backup','Device','Backup'],['RackDevices','Name','Other device'],['ServerMI','Hostname','Server']];
function devList(){const out=[],seen=new Set();DEV_SRC.forEach(s=>(DB[s[0]]||[]).forEach(r=>{if(s[0]==='ServerMI'&&r.Platform!=='Physical')return;const n=String(r[s[1]]||'');if(!n||seen.has(n))return;seen.add(n);out.push({n:n,sheet:s[0],kind:s[2],dc:r.DC||'',rack:r.Rack||''})}));return out}
function devRename(sheet,o,n){if(o===n||!o||!DEV_SRC.some(s=>s[0]===sheet))return;(DB.NetPorts||[]).forEach(r=>{if(r.Device===o)r.Device=n;if(r['Remote device']===o)r['Remote device']=n});(DB.Disks||[]).forEach(r=>{if(r.Device===o)r.Device=n});(DB.ArrayParts||[]).forEach(r=>{if(r.Device===o)r.Device=n});if(PV.dev===o)PV.dev=n;if(DV.dev===o)DV.dev=n}
const PV={dev:'',per:0,q:''},DV={dev:'',per:0};
const natc=(a,b)=>String(a).localeCompare(String(b),undefined,{numeric:true});
function devSelect(cur,list,extra,f,v){
const by={};list.forEach(d=>(by[d.kind]=by[d.kind]||[]).push(d));
return '<select class="inp" data-act="devsel" data-v="'+v+'" data-f="dev" aria-label="Device" style="min-width:240px">'+Object.keys(by).map(k=>'<optgroup label="'+esc(k)+'">'+by[k].map(d=>'<option value="'+esc(d.n)+'"'+(d.n===cur?' selected':'')+'>'+esc(d.n)+(d.dc?' · '+esc(d.dc)+(d.rack?'/'+esc(d.rack):''):'')+' ('+f(d.n)+')</option>').join('')+'</optgroup>').join('')+(extra.length?'<optgroup label="Not in inventory">'+extra.map(n=>'<option value="'+esc(n)+'"'+(n===cur?' selected':'')+'>'+esc(n)+' ('+f(n)+')</option>').join('')+'</optgroup>':'')+'</select>'}
function perSelect(cur,def,v){return '<select class="inp" data-act="devsel" data-v="'+v+'" data-f="per" aria-label="Tiles per row">'+[6,8,12,16,24,48].map(n=>'<option value="'+n+'"'+((cur||def)===n?' selected':'')+'>'+n+' per row</option>').join('')+'</select>'}
const PST={Free:'free',Connected:'conn',Reserved:'resv',Down:'down'};
function netSync(base,old){
const unlink=(d,p,me)=>{const r=DB.NetPorts.find(x=>x.Device===d&&x.Port===p);if(r&&r['Remote device']===me.Device&&r['Remote port']===me.Port){r['Remote device']='';r['Remote port']='';if(r.State==='Connected')r.State='Free';r.Updated=ds(0)}};
if(old&&old['Remote device']&&(old['Remote device']!==base['Remote device']||old['Remote port']!==base['Remote port']))unlink(old['Remote device'],old['Remote port'],old);
if(base['Remote device']&&base['Remote port']){
if(base.State==='Free'||!base.State)base.State='Connected';
let r2=DB.NetPorts.find(x=>x.Device===base['Remote device']&&x.Port===base['Remote port']&&x!==old);
if(!r2){r2={Device:base['Remote device'],Port:base['Remote port'],Kind:base.Kind||'',Speed:base.Speed||'',State:'Connected'};DB.NetPorts.push(r2)}
else{const prev=DB.NetPorts.find(x=>x.Device===r2['Remote device']&&x.Port===r2['Remote port']);if(r2['Remote device']&&(r2['Remote device']!==base.Device||r2['Remote port']!==base.Port)&&prev&&prev!==old&&prev!==r2){prev['Remote device']='';prev['Remote port']='';if(prev.State==='Connected')prev.State='Free'}}
r2['Remote device']=base.Device;r2['Remote port']=base.Port;if(!r2.State||r2.State==='Free')r2.State='Connected';if(!r2.Cable&&base.Cable)r2.Cable=base.Cable;r2.Updated=ds(0)}}
function netUnlink(r){if(!r['Remote device'])return;const r2=DB.NetPorts.find(x=>x.Device===r['Remote device']&&x.Port===r['Remote port']);if(r2&&r2['Remote device']===r.Device&&r2['Remote port']===r.Port){r2['Remote device']='';r2['Remote port']='';if(r2.State==='Connected')r2.State='Free'}}
function portsView(){
const devs=devList(),known=new Set(devs.map(d=>d.n));
const extra=Array.from(new Set(DB.NetPorts.map(r=>String(r.Device)).filter(n=>n&&!known.has(n))));
const cnt=n=>DB.NetPorts.filter(r=>r.Device===n).length;
if(!PV.dev||(!known.has(PV.dev)&&extra.indexOf(PV.dev)<0)){const best=devs.slice().sort((x,y)=>cnt(y.n)-cnt(x.n))[0];PV.dev=(best&&cnt(best.n)?best.n:(devs[0]||{}).n)||extra[0]||''}
const rows=DB.NetPorts.map((r,i)=>[r,i]).filter(x=>x[0].Device===PV.dev).sort((a,b)=>natc(a[0].Port,b[0].Port));
const per=PV.per||(rows.length>24?24:12);
const st=s=>rows.filter(x=>(x[0].State||'Free')===s).length;
const grid=rows.length?'<div class="pgrid" style="--n:'+per+'">'+rows.map(x=>{const r=x[0],s=PST[r.State||'Free']||'free',rem=r['Remote device']?r['Remote device']+(r['Remote port']?' : '+r['Remote port']:''):'';return '<button class="pt '+s+'" data-act="portedit" data-i="'+x[1]+'" title="'+esc(r.Port+' · '+(r.Kind||'')+(r.Speed?' '+r.Speed:'')+' · '+(r.State||'Free')+(rem?' → '+rem:'')+(r['VLAN / purpose']?' · '+r['VLAN / purpose']:''))+'"><i>'+esc(r.Port)+'</i><small>'+esc(r['Remote device']||'')+'</small></button>'}).join('')+'</div>':'<div class="empty">No ports for this device yet. Use “Generate ports” to create them in one go.</div>';
const conn=rows.filter(x=>x[0]['Remote device']||x[0]['VLAN / purpose']||x[0].Cable);
const connTbl=conn.length?'<div class="tw"><table><thead><tr><th>Port</th><th>Kind</th><th>Speed</th><th>State</th><th>Connected to</th><th>Cable</th><th>VLAN / purpose</th></tr></thead><tbody>'+conn.map(x=>{const r=x[0];return '<tr><td><a href="#" data-act="portedit" data-i="'+x[1]+'"><b>'+esc(r.Port)+'</b></a></td><td>'+esc(r.Kind||'')+'</td><td>'+esc(r.Speed||'')+'</td><td><span class="badge '+(r.State==='Connected'?'b-ok':r.State==='Down'?'b-bad':r.State==='Reserved'?'b-warn':'b-off')+'">'+esc(r.State||'Free')+'</span></td><td>'+(r['Remote device']?'<a href="#" data-act="portgo" data-d="'+esc(r['Remote device'])+'">'+esc(r['Remote device'])+'</a>'+(r['Remote port']?' : '+esc(r['Remote port']):''):'')+'</td><td>'+esc(r.Cable||'')+'</td><td>'+esc(r['VLAN / purpose']||'')+'</td></tr>'}).join('')+'</tbody></table></div>':'<p class="note" style="margin:0">No connections recorded for this device.</p>';
const q=PV.q.trim().toLowerCase(),found=q?DB.NetPorts.map((r,i)=>[r,i]).filter(x=>['Device','Port','Remote device','Remote port','Cable','VLAN / purpose','Notes'].some(k=>String(x[0][k]||'').toLowerCase().includes(q))).slice(0,60):[];
const res=q?(found.length?'<div class="tw"><table><thead><tr><th>Device</th><th>Port</th><th>State</th><th>Connected to</th><th>Cable</th><th>Purpose</th></tr></thead><tbody>'+found.map(x=>{const r=x[0];return '<tr><td><a href="#" data-act="portgo" data-d="'+esc(r.Device)+'">'+esc(r.Device)+'</a></td><td><a href="#" data-act="portedit" data-i="'+x[1]+'">'+esc(r.Port)+'</a></td><td>'+esc(r.State||'')+'</td><td>'+esc((r['Remote device']||'')+(r['Remote port']?' : '+r['Remote port']:''))+'</td><td>'+esc(r.Cable||'')+'</td><td>'+esc(r['VLAN / purpose']||'')+'</td></tr>'}).join('')+'</tbody></table></div>':'<p class="note" style="margin:8px 0 0">Nothing found.</p>'):'';
return head('Ports &amp; cabling','Network switches, servers and arrays: mark which port is connected to what. Setting both ends is automatic. · sheet “NetPorts”','<button class="btn" data-act="portlist">All ports (list)</button><button class="btn" data-act="portadd">Add port</button><button class="btn p" data-act="portgen">Generate ports</button>')

+'<section class="card"><div class="tools" style="margin-bottom:10px">'+(devs.length||extra.length?devSelect(PV.dev,devs,extra,n=>cnt(n)+' ports','ports')+perSelect(PV.per,per,'ports'):'<span class="note">No devices yet. Add ESXi hosts, storage, backup or other devices first.</span>')+'<span class="tools" style="margin-left:auto"><span class="badge b-ok">'+st('Connected')+' connected</span><span class="badge b-off">'+st('Free')+' free</span><span class="badge b-warn">'+st('Reserved')+' reserved</span><span class="badge b-bad">'+st('Down')+' down</span></span></div>'+grid+'</section>'
+'<section class="card"><h2>Connections of '+esc(PV.dev||'—')+'</h2>'+connTbl+'</section>'
+'<section class="card"><h2>Find a port or cable</h2><input class="inp" data-act="pvq" placeholder="Device, port, cable label, VLAN…" value="'+esc(PV.q)+'" style="max-width:420px">'+res+'</section>'}
/* disks */
const DST={OK:'conn',Spare:'spare',Failed:'down','Predictive fail':'resv',Empty:'free'};
function disksView(){
const devs=devList().filter(d=>d.sheet==='Storage'||d.sheet==='Backup'||d.sheet==='ESXi'||d.sheet==='ServerMI'||DB.Disks.some(r=>r.Device===d.n));
const known=new Set(devs.map(d=>d.n)),extra=Array.from(new Set(DB.Disks.map(r=>String(r.Device)).filter(n=>n&&!known.has(n))));
if(!DV.dev||(!known.has(DV.dev)&&extra.indexOf(DV.dev)<0))DV.dev=((devs.find(d=>DB.Disks.some(r=>r.Device===d.n))||devs.find(d=>d.sheet==='Storage')||devs[0]||{}).n)||extra[0]||'';
const cnt=n=>DB.Disks.filter(r=>r.Device===n).length;
const rows=DB.Disks.map((r,i)=>[r,i]).filter(x=>x[0].Device===DV.dev).sort((a,b)=>natc(a[0].Drawer||'',b[0].Drawer||'')||natc(a[0].Row||'',b[0].Row||'')||natc(a[0].Slot,b[0].Slot));
const grp={};rows.forEach(x=>{const k=(x[0].Drawer||'')+'\u0001'+(x[0].Row||'');(grp[k]=grp[k]||[]).push(x)});const hasDr=rows.some(x=>x[0].Drawer||x[0].Row),maxG=Math.max.apply(null,[0].concat(Object.keys(grp).map(k=>grp[k].length)));
const per=DV.per||(hasDr?Math.min(24,maxG||12):rows.length>24?24:12);
const st=s=>rows.filter(x=>(x[0].State||'OK')===s).length;
const tb=rows.filter(x=>x[0].State!=='Failed'&&x[0].State!=='Empty'&&x[0].State!=='Spare').reduce((a,x)=>a+(parseFloat(x[0]['Size TB'])||0),0);
const gridOf=rs=>rs.length?'<div class="pgrid dk" style="--n:'+per+'">'+rs.map(x=>{const r=x[0],s=DST[r.State||'OK']||'free';return '<button class="pt '+s+'" data-act="diskedit" data-i="'+x[1]+'" title="'+esc((r.Drawer?r.Drawer+' · ':'')+(r.Row?r.Row+' row · ':'')+'Slot '+r.Slot+' · '+(r.Type||'')+' '+(r['Size TB']?r['Size TB']+' TB':'')+' · '+(r.State||'OK')+(r.Model?' · '+r.Model:'')+(r.Serial?' · S/N '+r.Serial:'')+(r['Group / pool']?' · '+r['Group / pool']:''))+'"><i>'+esc(r.Slot)+'</i><small>'+esc(r.State==='Empty'?'empty':((r['Size TB']?r['Size TB']+'T ':'')+(r.Type||'')))+'</small></button>'}).join('')+'</div>':'<div class="empty">No disks for this device yet. Use “Generate disks” to create the bays.</div>';
const stOf=rs=>{const f=rs.filter(x=>x[0].State==='Failed'||x[0].State==='Predictive fail').length;return '<span class="note">'+rs.length+' disks'+(f?' · <b style="color:var(--bad-fg)">'+f+' need attention</b>':'')+'</span>'};
const grid=hasDr&&rows.length?Object.keys(grp).reduce((a,k)=>{const d=k.split('\u0001')[0];if(a.seen.indexOf(d)<0){a.seen.push(d);a.h+='<h3 style="margin:'+(a.seen.length>1?'18px':'0')+' 0 8px;font-size:14px">'+esc(d||'No drawer')+' <span class="note">'+stOf(rows.filter(x=>(x[0].Drawer||'')===d))+'</span></h3>'}
const rw=k.split('\u0001')[1];a.h+=(rw?'<div class="note" style="margin:6px 0 4px"><b>'+esc(rw)+' row</b>'+(/rear|back|lower|under/i.test(rw)?' · sits under the front row, pull the drawer out to reach it':'')+'</div>':'')+gridOf(grp[k]);return a},{seen:[],h:''}).h:gridOf(rows);
const bad=rows.filter(x=>x[0].State==='Failed'||x[0].State==='Predictive fail');
const badTbl=bad.length?'<div class="tw"><table><thead><tr><th>Slot</th><th>State</th><th>Type</th><th>Size TB</th><th>Model</th><th>Serial</th><th>Group / pool</th></tr></thead><tbody>'+bad.map(x=>{const r=x[0];return '<tr><td><a href="#" data-act="diskedit" data-i="'+x[1]+'"><b>'+esc((r.Drawer?r.Drawer+' · ':'')+(r.Row?r.Row+' · ':'')+r.Slot)+'</b></a></td><td><span class="badge '+(r.State==='Failed'?'b-bad':'b-warn')+'">'+esc(r.State)+'</span></td><td>'+esc(r.Type||'')+'</td><td>'+esc(r['Size TB']||'')+'</td><td>'+esc(r.Model||'')+'</td><td class="mono">'+esc(r.Serial||'')+'</td><td>'+esc(r['Group / pool']||'')+'</td></tr>'}).join('')+'</tbody></table></div>':'<p class="note" style="margin:0">No failed or predicted-failure disks on this device.</p>';
return head('Disks','Disk bays of storage arrays, backup devices and servers: type, size, state and RAID group per slot. · sheet “Disks”','<button class="btn" data-act="disklist">All disks (list)</button><button class="btn" data-act="diskadd">Add disk</button><button class="btn p" data-act="diskgen">Generate disks</button>')

+'<section class="card"><div class="tools" style="margin-bottom:10px">'+(devs.length||extra.length?devSelect(DV.dev,devs,extra,n=>cnt(n)+' disks','disks')+perSelect(DV.per,per,'disks'):'<span class="note">No devices yet.</span>')+'<span class="tools" style="margin-left:auto"><span class="badge b-ok">'+st('OK')+' OK</span><span class="badge b-info">'+st('Spare')+' spare</span><span class="badge b-warn">'+st('Predictive fail')+' predictive</span><span class="badge b-bad">'+st('Failed')+' failed</span><span class="badge b-off">'+r1(tb)+' TB active</span></span></div>'+grid+'</section>'
+'<section class="card"><h2>Disks needing attention · '+esc(DV.dev||'—')+'</h2>'+badTbl+'</section>'}
function genDlg(kind){
const isP=kind==='ports',devs=devList(),cur=isP?PV.dev:DV.dev;
const opts=devs.map(d=>'<option'+(d.n===cur?' selected':'')+'>'+esc(d.n)+'</option>').join('');
const kindOpts=(isP?SCHEMA.NetPorts:SCHEMA.Disks).cols.find(c=>c.k===(isP?'Kind':'Type')).o.map(o=>'<option>'+esc(o)+'</option>').join('');
$('modal').innerHTML='<div class="modal" data-act="mbg"><div class="dlg" role="dialog" aria-modal="true" aria-label="Generate '+kind+'" style="width:min(520px,100%)"><h2>Generate '+kind+'</h2><div class="fgrid">'
+'<label class="wide" for="g-dev">Device<select class="inp" id="g-dev">'+opts+'</select></label>'
+'<label for="g-pre">'+(isP?'Port name prefix':'Slot name prefix')+'<input class="inp" id="g-pre" placeholder="'+(isP?'Gi1/0/':'Bay ')+'" value=""></label>'
+(isP?'':'<label for="g-dr">Drawer / enclosure (optional)<input class="inp" id="g-dr" placeholder="Drawer 1"></label><label for="g-rw">Row(s), comma separated (optional)<input class="inp" id="g-rw" placeholder="Front, Rear"></label>')+'<label for="g-start">Start number<input class="inp" id="g-start" type="number" value="1"></label>'
+'<label for="g-n">How many<input class="inp" id="g-n" type="number" value="'+(isP?24:12)+'" min="1" max="'+(isP?96:120)+'"></label>'
+'<label for="g-kind">'+(isP?'Kind':'Type')+'<select class="inp" id="g-kind">'+kindOpts+'</select></label>'
+'<label for="g-x">'+(isP?'Speed':'Size TB')+'<input class="inp" id="g-x" '+(isP?'placeholder="1G, 10G, 25G…"':'type="number" step="any"')+'></label></div>'
+'<p class="note" style="margin:8px 0 0">Existing '+(isP?'ports':'slots')+' with the same name are kept as they are; only missing ones are added.</p><div id="g-err" class="note" style="color:var(--bad-fg)" role="alert"></div>'
+'<div class="acts"><span></span><div class="tools"><button class="btn" data-act="mclose">Cancel</button><button class="btn p" data-act="gengo" data-v="'+kind+'">Generate</button></div></div></div></div>'}
function genGo(kind){
const isP=kind==='ports',dev=$('g-dev').value,pre=$('g-pre').value,s=parseInt($('g-start').value),n=parseInt($('g-n').value);
if(!dev){$('g-err').textContent='Choose a device';return}if(!(n>=1)||isNaN(s)){$('g-err').textContent='Enter a start number and a count';return}
const sh=isP?'NetPorts':'Disks',pk=isP?'Port':'Slot';let add=0;const dr=isP?'':$('g-dr').value.trim(),rws=isP?['']:($('g-rw').value.split(',').map(x=>x.trim()).filter(Boolean).length?$('g-rw').value.split(',').map(x=>x.trim()).filter(Boolean):['']);
rws.forEach(rw=>{for(let k=0;k<n;k++){const nm=pre+(s+k);if(DB[sh].some(r=>r.Device===dev&&String(r[pk])===nm&&(isP||((r.Drawer||'')===dr&&(r.Row||'')===rw))))continue;
const r=isP?{Device:dev,Port:nm,Kind:$('g-kind').value,Speed:$('g-x').value.trim(),State:'Free'}:{Device:dev,Drawer:dr,Row:rw,Slot:nm,Type:$('g-kind').value,'Size TB':$('g-x').value===''?'':parseFloat($('g-x').value),State:'Empty'};r.Updated=ds(0);DB[sh].push(r);add++}});
if(isP)PV.dev=dev;else DV.dev=dev;closeForm();changed();route();toast(add+' '+kind+' added to '+dev)}
const PORTACT={
portedit(el){openForm('NetPorts',+el.dataset.i)},portgo(el){PV.dev=el.dataset.d;PV.q='';route()},
portadd(){openForm('NetPorts',null,{Device:PV.dev})},portgen(){genDlg('ports')},portlist(){location.hash='#netports'},
diskedit(el){openForm('Disks',+el.dataset.i)},diskadd(){openForm('Disks',null,{Device:DV.dev})},diskgen(){genDlg('disks')},disklist(){location.hash='#disklist'},
gengo(el){genGo(el.dataset.v)}};
/* ---------- Catalyst helpers, datastore host picker, rack full-details link ---------- */
function catJobs(r){const n=String(r.Store||'');return DB.BackupJobs.filter(j=>(j['Catalyst store']&&j['Catalyst store']===n)||(!j['Catalyst store']&&n&&j.Target===n)).map(j=>String(j.Job))}
function catRepl(r){const n=String(r.Store||''),o=[];if(r['Replica appliance']||r['Replica store'])o.push((r['Replica appliance']||'?')+(r['Replica store']?' : '+r['Replica store']:''));
DB.ReplJobs.forEach(j=>{if(j['Source store']===n&&j.Active!=='No'){const t=(j['Target appliance']||'?')+(j['Target store']?' : '+j['Target store']:'')+' (via '+j.Job+')';if(!o.some(x=>x.split(' (via')[0]===t.split(' (via')[0]))o.push(t)}});return o}
function hostPick(c,v){
const cur=String(v||'').split(/[;,\n]+/).map(x=>x.trim()).filter(Boolean),hosts=DB.ESXi.map(h=>({n:String(h.Hostname),cl:String(h.Cluster||'(no cluster)')}));
cur.forEach(n=>{if(!hosts.some(h=>h.n===n))hosts.push({n:n,cl:'Not in the ESXi list'})});
const cls=Array.from(new Set(hosts.map(h=>h.cl))).sort();
return '<div class="wide hostpick"><span class="note">'+esc(c.label||c.k)+' (<span id="hp-n">'+cur.length+'</span> selected)</span><input type="hidden" name="'+esc(c.k)+'" value="'+esc(cur.join('; '))+'">'
+'<div class="hpbox">'+(hosts.length?cls.map(cl=>'<div class="hpg"><div class="tools" style="gap:8px"><b>'+esc(cl)+'</b><button type="button" class="btn s" data-act="hpcl" data-cl="'+esc(cl)+'">Toggle all</button></div><div class="hpl">'+hosts.filter(h=>h.cl===cl).map(h=>'<label class="chkrow"><input type="checkbox" class="hpc" data-cl="'+esc(cl)+'" value="'+esc(h.n)+'"'+(cur.indexOf(h.n)>=0?' checked':'')+'> '+esc(h.n)+'</label>').join('')+'</div></div>').join(''):'<span class="note">No ESXi hosts in the inventory yet.</span>')+'</div></div>'}
function hpSync(el){const box=el.closest('.hostpick'),vals=Array.prototype.slice.call(box.querySelectorAll('.hpc:checked')).map(x=>x.value);box.querySelector('input[type=hidden]').value=vals.join('; ');const n=box.querySelector('#hp-n');if(n)n.textContent=vals.length}
const HPACT={hpcl(el){const box=el.closest('.hostpick'),cs=Array.prototype.slice.call(box.querySelectorAll('.hpc')).filter(x=>x.dataset.cl===el.dataset.cl),all=cs.every(x=>x.checked);cs.forEach(x=>{x.checked=!all});hpSync(cs[0])},
rkfull(el){const sh=el.dataset.sheet,i=+el.dataset.i,r=DB[sh]&&DB[sh][i];if(!r)return;const id=SHEET_VIEW[sh],nm=r[SCHEMA[sh].key];if(UI[sh])UI[sh].q=String(nm||'');else uiOf(sh).q=String(nm||'');location.hash='#'+id;setTimeout(()=>openForm(sh,i),80)}};
