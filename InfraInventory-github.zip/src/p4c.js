
/* ---------- knowledge base ---------- */
const KS={sel:null,q:'',type:'All',status:'All'};
const KB_TYPES=['SOP','How-to','Known issue','Reference'],KB_STATUS=['Draft','In review','Approved','Outdated'],CM_TYPES=['Comment','Question','Resolution','Change request'];
let KBDIR=null;
const kbFiles=r=>String(r.Files||'').split(';').map(x=>x.trim()).filter(Boolean);
const kbStCls=s=>s==='Approved'?'b-ok':s==='In review'?'b-info':s==='Outdated'?'b-bad':'b-off';
const cmCls=t=>t==='Resolution'?'b-ok':t==='Question'?'b-info':t==='Change request'?'b-warn':'b-off';
function kbReview(r){const d=daysTo(r['Review due']);if(d===null)return null;return d<0?['b-bad','Review overdue '+(-d)+' d']:d<=30?['b-warn','Review in '+d+' d']:['b-ok','Review '+r['Review due']]}
function kbRows(){
const q=KS.q.trim().toLowerCase();
return DB.KB.filter(r=>(KS.type==='All'||r.Type===KS.type)&&(KS.status==='All'||r.Status===KS.status)&&(!q||[r.ID,r.Title,r.Tags,r.Summary,r.Content,r.Resolution,r.Category].join(' ').toLowerCase().indexOf(q)>=0))
.sort((a,b)=>String(a.Category).localeCompare(String(b.Category))||String(a.ID).localeCompare(String(b.ID)));
}
function kbList(){
const rows=kbRows();let cat=null;
return rows.length?rows.map(r=>{const h=r.Category!==cat?'<div class="note" style="margin:10px 0 4px;text-transform:uppercase;letter-spacing:.05em;font-weight:600">'+esc(r.Category||'Other')+'</div>':'';cat=r.Category;const n=DB.KBComments.filter(c=>c.Article===r.ID).length,rv=kbReview(r);
return h+'<button class="btn" style="width:100%;flex-direction:column;align-items:stretch;gap:6px;height:auto;padding:10px 12px;text-align:left;white-space:normal;margin-bottom:6px;'+(r.ID===KS.sel?'border-color:var(--accent);background:var(--accent-soft)':'')+'" data-act="kbsel" data-id="'+esc(r.ID)+'"><span><b>'+esc(r.Title)+'</b></span><span style="display:flex;flex-wrap:wrap;gap:6px;align-items:center"><span class="mono note">'+esc(r.ID)+'</span><span class="badge b-info">'+esc(r.Type)+'</span><span class="badge '+kbStCls(r.Status)+'">'+esc(r.Status)+'</span>'+(rv&&rv[0]==='b-bad'?'<span class="badge b-bad">Review overdue</span>':'')+(n?'<span class="note">'+n+' comment'+(n>1?'s':'')+'</span>':'')+'</span></button>'}).join(''):'<div class="empty">No article matches. Change the filters or add one.</div>';
}
function kbDetail(){
const r=DB.KB.find(x=>x.ID===KS.sel);
if(!r)return '<div class="empty">Select an article, or create a new one.</div>';
const idx=DB.KB.indexOf(r),cm=DB.KBComments.filter(c=>c.Article===r.ID),fl=kbFiles(r),rv=kbReview(r);
const meta=[['Owner',r.Owner],['Version',r.Version],['Category',r.Category],['Last reviewed',r['Last reviewed']],['Created',r.Created],['Tags',r.Tags]].map(x=>'<label>'+x[0]+'<span style="color:var(--ink);font-size:14px">'+esc(x[1]||'—')+'</span></label>').join('');
const blk=(t,v)=>v?'<h3 style="font-size:14px;margin:16px 0 4px">'+t+'</h3><div style="white-space:pre-wrap">'+esc(v)+'</div>':'';
return '<div class="tools" style="justify-content:space-between"><div><span class="mono note">'+esc(r.ID)+'</span><h2 style="font-size:19px;margin:2px 0 0">'+esc(r.Title)+'</h2><div class="tools" style="margin-top:6px"><span class="badge b-info">'+esc(r.Type)+'</span><span class="badge '+kbStCls(r.Status)+'">'+esc(r.Status)+'</span>'+(rv?'<span class="badge '+rv[0]+'">'+esc(rv[1])+'</span>':'')+'</div></div><div class="tools"><button class="btn s" data-act="kbreview">Mark reviewed</button><button class="btn s" data-act="edit" data-sheet="KB" data-i="'+idx+'">Edit</button></div></div>'
+'<div class="fgrid" style="margin:14px 0">'+meta+'</div>'
+blk('Summary',r.Summary)+blk('Procedure',r.Content)
+(r.Resolution?'<div class="card" style="margin-top:16px;background:var(--surface2);border-color:var(--ok-fg,var(--line))"><h3 style="font-size:14px;margin:0 0 4px">Resolution</h3><div style="white-space:pre-wrap">'+esc(r.Resolution)+'</div></div>':(r.Type==='Known issue'?'<div class="note" style="margin-top:16px">No resolution recorded yet. Add one in Edit, or use “Use as resolution” on a comment below.</div>':''))
+'<h3 style="font-size:14px;margin:18px 0 6px">Attachments</h3>'
+(fl.length?fl.map(n=>'<div class="tools" style="justify-content:space-between;border-top:1px solid var(--line2);padding:6px 0"><a class="lnk" href="Stuff/KnowledgeBase/'+encodeURIComponent(r.ID)+'/'+encodeURIComponent(n)+'" target="_blank" rel="noopener">'+esc(n)+' ↗</a><button class="btn s d" data-act="kbfdel" data-name="'+esc(n)+'">Remove</button></div>').join(''):'<div class="note">No files attached.</div>')
+'<div class="tools" style="margin-top:8px"><label class="btn" for="kb-file" style="cursor:pointer">+ Attach file<input id="kb-file" type="file" multiple hidden></label>'+(!KBDIR?rootBtn():'')+'<span class="note">'+(KBDIR?'Connected: files are written to the folder.':'Files go to Stuff/KnowledgeBase/'+esc(r.ID)+'/ . Not connected, so only the name is recorded: copy the file there yourself.')+'</span></div>'
+'<h3 style="font-size:14px;margin:18px 0 4px">Comments and resolutions</h3>'
+(cm.length?cm.map((c,i)=>'<div class="cmt"><div><b>'+esc(c.Author)+'</b> <span class="badge '+cmCls(c.Type)+'">'+esc(c.Type)+'</span> <small>'+esc(c.Time)+'</small></div><div style="white-space:pre-wrap">'+esc(c.Text)+'</div>'+(c.Type==='Resolution'||c.Type==='Comment'?'<div style="margin-top:6px"><button class="btn s" data-act="kbres" data-ci="'+DB.KBComments.indexOf(c)+'">Use as resolution</button></div>':'')+'</div>').join(''):'<div class="note">No comments yet.</div>')
+'<div class="cmt"><label class="note" for="kc-text">Add a comment</label><textarea class="inp" id="kc-text" rows="3" placeholder="Question, remark, proposed change or a working resolution"></textarea><div class="tools"><select class="inp" id="kc-type" style="width:auto" aria-label="Comment type">'+CM_TYPES.map(t=>'<option>'+t+'</option>').join('')+'</select><select class="inp" id="kc-author" style="width:auto" aria-label="Comment author">'+DB.Operators.filter(o=>o.Active!=='No').map(o=>'<option>'+esc(o.Name)+'</option>').concat(['<option>Team</option>']).join('')+'</select><button class="btn p" data-act="kbcomment">Add comment</button></div></div>';
}
function fgrp(label,items){return '<div class="fgp"><span class="fgl">'+esc(label)+'</span><div class="fgc">'+items.map(i=>'<button class="fc'+(i.on?' on':'')+'" data-act="'+i.act+'" '+(i.k?'data-k="'+i.k+'" ':'')+'data-v="'+esc(i.v)+'">'+esc(i.v)+(i.n==null?'':'<em>'+i.n+'</em>')+'</button>').join('')+'</div></div>'}
function fpanel(gs){return '<div class="fpn">'+gs.join('')+'</div>'}
function kbView(){
if(!KS.sel||!DB.KB.some(r=>r.ID===KS.sel))KS.sel=(kbRows()[0]||DB.KB[0]||{}).ID||null;
const od=DB.KB.filter(r=>{const d=daysTo(r['Review due']);return d!==null&&d<0}).length,ap=DB.KB.filter(r=>r.Status==='Approved').length;
const chips=(arr,k)=>['All'].concat(arr).map(o=>'<button class="chip'+(KS[k]===o?' on':'')+'" data-act="kbf" data-k="'+k+'" data-v="'+esc(o)+'">'+esc(o)+'</button>').join('');
return head('Knowledge base','Internal SOPs, how-tos, known issues and reference notes, with comments and resolutions. Files live in Stuff/KnowledgeBase/<article ID>/.','<button class="btn" data-act="cols" data-sheet="KB">Columns</button><button class="btn p" data-act="kbnew">+ New article</button>')
+'<div class="kpis"><div class="kpi"><span>Articles</span><b>'+DB.KB.length+'</b><small>'+ap+' approved</small></div><div class="kpi"><span>SOPs</span><b>'+DB.KB.filter(r=>r.Type==='SOP').length+'</b><small>&nbsp;</small></div><div class="kpi"><span>Known issues</span><b>'+DB.KB.filter(r=>r.Type==='Known issue').length+'</b><small>'+DB.KB.filter(r=>r.Type==='Known issue'&&!r.Resolution).length+' without resolution</small></div><div class="kpi"><span>Review overdue</span><b>'+od+'</b><small class="'+(od?'w':'g')+'">'+(od?'Needs a review':'All reviewed in time')+'</small></div></div>'
+'<div class="row" style="align-items:flex-start"><section class="card" style="flex:1 1 320px;max-width:440px"><input class="inp" id="kb-q" type="search" data-act="kbq" placeholder="Search title, tags, text" value="'+esc(KS.q)+'" aria-label="Search the knowledge base">'+fpanel([fgrp('Type',['All'].concat(KB_TYPES).map(o=>({v:o,n:o==='All'?DB.KB.length:DB.KB.filter(r=>r.Type===o).length,on:KS.type===o,act:'kbf',k:'type'}))),fgrp('Status',['All'].concat(KB_STATUS).map(o=>({v:o,n:o==='All'?DB.KB.length:DB.KB.filter(r=>r.Status===o).length,on:KS.status===o,act:'kbf',k:'status'})))])+'<div id="kb-list" style="margin-top:6px">'+kbList()+'</div></section>'
+'<section class="card" style="flex:2 1 520px" id="kb-detail">'+kbDetail()+'</section></div>';
}
async function kbAttach(files){
const r=DB.KB.find(x=>x.ID===KS.sel);if(!r)return;let n=0;const names=kbFiles(r);
try{for(const f of files){
if(KBDIR){const d=await KBDIR.getDirectoryHandle(r.ID,{create:true}),h=await d.getFileHandle(f.name,{create:true}),w=await h.createWritable();await w.write(f);await w.close()}
if(names.indexOf(f.name)<0)names.push(f.name);n++}}catch(e){toast('Could not write the file. Check the folder permission.')}
if(n){r.Files=names.join('; ');r.Updated=ds(0);changed()}route();if(n)toast(n+(n===1?' file ':' files ')+(KBDIR?'saved to the article folder':'recorded. Copy it into Stuff/KnowledgeBase/'+r.ID+'/'));
}
