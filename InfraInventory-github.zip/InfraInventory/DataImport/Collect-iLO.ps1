<#
 Collect-iLO.ps1 - read-only collector for HPE iLO / BMC (IPMI) controllers through Redfish (https, iLO 4 2.30+, iLO 5, iLO 6).
 Collects per controller: server name, model, serial number, product ID, iLO + BIOS firmware, power state, health, CPU, RAM,
 iLO address -> sheet "iLO" (import it into ESXi hosts or ServersMI, matched on serial number or BMC IP).
 Daily Health checks: system health, power supplies, fans, temperatures, power state, integrated management log (last 24 h,
 Critical / Warning entries), reachability.
 Output: Output\ilo\iLO-latest.xlsx (or CSV folder) + dated copy.

 Targets: iLO addresses. One per line in a file, optionally "address,credentialName" so different iLOs can use different accounts:
   10.20.100.11
   10.20.100.12,ilo-dc2
 Examples:
   .\Collect-iLO.ps1 -Target 10.20.100.11,10.20.100.12
   .\Collect-iLO.ps1 -TargetFile .\targets\ilo.txt -CredentialName ilo-default -NonInteractive
#>
param(
  [string[]]$Target,
  [string]$TargetFile,
  [pscredential]$Credential,
  [string]$CredentialName = 'ilo',
  [string]$OutDir = '',
  [ValidateSet('Auto','Xlsx','Csv')][string]$Format = 'Auto',
  [int]$LogHours = 24,
  [switch]$NoLog,
  [switch]$StrictTls,
  [switch]$SaveCredential,
  [switch]$NonInteractive
)
# folder of this script ($PSScriptRoot is empty in some hosts / when started by full path)
$HERE = $PSScriptRoot
if (-not $HERE) { try { $HERE = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { } }
if (-not $HERE) { $HERE = (Get-Location).Path }
if (-not $OutDir) { $OutDir = Join-Path $HERE 'Output\ilo' }
. (Join-Path $HERE 'Collector-Common.ps1')
$script:StrictTls = $StrictTls
Set-Tls -Strict:$StrictTls
$SRC = 'iLO'
$targets = Read-Targets $Target $TargetFile
if (-not $targets.Count) { throw 'Give -Target a,b or -TargetFile file.txt' }
$rows = New-Object System.Collections.ArrayList
$credCache = @{}
function Health-Of($x) { $s = "$(Get-Prop $x 'Status.Health')"; if (-not $s) { $s = "$(Get-Prop $x 'Status.HealthRollup')" }; return $s }

foreach ($t in $targets) {
  $t0 = Get-Date; $name = $t.Name
  Write-Host "== $name"
  try {
    $cn = $CredentialName; if ($t.Cred) { $cn = $t.Cred }
    if (-not $credCache.ContainsKey($cn)) { $credCache[$cn] = Get-CollectorCredential $cn $Credential -NonInteractive:$NonInteractive -Save:$SaveCredential }
    $c = $credCache[$cn]
    $auth = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes($c.UserName + ':' + (Get-PlainPassword $c)))
    $h = @{ Authorization = $auth; 'OData-Version' = '4.0' }
    $b = "https://$name"
    $sys = Invoke-Rest "$b/redfish/v1/Systems/1/" 'GET' $h $null 30
    $mgr = $null; try { $mgr = Invoke-Rest "$b/redfish/v1/Managers/1/" 'GET' $h $null 30 } catch { }
    $sh = Health-Of $sys
    $hostn = "$($sys.HostName)"; if (-not $hostn) { $hostn = "$($sys.Name)" }
    $ram = Get-Prop $sys 'MemorySummary.TotalSystemMemoryGiB'
    $cpu = ''; try { $cpu = "{0} x {1}" -f $sys.ProcessorSummary.Count, $sys.ProcessorSummary.Model } catch { }
    $bios = "$($sys.BiosVersion)"
    [void]$rows.Add([pscustomobject][ordered]@{ Hostname = $hostn; 'BMC IP' = $name; 'iLO URL' = "https://$name"; Interface = 'IPMI (iLO)'; Model = $sys.Model; Serial = $sys.SerialNumber; 'Product ID' = $sys.SKU; 'iLO model' = "$(Get-Prop $mgr 'Model')"; 'iLO firmware' = "$(Get-Prop $mgr 'FirmwareVersion')"; 'BIOS version' = $bios; 'Power state' = $sys.PowerState; Health = $sh; CPU = $cpu; 'RAM GB' = $ram })
    Add-Health $SRC $name 'System health' $(if ($sh -eq 'OK') { 'OK' } elseif ($sh -eq 'Warning') { 'WARN' } elseif ($sh) { 'CRIT' } else { 'WARN' }) "${hostn}: $sh, power $($sys.PowerState)"
    # subsystem rollup (memory, processors, storage, network ...) as iLO reports it
    $agg = Get-Prop $sys 'Oem.Hpe.AggregateHealthStatus'; if (-not $agg) { $agg = Get-Prop $sys 'Oem.Hp.AggregateHealthStatus' }
    if ($agg) { foreach ($pp in $agg.PSObject.Properties) { $s = "$(Get-Prop $pp.Value 'Status.Health')"; if ($s -and $s -ne 'OK' -and $pp.Name -notmatch '^(PowerSupplies|Fans|Temperatures)$') { Add-Health $SRC $name ("Subsystem " + $pp.Name) $(if ($s -eq 'Warning') { 'WARN' } else { 'CRIT' }) $s } } }
    # chassis: power supplies, fans, temperatures
    try {
      $pw = Invoke-Rest "$b/redfish/v1/Chassis/1/Power/" 'GET' $h $null 30
      $pi = 0
      foreach ($p in @($pw.PowerSupplies)) { $pi++; $s = Health-Of $p; if ($s -and $s -ne 'OK') { Add-Health $SRC $name "PSU $pi" $(if ($s -eq 'Warning') { 'WARN' } else { 'CRIT' }) "$s $($p.Status.State) $($p.Model)".Trim() } }
    } catch { }
    try {
      $th = Invoke-Rest "$b/redfish/v1/Chassis/1/Thermal/" 'GET' $h $null 30
      foreach ($f in @($th.Fans)) { $s = Health-Of $f; $nm = "$($f.Name)$($f.FanName)"; if ($s -and $s -ne 'OK') { Add-Health $SRC $name ("Fan " + $nm) $(if ($s -eq 'Warning') { 'WARN' } else { 'CRIT' }) "$s" } }
      foreach ($x in @($th.Temperatures)) { $s = Health-Of $x; if ($s -and $s -ne 'OK') { Add-Health $SRC $name ("Temp " + $x.Name) $(if ($s -eq 'Warning') { 'WARN' } else { 'CRIT' }) "$s $($x.ReadingCelsius) C" } }
    } catch { }
    # integrated management log, last N hours
    if (-not $NoLog) {
      try {
        $since = (Get-Date).AddHours(-$LogHours)
        $log = Invoke-Rest "$b/redfish/v1/Systems/1/LogServices/IML/Entries/" 'GET' $h $null 60
        $ent = @($log.Members | Where-Object { $_.Created -and ([datetime]$_.Created) -ge $since -and $_.Severity -in 'Critical', 'Warning' })
        $crit = @($ent | Where-Object { $_.Severity -eq 'Critical' }); $warn = @($ent | Where-Object { $_.Severity -eq 'Warning' })
        if ($crit.Count) { Add-Health $SRC $name 'IML (24 h)' 'CRIT' ("{0} critical: {1}" -f $crit.Count, (($crit | Select-Object -First 3 | ForEach-Object { $_.Message }) -join ' | ')) }
        elseif ($warn.Count) { Add-Health $SRC $name 'IML (24 h)' 'WARN' ("{0} warning: {1}" -f $warn.Count, (($warn | Select-Object -First 3 | ForEach-Object { $_.Message }) -join ' | ')) }
        else { Add-Health $SRC $name 'IML (24 h)' 'OK' 'No critical or warning entries' }
      } catch { Add-Health $SRC $name 'IML (24 h)' 'WARN' "Log not read: $($_.Exception.Message)" }
    }
    Add-Run $name 'iLO' 'ok' 'ok' $t0
  } catch {
    Write-Warning "$name failed: $($_.Exception.Message)"
    Add-Health $SRC $name 'Reachability' 'CRIT' $_.Exception.Message
    Add-Run $name 'iLO' 'FAILED' $_.Exception.Message $t0
  }
}
$sheets = [ordered]@{ iLO = $rows.ToArray() }
exit (Write-CollectorOutput $SRC $sheets $OutDir $Format)
