<#
 Creates (or replaces) a Windows scheduled task that runs one collector every day.
 Run in an elevated PowerShell on the Windows server that hosts the project:
   .\Register-CollectorTask.ps1 -Name Collect-3PAR -Script Collect-3PAR.ps1 -Arguments "-TargetFile .\targets\3par.txt -CredentialName 3par-main" -At 02:30
   .\Register-CollectorTask.ps1 -Name Collect-WSFC -Script Collect-WSFC.ps1 -Arguments "-All" -At 03:00 -RunAsUser CORP\svc-collect
 The task runs as the current user (only while logged on) unless -RunAsUser is given (asks for its password, runs whether
 logged on or not). Saved credentials (Set-CollectorCredential.ps1) must have been created by that same user.
 -Remove deletes the task.
#>
param(
  [Parameter(Mandatory)][string]$Name,
  [string]$Script,
  [string]$Arguments = '',
  [string]$At = '02:30',
  [int]$EveryHours = 0,
  [string]$RunAsUser,
  [switch]$Remove
)
# folder of this script ($PSScriptRoot is empty in some hosts / when started by full path)
$HERE = $PSScriptRoot
if (-not $HERE) { try { $HERE = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { } }
if (-not $HERE) { $HERE = (Get-Location).Path }
$ErrorActionPreference = 'Stop'
if ($Remove) { Unregister-ScheduledTask -TaskName $Name -Confirm:$false; Write-Host "Removed task $Name"; return }
if (-not $Script) { throw '-Script is required.' }
$path = Join-Path $HERE $Script
if (-not (Test-Path -LiteralPath $path)) { throw "Script not found: $path" }
$ps = (Get-Command powershell.exe).Source
$arg = '-NoProfile -ExecutionPolicy Bypass -File "{0}" {1} -NonInteractive' -f $path, $Arguments
$action = New-ScheduledTaskAction -Execute $ps -Argument $arg -WorkingDirectory $HERE
$trigger = New-ScheduledTaskTrigger -Daily -At $At
if ($EveryHours -gt 0) { $trigger.Repetition = (New-ScheduledTaskTrigger -Once -At $At -RepetitionInterval (New-TimeSpan -Hours $EveryHours) -RepetitionDuration (New-TimeSpan -Days 1)).Repetition }
$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Hours 2) -MultipleInstances IgnoreNew
if ($RunAsUser) {
  $c = Get-Credential -UserName $RunAsUser -Message "Password of $RunAsUser (task runs whether logged on or not)"
  Register-ScheduledTask -TaskName $Name -Action $action -Trigger $trigger -Settings $settings -User $c.UserName -Password $c.GetNetworkCredential().Password -RunLevel Limited -Force | Out-Null
} else {
  Register-ScheduledTask -TaskName $Name -Action $action -Trigger $trigger -Settings $settings -User ([Security.Principal.WindowsIdentity]::GetCurrent().Name) -RunLevel Limited -Force | Out-Null
}
Write-Host "Task '$Name' created: daily at $At$(if ($EveryHours) { ", every $EveryHours h" }). Test it: Start-ScheduledTask -TaskName $Name"
