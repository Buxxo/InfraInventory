<#
 Collect-OneView.ps1 - read-only collector for HPE OneView (REST API, no module needed).
 Collects: server hardware (host name as iLO reports it or the profile name, OneView name, model, serial, iLO address, iLO + ROM firmware, power, status, enclosure, bay, CPU, RAM,
 server profile) -> sheet "ServerHardware" (import into ESXi hosts or ServersMI, matched on serial number);
 enclosures (model, serial, status) -> "Enclosures" (import into rack devices).
 Daily Health checks: hardware status (OK / Warning / Critical), enclosure status, active Critical / Warning alerts.
 Output: Output\oneview\OneView-latest.xlsx (or CSV folder) + dated copy.

 Examples:
   .\Collect-OneView.ps1 -Target oneview.corp.local
   .\Collect-OneView.ps1 -TargetFile .\targets\oneview.txt -CredentialName oneview-ro -NonInteractive
 -LoginDomain: for a directory account, e.g. -LoginDomain CORP (default is the local OneView user).
#>
param(
  [string[]]$Target,
  [string]$TargetFile,
  [pscredential]$Credential,
  [string]$CredentialName = 'oneview',
  [string]$LoginDomain = 'local',
  [string]$OutDir = '',
  [ValidateSet('Auto','Xlsx','Csv')][string]$Format = 'Auto',
  [switch]$StrictTls,
  [switch]$SaveCredential,
  [switch]$NonInteractive
)
# folder of this script ($PSScriptRoot is empty in some hosts / when started by full path)
$HERE = $PSScriptRoot
if (-not $HERE) { try { $HERE = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { } }
if (-not $HERE) { $HERE = (Get-Location).Path }
if (-not $OutDir) { $OutDir = Join-Path $HERE 'Output\oneview' }
. (Join-Path $HERE 'Collector-Common.ps1')
$script:StrictTls = $StrictTls
Set-Tls -Strict:$StrictTls
$SRC = 'OneView'
$targets = Read-Targets $Target $TargetFile
if (-not $targets.Count) { throw 'Give -Target a,b or -TargetFile file.txt' }
$hw = New-Object System.Collections.ArrayList; $enc = New-Object System.Collections.ArrayList
function St([string]$s) { if ($s -eq 'OK') { return 'OK' } elseif ($s -eq 'Warning') { return 'WARN' } elseif ($s -in 'Critical', 'Disabled') { return 'CRIT' } else { return 'WARN' } }

foreach ($t in $targets) {
  $t0 = Get-Date; $name = $t.Name; $tok = $null
  Write-Host "== $name"
  $b = "https://$name"
  try {
    $cn = $CredentialName; if ($t.Cred) { $cn = $t.Cred }
    $cred = Get-CollectorCredential $cn $Credential -NonInteractive:$NonInteractive -Save:$SaveCredential
    $ver = 800; try { $ver = (Invoke-Rest "$b/rest/version" 'GET' @{}).currentVersion } catch { }
    $h = @{ 'X-API-Version' = "$ver" }
    $lg = Invoke-Rest "$b/rest/login-sessions" 'POST' $h @{ userName = $cred.UserName; password = (Get-PlainPassword $cred); authLoginDomain = $LoginDomain }
    $tok = $lg.sessionID
    $h = @{ 'X-API-Version' = "$ver"; Auth = $tok }
    $encName = @{}
    foreach ($e in @((Invoke-Rest "$b/rest/enclosures?count=-1" 'GET' $h).members)) {
      $encName[$e.uri] = $e.name
      [void]$enc.Add([pscustomobject][ordered]@{ Name = $e.name; Type = 'Blade enclosure'; Model = $e.enclosureModel; Serial = $e.serialNumber; Status = $e.status; 'Bays' = $e.deviceBayCount; Firmware = "$($e.baselineName)"; Source = $name })
      Add-Health $SRC $e.name 'Enclosure status' (St $e.status) "$($e.status)"
    }
    foreach ($s in @((Invoke-Rest "$b/rest/server-hardware?count=-1" 'GET' $h).members)) {
      $ilo = ''; try { $ilo = (@($s.mpHostInfo.mpIpAddresses) | Where-Object { $_.type -ne 'LinkLocal' } | Select-Object -First 1).address } catch { }
      $en = ''; if ($s.locationUri) { $en = $encName[$s.locationUri] }
      $prof = ''; if ($s.serverProfileUri) { try { $prof = (Invoke-Rest "$b$($s.serverProfileUri)" 'GET' $h).name } catch { } }
      $osn = "$($s.serverName)"; if (-not $osn) { $osn = $prof }
      [void]$hw.Add([pscustomobject][ordered]@{ Hostname = $osn; 'OneView name' = $s.name; 'BMC IP' = $ilo; 'iLO URL' = $(if ($ilo) { "https://$ilo" } else { '' }); Model = $s.model; Serial = $s.serialNumber; 'iLO firmware' = $s.mpFirmwareVersion; 'ROM version' = $s.romVersion; 'Power state' = $s.powerState; Status = $s.status; Enclosure = $en; Bay = $s.position; CPU = "$($s.processorCount) x $($s.processorType)"; 'RAM GB' = [math]::Round([double]$s.memoryMb / 1024, 0); 'Server profile' = $prof; Source = $name })
      if ($s.status -ne 'OK') { Add-Health $SRC $s.name 'Hardware status' (St $s.status) "$($s.status), power $($s.powerState)" }
    }
    try {
      $al = @((Invoke-Rest ("$b/rest/alerts?count=-1&filter=" + [uri]::EscapeDataString("alertState='Active'")) 'GET' $h).members)
      $cr = @($al | Where-Object { $_.severity -eq 'Critical' }); $wa = @($al | Where-Object { $_.severity -eq 'Warning' })
      Add-Health $SRC $name 'Active alerts' $(if ($cr.Count) { 'CRIT' } elseif ($wa.Count) { 'WARN' } else { 'OK' }) ("{0} critical, {1} warning{2}" -f $cr.Count, $wa.Count, $(if ($cr.Count) { ': ' + (($cr | Select-Object -First 3 | ForEach-Object { "$($_.resourceName): $($_.description)" }) -join ' | ') } else { '' }))
    } catch { Add-Health $SRC $name 'Active alerts' 'WARN' "Not read: $($_.Exception.Message)" }
    Add-Run $name 'OneView' 'ok' 'ok' $t0
  } catch {
    Write-Warning "$name failed: $($_.Exception.Message)"
    Add-Health $SRC $name 'Reachability' 'CRIT' $_.Exception.Message
    Add-Run $name 'OneView' 'FAILED' $_.Exception.Message $t0
  } finally { if ($tok) { try { Invoke-Rest "$b/rest/login-sessions" 'DELETE' @{ 'X-API-Version' = '800'; Auth = $tok } | Out-Null } catch { } } }
}
$sheets = [ordered]@{ ServerHardware = $hw.ToArray(); Enclosures = $enc.ToArray() }
exit (Write-CollectorOutput $SRC $sheets $OutDir $Format)
