<#
  Collect-WSFC.ps1  -  Windows failover cluster collector for the infrastructure inventory

  TRANSPORT  Default is WinRM (WS-Man, TCP 5985; 5986 with -UseSSL; any other port with -Port): one port, no RPC.
             -Transport DCOM uses the old RPC / DCOM path (TCP 135 + the dynamic RPC range) instead.
             .\Collect-WSFC.ps1 -All                       WinRM on 5985
             .\Collect-WSFC.ps1 -All -Port 5985 -Credential (Get-Credential)   other account
             .\Collect-WSFC.ps1 -All -Transport DCOM       RPC / DCOM
             Test first:  Test-NetConnection <node> -Port 5985 ; Test-WSMan <node>

  NO MODULES NEEDED. Everything is read with plain WMI / CIM (Get-CimInstance over WinRM, or Get-WmiObject over DCOM), so it runs from any
  Windows PowerShell 3+ machine without RSAT, FailoverClusters, NetAdapter or Storage modules, and it reads
  Windows Server 2012 R2 (and newer) clusters and nodes. The cluster is queried through its own WMI provider
  (root\MSCluster) on the cluster name, the nodes through root\Microsoft\Windows\Storage and Win32_* classes.

  WHAT IT DOES
    For every cluster it reads, read-only: nodes, roles, cluster disks (size, drive letters / CSV paths, NAA id,
    VMDK / RDM / direct FC-iSCSI), quorum witness, and every network interface of every node (name, IP, prefix,
    VLAN, MAC, cluster role). It writes ONE Excel file (or a folder of CSV files) whose sheet names and column
    names are exactly the inventory's, so the Data import page matches everything automatically:
        Clusters, ClusterNodes, ClusterRoles, ClusterResources (everything inside a role: virtual name, IPs,
        disks, services...), ClusterDisks, ServerNics, ServerDisks (standalone servers only), ServerMI
    plus Health (daily checks: node, role, resource, network, quorum state, role not on a preferred owner),
    RunLog (what worked / failed per cluster) and Check (notes about how values were decided). Never imported.

  HOW TO RUN (examples)
    .\Collect-WSFC.ps1 -All                                   every cluster found in the domain (Active Directory)
    .\Collect-WSFC.ps1 -Cluster SQL-FCI01,FS-CL02              only these clusters
    .\Collect-WSFC.ps1 -ClusterFile .\clusters.txt             one name per line, # for comments
    .\Collect-WSFC.ps1 -All -Exclude 'TEST*','LAB*'            skip by wildcard
    .\Collect-WSFC.ps1 -All -VCenter vc-a.corp.example,vc-b    ask vCenter too: tells VMDK from RDM for certain
                                                               (needs VMware.PowerCLI; skipped with a note when absent)
    .\Collect-WSFC.ps1 -Discover                               only list the clusters it would collect
    .\Collect-WSFC.ps1 -Server SRV01,SRV02                    standalone Windows servers (disks, NICs, platform)
    .\Collect-WSFC.ps1 -ServerFile .\servers.txt              same, names from a file
    (clusters and standalone servers can be combined in one run)
  The file given to -ClusterFile / -ServerFile must exist; a relative path is relative to the folder you are in.

  Then open the inventory -> Data import -> "Windows failover clusters" -> drop Output\WSFC-latest.xlsx
  (or all the CSV files of the latest folder). Review, write. Run it again whenever you want a refresh;
  the import shows only what changed and what is no longer reported.

  NEEDS  Windows PowerShell 3.0 or newer (WinRM transport also runs in PowerShell 7; DCOM needs Windows PowerShell),
         TCP 5985 (WinRM) - or with -Transport DCOM: TCP 135 + the dynamic RPC range - from this machine to the
         cluster and to every node, and an account that may read
         them (a cluster administrator / local administrator of the nodes is fine). Optional: ImportExcel
         (Excel output, otherwise CSV). Nothing is changed on any cluster; no password is stored.

  SCHEDULING  .\Register-CollectorTask.ps1 -Name Collect-WSFC -Script Collect-WSFC.ps1 -Arguments '-All' -At 03:00
    Exit code 0 = everything collected, 1 = a cluster or server failed (see RunLog). With -VCenter in a scheduled
    run save the vCenter account first: .\Set-CollectorCredential.ps1 -Name vcenter

  NOT TESTED against your environment. Please run it first on one or two clusters (-Cluster) and look at Check.
#>
[CmdletBinding()]
param(
  [string[]]$Cluster,
  [string]$ClusterFile,
  [switch]$All,
  [string[]]$Server,
  [string]$ServerFile,
  [string]$Domain = $env:USERDNSDOMAIN,
  [string[]]$Exclude = @(),
  [string]$OutDir = '',
  [ValidateSet('Auto','Xlsx','Csv')][string]$Format = 'Auto',
  [string[]]$VCenter,
  [pscredential]$VCCredential,
  [string]$VCCredentialName = 'vcenter',
  [switch]$NonInteractive,
  [switch]$NoNics,
  [switch]$NoDns,
  [switch]$NoRoles,
  [switch]$NoDisksOnStandalone,
  [switch]$Discover,
  [ValidateSet('WinRM','DCOM')][string]$Transport = 'WinRM',
  [int]$Port = 0,
  [switch]$UseSSL,
  [pscredential]$Credential,
  [ValidateSet('Default','Kerberos','Negotiate','Basic','Credssp')][string]$Authentication = 'Default',
  [int]$TimeoutSec = 60,
  # adapter name pattern -> Purpose in the inventory. Cluster network role wins for heartbeat/production.
  [System.Collections.IDictionary]$PurposeMap = [ordered]@{ 'backup|bkp|veeam|commvault' = 'Backup'; 'iscsi|storage|san|smb' = 'Storage'; 'mgmt|manage|admin' = 'Management'; 'hb|heart|private|csv' = 'Heartbeat' }
)
$ErrorActionPreference = 'Stop'
Set-StrictMode -Off

# folder of this script ($PSScriptRoot is empty in some hosts / when started by full path)
$HERE = $PSScriptRoot
if (-not $HERE) { try { $HERE = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { } }
if (-not $HERE) { $HERE = (Get-Location).Path }
if (-not $OutDir) { $OutDir = Join-Path $HERE 'Output\wsfc' }
if ($Port -le 0) { if ($Transport -eq 'DCOM') { $Port = 135 } elseif ($UseSSL) { $Port = 5986 } else { $Port = 5985 } }
if ($Transport -eq 'DCOM' -and -not (Get-Command Get-WmiObject -ErrorAction SilentlyContinue)) {
  throw 'Get-WmiObject is not available (PowerShell 7?). Start this script from Windows PowerShell 5.1 (powershell.exe).'
}

# ------------------------------------------------------------ helpers
$script:Check = New-Object System.Collections.ArrayList
function Add-Check([string]$cl, [string]$item, [string]$msg) { [void]$script:Check.Add([pscustomobject][ordered]@{ Cluster = $cl; Item = $item; Message = $msg }) }
$script:HealthRows = New-Object System.Collections.ArrayList
function New-Hl([string]$target, [string]$item, [string]$status, [string]$msg) { return [pscustomobject][ordered]@{ Source = 'WSFC'; Target = $target; Item = $item; Status = $status; Message = $msg } }
function Short([string]$n) { if (-not $n) { return '' }; return ($n.Split('.')[0]).ToUpper() }
function ConvertTo-Naa([string]$u) {
  if (-not $u) { return '' }
  $s = ($u -replace '^naa\.', '').Trim().ToLower()
  if ($s -match '^[0-9a-f]{32}$') { return 'naa.' + $s }
  if ($s -match '^[0-9a-f]{16}$') { return 'naa.' + $s }
  return $u.Trim()
}
function IpToInt([string]$ip) {
  $b = [System.Net.IPAddress]::Parse($ip).GetAddressBytes()
  return ([int64]$b[0] -shl 24) + ([int64]$b[1] -shl 16) + ([int64]$b[2] -shl 8) + [int64]$b[3]
}
function MaskToLen([string]$mask) {
  try { $n = IpToInt $mask; $c = 0; for ($i = 31; $i -ge 0; $i--) { if (($n -shr $i) -band 1) { $c++ } else { break } }; return $c } catch { return 0 }
}
function Get-Subnet([string]$ip, $len) {
  try {
    $n = IpToInt $ip
    $full = [int64]4294967295
    $m = if ([int]$len -le 0) { [int64]0 } else { ($full -shl (32 - [int]$len)) -band $full }
    $a = $n -band $m
    return ('{0}.{1}.{2}.{3}/{4}' -f (($a -shr 24) -band 255), (($a -shr 16) -band 255), (($a -shr 8) -band 255), ($a -band 255), $len)
  } catch { return '' }
}

# ---- WMI access (DCOM). One call = one query against one machine.
$NS_CL = 'root\MSCluster'
$NS_ST = 'root\Microsoft\Windows\Storage'
$NS_NET = 'root\StandardCimv2'
$script:CimSess = @{}
function Get-Cs([string]$comp) {
  $k = $comp.ToLower()
  if ($script:CimSess.ContainsKey($k)) { return $script:CimSess[$k] }
  # -Protocol and -UseSsl are different parameter sets: they cannot be combined
  if ($UseSSL) { $so = New-CimSessionOption -UseSsl } else { $so = New-CimSessionOption -Protocol Wsman }
  $a = @{ ComputerName = $comp; Port = $Port; SessionOption = $so; OperationTimeoutSec = $TimeoutSec; ErrorAction = 'Stop' }
  if ($Credential) { $a['Credential'] = $Credential }
  if ($Authentication -ne 'Default') { $a['Authentication'] = $Authentication }
  $cs = New-CimSession @a
  $script:CimSess[$k] = $cs
  return $cs
}
function Wq([string]$comp, [string]$ns, [string]$query) {
  if ($Transport -eq 'WinRM') { return @(Get-CimInstance -CimSession (Get-Cs $comp) -Namespace $ns -Query $query -ErrorAction Stop) }
  return @(Get-WmiObject -ComputerName $comp -Namespace $ns -Query $query -ErrorAction Stop)
}
function WqEsc([string]$s) { return $s.Replace('\', '\\').Replace("'", "\'") }
# objects related to $obj through an association class (the object must come from Wq / Get-WmiObject)
function Wrel($obj, [string]$comp, [string]$ns, [string]$assoc, [string]$result) {
  if ($Transport -eq 'WinRM') {
    $a = @{ InputObject = $obj; Association = $assoc; CimSession = (Get-Cs $comp); ErrorAction = 'Stop' }
    if ($result) { $a['ResultClassName'] = $result }
    return @(Get-CimAssociatedInstance @a)
  }
  $q = "ASSOCIATORS OF {$($obj.__RELPATH)} WHERE AssocClass = $assoc"
  if ($result) { $q += " ResultClass = $result" }
  return @(Get-WmiObject -ComputerName $comp -Namespace $ns -Query $q -ErrorAction Stop)
}
# private property of a cluster resource (Address, DnsName, DiskSignature, ...)
function Get-Param($res, [string]$name) {
  try {
    $pp = $res.PrivateProperties
    if ($pp -eq $null) { return $null }
    $pl = $null
    if ($pp.CimInstanceProperties) { $pl = $pp.CimInstanceProperties } elseif ($pp.Properties) { $pl = $pp.Properties }
    if ($pl) { foreach ($p in $pl) { if ($p.Name -eq $name) { $v = $p.Value; if ($v -is [array]) { $v = ($v -join ', ') }; return $v } } }
    # last resort: plain property access (works on both object kinds)
    $pr = $pp.psobject.Properties[$name]
    if ($pr) { $v = $pr.Value; if ($v -is [array]) { $v = ($v -join ', ') }; return $v }
  } catch { }
  return $null
}
# plain-words hint for the most common connection errors (added to the message in RunLog / Health)
function Add-Hint([string]$m) {
  $h = ''
  if ($m -match 'RPC server|0x800706BA') { $h = 'RPC / DCOM is blocked: use the default -Transport WinRM (TCP 5985).' }
  elseif ($m -match 'Access is denied|0x80070005|AccessDenied|Unauthorized') { $h = 'The account has no rights on that machine: run PowerShell as a cluster / local administrator of the nodes, or pass -Credential.' }
  elseif ($m -match 'Kerberos|target principal|SPN|0x80090322|0x8009030') { $h = 'Kerberos failed: use the FQDN (not an IP address) and check the time and DNS of this machine, or try -Authentication Negotiate.' }
  elseif ($m -match 'WinRM cannot process|WS-Management|0x803381|cannot connect to the destination|Cannot connect') { $h = 'WinRM does not answer on that port: check the WinRM service / listener on the target (winrm quickconfig, winrm enumerate winrm/config/listener) and the firewall for TCP ' + $Port + '.' }
  elseif ($m -match 'Invalid namespace|0x8004100E') { $h = 'Namespace missing: the Cluster service is not running there, or it is not a cluster node (MSCluster).' }
  elseif ($m -match 'timed out|timeout|0x80338126') { $h = 'No answer in time: try a larger -TimeoutSec or check the network path.' }
  if ($h) { return "$m  >> $h" }
  return $m
}
# is the transport port open (5985 WinRM / 135 RPC)? (a quick answer instead of a long DCOM time-out)
function Test-Rpc([string]$comp) {
  try {
    $c = New-Object System.Net.Sockets.TcpClient
    $iar = $c.BeginConnect($comp, $Port, $null, $null)
    $ok = $iar.AsyncWaitHandle.WaitOne(4000, $false)
    if ($ok -and $c.Connected) { $c.Close(); return $true }
    $c.Close(); return $false
  } catch { return $false }
}

$StateRes = @{ '-1' = 'Unknown'; '0' = 'Inherited'; '1' = 'Initializing'; '2' = 'Online'; '3' = 'Offline'; '4' = 'Failed'; '128' = 'Pending'; '129' = 'OnlinePending'; '130' = 'OfflinePending' }
$StateGrp = @{ '-1' = 'Unknown'; '0' = 'Online'; '1' = 'Offline'; '2' = 'Failed'; '3' = 'PartialOnline'; '4' = 'Pending' }
$StateNode = @{ '-1' = 'Unknown'; '0' = 'Up'; '1' = 'Down'; '2' = 'Paused'; '3' = 'Joining' }
$StateNet = @{ '-1' = 'Unknown'; '0' = 'Unavailable'; '1' = 'Down'; '2' = 'Partitioned'; '3' = 'Up' }
$BusName = @{ '1' = 'SCSI'; '2' = 'ATAPI'; '3' = 'ATA'; '4' = '1394'; '5' = 'SSA'; '6' = 'Fibre Channel'; '7' = 'USB'; '8' = 'RAID'; '9' = 'iSCSI'; '10' = 'SAS'; '11' = 'SATA'; '12' = 'SD'; '13' = 'MMC'; '14' = 'Virtual'; '15' = 'FileBackedVirtual'; '16' = 'Spaces'; '17' = 'NVMe' }
function St($map, $v) { $k = "$v"; if ($map.ContainsKey($k)) { return $map[$k] } else { return $k } }

# Decide VMDK / RDM / direct for one disk seen inside Windows. $vi = vCenter info of the VM (or $null).
function Resolve-DiskType($naa, $serial, $model, $bus, $size, $virtNode, $vi) {
  $type = ''; $ds = ''; $note = ''
  if ($vi) {
    $hd = $null
    if ($naa) { $hd = $vi.Disks | Where-Object { $_.ScsiCanonicalName -and (ConvertTo-Naa $_.ScsiCanonicalName) -eq $naa } | Select-Object -First 1 }
    if (-not $hd) {
      $ser = ($serial -replace '[-\s]', '').ToLower()
      if ($ser) { $hd = $vi.Disks | Where-Object { try { (($_.ExtensionData.Backing.Uuid) -replace '-', '').ToLower() -eq $ser } catch { $false } } | Select-Object -First 1 }
      if (-not $hd -and $size) {
        $cand = @($vi.Disks | Where-Object { $_.CapacityGB -and [math]::Abs($_.CapacityGB - $size) -lt 0.1 })
        if ($cand.Count -eq 1) { $hd = $cand[0]; $note = 'matched to the vCenter disk by size only' }
      }
    }
    if ($hd) {
      if ("$($hd.DiskType)" -match 'Raw') { if ("$($hd.DiskType)" -match 'Physical') { $type = 'RDM - physical' } else { $type = 'RDM - virtual' } } else { $type = 'VMDK' }
      if ($hd.Filename -match '^\[([^\]]+)\]') { $ds = $Matches[1] }
    }
  }
  if (-not $type) {
    if ($bus -match 'iSCSI') { $type = 'FC / iSCSI direct' }
    elseif ($virtNode -eq $false) { $type = 'FC / iSCSI direct' }
    elseif ($model -match 'VMware') { $type = 'VMDK'; $note = 'Shown as VMDK because the guest sees a VMware virtual disk. A virtual-mode RDM looks the same: use -VCenter or an RVTools import to confirm.' }
    elseif ($virtNode -eq $true) { $type = 'RDM - physical'; $note = 'Array LUN seen inside a VM: assumed physical RDM (could also be in-guest iSCSI). Use -VCenter to confirm.' }
    else { $type = 'FC / iSCSI direct' }
  }
  return [pscustomobject]@{ Type = $type; Ds = $ds; Note = $note }
}

# SCSI id as vSphere shows it (controller:unit). In a VMware guest the PCI slot tells the controller (160, 192, 224, 256 = SCSI 0..3)
# and the target is the unit number. Empty when it cannot be told.
function Get-ScsiId([string]$loc, $virt) {
  if ($loc -match 'SCSI\(P(\d+)T(\d+)L(\d+)\)') { return "$($Matches[1]):$($Matches[2]):$($Matches[3])" }
  if ($virt -eq $true -and $loc -match 'PCI Slot (\d+).*Target (\d+)') {
    $map = @{ 160 = 0; 192 = 1; 224 = 2; 256 = 3 }; $sl = [int]$Matches[1]; $tg = $Matches[2]
    if ($map.ContainsKey($sl)) { return "$($map[$sl]):$tg" }
  }
  return ''
}

# Platform / OS / model of one node
function Get-NodeFacts([string]$comp) {
  $o = [pscustomobject]@{ Virtual = $null; Model = ''; OS = ''; Version = ''; Err = '' }
  try {
    $cs = @(Wq $comp 'root\cimv2' 'SELECT Manufacturer, Model FROM Win32_ComputerSystem')[0]
    $o.Model = "$($cs.Manufacturer) $($cs.Model)".Trim()
    $o.Virtual = [bool](($cs.Model -match 'Virtual|VMware|KVM|VirtualBox') -or ($cs.Manufacturer -match 'VMware|QEMU|Xen'))
    $os = @(Wq $comp 'root\cimv2' 'SELECT Caption, Version FROM Win32_OperatingSystem')[0]
    $o.OS = "$($os.Caption)".Trim(); $o.Version = "$($os.Version)"
  } catch { $o.Err = $_.Exception.Message }
  return $o
}

# Disks of one node (Storage WMI namespace: 2012 and newer; older systems fall back to Win32_DiskDrive without NAA ids).
# Returns objects: Number Size UniqueId Serial Model Bus Location Signature Guid IsBoot IsSystem Mounts (array)
function Get-NodeDisks([string]$comp) {
  $out = @()
  $stOk = $true
  try { $disks = @(Wq $comp $NS_ST 'SELECT * FROM MSFT_Disk') } catch { $stOk = $false }
  if ($stOk) {
    $parts = @(); try { $parts = @(Wq $comp $NS_ST 'SELECT * FROM MSFT_Partition') } catch { }
    foreach ($d in $disks) {
      $mnt = @()
      foreach ($p in @($parts | Where-Object { [string]$_.DiskNumber -eq [string]$d.Number })) {
        $dl = $p.DriveLetter; $c = ''
        if ($dl -is [char]) { if ([int]$dl -ge 65) { $c = [string]$dl } }
        elseif ("$dl" -match '^[A-Za-z]$') { $c = "$dl" }
        elseif ("$dl" -match '^\d+$' -and [int]$dl -ge 65) { $c = [string][char][int]$dl }
        if ($c) { $mnt += ("{0}:" -f $c.ToUpper()) }
        foreach ($ap in @($p.AccessPaths)) { if ("$ap" -match '^[A-Za-z]:\\.+') { $mnt += ("$ap").TrimEnd('\') } }
      }
      $sig = $null; if ("$($d.Signature)" -match '^\d+$') { $sig = [uint32]([int64]$d.Signature -band [int64]4294967295) }
      $out += [pscustomobject]@{
        Number = [int]$d.Number; Size = [double]$d.Size; UniqueId = "$($d.UniqueId)"; Serial = "$($d.SerialNumber)".Trim()
        Model = ("$($d.FriendlyName) $($d.Model)").Trim(); Bus = (St $BusName $d.BusType); Location = "$($d.Location)"
        Signature = $sig; Guid = ("$($d.Guid)").Trim('{}').ToLower(); IsBoot = [bool]$d.IsBoot; IsSystem = [bool]$d.IsSystem; Mounts = @($mnt)
      }
    }
    return $out
  }
  # fallback: Win32_DiskDrive
  $dd = @(Wq $comp 'root\cimv2' 'SELECT * FROM Win32_DiskDrive')
  foreach ($d in $dd) {
    $mnt = @()
    try {
      foreach ($p in @(Wrel $d $comp 'root\cimv2' 'Win32_DiskDriveToDiskPartition' 'Win32_DiskPartition')) {
        foreach ($l in @(Wrel $p $comp 'root\cimv2' 'Win32_LogicalDiskToPartition' 'Win32_LogicalDisk')) { if ($l.DeviceID) { $mnt += "$($l.DeviceID)" } }
      }
    } catch { }
    $sig = $null; if ("$($d.Signature)" -match '^\d+$') { $sig = [uint32]([int64]$d.Signature -band [int64]4294967295) }
    $loc = ''; if ($d.SCSIPort -ne $null) { $loc = "SCSI(P$($d.SCSIPort)T$($d.SCSITargetId)L$($d.SCSILogicalUnit))" }
    $out += [pscustomobject]@{
      Number = [int]$d.Index; Size = [double]$d.Size; UniqueId = ''; Serial = "$($d.SerialNumber)".Trim(); Model = "$($d.Model)".Trim(); Bus = "$($d.InterfaceType)"
      Location = $loc; Signature = $sig; Guid = ''; IsBoot = $false; IsSystem = $false; Mounts = @($mnt)
    }
  }
  return $out
}

# Network interfaces of one node. $cnets are the cluster's networks (empty for standalone), already with numeric subnet.
function Get-NicRows([string]$comp, [string]$name, $cnets, $vi, [string]$cl) {
  $out = @()
  try {
    $ads = @(Wq $comp 'root\cimv2' 'SELECT * FROM Win32_NetworkAdapter WHERE NetConnectionID IS NOT NULL')
    $cfg = @(Wq $comp 'root\cimv2' 'SELECT * FROM Win32_NetworkAdapterConfiguration')
  } catch { Add-Check $cl $name "Network adapters not read: $($_.Exception.Message)"; return $out }
  # DNS: forward lookup of "<host>p.<domain>" (primary name of a cluster node) and PTR of every address. No record = empty.
  $pIps = @()
  if (-not $NoDns) {
    try {
      $sh = Short $name; $dom = ''
      if ("$name" -match '^[^.]+\.(.+)$') { $dom = $Matches[1] } elseif ($env:USERDNSDOMAIN) { $dom = $env:USERDNSDOMAIN.ToLower() }
      if ($dom) { $pIps = @([System.Net.Dns]::GetHostAddresses("${sh}p.$dom") | ForEach-Object { $_.IPAddressToString }); $pName = "${sh}p.$dom" }
    } catch { $pIps = @() }
  }
  $vlans = @{}
  try { foreach ($na in @(Wq $comp $NS_NET 'SELECT InterfaceIndex, VlanID FROM MSFT_NetAdapter')) { $vlans["$($na.InterfaceIndex)"] = $na.VlanID } } catch { }
  foreach ($a in $ads) {
    if ("$($a.Name)" -match 'Failover Cluster Virtual|Loopback|ISATAP|Teredo|6to4|WAN Miniport|Hyper-V Virtual Switch Extension') { continue }
    $c = $cfg | Where-Object { [string]$_.Index -eq [string]$a.Index } | Select-Object -First 1
    $ip = ''; $subnet = ''; $len = 0; $gw = $false
    if ($c) {
      $addrs = @($c.IPAddress); $masks = @($c.IPSubnet)
      for ($i = 0; $i -lt $addrs.Count; $i++) {
        if ("$($addrs[$i])" -match '^\d+\.\d+\.\d+\.\d+$' -and "$($addrs[$i])" -notmatch '^169\.254\.') { $ip = "$($addrs[$i])"; if ($i -lt $masks.Count) { $len = MaskToLen "$($masks[$i])" }; break }
      }
      if ($ip) { $subnet = Get-Subnet $ip $len }
      $gw = [bool](@($c.DefaultIPGateway) | Where-Object { $_ })
    }
    $cnet = $null
    if ($ip -and $cnets) { try { $n = IpToInt $ip; foreach ($x in $cnets) { if (($n -band $x.Mask) -eq ($x.Base -band $x.Mask)) { $cnet = $x; break } } } catch { } }
    # hint only: the dashboard decides the final purpose (ServersMI IP, host+p name, Subnets list, routing)
    $pre = 'Collector'; if ($NoDns) { $pre = 'Hint' }
    $purpose = 'Other'; $basis = "${pre}: no hint"
    if ($cnet) {
      if ([int]$cnet.Role -eq 1) { $purpose = 'Heartbeat'; $basis = "${pre}: cluster network $($cnet.Name) (cluster only)" }
      elseif ([int]$cnet.Role -eq 3) { $purpose = 'Production'; $basis = "${pre}: cluster network $($cnet.Name) (cluster and clients)" }
    }
    $nm = "$($a.NetConnectionID)"
    if ($purpose -eq 'Other') {
      foreach ($k in $PurposeMap.Keys) { if ($nm -match $k -or ($cnet -and $cnet.Name -match $k)) { $purpose = $PurposeMap[$k]; $basis = "${pre}: name pattern $k"; break } }
    }
    $gwv = ''; if ($c) { $gwv = "$(@($c.DefaultIPGateway) | Where-Object { $_ } | Select-Object -First 1)" }
    $dnsn = ''
    if (-not $NoDns -and $ip) {
      if ($pIps -contains $ip) { $dnsn = $pName }
      else { try { $he = [System.Net.Dns]::GetHostEntry($ip); if ($he -and $he.HostName -and $he.HostName -ne $ip) { $dnsn = "$($he.HostName)".ToLower() } } catch { } }
    }
    $mac = ("$($a.MACAddress)").Replace('-', ':')
    $vlan = ''; try { $v = $vlans["$($a.InterfaceIndex)"]; if ($v) { $vlan = $v } } catch { }
    $pg = ''
    if ($vi -and $mac) { $vn = $vi.Nics | Where-Object { ("$($_.MacAddress)").ToLower() -eq $mac.ToLower() } | Select-Object -First 1; if ($vn) { $pg = $vn.NetworkName } }
    $out += [pscustomobject][ordered]@{ Server = (Short $name); Interface = $nm; Purpose = $purpose; IP = $ip; 'Subnet / prefix' = $subnet; VLAN = $vlan; 'DNS name' = $dnsn; Gateway = $gwv; MAC = $mac; 'Port group / switch' = $pg; 'Detected by' = $basis }
  }
  return $out
}

# Details text of one cluster resource (virtual name, IP, service, share, instance ...)
function Get-ResDetails($r) {
  $t = "$($r.Type)"
  $p = { param($n) $v = Get-Param $r $n; if ($v) { "$v" } else { '' } }
  switch -Regex ($t) {
    '^Network Name$'     { $d = & $p 'DnsName'; if (-not $d) { $d = & $p 'Name' }; $dom = & $p 'Domain'; return ('DNS name ' + $d + $(if ($dom) { ' (' + $dom + ')' } else { '' })) }
    '^IP Address$'       { $a = & $p 'Address'; $m = & $p 'SubnetMask'; $n = & $p 'Network'; $x = $a; if ($m) { $x += ' / ' + $m }; if ($n) { $x += ' on ' + $n }; return $x }
    'Generic Service'    { return ('Service ' + (& $p 'ServiceName')) }
    'Generic Application' { return ('Command ' + (& $p 'CommandLine')) }
    'Generic Script'     { return ('Script ' + (& $p 'ScriptFilepath')) }
    '^File Share$'       { return ('Share ' + (& $p 'ShareName') + ' = ' + (& $p 'Path')) }
    '^SQL Server$'       { return ('Instance ' + (& $p 'InstanceName') + ' (virtual server ' + (& $p 'VirtualServerName') + ')') }
    'Share Witness'      { return ('Share ' + (& $p 'SharePath')) }
    default              { return '' }
  }
}

# clusters registered in Active Directory (no module): every cluster has a computer object with an SPN MSServerClusterMgmtAPI/<name>
function Find-ClustersInAd([string]$dom) {
  $root = $null
  if ($dom) { $root = New-Object System.DirectoryServices.DirectoryEntry(('LDAP://DC=' + ($dom -replace '\.', ',DC='))) }
  $ds = New-Object System.DirectoryServices.DirectorySearcher
  if ($root) { $ds.SearchRoot = $root }
  $ds.Filter = '(&(objectCategory=computer)(servicePrincipalName=MSServerClusterMgmtAPI/*))'
  $ds.PageSize = 500
  [void]$ds.PropertiesToLoad.Add('name')
  $res = @(); foreach ($r in $ds.FindAll()) { $res += "$($r.Properties['name'][0])" }
  return $res
}

# ------------------------------------------------------------ which clusters / servers
function Read-List([string]$file) {
  if (-not (Test-Path -LiteralPath $file)) { throw "List file not found: $file (current folder: $((Get-Location).Path))" }
  $o = @(); foreach ($l in (Get-Content -LiteralPath $file)) { $x = ($l -replace '#.*$', '').Trim(); if ($x) { $o += $x } }
  return $o
}
$names = New-Object System.Collections.ArrayList
if ($Cluster) { $Cluster | ForEach-Object { [void]$names.Add($_.Trim()) } }
if ($ClusterFile) { Read-List $ClusterFile | ForEach-Object { [void]$names.Add($_) } }
$srvNames = New-Object System.Collections.ArrayList
if ($Server) { $Server | ForEach-Object { [void]$srvNames.Add($_.Trim()) } }
if ($ServerFile) { Read-List $ServerFile | ForEach-Object { [void]$srvNames.Add($_) } }
if (-not $All -and -not $Discover -and -not $names.Count -and -not $srvNames.Count) { throw 'Give -All, -Cluster <names>, -ClusterFile <file>, -Server <names> or -ServerFile <file>.' }
if ($All -or $Discover) {
  Write-Host "Looking for clusters in Active Directory $(if ($Domain) { "('$Domain')" } else { '(current domain)' }) ..."
  Find-ClustersInAd $Domain | ForEach-Object { [void]$names.Add($_) }
}
$names = @($names | Sort-Object -Unique | Where-Object { $n = $_; -not ($Exclude | Where-Object { $n -like $_ }) })
$srvNames = @($srvNames | Sort-Object -Unique | Where-Object { $n = $_; -not ($Exclude | Where-Object { $n -like $_ }) })
Write-Host ("{0} cluster(s): {1}" -f $names.Count, ($names -join ', '))
if ($srvNames.Count) { Write-Host ("{0} standalone server(s): {1}" -f $srvNames.Count, ($srvNames -join ', ')) }
if ($Discover) { return }

# ------------------------------------------------------------ optional vCenter
$vmCache = @{}
$haveVC = $false
if ($VCenter) {
  try {
    Import-Module VMware.VimAutomation.Core -ErrorAction Stop
    if (-not $VCCredential) {
      $cf = Join-Path (Join-Path $HERE 'Credentials') ("{0}.xml" -f ($VCCredentialName -replace '[^\w\.-]', '_'))
      if (Test-Path -LiteralPath $cf) { $VCCredential = Import-Clixml -LiteralPath $cf }
      elseif ($NonInteractive -or -not [Environment]::UserInteractive) { throw "no saved credential '$VCCredentialName' (Set-CollectorCredential.ps1 -Name $VCCredentialName)" }
      else { $VCCredential = Get-Credential -Message 'vCenter account (read-only is enough)' }
    }
    foreach ($vc in $VCenter) { [void](Connect-VIServer -Server $vc -Credential $VCCredential -ErrorAction Stop) }
    $haveVC = $true
  } catch { Write-Warning "vCenter not used: $($_.Exception.Message)"; Add-Check '' 'vCenter' "Not used: $($_.Exception.Message)" }
}
function Get-VmInfo([string]$node) {
  $k = Short $node
  if ($vmCache.ContainsKey($k)) { return $vmCache[$k] }
  $info = $null
  if ($haveVC) {
    try {
      $vm = Get-VM -Name $k -ErrorAction SilentlyContinue | Select-Object -First 1
      if (-not $vm) { $vm = Get-VM -ErrorAction SilentlyContinue | Where-Object { $_.Guest.HostName -and (Short $_.Guest.HostName) -eq $k } | Select-Object -First 1 }
      if ($vm) {
        $hds = @(Get-HardDisk -VM $vm -ErrorAction Stop)
        $nics = @(Get-NetworkAdapter -VM $vm -ErrorAction SilentlyContinue)
        $info = [pscustomobject]@{ Vm = $vm; Disks = $hds; Nics = $nics }
      }
    } catch { }
  }
  $vmCache[$k] = $info
  return $info
}

# ------------------------------------------------------------ collect
$sheetNames = 'Clusters', 'ClusterNodes', 'ClusterRoles', 'ClusterResources', 'ClusterDisks', 'ServerNics', 'ServerDisks', 'ServerMI'
$Rows = @{}; foreach ($k in $sheetNames) { $Rows[$k] = New-Object System.Collections.ArrayList }
$runlog = @()
$allClusterNodes = @{}
$levelByVer = @{ '6.3' = '8 (Windows Server 2012 R2)'; '6.2' = '7 (Windows Server 2012)'; '6.1' = '4 (Windows Server 2008 R2)' }

foreach ($cn in $names) {
  $t0 = Get-Date
  $nDisks = 0; $nNics = 0; $nNodes = 0; $nRes = 0; $msg = 'ok'
  $local = @{}; foreach ($k in $sheetNames) { $local[$k] = @() }
  $hl = @()
  Write-Host "== $cn"
  try {
    if (-not (Test-Rpc $cn)) { throw "${cn}: $Transport port $Port not reachable from this machine (name wrong, firewall, or cluster name resource offline)" }
    $clw = @(Wq $cn $NS_CL 'SELECT * FROM MSCluster_Cluster')[0]
    $cname = "$($clw.Name)"; if (-not $cname) { $cname = $cn }
    $nodes = @(Wq $cn $NS_CL 'SELECT * FROM MSCluster_Node')
    $nNodes = $nodes.Count
    $groups = @(Wq $cn $NS_CL 'SELECT * FROM MSCluster_ResourceGroup')
    $allRes = @(Wq $cn $NS_CL 'SELECT * FROM MSCluster_Resource')

    # ---- role -> resources, owner node of each role (one association query per role)
    $gRes = @{}; $gOwner = @{}; $resGroup = @{}
    foreach ($g in $groups) {
      $rn = @(); try { $rn = @(Wrel $g $cn $NS_CL 'MSCluster_ResourceGroupToResource' 'MSCluster_Resource') } catch { Add-Check $cname $g.Name "Resources of role not read: $($_.Exception.Message)" }
      $gRes[$g.Name] = $rn
      foreach ($x in $rn) { $resGroup[$x.Name] = $g.Name }
      $ow = ''; try { $o = @(Wrel $g $cn $NS_CL 'MSCluster_NodeToActiveGroup' 'MSCluster_Node'); if ($o.Count) { $ow = "$($o[0].Name)" } } catch { }
      $gOwner[$g.Name] = $ow
    }
    $primary = ''; if ($gOwner.ContainsKey('Cluster Group')) { $primary = $gOwner['Cluster Group'] }
    $resByName = @{}; foreach ($x in $allRes) { $resByName[$x.Name] = $x }

    # ---- nodes: platform, OS
    $ninfo = @{}; $nodeOk = @{}
    foreach ($n in $nodes) {
      $nm = "$($n.Name)"
      $allClusterNodes[(Short $nm)] = $true
      $f = $null
      if (Test-Rpc $nm) { $f = Get-NodeFacts $nm; $nodeOk[$nm] = (-not $f.Err) } else { $f = [pscustomobject]@{ Virtual = $null; Model = ''; OS = ''; Version = ''; Err = "$Transport port $Port not reachable" }; $nodeOk[$nm] = $false }
      $ns = St $StateNode $n.State
      if ($f.Err) { Add-Check $cname $nm "Computer details: $($f.Err)"; if ($ns -eq 'Up') { $hl += New-Hl $cname "Node $(Short $nm) remote access" 'WARN' $f.Err } }
      $hl += New-Hl $cname "Node $(Short $nm)" $(if ($ns -eq 'Up') { 'OK' } elseif ($ns -eq 'Paused') { 'WARN' } else { 'CRIT' }) "state $ns"
      $ninfo[$nm] = $f
      $plat = ''; if ($f.Virtual -eq $true) { $plat = 'Virtual' } elseif ($f.Virtual -eq $false) { $plat = 'Physical' }
      $vote = ''; try { if ($n.NodeWeight -ne $null) { $vote = $n.NodeWeight } } catch { }
      $local.ClusterNodes += [pscustomobject][ordered]@{ Cluster = $cname; Node = (Short $nm); Primary = $(if ($nm -eq $primary) { 'Yes' } else { 'No' }); State = $ns; Votes = $vote }
      $local.ServerMI += [pscustomobject][ordered]@{ Hostname = (Short $nm); 'Failover cluster' = $cname; 'Cluster/Standalone' = 'Cluster'; Platform = $plat; OS = $f.OS }
    }
    $mixed = @($ninfo.Values | ForEach-Object { $_.Virtual } | Where-Object { $_ -ne $null } | Sort-Object -Unique)
    if ($mixed.Count -gt 1) { Add-Check $cname '' 'Cluster mixes virtual and physical nodes.' }

    # ---- disks of every node, read once
    $diskCache = @{}
    function Get-Dc([string]$nm) {
      if (-not $diskCache.ContainsKey($nm)) {
        if ($nodeOk[$nm]) { try { $diskCache[$nm] = @(Get-NodeDisks $nm) } catch { $diskCache[$nm] = @(); Add-Check $cname $nm "Disks not read: $($_.Exception.Message)" } } else { $diskCache[$nm] = @() }
      }
      return $diskCache[$nm]
    }

    # ---- shared disks (Physical Disk resources + cluster shared volumes)
    $csvNames = @{}
    try { foreach ($v in @(Wq $cn $NS_CL 'SELECT * FROM MSCluster_ClusterSharedVolume')) { $csvNames[$v.Name] = $v } } catch { }
    $diskRows = @{}
    $diskItems = @($allRes | Where-Object { $_.Type -eq 'Physical Disk' })
    foreach ($r in $diskItems) {
      $isCsv = $csvNames.ContainsKey($r.Name)
      $grp = $resGroup[$r.Name]
      $node = ''; if ($grp) { $node = $gOwner[$grp] }
      $sigv = Get-Param $r 'DiskSignature'; $gv = Get-Param $r 'DiskIdGuid'
      $sig = $null; if ($sigv -ne $null -and "$sigv" -match '^-?\d+$') { $sig = [uint32]([int64]$sigv -band [int64]4294967295); if ($sig -eq 0) { $sig = $null } }
      $guid = ''; if ($gv) { $guid = ("$gv").Trim('{}').ToLower() }
      $d = $null
      $order = @(); if ($node) { $order += $node }; foreach ($n in $nodes) { if ($n.Name -ne $node) { $order += "$($n.Name)" } }
      foreach ($nm in $order) {
        $d = (Get-Dc $nm) | Where-Object { ($sig -ne $null -and $_.Signature -eq $sig) -or ($guid -and $_.Guid -and $_.Guid -eq $guid) } | Select-Object -First 1
        if ($d) { $node = $nm; break }
      }
      $state = St $StateRes $r.State
      $size = ''; $naa = ''; $serial = ''; $model = ''; $bus = ''; $lun = ''
      if ($d) {
        $size = [math]::Round($d.Size / 1GB, 2); $naa = ConvertTo-Naa $d.UniqueId; $serial = $d.Serial; $model = $d.Model; $bus = $d.Bus
        if ($d.Location -match 'LUN\s*(\d+)') { $lun = $Matches[1] } elseif ($d.Location -match 'L(\d+)\)') { $lun = $Matches[1] }
      } else { Add-Check $cname $r.Name "Disk details not found on any node (resource state $state). Size / NAA left empty." }
      $mnt = @(); if ($d) { $mnt = @($d.Mounts) }
      if ($d) { $rt = Resolve-DiskType $naa $serial $model $bus $size $ninfo[$node].Virtual (Get-VmInfo $node) } else { $rt = [pscustomobject]@{ Type = ''; Ds = ''; Note = '' } }
      if ($rt.Note) { Add-Check $cname $r.Name $rt.Note }
      $role = $grp
      if ($isCsv) { $role = 'CSV' }
      $row = [pscustomobject][ordered]@{
        Cluster = $cname; Disk = $r.Name; 'Drive / mount' = ($mnt -join ', '); 'Size GB' = $size; Type = $rt.Type
        'LUN ID' = $lun; 'NAA ID' = $naa; 'Datastore / array' = $rt.Ds; Role = $role; State = $state
      }
      $local.ClusterDisks += $row
      $diskRows[$r.Name] = $row
      $nDisks++
    }
    foreach ($cvn in $csvNames.Keys) {
      if (-not $diskRows.ContainsKey($cvn)) { Add-Check $cname $cvn 'Cluster shared volume found, but no Physical Disk resource with that name: disk details not collected for it.' }
    }

    # ---- quorum, cluster IP
    $quorumType = ''; $wNaa = ''; $wLun = ''; $wShare = ''
    try {
      $qr = @(Wrel $clw $cn $NS_CL 'MSCluster_ClusterToQuorumResource' 'MSCluster_Resource')
      if ($qr.Count) {
        $q = $qr[0]; $rt2 = "$($q.Type)"
        if ($rt2 -eq 'Physical Disk') {
          $wr = $diskRows[$q.Name]
          if ($wr) {
            if ($wr.Type -like 'RDM*') { $quorumType = 'Disk witness - RDM' } else { $quorumType = 'Disk witness - VMDK' }
            $wNaa = $wr.'NAA ID'; $wLun = $wr.'LUN ID'
          } else { $quorumType = 'Disk witness - VMDK' }
        } elseif ($rt2 -match 'File Share') { $quorumType = 'File share witness'; $wShare = Get-Param $q 'SharePath' }
        elseif ($rt2 -match 'Cloud') { $quorumType = 'Cloud witness' }
        $qs = St $StateRes $q.State; $hl += New-Hl $cname 'Quorum witness' $(if ($qs -eq 'Online') { 'OK' } else { 'CRIT' }) "$($q.Name): $qs"
      } else { $quorumType = 'None' }
    } catch { Add-Check $cname '' "Quorum not read: $($_.Exception.Message)" }
    $cip = ''
    if ($gRes.ContainsKey('Cluster Group')) {
      $ipres = $gRes['Cluster Group'] | Where-Object { $_.Type -eq 'IP Address' } | Select-Object -First 1
      if ($ipres) { $ipfull = $resByName[$ipres.Name]; if ($ipfull) { $cip = Get-Param $ipfull 'Address' } else { $cip = Get-Param $ipres 'Address' } }
    }
    $fqdn = $cname; try { if ($clw.Fqdn) { $fqdn = "$($clw.Fqdn)".ToLower() } elseif ($Domain) { $fqdn = ($cname + '.' + $Domain).ToLower() } } catch { }
    $lvl = ''; try { if ($clw.ClusterFunctionalLevel -ne $null) { $lvl = "$($clw.ClusterFunctionalLevel)" } } catch { }
    if (-not $lvl) {
      $vers = @($ninfo.Values | ForEach-Object { $v = "$($_.Version)"; if ($v -match '^(\d+\.\d+)') { $Matches[1] } } | Sort-Object -Unique)
      if ($vers.Count -ge 1) { $v0 = $vers[0]; if ($levelByVer.ContainsKey($v0)) { $lvl = $levelByVer[$v0] + ' - by node OS' } else { $lvl = "node OS $v0" } }
    } else {
      $lvlName = @{ '8' = '2012 R2'; '9' = '2016'; '10' = '2019'; '11' = '2022'; '12' = '2025' }
      if ($lvlName.ContainsKey($lvl)) { $lvl = "$lvl (Windows Server $($lvlName[$lvl]))" }
    }
    $local.Clusters += [pscustomobject][ordered]@{ Cluster = $cname; 'Cluster IP' = $cip; 'Cluster FQDN' = $fqdn; 'Functional level' = $lvl; 'Quorum type' = $quorumType; 'Witness LUN ID' = $wLun; 'Witness NAA' = $wNaa; 'Witness share path' = $wShare }

    # ---- roles and everything inside them
    if (-not $NoRoles) {
      $vmRoles = 0
      foreach ($g in $groups) {
        $isCore = ($g.Name -eq 'Cluster Group')
        if ($g.Name -eq 'Available Storage') { continue }
        $res = @($gRes[$g.Name] | ForEach-Object { if ($resByName.ContainsKey($_.Name)) { $resByName[$_.Name] } else { $_ } })
        if (@($res | Where-Object { $_.Type -eq 'Virtual Machine' }).Count) { $vmRoles++; continue }
        $own = $gOwner[$g.Name]
        # every resource of the role, with details
        $vnames = @(); $ips = @(); $drv = @()
        $gs = St $StateGrp $g.State
        foreach ($x in $res) {
          $xt = "$($x.Type)"
          $det = Get-ResDetails $x
          if ($xt -eq 'Physical Disk') { $dr = $diskRows[$x.Name]; if ($dr) { $det = ($dr.'Drive / mount' + ' ' + $dr.'Size GB' + ' GB ' + $dr.Type).Trim(); if ($dr.'Drive / mount') { $drv += $dr.'Drive / mount' } else { $drv += $x.Name } } else { $drv += $x.Name } }
          if ($xt -eq 'Network Name') { $dn = Get-Param $x 'DnsName'; if (-not $dn) { $dn = $x.Name }; $vnames += $dn }
          if ($xt -eq 'IP Address') { $a = Get-Param $x 'Address'; if ($a) { $ips += $a } }
          $xs = St $StateRes $x.State
          $local.ClusterResources += [pscustomobject][ordered]@{ Cluster = $cname; Role = $g.Name; Resource = $x.Name; 'Resource type' = $xt; State = $xs; 'Owner node' = (Short $own); Details = $det }
          $nRes++
          if ($xs -eq 'Failed') { $hl += New-Hl $cname "Resource $($x.Name)" 'CRIT' "Failed (role $($g.Name))" }
          elseif ($xs -ne 'Online' -and ($gs -eq 'Online' -or $gs -eq 'PartialOnline')) { $hl += New-Hl $cname "Resource $($x.Name)" 'WARN' "$xs while role $($g.Name) is $gs" }
        }
        if ($gs -eq 'Failed') { $hl += New-Hl $cname "Role $($g.Name)" 'CRIT' 'Failed' }
        elseif ($gs -ne 'Online') { $hl += New-Hl $cname "Role $($g.Name)" 'WARN' "state $gs" }
        if ($isCore) { continue }
        $types = @($res | ForEach-Object { $_.Type })
        $rtype = 'Other'
        if ($types -match 'SQL Server') { $rtype = 'SQL Server (FCI)' }
        elseif ($types -contains 'Scale Out File Server') { $rtype = 'Scale-Out File Server' }
        elseif ($types -contains 'File Server') { $rtype = 'File server' }
        elseif ($types -match 'Distributed Transaction') { $rtype = 'DTC' }
        elseif ($types -match 'DHCP') { $rtype = 'DHCP' }
        elseif ($types -contains 'Generic Service') { $rtype = 'Generic service' }
        elseif ($types -contains 'Generic Application' -or $types -contains 'Generic Script') { $rtype = 'Generic application' }
        $pref = ''; try { $pref = (@(Wrel $g $cn $NS_CL 'MSCluster_ResourceGroupToPreferredNode' 'MSCluster_Node') | ForEach-Object { Short $_.Name }) -join ', ' } catch { }
        if ($pref -and $gs -eq 'Online' -and (($pref -split ', ') -notcontains (Short $own))) { $hl += New-Hl $cname "Placement $($g.Name)" 'WARN' "Runs on $(Short $own), preferred owners: $pref" }
        $local.ClusterRoles += [pscustomobject][ordered]@{ Cluster = $cname; Role = $g.Name; Type = $rtype; 'Virtual name' = ($vnames -join ', '); State = $gs; 'Owner node' = (Short $own); 'Preferred owners' = $pref; 'Role IP' = ($ips -join ', '); Drives = ($drv -join ', ') }
      }
      if ($vmRoles) { Add-Check $cname '' "$vmRoles virtual machine role(s) skipped (Hyper-V clusters list VMs in ServersMI, not as cluster roles)." }
    }

    # ---- cluster networks (numeric subnet kept for matching the node adapters)
    $cnets = @()
    try {
      foreach ($nw in @(Wq $cn $NS_CL 'SELECT * FROM MSCluster_Network')) {
        $nst = St $StateNet $nw.State
        if ($nst -ne 'Up') { $hl += New-Hl $cname "Network $($nw.Name)" $(if ($nst -eq 'Down' -or $nst -eq 'Unavailable') { 'CRIT' } else { 'WARN' }) "state $nst" }
        try { $cnets += [pscustomobject]@{ Name = "$($nw.Name)"; Role = $nw.Role; Base = (IpToInt "$($nw.Address)"); Mask = (IpToInt "$($nw.AddressMask)") } } catch { }
      }
    } catch { Add-Check $cname '' "Cluster networks not read: $($_.Exception.Message)" }
    $hl += New-Hl $cname 'Cluster' 'OK' 'collected'

    # ---- network interfaces of every node
    if (-not $NoNics) {
      foreach ($n in $nodes) {
        $nm = "$($n.Name)"; if (-not $nodeOk[$nm]) { continue }
        $rowsN = @(Get-NicRows $nm $nm $cnets (Get-VmInfo $nm) $cname)
        $local.ServerNics += $rowsN; $nNics += $rowsN.Count
      }
    }
  } catch {
    $msg = Add-Hint $_.Exception.Message
    Write-Warning "$cn failed: $msg"
    $local = @{}; foreach ($k in $sheetNames) { $local[$k] = @() }
    $nDisks = 0; $nNics = 0; $nRes = 0
    $hl = @(New-Hl $cn 'Reachability' 'CRIT' $msg)
  }
  foreach ($k in $local.Keys) { foreach ($x in $local[$k]) { [void]$Rows[$k].Add($x) } }
  foreach ($x in $hl) { [void]$script:HealthRows.Add($x) }
  $st = 'FAILED'; if ($msg -eq 'ok') { $st = 'ok' }
  $runlog += [pscustomobject][ordered]@{ Target = $cn; Kind = 'Cluster'; Status = $st; Nodes = $nNodes; Resources = $nRes; Disks = $nDisks; NICs = $nNics; Seconds = [int]((Get-Date) - $t0).TotalSeconds; Message = $msg; Collected = (Get-Date -Format 'yyyy-MM-dd HH:mm') }
}

# ---- standalone servers (anything that is not a cluster node): platform, OS, disks, network interfaces
foreach ($sv in $srvNames) {
  $t0 = Get-Date; $msg = 'ok'; $nDisks = 0; $nNics = 0
  $short = Short $sv
  Write-Host "== $sv (standalone)"
  if ($allClusterNodes.ContainsKey($short)) { Add-Check '' $sv 'Is a cluster node in this run: skipped as standalone.'; continue }
  try {
    if (-not (Test-Rpc $sv)) { throw "${sv}: $Transport port $Port not reachable from this machine" }
    $f = Get-NodeFacts $sv
    if ($f.Err) { throw $f.Err }
    $plat = ''; if ($f.Virtual -eq $true) { $plat = 'Virtual' } elseif ($f.Virtual -eq $false) { $plat = 'Physical' }
    [void]$Rows.ServerMI.Add([pscustomobject][ordered]@{ Hostname = $short; 'Failover cluster' = ''; 'Cluster/Standalone' = 'Standalone'; Platform = $plat; OS = $f.OS })
    $vi = Get-VmInfo $sv
    if (-not $NoDisksOnStandalone) {
      $disks = @(Get-NodeDisks $sv | Where-Object { $_.Size -gt 0 })
      foreach ($d in $disks) {
        $mnt = @($d.Mounts)
        $size = [math]::Round($d.Size / 1GB, 2); $naa = ConvertTo-Naa $d.UniqueId
        $rt = Resolve-DiskType $naa $d.Serial $d.Model $d.Bus $size $f.Virtual $vi
        if ($rt.Note) { Add-Check '' "$short Disk $($d.Number)" $rt.Note }
        $purpose = 'Data'; if ($d.IsBoot -or $d.IsSystem -or ($mnt -contains 'C:')) { $purpose = 'OS' }
        $scsi = Get-ScsiId $d.Location $f.Virtual
        $lun = ''; if ($d.Location -match 'LUN\s*(\d+)') { $lun = $Matches[1] }
        [void]$Rows.ServerDisks.Add([pscustomobject][ordered]@{ Server = $short; Disk = ("Disk {0}" -f $d.Number); 'Drive / mount' = ($mnt -join ', '); 'Size GB' = $size; Type = $rt.Type; Purpose = $purpose; 'SCSI ID' = $scsi; 'LUN ID' = $lun; 'NAA ID' = $naa; 'Datastore / array' = $rt.Ds })
        $nDisks++
      }
    }
    if (-not $NoNics) {
      $rowsN = @(Get-NicRows $sv $sv @() $vi '')
      foreach ($x in $rowsN) { [void]$Rows.ServerNics.Add($x) }; $nNics = $rowsN.Count
    }
  } catch { $msg = Add-Hint $_.Exception.Message; Write-Warning "$sv failed: $msg"; [void]$script:HealthRows.Add((New-Hl $short 'Reachability' 'CRIT' $msg)) }
  $st = 'FAILED'; if ($msg -eq 'ok') { $st = 'ok'; [void]$script:HealthRows.Add((New-Hl $short 'Server' 'OK' 'collected')) }
  $runlog += [pscustomobject][ordered]@{ Target = $sv; Kind = 'Standalone'; Status = $st; Nodes = 1; Resources = 0; Disks = $nDisks; NICs = $nNics; Seconds = [int]((Get-Date) - $t0).TotalSeconds; Message = $msg; Collected = (Get-Date -Format 'yyyy-MM-dd HH:mm') }
}
if ($haveVC) { Disconnect-VIServer -Server * -Confirm:$false -ErrorAction SilentlyContinue }

# ------------------------------------------------------------ write
if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir | Out-Null }
$stamp = Get-Date -Format 'yyyyMMdd-HHmm'
$sheets = [ordered]@{}
foreach ($k in $sheetNames) { if ($Rows[$k].Count) { $sheets[$k] = $Rows[$k].ToArray() } }
if ($script:HealthRows.Count) { $sheets['Health'] = $script:HealthRows.ToArray() }
$sheets['RunLog'] = $runlog
if ($script:Check.Count) { $sheets['Check'] = $script:Check.ToArray() }
$useX = ($Format -eq 'Xlsx') -or ($Format -eq 'Auto' -and (Get-Module -ListAvailable -Name ImportExcel))
if ($useX) {
  Import-Module ImportExcel -ErrorAction Stop
  $f = Join-Path $OutDir "WSFC-$stamp.xlsx"
  foreach ($k in $sheets.Keys) { $sheets[$k] | Export-Excel -Path $f -WorksheetName $k -AutoSize -FreezeTopRow -BoldTopRow }
  Copy-Item -LiteralPath $f -Destination (Join-Path $OutDir 'WSFC-latest.xlsx') -Force
  Write-Host "Written: $f  (and WSFC-latest.xlsx)"
} else {
  $d = Join-Path $OutDir "WSFC-$stamp"
  New-Item -ItemType Directory -Path $d -Force | Out-Null
  foreach ($k in $sheets.Keys) { $sheets[$k] | Export-Csv -LiteralPath (Join-Path $d "$k.csv") -NoTypeInformation -Encoding UTF8 }
  $lat = Join-Path $OutDir 'WSFC-latest'
  if (Test-Path -LiteralPath $lat) { Remove-Item -LiteralPath $lat -Recurse -Force }
  Copy-Item -LiteralPath $d -Destination $lat -Recurse
  Write-Host "Written: $d  (and WSFC-latest\)"
}
# keep the last 30 dated copies
Get-ChildItem -LiteralPath $OutDir | Where-Object { $_.Name -like 'WSFC-2*' } | Sort-Object LastWriteTime -Descending | Select-Object -Skip 30 | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
if ($script:CimSess.Count) { foreach ($v in $script:CimSess.Values) { try { Remove-CimSession -CimSession $v -ErrorAction SilentlyContinue } catch { } } }
$bad = @($runlog | Where-Object { $_.Status -ne 'ok' }).Count
Write-Host ("Done: {0} target(s) ok, {1} failed, {2} item(s) in Check." -f ($runlog.Count - $bad), $bad, $script:Check.Count)
if ($bad) { exit 1 } else { exit 0 }
