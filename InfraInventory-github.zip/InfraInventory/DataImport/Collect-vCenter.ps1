<#
 Collect-vCenter.ps1 - read-only collector for VMware vCenter (PowerCLI).
 Needs: PowerShell 5.1+, VMware.PowerCLI (Install-Module VMware.PowerCLI -Scope CurrentUser), a read-only vCenter account.
 Collects: ESXi hosts (model, serial, version, cluster, CPU, RAM, VM count, BMC IP with -Bmc) -> ESXi;
 datastores (type, NAA, capacity, free, provisioned, VMs, hosts) -> Datastores; DRS rules -> DrsRules;
 virtual machines (guest name, IP, OS, vCPU, RAM, disk, ESXi host) -> ServerMI (skip with -NoVMs).
 Daily Health checks: host connection / maintenance / overall status, triggered alarms, datastore free space.
 Output: Output\vcenter\vCenter-latest.xlsx (or CSV folder) + dated copy. Sheets are named like the inventory.

 Examples:
   .\Collect-vCenter.ps1 -Target vc-a.corp.local,vc-b.corp.local
   .\Collect-vCenter.ps1 -TargetFile .\targets\vcenter.txt -CredentialName vcenter-ro -NonInteractive -NoVMs
#>
param(
  [string[]]$Target,
  [string]$TargetFile,
  [pscredential]$Credential,
  [string]$CredentialName = 'vcenter',
  [string]$OutDir = '',
  [ValidateSet('Auto','Xlsx','Csv')][string]$Format = 'Auto',
  [double]$CapWarn = 80,
  [double]$CapCrit = 90,
  [switch]$NoVMs,
  [switch]$Bmc,
  [switch]$StrictTls,
  [switch]$SaveCredential,
  [switch]$NonInteractive
)
# folder of this script ($PSScriptRoot is empty in some hosts / when started by full path)
$HERE = $PSScriptRoot
if (-not $HERE) { try { $HERE = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { } }
if (-not $HERE) { $HERE = (Get-Location).Path }
if (-not $OutDir) { $OutDir = Join-Path $HERE 'Output\vcenter' }
. (Join-Path $HERE 'Collector-Common.ps1')
$script:StrictTls = $StrictTls
$SRC = 'vCenter'
$targets = Read-Targets $Target $TargetFile
if (-not $targets.Count) { throw 'Give -Target a,b or -TargetFile file.txt' }
Import-Module VMware.VimAutomation.Core -ErrorAction Stop
$null = Set-PowerCLIConfiguration -Scope Session -InvalidCertificateAction $(if ($StrictTls) { 'Fail' } else { 'Ignore' }) -DisplayDeprecationWarnings:$false -Confirm:$false -ParticipateInCEIP $false
$esx = New-Object System.Collections.ArrayList; $dsl = New-Object System.Collections.ArrayList; $drs = New-Object System.Collections.ArrayList; $vms = New-Object System.Collections.ArrayList

foreach ($t in $targets) {
  $t0 = Get-Date; $name = $t.Name; $vc = $null
  Write-Host "== $name"
  try {
    $cn = $CredentialName; if ($t.Cred) { $cn = $t.Cred }
    $cred = Get-CollectorCredential $cn $Credential -NonInteractive:$NonInteractive -Save:$SaveCredential
    $vc = Connect-VIServer -Server $name -Credential $cred -ErrorAction Stop
    $vcn = $name
    $hosts = @(Get-VMHost -Server $vc)
    $nVm = @{}
    $allVm = @(Get-VM -Server $vc)
    $vmName = @{}
    foreach ($v in $allVm) { $vmName["$($v.Id)"] = $v.Name; $k = "$($v.VMHost.Name)"; if (-not $k) { continue }; if (-not $nVm.ContainsKey($k)) { $nVm[$k] = 0 }; $nVm[$k]++ }
    $hostCl = @{}
    foreach ($hh in $hosts) {
      $ed = $hh.ExtensionData
      $serial = ''; $model = "$($hh.Model)"
      try { $serial = "$($ed.Hardware.SystemInfo.SerialNumber)" } catch { }
      if (-not $serial) { try { $serial = ($ed.Hardware.SystemInfo.OtherIdentifyingInfo | Where-Object { $_.IdentifierType.Key -eq 'ServiceTag' } | Select-Object -First 1).IdentifierValue } catch { } }
      $cl = ''; try { $cl = "$($hh.Parent.Name)" } catch { }
      $hostCl["$($hh.Id)"] = $cl
      $cpu = ''; try { $cpu = "{0} x {1} ({2} cores)" -f $ed.Hardware.CpuInfo.NumCpuPackages, $ed.Hardware.CpuPkg[0].Description, $ed.Hardware.CpuInfo.NumCpuCores } catch { }
      $bmcIp = ''
      if ($Bmc) { try { $bmcIp = (Get-EsxCli -VMHost $hh -V2 -ErrorAction Stop).hardware.ipmi.bmc.get.Invoke().IPv4Address } catch { } }
      [void]$esx.Add([pscustomobject][ordered]@{ Hostname = $hh.Name; Model = $model; Serial = $serial; 'ESXi version' = "$($hh.Version) build $($hh.Build)"; vCenter = $vcn; Cluster = $cl; CPU = $cpu; 'RAM GB' = [math]::Round($hh.MemoryTotalGB, 0); VMs = [int]$nVm[$hh.Name]; 'BMC IP' = $bmcIp })
      $cs = "$($hh.ConnectionState)"
      if ($cs -eq 'Connected') { Add-Health $SRC $hh.Name 'Host state' 'OK' 'Connected' }
      elseif ($cs -eq 'Maintenance') { Add-Health $SRC $hh.Name 'Host state' 'WARN' 'In maintenance mode' }
      else { Add-Health $SRC $hh.Name 'Host state' 'CRIT' $cs }
      $os = "$($ed.OverallStatus)"; if ($os -in 'red', 'yellow') { Add-Health $SRC $hh.Name 'Overall status' $(if ($os -eq 'red') { 'CRIT' } else { 'WARN' }) $os }
    }
    $allDs = @(Get-Datastore -Server $vc)
    # triggered alarms of hosts, datastores, clusters
    try {
      $ents = @(); $ents += @(Get-Cluster -Server $vc); $ents += $allDs; $ents += $hosts
      foreach ($en in $ents) {
        foreach ($a in @($en.ExtensionData.TriggeredAlarmState)) {
          $al = Get-View $a.Alarm -Property Info.Name -ErrorAction SilentlyContinue
          $nm = ''; if ($al) { $nm = $al.Info.Name }
          if ("$($a.OverallStatus)" -in 'red', 'yellow') { Add-Health $SRC $en.Name ("Alarm: " + $nm) $(if ("$($a.OverallStatus)" -eq 'red') { 'CRIT' } else { 'WARN' }) "triggered $($a.Time.ToString('yyyy-MM-dd HH:mm'))" }
        }
      }
    } catch { Add-Health $SRC $name 'Alarms' 'WARN' "Not read: $($_.Exception.Message)" }
    # datastores
    foreach ($d in $allDs) {
      $naa = ''; try { $naa = $d.ExtensionData.Info.Vmfs.Extent[0].DiskName } catch { }
      $capTb = [math]::Round($d.CapacityGB / 1024, 3); $freeTb = [math]::Round($d.FreeSpaceGB / 1024, 3)
      $usedPct = Pct ($d.CapacityGB - $d.FreeSpaceGB) $d.CapacityGB
      $prov = ''; try { $prov = [math]::Round(($d.ExtensionData.Summary.Capacity - $d.ExtensionData.Summary.FreeSpace + $d.ExtensionData.Summary.Uncommitted) / 1TB, 3) } catch { }
      $cl = ''; try { $cl = ((@($d.ExtensionData.Host) | ForEach-Object { $hostCl["$($_.Key)"] } | Where-Object { $_ }) | Sort-Object -Unique) -join ', ' } catch { }
      $dsc = ''; try { if ($d.ParentFolderId -like 'StoragePod*') { $dsc = (Get-DatastoreCluster -Id $d.ParentFolderId -Server $vc).Name } } catch { }
      [void]$dsl.Add([pscustomobject][ordered]@{ Datastore = $d.Name; vCenter = $vcn; Cluster = $cl; 'Datastore cluster' = $dsc; Type = $d.Type; 'NAA ID' = $naa; 'Capacity TB' = $capTb; 'Free TB' = $freeTb; 'Used %' = $usedPct; 'Provisioned TB' = $prov; VMs = @($d.ExtensionData.Vm).Count; Hosts = @($d.ExtensionData.Host).Count })
      if ($usedPct -ne '') { $s = Cap-Status $usedPct $CapWarn $CapCrit; if ($s -ne 'OK') { Add-Health $SRC $d.Name 'Datastore capacity' $s "$usedPct % used, $freeTb TB free" } }
      if ($d.State -ne 'Available') { Add-Health $SRC $d.Name 'Datastore state' 'CRIT' "$($d.State)" }
    }
    # DRS rules
    foreach ($c in @(Get-Cluster -Server $vc)) {
      foreach ($r in @(Get-DrsRule -Cluster $c -Server $vc -ErrorAction SilentlyContinue)) {
        $vn = (@($r.VMIds | ForEach-Object { $vmName["$_"] } | Where-Object { $_ }) | Sort-Object) -join ', '
        $ty = switch ("$($r.Type)") { 'VMAffinity' { 'VMs together (affinity)' } 'VMAntiAffinity' { 'VMs separate (anti-affinity)' } default { "$($r.Type)" } }
        [void]$drs.Add([pscustomobject][ordered]@{ Rule = $r.Name; Cluster = $c.Name; vCenter = $vcn; Type = $ty; VMs = $vn; Enabled = $(if ($r.Enabled) { 'Yes' } else { 'No' }) })
      }
    }
    if (-not $NoVMs) {
      foreach ($v in $allVm) {
        $g = $v.Guest; $ip = ''; try { $ip = (@($g.IPAddress) | Where-Object { $_ -match '^\d+\.\d+\.\d+\.\d+$' } | Select-Object -First 1) } catch { }
        $hn = ''; try { $hn = ("$($g.HostName)").Split('.')[0] } catch { }
        if (-not $hn) { $hn = $v.Name }
        [void]$vms.Add([pscustomobject][ordered]@{ 'vCenter name' = $v.Name; Hostname = $hn; FQDN = "$($g.HostName)"; IP = $ip; OS = "$($g.OSFullName)"; vCPU = $v.NumCpu; 'RAM GB' = [math]::Round($v.MemoryGB, 1); 'Disk GB' = [math]::Round($v.ProvisionedSpaceGB, 0); 'ESXi host' = $v.VMHost.Name })
      }
    }
    Add-Health $SRC $name 'vCenter' 'OK' ("{0} hosts, {1} datastores, {2} VMs read" -f $hosts.Count, $allDs.Count, $allVm.Count)
    Add-Run $name 'vCenter' 'ok' 'ok' $t0
  } catch {
    Write-Warning "$name failed: $($_.Exception.Message)"
    Add-Health $SRC $name 'Reachability' 'CRIT' $_.Exception.Message
    Add-Run $name 'vCenter' 'FAILED' $_.Exception.Message $t0
  } finally { if ($vc) { Disconnect-VIServer -Server $vc -Confirm:$false -ErrorAction SilentlyContinue } }
}
$sheets = [ordered]@{ ESXi = $esx.ToArray(); Datastores = $dsl.ToArray(); DrsRules = $drs.ToArray(); ServerMI = $vms.ToArray() }
exit (Write-CollectorOutput $SRC $sheets $OutDir $Format)
