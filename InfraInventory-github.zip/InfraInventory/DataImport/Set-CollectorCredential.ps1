<#
 Saves a credential for a collector, encrypted with Windows DPAPI: only THIS Windows user on THIS machine can read it.
 Run it once, as the account that will run the scheduled task:
   .\Set-CollectorCredential.ps1 -Name 3par-main
   .\Set-CollectorCredential.ps1 -Name ilo-dc2 -UserName Administrator
 A collector that finds no saved credential asks for one when started by hand, and fails clearly when run by Task Scheduler.
 -Name is the value you give to the collector as -CredentialName (or the second field of a line in a target file).
#>
param([Parameter(Mandatory)][string]$Name, [string]$UserName, [switch]$Remove)
# folder of this script ($PSScriptRoot is empty in some hosts / when started by full path)
$HERE = $PSScriptRoot
if (-not $HERE) { try { $HERE = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { } }
if (-not $HERE) { $HERE = (Get-Location).Path }
$dir = Join-Path $HERE 'Credentials'
$f = Join-Path $dir ("{0}.xml" -f ($Name -replace '[^\w\.-]', '_'))
if ($Remove) { if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f; Write-Host "Removed $f" } else { Write-Host 'Nothing saved under that name.' }; return }
if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
if ($UserName) { $c = Get-Credential -UserName $UserName -Message "Read-only account for $Name" } else { $c = Get-Credential -Message "Read-only account for $Name" }
if (-not $c) { return }
$c | Export-Clixml -LiteralPath $f
Write-Host "Saved: $f"
