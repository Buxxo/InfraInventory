DataImport folder
-----------------
Collectors (read-only; each writes Output\<source>\<Source>-latest.xlsx or -latest\*.csv plus a dated copy):
  Collect-WSFC.ps1      Windows failover clusters (roles, resources, disks, NICs) and standalone servers; no modules needed (WMI), 2012 R2+
  Collect-3PAR.ps1      3PAR / Primera arrays: array, volumes, remote copy, health + capacity checks
  Collect-vCenter.ps1   vCenter: hosts, datastores, DRS rules, VMs, alarms and capacity checks
  Collect-iLO.ps1       many iLO / BMC (IPMI) controllers over Redfish: model, serial, firmware, health, IML
  Collect-OneView.ps1   OneView: server hardware, enclosures, alerts
Helpers:
  Collector-Common.ps1          shared code (needed next to every collector)
  Set-CollectorCredential.ps1   saves a credential encrypted for the current Windows user (.\Set-CollectorCredential.ps1 -Name 3par)
  Register-CollectorTask.ps1    creates the daily Windows scheduled task for a collector
  targets\*.txt                 one target per line (optional ",credentialName")
Credentials: -Credential, else Credentials\<name>.xml, else a prompt (not in scheduled runs).
Daily use: Task Scheduler runs the collectors; open the inventory -> Collector -> Overview -> Run daily checks;
open a tab to read the output and "Review and import" the changes.
All scripts were run against simulated systems only. First run each collector by hand on one real target and read Health, RunLog and Check.
