<#
 Collect-3PAR.ps1 - read-only collector for HPE 3PAR / Primera / Alletra 9000 arrays through the WSAPI (REST, port 8080).
 Needs: PowerShell 5.1+, network access to the array on 8080, WSAPI enabled (showwsapi), a read-only ("browse") user.
 Collects: array (model, serial, OS version, capacity, nodes) -> Storage; virtual volumes with WWN/NAA, size, CPG,
 provisioning, export (host + LUN), remote copy group -> ArrayVolumes; remote copy groups -> RemoteCopyGroups;
 daily Health checks: disks, nodes, ports, capacity of the array and every CPG, remote copy group state.
 Output: Output\3par\3PAR-latest.xlsx (or CSV folder) + dated copy. Sheets are named like the inventory, so the page
 "Collector" -> 3PAR (or Data import -> 3PAR) matches them automatically. Health and RunLog are never imported.

 Examples:
   .\Collect-3PAR.ps1 -Target 3par-a.corp.local,3par-b.corp.local
   .\Collect-3PAR.ps1 -TargetFile .\targets\3par.txt -CredentialName 3par-main -NonInteractive
 Credentials: -Credential, else saved file (Set-CollectorCredential.ps1 -Name <CredentialName>), else a prompt.
#>
param(
  [string[]]$Target,
  [string]$TargetFile,
  [pscredential]$Credential,
  [string]$CredentialName = '3par',
  [string]$OutDir = '',
  [ValidateSet('Auto','Xlsx','Csv')][string]$Format = 'Auto',
  [int]$Port = 8080,
  [double]$CapWarn = 80,
  [double]$CapCrit = 90,
  [switch]$NoVolumes,
  [switch]$StrictTls,
  [switch]$SaveCredential,
  [switch]$NonInteractive
)
# folder of this script ($PSScriptRoot is empty in some hosts / when started by full path)
$HERE = $PSScriptRoot
if (-not $HERE) { try { $HERE = Split-Path -Parent $MyInvocation.MyCommand.Path } catch { } }
if (-not $HERE) { $HERE = (Get-Location).Path }
if (-not $OutDir) { $OutDir = Join-Path $HERE 'Output\3par' }
. (Join-Path $HERE 'Collector-Common.ps1')
$script:StrictTls = $StrictTls
Set-Tls -Strict:$StrictTls
$SRC = '3PAR'
$targets = Read-Targets $Target $TargetFile
if (-not $targets.Count) { throw 'Give -Target a,b or -TargetFile file.txt' }
$sheets = [ordered]@{ Storage = @(); ArrayVolumes = @(); RemoteCopyGroups = @() }
$st = New-Object System.Collections.ArrayList; $vols = New-Object System.Collections.ArrayList; $rcs = New-Object System.Collections.ArrayList
$provMap = @{ 1 = 'Thick'; 2 = 'Thin'; 3 = 'Snapshot'; 4 = 'Peer'; 5 = 'Unknown'; 6 = 'Thin'; 7 = 'Thin' }
$modeMap = @{ 1 = 'Sync'; 2 = 'Periodic'; 3 = 'Periodic'; 4 = 'Async' }
$rcState = @{ 1 = 'New'; 2 = 'Starting'; 3 = 'Started'; 4 = 'Restart'; 5 = 'Stopped'; 6 = 'Backup'; 7 = 'Failsafe'; 8 = 'Logging' }
$diskState = @{ 1 = 'normal'; 2 = 'degraded'; 3 = 'new'; 4 = 'failed' }
$volState = @{ 1 = 'normal'; 2 = 'degraded'; 3 = 'failed' }

foreach ($t in $targets) {
  $t0 = Get-Date; $name = $t.Name; $key = $null
  Write-Host "== $name"
  $base = "https://${name}:$Port/api/v1"
  try {
    $cn = $CredentialName; if ($t.Cred) { $cn = $t.Cred }
    $cred = Get-CollectorCredential $cn $Credential -NonInteractive:$NonInteractive -Save:$SaveCredential
    $r = Invoke-Rest "$base/credentials" 'POST' @{} @{ user = $cred.UserName; password = (Get-PlainPassword $cred) }
    $key = $r.key
    $h = @{ 'X-HP3PAR-WSAPI-SessionKey' = $key }
    $sys = Invoke-Rest "$base/system" 'GET' $h
    $arr = $sys.name; if (-not $arr) { $arr = $name }
    $cap = $null; try { $cap = Invoke-Rest "$base/capacity" 'GET' $h } catch { Add-Health $SRC $arr 'Capacity' 'WARN' "Capacity not read: $($_.Exception.Message)" }
    $rawTb = ''; $usableTb = ''; $usedPct = ''
    if ($cap -and $cap.allCapacity) {
      $tot = [double]$cap.allCapacity.totalMiB; $free = [double]$cap.allCapacity.freeMiB
      $rawTb = [math]::Round($tot / 1MB, 2); $usableTb = $rawTb; $usedPct = Pct ($tot - $free) $tot
      if ($usedPct -ne '') { Add-Health $SRC $arr 'Array capacity' (Cap-Status $usedPct $CapWarn $CapCrit) "$usedPct % used of $rawTb TB" }
      $fail = [double]$cap.allCapacity.failedCapacityMiB; if ($fail -gt 0) { Add-Health $SRC $arr 'Failed capacity' 'CRIT' ("{0} TB failed" -f [math]::Round($fail / 1MB, 2)) }
    }
    [void]$st.Add([pscustomobject][ordered]@{ Array = $arr; Model = $sys.model; Serial = $sys.serialNumber; Firmware = $sys.systemVersion; 'Raw TB' = $rawTb; 'Used %' = $usedPct; Controllers = $sys.totalNodes; Status = $(if ($sys.onlineNodes -and $sys.totalNodes -and @($sys.onlineNodes).Count -lt [int]$sys.totalNodes) { 'Degraded' } else { '' }) })
    if ($sys.onlineNodes -and $sys.totalNodes) { $on = @($sys.onlineNodes).Count; Add-Health $SRC $arr 'Nodes' $(if ($on -lt [int]$sys.totalNodes) { 'CRIT' } else { 'OK' }) "$on of $($sys.totalNodes) nodes online" }

    # disks / ports
    try {
      $disks = @((Invoke-Rest "$base/disks" 'GET' $h).members)
      $badD = @($disks | Where-Object { $_.state -ne 1 })
      $failD = @($badD | Where-Object { $_.state -notin 2, 3 })
      Add-Health $SRC $arr 'Physical disks' $(if ($failD.Count) { 'CRIT' } elseif ($badD.Count) { 'WARN' } else { 'OK' }) ("{0} disks, {1} not normal{2}" -f $disks.Count, $badD.Count, $(if ($badD.Count) { ': ' + (($badD | Select-Object -First 8 | ForEach-Object { $dn = $diskState[[int]$_.state]; if (-not $dn) { $dn = "state $($_.state)" }; "disk $($_.id) $dn" }) -join '; ') } else { '' }))
    } catch { Add-Health $SRC $arr 'Physical disks' 'WARN' "Not read: $($_.Exception.Message)" }
    try {
      $ports = @((Invoke-Rest "$base/ports" 'GET' $h).members)
      # linkState 4 = ready, 5 = loss of sync (normal for unused ports), 6 = error, 9 = core dump, 11 = firmware dead
      $badP = @($ports | Where-Object { $_.linkState -in 6, 9, 11 })
      $rdy = @($ports | Where-Object { $_.linkState -eq 4 }).Count
      if ($ports.Count) { Add-Health $SRC $arr 'Ports' $(if ($badP.Count) { 'CRIT' } else { 'OK' }) ("{0} ports, {1} ready, {2} in error{3}" -f $ports.Count, $rdy, $badP.Count, $(if ($badP.Count) { ': ' + (($badP | ForEach-Object { "$($_.portPos.node):$($_.portPos.slot):$($_.portPos.cardPort)" }) -join ', ') } else { '' })) }
    } catch { }
    # CPGs
    try {
      foreach ($c in @((Invoke-Rest "$base/cpgs" 'GET' $h).members)) {
        $tot = [double](Get-Prop $c 'UsrUsage.totalMiB'); $used = [double](Get-Prop $c 'UsrUsage.usedMiB')
        $lim = [double]$c.SDGrowth.limitMiB
        if ($lim -gt 0) { $pc = Pct $used $lim } else { $pc = '' }
        if ($pc -ne '') { Add-Health $SRC $arr ("CPG " + $c.name) (Cap-Status $pc $CapWarn $CapCrit) "$pc % of growth limit used" }
      }
    } catch { }

    if (-not $NoVolumes) {
      $vl = @((Invoke-Rest "$base/volumes" 'GET' $h).members)
      $exp = @{}
      try { foreach ($v in @((Invoke-Rest "$base/vluns" 'GET' $h).members)) { if (-not $exp.ContainsKey($v.volumeName)) { $exp[$v.volumeName] = @{ hosts = @(); lun = $v.lun } }; if ($v.hostname -and $exp[$v.volumeName].hosts -notcontains $v.hostname) { $exp[$v.volumeName].hosts += $v.hostname } } } catch { Add-Health $SRC $arr 'VLUNs' 'WARN' "Exports not read: $($_.Exception.Message)" }
      $rcgOf = @{}
      $rcl = @(); try { $rcl = @((Invoke-Rest "$base/remotecopygroups" 'GET' $h).members) } catch { }
      foreach ($g in $rcl) {
        $tgt = ''; $mode = ''; $stt = ''
        if ($g.targets) { $tgt = (@($g.targets) | ForEach-Object { $_.targetName }) -join ', '; $mode = $modeMap[[int]@($g.targets)[0].mode]; $sn = [int]@($g.targets)[0].state; $stt = $rcState[$sn]; if (-not $stt) { $stt = "state $sn" } }
        [void]$rcs.Add([pscustomobject][ordered]@{ Group = $g.name; 'Source array' = $arr; 'Target array' = $tgt; Mode = $mode; Status = $stt })
        foreach ($gv in @($g.volumes)) { $rcgOf[$gv.localVolumeName] = $g.name }
        Add-Health $SRC $arr ("Remote copy " + $g.name) $(if ($stt -eq 'Started') { 'OK' } elseif ($stt -in 'Stopped', 'Failsafe') { 'CRIT' } else { 'WARN' }) "$stt, target $tgt"
      }
      foreach ($v in $vl) {
        if ($v.copyType -eq 3) { continue }
        $naa = ''; if ($v.wwn) { $naa = 'naa.' + $v.wwn.ToLower() }
        $e = $exp[$v.name]; $lun = ''; $to = ''; if ($e) { $lun = $e.lun; $to = ($e.hosts -join ', ') }
        $rg = $rcgOf[$v.name]
        [void]$vols.Add([pscustomobject][ordered]@{ Volume = $v.name; Array = $arr; 'NAA ID' = $naa; 'LUN ID' = $lun; 'Size GB' = [math]::Round([double]$v.sizeMiB / 1024, 2); 'Pool / CPG' = $v.userCPG; Provisioning = $provMap[[int]$v.provisioningType]; Replicated = $(if ($rg) { 'Yes' } else { 'No' }); 'Remote copy group' = $rg; 'Exported to' = $to })
        if ($v.state -and $v.state -ne 1) { $vs = $volState[[int]$v.state]; if (-not $vs) { $vs = "state $($v.state)" }; Add-Health $SRC $arr ("Volume " + $v.name) $(if ($vs -eq 'failed') { 'CRIT' } else { 'WARN' }) $vs }
      }
    }
    Add-Run $name 'Array' 'ok' 'ok' $t0
  } catch {
    Write-Warning "$name failed: $($_.Exception.Message)"
    Add-Health $SRC $name 'Reachability' 'CRIT' $_.Exception.Message
    Add-Run $name 'Array' 'FAILED' $_.Exception.Message $t0
  } finally {
    if ($key) { try { Invoke-Rest "$base/credentials/$key" 'DELETE' @{ 'X-HP3PAR-WSAPI-SessionKey' = $key } | Out-Null } catch { } }
  }
}
$sheets.Storage = $st.ToArray(); $sheets.ArrayVolumes = $vols.ToArray(); $sheets.RemoteCopyGroups = $rcs.ToArray()
exit (Write-CollectorOutput $SRC $sheets $OutDir $Format)
