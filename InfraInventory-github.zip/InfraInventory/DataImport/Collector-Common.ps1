# Collector-Common.ps1 - shared helpers of the DataImport collectors (dot-sourced, do not run on its own).
# Read-only: the collectors only read from the systems and write files below DataImport\Output\<source>\.
$ErrorActionPreference = 'Stop'
$script:CredDir = Join-Path $(if ($HERE) { $HERE } else { $PSScriptRoot }) 'Credentials'
$script:Health = New-Object System.Collections.ArrayList
$script:RunLog = New-Object System.Collections.ArrayList

function Add-Health([string]$source, [string]$target, [string]$item, [string]$status, [string]$msg) {
  [void]$script:Health.Add([pscustomobject][ordered]@{ Source = $source; Target = $target; Item = $item; Status = $status; Message = $msg })
}
function Add-Run([string]$target, [string]$kind, [string]$status, [string]$msg, [datetime]$t0) {
  [void]$script:RunLog.Add([pscustomobject][ordered]@{ Target = $target; Kind = $kind; Status = $status; Message = $msg; Seconds = [int]((Get-Date) - $t0).TotalSeconds; Collected = (Get-Date -Format 'yyyy-MM-dd HH:mm') })
}

# Targets: -Target a,b and/or -TargetFile (one per line, # comments). A line may be "name,credentialName".
function Read-Targets([string[]]$Target, [string]$TargetFile) {
  $out = New-Object System.Collections.ArrayList
  foreach ($t in @($Target)) { if ($t -and $t.Trim()) { [void]$out.Add([pscustomobject]@{ Name = $t.Trim(); Cred = '' }) } }
  if ($TargetFile) {
    foreach ($l in (Get-Content -LiteralPath $TargetFile)) {
      $l = ($l -replace '#.*$', '').Trim(); if (-not $l) { continue }
      $p = $l.Split(',')
      $c = ''; if ($p.Count -gt 1) { $c = $p[1].Trim() }
      [void]$out.Add([pscustomobject]@{ Name = $p[0].Trim(); Cred = $c })
    }
  }
  return ,@($out | Sort-Object Name -Unique)
}

# Credentials: 1) -Credential given  2) saved file Credentials\<name>.xml (Set-CollectorCredential.ps1, encrypted for this
# Windows user on this machine)  3) prompt, but only when someone is at the console (not -NonInteractive / scheduled task).
function Get-CollectorCredential([string]$Name, [pscredential]$Given, [switch]$NonInteractive, [switch]$Save) {
  if ($Given) { return $Given }
  $f = Join-Path $script:CredDir ("{0}.xml" -f ($Name -replace '[^\w\.-]', '_'))
  if (Test-Path -LiteralPath $f) { try { return (Import-Clixml -LiteralPath $f) } catch { Write-Warning "Saved credential $f cannot be read by this user/machine: $($_.Exception.Message)" } }
  if ($NonInteractive -or -not [Environment]::UserInteractive) { throw "No saved credential '$Name' (run Set-CollectorCredential.ps1 -Name $Name as the account that runs this task)." }
  $c = Get-Credential -Message "Read-only account for $Name"
  if (-not $c) { throw "No credential given for $Name." }
  if ($Save) {
    if (-not (Test-Path -LiteralPath $script:CredDir)) { New-Item -ItemType Directory -Path $script:CredDir | Out-Null }
    $c | Export-Clixml -LiteralPath $f
    Write-Host "Credential saved to $f (only this user on this machine can read it)."
  }
  return $c
}
function Get-PlainPassword([pscredential]$c) { return $c.GetNetworkCredential().Password }

# Self-signed certificates are normal on 3PAR / iLO / OneView, so they are accepted unless -StrictTls is given.
function Set-Tls([switch]$Strict) {
  try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch { }
  if ($Strict) { return }
  if ($PSVersionTable.PSVersion.Major -lt 6) {
    if (-not ('TrustAllCertsPolicy' -as [type])) {
      Add-Type -TypeDefinition 'using System.Net; using System.Security.Cryptography.X509Certificates; public class TrustAllCertsPolicy : ICertificatePolicy { public bool CheckValidationResult(ServicePoint s, X509Certificate c, WebRequest r, int p) { return true; } }'
    }
    [Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
  }
}
# REST call; PowerShell 6+ needs -SkipCertificateCheck, 5.1 uses the policy above.
function Invoke-Rest([string]$Uri, [string]$Method = 'GET', $Headers = @{}, $Body = $null, [int]$Timeout = 60) {
  $p = @{ Uri = $Uri; Method = $Method; Headers = $Headers; TimeoutSec = $Timeout; ContentType = 'application/json' }
  if ($null -ne $Body) { $p.Body = ($Body | ConvertTo-Json -Depth 8 -Compress) }
  if ($PSVersionTable.PSVersion.Major -ge 6 -and -not $script:StrictTls) { $p.SkipCertificateCheck = $true }
  return Invoke-RestMethod @p
}
function Get-Prop($o, [string]$path) {
  $v = $o; foreach ($p in $path.Split('.')) { if ($null -eq $v) { return $null }; $v = $v.$p }; return $v
}
function Pct($used, $total) { if ($total -and [double]$total -gt 0) { return [math]::Round(100 * [double]$used / [double]$total, 1) } else { return '' } }
function Cap-Status([double]$pct, [double]$warn, [double]$crit) { if ($pct -ge $crit) { return 'CRIT' } elseif ($pct -ge $warn) { return 'WARN' } else { return 'OK' } }

# Writes the sheets as WSFC-style files: <Source>-<stamp>.xlsx + <Source>-latest.xlsx (ImportExcel), or a CSV folder + <Source>-latest\
function Write-CollectorOutput([string]$Source, [System.Collections.IDictionary]$Sheets, [string]$OutDir, [string]$Format = 'Auto') {
  if (-not (Test-Path -LiteralPath $OutDir)) { New-Item -ItemType Directory -Path $OutDir -Force | Out-Null }
  $stamp = Get-Date -Format 'yyyyMMdd-HHmm'
  $Sheets['Health'] = $script:Health.ToArray()
  $Sheets['RunLog'] = $script:RunLog.ToArray()
  $useX = ($Format -eq 'Xlsx') -or ($Format -eq 'Auto' -and (Get-Module -ListAvailable -Name ImportExcel))
  if ($useX) {
    Import-Module ImportExcel -ErrorAction Stop
    $f = Join-Path $OutDir "$Source-$stamp.xlsx"
    foreach ($k in $Sheets.Keys) { $rows = @($Sheets[$k]); if ($rows.Count) { $rows | Export-Excel -Path $f -WorksheetName $k -AutoSize -FreezeTopRow -BoldTopRow } }
    Copy-Item -LiteralPath $f -Destination (Join-Path $OutDir "$Source-latest.xlsx") -Force
    Write-Host "Written: $f  (and $Source-latest.xlsx)"
  } else {
    $d = Join-Path $OutDir "$Source-$stamp"
    New-Item -ItemType Directory -Path $d -Force | Out-Null
    foreach ($k in $Sheets.Keys) { $rows = @($Sheets[$k]); if ($rows.Count) { $rows | Export-Csv -LiteralPath (Join-Path $d "$k.csv") -NoTypeInformation -Encoding UTF8 } }
    $lat = Join-Path $OutDir "$Source-latest"
    if (Test-Path -LiteralPath $lat) { Remove-Item -LiteralPath $lat -Recurse -Force }
    Copy-Item -LiteralPath $d -Destination $lat -Recurse
    Write-Host "Written: $d  (and $Source-latest\)"
  }
  # keep the last 30 dated copies per source
  Get-ChildItem -LiteralPath $OutDir | Where-Object { $_.Name -like "$Source-2*" } | Sort-Object LastWriteTime -Descending | Select-Object -Skip 30 | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
  $bad = @($script:RunLog | Where-Object { $_.Status -ne 'ok' }).Count
  $crit = @($script:Health | Where-Object { $_.Status -eq 'CRIT' }).Count
  $warn = @($script:Health | Where-Object { $_.Status -eq 'WARN' }).Count
  Write-Host ("Done: {0} target(s) ok, {1} failed; health: {2} CRIT, {3} WARN." -f ($script:RunLog.Count - $bad), $bad, $crit, $warn)
  if ($bad) { return 1 } else { return 0 }
}
