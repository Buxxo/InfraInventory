#!/usr/bin/env python3
"""Builds InfraInventory/index.html and dashboard-template.html from src/.
   python3 tools/build.py        (needs Python 3; run from anywhere)
The page is one self-contained HTML file: the src parts are concatenated in the order below."""
import os, re, subprocess, sys
R = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
S = os.path.join(R, 'src'); O = os.path.join(R, 'InfraInventory')
subprocess.check_call([sys.executable, os.path.join(S, 'genps.py')])   # embeds DataImport/*.ps1 into p4zv.js
parts = ['p1.html','p2.js','p3.js','p3b.js','p3c.js','p3d.js','p3e.js','p4.js','p4b.js','p4c.js','p4d.js','p4e.js','p4f.js','p4g.js','p4h.js','p4i.js','p4j.js',
 'p4k.js','p4l.js','p4m.js','p4n.js','p4o.js','p4p.js','p4r.js','p4s.js','p4t.js','p4v.js','p4w.js','p4x.js','p4y.js','p4z.js','p4zv.js','p4zz.js','p4zy.js','p4zx.js','p4zw.js',
 'p4todo.js','p4sec.js','p4nic.js','p4rds.js','p5.js']
rd = lambda n: open(os.path.join(S, n), encoding='utf-8').read()
h = ''.join(rd(p) for p in parts if os.path.exists(os.path.join(S, p)))
h = h.replace('/*@@V3@@*/', rd('fonts.css') + rd('v3.css'))
h = h.replace('const DEMO=true;', 'const DEMO=false;')
h = h.replace('<meta name="claude:viewport-fit-sides" content="cover">\n', '')
h = re.sub(r'<link rel="stylesheet" href="https://fonts.googleapis.com[^>]*>\n', '', h)
h = h.replace('https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js', 'vendor/xlsx.full.min.js')
h = h.replace('Master inventory · demo', 'Master inventory')
assert 'cdnjs' not in h and 'googleapis' not in h
wrap = '<!doctype html>\n<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">\n<style>:root{color-scheme:light}body{margin:0;font:14px system-ui,-apple-system,"Segoe UI",sans-serif}img{max-width:100%}[hidden]{display:none!important}</style>\n'
full = wrap + h + '\n</body></html>\n'
for n in ('index.html', 'dashboard-template.html'):
    open(os.path.join(O, n), 'w', encoding='utf-8', newline='').write(full)
print('built', len(full), 'characters')
