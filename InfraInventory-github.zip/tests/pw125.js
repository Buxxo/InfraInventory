const {chromium}=require('playwright');const XLSX=require('../InfraInventory/vendor/xlsx.full.min.js');
(async()=>{
const vi=[['VM','Datacenter','Cluster','Host','Powerstate','Template'],['sql1','D','c1','h1','poweredOn',false],['sql2','D','c1','h2','poweredOn',false],['solo1','D','c1','h1','poweredOn',false]];
const H=['VM','Disk','Disk Path','Capacity MiB','Raw','Raw LUN ID','Raw Comp. Mode','Disk Mode','Sharing mode','Shared Bus','Thin'];
const vd=[H,
['sql1','Hard disk 1','[ds1] sql1/sql1.vmdk',102400,false,'','','persistent','sharingnone','No Sharing',true],
['sql2','Hard disk 1','[ds1] sql2/sql2.vmdk',102400,false,'','','persistent','sharingnone','No Sharing',true],
['sql1','Hard disk 2','',512000,true,'naa.600507680c80aaaa00000000000001','physicalMode','persistent','sharingnone','Physical Sharing',false],
['sql2','Hard disk 2','',512000,true,'naa.600507680c80aaaa00000000000001','physicalMode','persistent','sharingnone','Physical Sharing',false],
['sql1','Hard disk 3','[ds2] shared/q.vmdk',1024,false,'','','independent_persistent','sharingmultiwriter','No Sharing',false],
['sql2','Hard disk 3','[ds2] shared/q.vmdk',1024,false,'','','independent_persistent','sharingmultiwriter','No Sharing',false],
['solo1','Hard disk 1','[ds1] solo1/solo1.vmdk',51200,false,'','','persistent','sharingnone','No Sharing',true]];
const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(vi),'vInfo');XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(vd),'vDisk');
require('fs').writeFileSync('/tmp/rv.xlsx',XLSX.write(wb,{type:'buffer',bookType:'xlsx'}));
const b=await chromium.launch();const p=await b.newPage({viewport:{width:1400,height:1000}});const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'..')+'/InfraInventory/index.html');await p.waitForTimeout(600);
require('fs').writeFileSync('/tmp/srv.csv','Hostname;Cluster/Standalone;Failover cluster\nsql1;Cluster;SQLCL\nsql2;Cluster;SQLCL\nsolo1;Standalone;\n');
await p.evaluate(()=>location.hash='#import');await p.waitForTimeout(500);
await p.setInputFiles('#imp-file','/tmp/srv.csv');await p.waitForTimeout(700);
await p.click('[data-act=impnext]');await p.waitForTimeout(500);await p.check('[data-act=impnew]');await p.waitForTimeout(400);await p.click('[data-act=impapply]');await p.click('[data-act=impapply]');await p.waitForTimeout(700);
console.log('applied',(await p.evaluate(()=>document.body.innerText)).replace(/\s+/g,' ').match(/Data import.{0,300}/)[0]);
await p.evaluate(()=>location.hash='#dash');await p.waitForTimeout(300);await p.evaluate(()=>location.hash='#import');await p.waitForTimeout(500);
if(await p.locator('[data-act=imprestart]').count())await p.click('[data-act=imprestart]');await p.waitForTimeout(300);
console.log(await p.evaluate(()=>[...document.querySelectorAll('[data-act^=imp]')].map(e=>e.dataset.act+':'+(e.dataset.v||'')).join(' ')));await p.click('[data-act=impsrc][data-v=rvtools]');await p.waitForTimeout(300);
await p.setInputFiles('#imp-file','/tmp/rv.xlsx');await p.waitForTimeout(900);
console.log('tabs',await p.locator('[data-act=impjob]').allInnerTexts());
const info=async()=>{const t=await p.evaluate(()=>document.body.innerText);return {panel:(t.match(/Failover cluster disks[\s\S]{0,420}/)||[''])[0].replace(/\s+/g,' '),jobs:await p.locator('[data-act=impjob]').allInnerTexts()}};
console.log(JSON.stringify(await info()));
await p.click('[data-act=clkeep]');await p.waitForTimeout(300);console.log('keep',JSON.stringify(await info()));
await p.click('[data-act=clsplit]');await p.waitForTimeout(300);console.log('off',JSON.stringify(await info()));
await p.click('[data-act=clsplit]');await p.waitForTimeout(300);
const keepTest=process.argv[2]==='keep';if(!keepTest){await p.click('[data-act=clkeep]');await p.waitForTimeout(300)}
await p.click('[data-act=impnext]');await p.waitForTimeout(700);
const t3=await p.evaluate(()=>document.body.innerText.replace(/\s+/g,' '));console.log('STEP3',(t3.match(/(NOT IN|WILL UPDATE).{0,200}/)||[''])[0]);
for(const i of [1,2,3]){await p.locator('[data-act=impjob]').nth(i).click();await p.waitForTimeout(500);const tt=await p.evaluate(()=>document.body.innerText.replace(/\s+/g,' '));console.log('JOB',i,(tt.match(/(NOT IN THE INVENTORY|WILL UPDATE).{0,120}/)||[''])[0],'|',(tt.match(/Action .{0,420}/)||[''])[0])}
console.log('rows',await p.locator('table tbody tr').allInnerTexts().then(a=>a.map(r=>r.replace(/\s+/g,' ').slice(0,150))));
console.log('errs',errs);await b.close()})()
