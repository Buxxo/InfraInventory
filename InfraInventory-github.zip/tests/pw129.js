const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const ctx=await b.newContext({viewport:{width:1400,height:900}});const p=await ctx.newPage();
const fs=require('fs');const tpl=fs.readFileSync(require('path').resolve(__dirname,'..')+'/InfraInventory/dashboard-template.html','utf8');
await p.addInitScript((tpl)=>{
window.__files={};window.__mt={};
const mkFile=(path)=>({kind:'file',name:path.split('/').pop(),async getFile(){const d=window.__files[path];return new File([d||''],path.split('/').pop(),{lastModified:window.__mt[path]||1})},async createWritable(){return{async write(x){if(x&&x.arrayBuffer){window.__files[path]=new Uint8Array(await x.arrayBuffer())}else window.__files[path]=typeof x==='string'?x:new Uint8Array(x.buffer?x.buffer.slice(x.byteOffset,x.byteOffset+x.byteLength):x);window.__mt[path]=Date.now()},async close(){}}},async queryPermission(){return'granted'},async requestPermission(){return'granted'}});
const dirs={};
const mkDir=(path)=>dirs[path]||(dirs[path]={kind:'directory',name:path.split('/').pop()||'InfraInventory',
 async getDirectoryHandle(n,o){return mkDir(path?path+'/'+n:n)},
 async getFileHandle(n,o){const fp=path?path+'/'+n:n;if(!(fp in window.__files)){if(o&&o.create){window.__files[fp]=new Uint8Array(0);window.__mt[fp]=Date.now()}else throw new Error('nf')}return mkFile(fp)},
 async removeEntry(n){delete window.__files[path?path+'/'+n:n]},
 async *entries(){for(const k of Object.keys(window.__files)){if(k.startsWith(path?path+'/':'')&&k.slice((path?path.length+1:0)).indexOf('/')<0)yield[k.split('/').pop(),mkFile(k)]}},
 async queryPermission(){return'granted'},async requestPermission(){return'granted'}});
window.__files['dashboard-template.html']=tpl;window.__files['Inventory/inventory.xlsx']=new Uint8Array(0);window.__mt['Inventory/inventory.xlsx']=1;
window.showDirectoryPicker=async()=>mkDir('');
},tpl);
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'..')+'/InfraInventory/index.html');await p.waitForTimeout(500);
await p.click('#pending button:has-text("Connect project folder")');await p.waitForTimeout(700);
const add=async(h)=>{await p.evaluate(()=>location.hash='servermi');await p.waitForTimeout(250);await p.click('.head > .tools > button.p');await p.waitForTimeout(200);await p.fill('#modal [name=Hostname]',h);await p.fill('#modal [name=IP]','10.20.4.'+(h.length*7));await p.fill('#modal [name=Owner]','team');await p.selectOption('#modal select[name=Env_sel]',{index:1});await p.click('#modal [type=submit]');await p.waitForTimeout(300)};
const save=async()=>{await p.evaluate(()=>{location.hash='servermi'});await p.waitForTimeout(200);await p.evaluate(()=>{const b=[...document.querySelectorAll('button')].find(x=>x.dataset.act==='saveXlsx');if(b)b.click()});await p.waitForTimeout(900)};

await p.addInitScript(()=>{try{if(!localStorage.getItem('infra-user'))localStorage.setItem('infra-user','Marcel')}catch(e){}});
const fsx=require('fs');
await p.goto('file://'+require('path').resolve(__dirname,'..')+'/InfraInventory/index.html');await p.waitForTimeout(500);
await p.click('#pending button:has-text("Connect project folder")');await p.waitForTimeout(700);
await add('a1');await save();
console.log('plain backups',await p.evaluate(()=>Object.keys(window.__files).filter(k=>/Backup/.test(k)).length));
await p.evaluate(()=>location.hash='settings');await p.waitForTimeout(400);
await p.click('[data-act=secon]');await p.waitForTimeout(200);
await p.fill('#sd-p1','short');await p.fill('#sd-p2','short');await p.click('[data-act=secdlgok]');await p.waitForTimeout(200);
console.log('short err',await p.locator('#sd-e').innerText());
await p.fill('#sd-p1','Admin-pass-1');await p.fill('#sd-p2','Admin-pass-1');await p.click('[data-act=secdlgok]');await p.waitForTimeout(3000);
console.log('toast',await p.locator('#toast').innerText());
const info=await p.evaluate(()=>{const f=window.__files['Inventory/inventory.xlsx'];const h=new TextDecoder().decode(f.slice(0,8));const idx=window.__files['index.html'];return{magic:h,size:f.length,idxHas:typeof idx==='string'?idx.includes('SVZFTkMwMDE'):'none',idxHasA1:typeof idx==='string'?idx.includes('a1'):0,bk:Object.keys(window.__files).filter(k=>/Backup/.test(k))}});
console.log(info);
await p.evaluate(()=>location.hash='settings');await p.waitForTimeout(300);
await p.click('[data-act=secadd]');await p.waitForTimeout(200);await p.fill('#sd-u','bob');await p.fill('#sd-p1','Bob-pass-12');await p.click('[data-act=secdlgok]');await p.waitForTimeout(3000);
console.log('users',await p.evaluate(()=>JSON.parse(new TextDecoder().decode(window.__files['Inventory/inventory.xlsx'].slice(12,12+new DataView(window.__files['Inventory/inventory.xlsx'].buffer).getUint32(8,true)))).users.map(u=>u.u)));
await p.click('[data-act=secbk]');await p.waitForTimeout(500);
console.log('bk after clean',await p.evaluate(()=>Object.keys(window.__files).filter(k=>/Backup/.test(k)).length),await p.locator('#toast').innerText());
// open the rebuilt index.html fresh
fsx.mkdirSync('/tmp/enc',{recursive:true});
const html=await p.evaluate(()=>window.__files['index.html']);fsx.writeFileSync('/tmp/enc/index.html',html);
try{fsx.symlinkSync(require('path').resolve(__dirname,'..')+'/InfraInventory/vendor','/tmp/enc/vendor')}catch(e){}
const p2=await (await b.newContext()).newPage();const e2=[];p2.on('pageerror',e=>e2.push(e.message));
await p2.goto('file:///tmp/enc/index.html');await p2.waitForTimeout(600);
console.log('login shown',await p2.locator('#secov').count(),'body text leak?',/a1/.test(await p2.evaluate(()=>document.getElementById('secov').nextSibling?'':'')));
await p2.fill('#sec-u','bob');await p2.fill('#sec-p','wrong');await p2.click('#sec-go');await p2.waitForTimeout(1500);
console.log('wrong:',await p2.locator('#sec-e').innerText());
await p2.fill('#sec-u','bob');await p2.fill('#sec-p','Bob-pass-12');await p2.click('#sec-go');await p2.waitForTimeout(2500);
console.log('overlay gone',await p2.locator('#secov').count()===0);
await p2.evaluate(()=>location.hash='servermi');await p2.waitForTimeout(400);
console.log('has a1',/a1/.test(await p2.evaluate(()=>document.body.innerText)));
await p2.evaluate(()=>location.hash='settings');await p2.waitForTimeout(400);
const st=await p2.evaluate(()=>document.body.innerText);console.log('bob sees admin buttons',/Add login/.test(st),/Change my password/.test(st),/Logged in as bob/.test(st));
console.log('ls plaintext?',await p2.evaluate(()=>Object.keys(localStorage).map(k=>k+':'+localStorage.getItem(k).length)));
await p2.screenshot({path:'/tmp/enc/s.png'});
console.log('errs',errs,e2);await b.close()})()
