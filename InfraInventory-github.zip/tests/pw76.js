const {chromium}=require('playwright');
(async()=>{
const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1400,height:900}})).newPage();
const fs=require('fs');const tpl=fs.readFileSync(require('path').resolve(__dirname,'..')+'/InfraInventory/dashboard-template.html','utf8');
await p.addInitScript((tpl)=>{
window.__files={};window.__mt={};
const mkFile=(path)=>({kind:'file',name:path.split('/').pop(),async getFile(){const d=window.__files[path];return new File([d||''],path.split('/').pop(),{lastModified:window.__mt[path]||1})},async createWritable(){return{async write(x){if(x&&x.arrayBuffer){window.__files[path]=new Uint8Array(await x.arrayBuffer())}else window.__files[path]=typeof x==='string'?x:new Uint8Array(x.buffer?x.buffer.slice(x.byteOffset,x.byteOffset+x.byteLength):x);window.__mt[path]=Date.now()},async close(){}}},async queryPermission(){return'granted'},async requestPermission(){return'granted'}});
const dirs={};
const mkDir=(path)=>dirs[path]||(dirs[path]={kind:'directory',name:path.split('/').pop()||'InfraInventory',
 async getDirectoryHandle(n,o){return mkDir(path?path+'/'+n:n)},
 async getFileHandle(n,o){const fp=path?path+'/'+n:n;if(!(fp in window.__files)){if(o&&o.create){window.__files[fp]=new Uint8Array(0);window.__mt[fp]=Date.now()}else throw new Error('nf')}return mkFile(fp)},
 async removeEntry(n){delete window.__files[path?path+'/'+n:n]},
 async *entries(){for(const k of Object.keys(window.__files)){if(k.startsWith(path?path+'/':'')&&k.slice((path?path.length+1:0)).indexOf('/')<0)yield[k.split('/').pop(),mkFile(k)]}},
 async queryPermission(){return'granted'},async requestPermission(){return'granted'}});
window.__files['dashboard-template.html']=tpl;window.__files['Inventory/inventory.xlsx']=new Uint8Array(0);window.__mt['Inventory/inventory.xlsx']=1;
window.showDirectoryPicker=async()=>mkDir('');
},tpl);
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'..')+'/InfraInventory/index.html');await p.waitForTimeout(500);
await p.click('#pending button:has-text("Connect project folder")');await p.waitForTimeout(700);
const add=async(h)=>{await p.evaluate(()=>location.hash='servermi');await p.waitForTimeout(250);await p.click('.head > .tools > button.p');await p.waitForTimeout(200);await p.fill('#modal [name=Hostname]',h);await p.fill('#modal [name=IP]','10.20.4.'+(h.length*7));await p.fill('#modal [name=Owner]','team');await p.selectOption('#modal select[name=Env_sel]',{index:1});await p.click('#modal [type=submit]');await p.waitForTimeout(300)};
const save=async()=>{await p.evaluate(()=>{location.hash='servermi'});await p.waitForTimeout(200);await p.evaluate(()=>{const b=[...document.querySelectorAll('button')].find(x=>x.dataset.act==='saveXlsx');if(b)b.click()});await p.waitForTimeout(900)};
p.on('dialog',d=>d.accept('tester'));
await add('a1');await save();
if(await p.locator('#modal input').count()){await p.fill('#modal input','Marcel');await p.click('#modal .btn.p');await p.waitForTimeout(900)}
console.log('toast1',await p.locator('#toast').textContent());
await add('a2');await save();console.log('toast2',await p.locator('#toast').textContent());
console.log('backups',await p.evaluate(()=>Object.keys(window.__files).filter(k=>/Backup/.test(k))));
// other user modifies the file on disk
await p.evaluate(()=>{const wb=XLSX.read(window.__files['Inventory/inventory.xlsx'],{type:'array'});const ws=wb.Sheets['ServersMI'];const rows=XLSX.utils.sheet_to_json(ws,{defval:''});const r=rows.find(x=>x.Hostname==='a1');r.Owner='them';r.Role='set-by-them';rows.push(Object.assign({},r,{Hostname:'b2',IP:'10.20.4.77',Owner:'them'}));wb.Sheets['ServersMI']=XLSX.utils.json_to_sheet(rows);window.__files['Inventory/inventory.xlsx']=new Uint8Array(XLSX.write(wb,{bookType:'xlsx',type:'array'}));window.__mt['Inventory/inventory.xlsx']=Date.now()+60000});
// my edits: a1 Owner (conflict) and a1 Notes (mine only)
await p.evaluate(()=>location.hash='servermi');await p.waitForTimeout(250);await p.fill('#q-ServerMI','a1');await p.waitForTimeout(300);
await p.evaluate(()=>{const t=document.querySelector('#tbl tbody tr');const e=t.matches('[data-act=rowopen]')?t:t.querySelector('[data-act=rowopen]')||t;e.click()});await p.waitForTimeout(300);{const eb=p.locator('#modal button[data-act=editrow],#modal button:has-text("Edit")').first();if(await eb.count()&&!(await p.locator('#modal [name=Owner]').count()))await eb.click();await p.waitForTimeout(300)}await p.fill('#modal [name=Owner]','mine-owner');await p.fill('#modal [name=Notes]','mine note');await p.click('#modal [type=submit]');await p.waitForTimeout(300);
await save();
console.log('dialog:',(await p.locator('#modal .dlg').innerText()).replace(/\n+/g,' | ').slice(0,500));
await p.screenshot({path:'/tmp/mg.png'});console.log('OVERVIEW',JSON.stringify(await p.evaluate(()=>[...document.querySelectorAll('.dlg tbody tr')].map(r=>r.innerText.replace(/\s+/g,' ').slice(0,110)).slice(0,12)))); await p.click('[data-act=mgflt][data-v=m]');await p.waitForTimeout(200);console.log('YOURS',await p.evaluate(()=>document.querySelectorAll('.dlg .tw')[0].querySelectorAll('tbody tr').length));await p.click('[data-act=mgall][data-v=t]');await p.click('[data-act=mggo]');await p.waitForTimeout(1200);
console.log('toast3',await p.locator('#toast').textContent());
console.log('result',await p.evaluate(()=>{const wb=XLSX.read(window.__files['Inventory/inventory.xlsx'],{type:'array'});return XLSX.utils.sheet_to_json(wb.Sheets['ServersMI'],{defval:''}).filter(r=>/^(a1|a2|b2)$/.test(r.Hostname)).map(r=>r.Hostname+':'+r.Owner+':'+r.Role+':'+r.Notes).join(' | ')}));
console.log('backups',await p.evaluate(()=>Object.keys(window.__files).filter(k=>/Backup/.test(k)).length));
await p.evaluate(()=>location.hash='sources');await p.waitForTimeout(800);console.log('bk section',(await p.locator('section:has(h2:text("Backups"))').innerText()).split('\n').slice(0,3).join(' | '));
console.log(errs);await b.close()})();
