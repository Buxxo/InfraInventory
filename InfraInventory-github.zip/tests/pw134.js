const {chromium}=require('playwright');const fs=require('fs');const XLSX=require('../InfraInventory/vendor/xlsx.full.min.js');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1400,height:1000}});const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{if(!localStorage.getItem('infra-user'))localStorage.setItem('infra-user','Marcel')}catch(e){}});
await p.goto('file://'+require('path').resolve(__dirname,'..')+'/InfraInventory/index.html');await p.waitForTimeout(600);
async function go(){await p.evaluate(()=>location.hash='#dash');await p.waitForTimeout(200);await p.evaluate(()=>location.hash='#import');await p.waitForTimeout(400);if(await p.locator('[data-act=imprestart]').count())await p.click('[data-act=imprestart]')}
async function apply(){await p.click('[data-act=impnext]');await p.waitForTimeout(600);if(await p.locator('[data-act=impapply][disabled]').count()){const nw=p.locator('[data-act=impnew]');if(await nw.count()){await nw.click();await p.waitForTimeout(300)}}await p.click('[data-act=impapply]');await p.click('[data-act=impapply]');await p.waitForTimeout(800)}
fs.writeFileSync('/tmp/s.csv','Hostname;FQDN;IP Primary;Env;Role;Owner;Status;Disk GB\nsql1;sql1.d.com;10.1.1.11;PROD;SQL;Ops;On;100\n');
await go();await p.setInputFiles('#imp-file','/tmp/s.csv');await p.waitForTimeout(700);await apply();
const wb=XLSX.utils.book_new();
XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([['Server','Disk','Drive / mount','Size GB','Type'],['sql1','OS','C:',80,'VMDK'],['sql1','ERP data','E:',500,'RDM - physical'],['sql1','DTC','G:',5,'RDM - virtual']]),'ServerDisks');
XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet([['Server','Interface','Purpose','IP','DNS name','Gateway','Detected by'],['sql1','Ethernet','Other','10.1.1.11','sql1.d.com','10.1.1.1','Collector: no hint'],['sql1','Ethernet 2','Other','10.9.9.11','sql1p.d.com','','Collector: no hint']]),'ServerNics');
fs.writeFileSync('/tmp/w.xlsx',XLSX.write(wb,{type:'buffer',bookType:'xlsx'}));
await go();await p.click('[data-act=impsrc][data-v=wsfc]');await p.waitForTimeout(300);await p.setInputFiles('#imp-file','/tmp/w.xlsx');await p.waitForTimeout(900);await apply();
await p.evaluate(()=>location.hash='#servermi');await p.waitForTimeout(500);
console.log(await p.evaluate(()=>{for(const k of Object.keys(localStorage)){try{const o=JSON.parse(localStorage.getItem(k));const d=o&&(o.DB||o);if(d&&d.ServerMI)return d.ServerMI.map(r=>r.Hostname+' Disk GB='+r['Disk GB'])}catch(e){}}}));
console.log(await p.evaluate(()=>[...new Set([...document.querySelectorAll('table tbody tr [data-act]')].map(e=>e.dataset.act))]));await p.evaluate(()=>document.querySelector('table tbody tr [data-act=rowopen]').click());await p.waitForTimeout(500);
const t=await p.evaluate(()=>document.getElementById('modal').innerText.replace(/\s+/g,' '));console.log(t.slice(0,150));console.log((t.match(/Disks .{0,120}/)||[])[0]);console.log((t.match(/Network interfaces.{0,260}/)||[])[0]);
await p.screenshot({path:'/tmp/frm.png'});console.log('errs',er);await b.close()})()
