const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await (await b.newContext({viewport:{width:1400,height:900}})).newPage();const er=[];p.on('pageerror',e=>er.push(e.message));
await p.goto('file://'+require('path').resolve(__dirname,'..')+'/InfraInventory/index.html');await p.waitForTimeout(500);
await p.evaluate(()=>location.hash='settings');await p.waitForTimeout(400);
console.log('ops',await p.evaluate(()=>[...document.querySelectorAll('section.card')].find(s=>/Operators for DC/.test(s.innerText)).innerText.slice(0,500)));
await p.click('[data-act=opadd]');await p.waitForTimeout(300);await p.fill('#modal [name=Name]','Anna');await p.fill('#modal [name=Username]','anna');await p.click('#modal [type=submit]');await p.waitForTimeout(300);
await p.evaluate(()=>location.hash='activitylog');await p.waitForTimeout(300);await p.click('[data-act=logwho]');await p.waitForTimeout(300);
await p.fill('#u-name','Zed');await p.click('[data-act=userok]');await p.waitForTimeout(300);console.log('reject',await p.locator('#toast').innerText(),await p.locator('#u-name').count());
await p.fill('#u-name','anna');await p.click('[data-act=userok]');await p.waitForTimeout(300);
await p.evaluate(()=>location.hash='servermi');await p.waitForTimeout(300);
await p.evaluate(()=>{const b=[...document.querySelectorAll('button')].find(x=>x.dataset.act==='saveXlsx');if(b)b.click()});await p.waitForTimeout(800);
await p.evaluate(()=>location.hash='settings');await p.waitForTimeout(400);
console.log('btn',await p.locator('[data-act=oplog]').allInnerTexts());
if(await p.locator('[data-act=oplog]').count()){await p.locator('[data-act=oplog]').first().click();await p.waitForTimeout(400);console.log(location=await p.evaluate(()=>location.hash),await p.evaluate(()=>document.querySelector('.srch input')&&document.querySelector('.srch input').value))}
console.log(er);await b.close()})()
