const {chromium}=require('playwright');const fs=require('fs');
(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1400,height:1000}});const er=[];p.on('pageerror',e=>er.push(e.message));
await p.addInitScript(()=>{try{if(!localStorage.getItem('infra-user'))localStorage.setItem('infra-user','Marcel')}catch(e){}});
await p.goto('file://'+require('path').resolve(__dirname,'..')+'/InfraInventory/index.html');await p.waitForTimeout(600);
async function imp(file,csv){fs.writeFileSync(file,csv);await p.evaluate(()=>location.hash='#dash');await p.waitForTimeout(200);await p.evaluate(()=>location.hash='#import');await p.waitForTimeout(400);
 if(await p.locator('[data-act=imprestart]').count())await p.click('[data-act=imprestart]');
 await p.setInputFiles('#imp-file',file);await p.waitForTimeout(700);await p.click('[data-act=impnext]');await p.waitForTimeout(500);
 const nw=p.locator('[data-act=impnew]');if(await p.locator('[data-act=impapply][disabled]').count()&&await nw.count()){await nw.click();await p.waitForTimeout(300)}await p.click('[data-act=impapply]');await p.click('[data-act=impapply]');await p.waitForTimeout(800)}
await imp('/tmp/servers.csv','Hostname;FQDN;IP Primary;Env;Role;Owner;Status;Failover cluster\nsql1;sql1.d.com;10.1.1.11;PROD;SQL;Ops;On;SQLCL\nsql2;sql2.d.com;10.1.1.12;PROD;SQL;Ops;On;SQLCL\nweb1;web1.d.com;10.2.2.5;TEST;Web;Ops;On\nold1;old1.d.com;10.2.2.9;DEV;Web;Ops;Decom\n');
// subnet with NIC purpose
await p.evaluate(()=>location.hash='#ipam');await p.waitForTimeout(400);await p.click('[data-act=ipadd]');await p.waitForTimeout(300);
await p.fill('#modal [name=Subnet]','10.5.5.0/24');await p.fill('#modal [name=VLAN]','55');await p.selectOption('#modal [name="NIC purpose"]','Storage');await p.click('#modal [type=submit]');await p.waitForTimeout(300);
const XLSX=require('../InfraInventory/vendor/xlsx.full.min.js');
const nr=[['Server','Interface','Purpose','IP','DNS name','Gateway','Detected by'],
['sql1','Ethernet','Other','10.1.1.11','sql1.d.com','10.1.1.1','Collector: no hint'],
['sql1','Ethernet 2','Other','10.9.9.11','','','Collector: no hint'],
['sql1','Ethernet 3','Production','10.7.7.11','sql1p.d.com','','Collector: no hint'],
['sql1','Ethernet 4','Other','10.5.5.11','','','Collector: no hint'],['sql1','Ethernet 5','Other','10.8.8.11','sql1b2.d.com','','Collector: no hint'],['web1','Ethernet','Production','10.2.2.5','web1.d.com','10.2.2.1','Collector: no hint'],['web1','Ethernet 2','Other','10.9.9.5','','','Collector: no hint'],['web1','Ethernet 3','Other','10.5.5.5','web1p.d.com','','Collector: no hint'],
['sql2','Ethernet','Production','10.1.1.12','sql2.d.com','10.1.1.1','Collector: no hint'],['sql2','Ethernet 3','Production','10.7.7.12','sql2p.d.com','','Collector: no hint'],
['sql2','HB','Heartbeat','10.9.9.12','','','Collector: cluster network Cluster Network 2 (cluster only)']];
const wb=XLSX.utils.book_new();XLSX.utils.book_append_sheet(wb,XLSX.utils.aoa_to_sheet(nr),'ServerNics');fs.writeFileSync('/tmp/wsfc.xlsx',XLSX.write(wb,{type:'buffer',bookType:'xlsx'}));
await p.evaluate(()=>location.hash='#dash');await p.waitForTimeout(200);await p.evaluate(()=>location.hash='#import');await p.waitForTimeout(400);
if(await p.locator('[data-act=imprestart]').count())await p.click('[data-act=imprestart]');
await p.click('[data-act=impsrc][data-v=wsfc]');await p.waitForTimeout(300);await p.setInputFiles('#imp-file','/tmp/wsfc.xlsx');await p.waitForTimeout(900);
await p.click('[data-act=impnext]');await p.waitForTimeout(600);
if(await p.locator('[data-act=impapply][disabled]').count()){const nw=p.locator('[data-act=impnew]');if(await nw.count()){await nw.click();await p.waitForTimeout(300)}}
await p.click('[data-act=impapply]');await p.click('[data-act=impapply]');await p.waitForTimeout(800);
await p.waitForTimeout(1500);
console.log(await p.evaluate(()=>{for(const k of Object.keys(localStorage)){try{const o=JSON.parse(localStorage.getItem(k));const d=o&&(o.DB||o.db||o);if(d&&d.ServerNics)return d.ServerNics.map(r=>r.Server+' '+r.Interface+' -> '+r.Purpose+' ['+r['Detected by']+']')}catch(e){}}return 'none'}));
// manual edit protection
await p.evaluate(()=>location.hash='#settings');await p.waitForTimeout(400);

// RDS tab
await p.evaluate(()=>location.hash='#stuff');await p.waitForTimeout(400);await p.click('[data-act=sttab][data-t=rds]');await p.waitForTimeout(300);
console.log('count',await p.locator('#rds-count').innerText());
await p.click('[data-act=rdsaccadd]');await p.waitForTimeout(200);await p.click('[data-act=rdsaccadd]');await p.waitForTimeout(200);
const ins=p.locator('[data-rds^="acc."]');await ins.nth(0).fill('Domain admin');await ins.nth(1).fill('CORP');await ins.nth(2).fill('adm_marcel');
await ins.nth(3).fill('Test acct');await ins.nth(4).fill('CORP');await ins.nth(5).fill('svc_test');
await ins.nth(5).dispatchEvent('change');await p.waitForTimeout(200);
const sels=p.locator('#rds-groups select');console.log('group selects',await sels.count());
const ids=await p.evaluate(()=>[...document.querySelectorAll('#rds-groups select')].map(s=>s.dataset.e||s.dataset.k));console.log(ids);
await sels.nth(0).selectOption({index:1});await p.waitForTimeout(100);
await p.fill('#rds-q','sql');await p.waitForTimeout(200);console.log('list rows',await p.locator('#rds-list tbody tr').count());
await p.fill('#rds-q','');
await p.click('[data-act=rdsprev]');await p.waitForTimeout(300);
const xml=await p.locator('pre.mono').innerText();console.log(xml);
fs.writeFileSync('/tmp/t.rdg',xml);
await p.screenshot({path:'/tmp/rds.png',fullPage:true});
console.log('errs',er);await b.close()})()
