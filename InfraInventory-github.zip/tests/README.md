Playwright tests against `../InfraInventory/index.html`.
Install: `npm i -g playwright && npx playwright install chromium`, then `NODE_PATH=$(npm root -g) node tests/pw133.js`.
pw76 merge + backups, pw125 RVTools cluster import, pw129 login and encryption, pw132 activity log / operators, pw133 NIC purposes + RDS Generator, pw134 disks total + NIC card.
